-- LOAD PROTOTYPES

-- own functions
require("prototypes.sodiumhydroxidesolution-functions")

if angelsmods.petrochem then -- only useful when this <-- is found
	require("prototypes.items.petrochemNaOH-item")

	require("prototypes.recipes.petrochemNaOH-recipe")
	
end