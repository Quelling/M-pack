data:extend(
{

	--CHLORINE

	{
		type = "fluid",
		name = "liquid-sodium-hydroxide-solution",
		icon = "__angelspetrochemNaOH__/graphics/icons/liquid-sodium-hydroxide-solution.png",
		icon_size = 32,
		subgroup = "fluids-petro",
		default_temperature = 25,
		heat_capacity = "0.1KJ",
		base_color = {r = 0.9, g = 0.9, b = 0.9},
		flow_color = {r = 0.9, g = 0.9, b = 0.9},
		max_temperature = 100,
		pressure_to_speed_ratio = 0.4,
		flow_to_energy_ratio = 0.59,
	},

	-- SOLIDS

	-- SODIUM

	-- {
		-- type = "item",
		-- name = "solid-sodium-hydroxide",
		-- icon = "__angelspetrochem__/graphics/icons/solid-sodium-hydroxide.png",
		-- icon_size = 32,
		-- flags = {"goes-to-main-inventory"},
		-- subgroup = "petrochem-raw",
		-- order = "a[solid-sodium-hydroxide]",
		-- stack_size = 200
	-- },
	-- {
		-- type = "item",
		-- name = "solid-sodium-hydroxide-1",
		-- icon = "__angelspetrochem__/graphics/icons/solid-sodium-hydroxide.png",
		-- icon_size = 32,
		-- flags = {"goes-to-main-inventory"},
		-- subgroup = "petrochem-raw",
		-- order = "a[solid-sodium-hydroxide-1]",
		-- stack_size = 200
	-- },

}
)