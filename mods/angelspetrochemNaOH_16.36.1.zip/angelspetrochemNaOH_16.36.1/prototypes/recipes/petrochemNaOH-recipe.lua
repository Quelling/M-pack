data:extend(
{
	--CHLORINE override
	
	-- {
		-- type = "recipe",
		-- name = "water-saline-separation-new",
		-- category = "petrochem-electrolyser",
		-- subgroup = "petrochem-chlorine",
		-- energy_required = 2,
		-- enabled = "false",
		-- ingredients ={
			-- {type="fluid", name="water-saline", amount=100}
		-- },
		-- results=
		-- {
			-- {type="fluid", name="gas-chlorine", amount=20}, -- 40
			-- {type="fluid", name="gas-hydrogen", amount=30}, -- 60
			-- {type="fluid", name="liquid-sodium-hydroxide-solution", amount=50},
			-- --{type="fluid", name="gas-hydrogen", amount=30}, -- 60
			-- -- {type="item", name="solid-sodium-hydroxide", amount=1},
		-- },
		-- icon = "__angelspetrochem__/graphics/icons/raw-separation-5.png",
		-- icon_size = 32,
		-- order = "a[water-saline-separation]",
	-- },
	
	-- SODIUM new from SOLUTION

	{
		type = "recipe",
		name = "solid-sodium-hydroxide-1",
		category = "chemistry",
		subgroup = "petrochem-sodium",
		energy_required = 2,
		enabled = "false",
		ingredients =
		{
			{type="fluid", name="liquid-sodium-hydroxide-solution", amount=60},
		},
		results=
		{
			{type="item", name="solid-sodium-hydroxide", amount=5},
			{type="fluid", name="water-purified", amount=50},
		},
		--main_product= "solid-sodium-hydroxide",
		icon = "__angelspetrochem__/graphics/icons/solid-sodium-hydroxide.png",
		icon_size = 32,
		order = "c[solid-sodium-hydroxide-1]",
	},
	
	-- ORIGINAL
	
	-- {
		-- type = "recipe",
		-- name = "solid-sodium-hydroxide",
		-- category = "liquifying",
		-- subgroup = "petrochem-sodium",
		-- energy_required = 2,
		-- enabled = "false",
		-- ingredients ={
			-- {type="item", name="solid-sodium", amount=5},
			-- {type="fluid", name="water-purified", amount=50},
		-- },
		-- results=
		-- {
			-- {type="item", name="solid-sodium-hydroxide", amount=5},
		-- },
		-- icon = "__angelspetrochem__/graphics/icons/solid-sodium-hydroxide.png",
		-- icon_size = 32,
		-- order = "c[solid-sodium-hydroxide]",
	-- },
}
)
