NaOH = {}
NaOH.table = {}

--ov_functions.add_unlock = function (technology, recipe)
function NaOH.table.copy(tbl, recursive) -- copy tables by assigning values
    -- recursive = incl. subtables
	local ret = {}
    for key, value in pairs(tbl) do
        if (type(value) == "table") and recursive then ret[key] = NaOH.table.copy(value)
        else ret[key] = value end
    end
    return ret
end

function NaOH.table.insertTable(table_destination, table_to_add)

   for k,v in ipairs(table_to_add) do
	  table.insert(table_destination, v)
   end 

   return table_destination
end

function NaOH.table.insertTable_wIndex(table_destination,t_index, table_to_add)
   for k,v in ipairs(table_to_add) do
	  table.insert(table_destination,t_index, v)
   end 

   return table_destination
end

local tablepath = {}
local tabledepth = 0

-- debug function to log internal tables
function NaOH.table.log(name, tbl, recursive)
	tabledepth = tabledepth + 1
	tablepath[tabledepth] = name
	local tblname = ""
	local i
	for i = 1, tabledepth do
		if i == 1 then
			tblname = tablepath[i]
		else
			tblname = tblname .. "." .. tablepath[i]
		end
	end
	
	log("starting to print table: "..tblname)
	
	for k, v in pairs(tbl) do
		log(tostring(k).." , "..tostring(v))
		
		if (type(v) == "table") and recursive then 
			log_table(tostring(k),v,recursive)
		end
	end
	tabledepth = tabledepth - 1
end