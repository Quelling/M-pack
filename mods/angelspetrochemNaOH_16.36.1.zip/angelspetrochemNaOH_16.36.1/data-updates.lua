-- data-updates.lua NaOH
local fTbl = NaOH.table
local OVERRIDE = angelsmods.functions.OV
local RCRSV = true -- recursive

if angelsmods.refining then
	--CREATE BARREL
	
	-- added sodium hydroxide solution by Baruk
	angelsmods.functions.make_void("liquid-sodium-hydroxide-solution", "water") -- clarifyable

end

if angelsmods.petrochem then -- Angels Petro available
	-- create fluidbox-container
	local NaOH_fluid_boxes = fTbl.copy(data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes,RCRSV)
	
	--table copy by values
	NaOH_fluid_boxes[5] = fTbl.copy(NaOH_fluid_boxes[3], RCRSV)

	-- 4th output as middle for working with original recipes
	NaOH_fluid_boxes[4].pipe_connections[1] = {position = {0, 3}}
	
	-- 5th fluidbox output location
	NaOH_fluid_boxes[5].pipe_connections[1] = {position = {2, 3}}

	-- CHECK ELECTROLYSERS
	
	--looking for angels electrolysers
	for _,assembler in pairs (data.raw["assembling-machine"]) do
		--look through all assembling-machines to find angels electrolysers
		if assembler.fast_replaceable_group == "angels-electrolyser" then
			
			-- kill old data and feeling safer
			assembler.fluid_boxes = {}
	
			-- copy new values incl. 5th fluidbox
			assembler.fluid_boxes = fTbl.copy(NaOH_fluid_boxes, RCRSV)
			
			--_____________________________________________________________________________________
			-- {
			-- --ASSIGN 3rd OUTPUT
			-- -- hardcode outputs (working)
			-- if pipecoverspictures2 then -- ShinyAngelsGFX (definition found in that mod)
				-- log("[NaOH] ShinyAngelsGFX found  "..assembler.name)
				-- -- 4th output as middle for working with original recipes
				-- assembler.fluid_boxes[4].pipe_connections = {{ position = {0, 3} }}
				-- -- add 5th fluidbox
				-- assembler.fluid_boxes[5] = 
				-- {
					-- production_type = "output",
					-- pipe_picture = electrolyserpictures(),
					-- pipe_covers = pipecoverspictures2(),
					-- base_level = 1,
					-- pipe_connections = {{ position = {2, 3} }}
				-- }
			-- else -- original Angels PetroChem	
				-- log("[NaOH] Angels Petro Chemistry found  "..assembler.name)
				-- -- 4th output as middle for working with original recipes
				-- assembler.fluid_boxes[4].pipe_connections = {{ position = {0, 3} }}
				-- -- add 5th fluidbox
				-- assembler.fluid_boxes[5] = 
				-- {
					-- production_type = "output",
					-- pipe_picture = electrolyserpictures(),
					-- pipe_covers = pipecoverspictures(),
					-- base_level = 1,
					-- pipe_connections = {{ position = {2, 3} }}
				-- }
			-- end}
			--_____________________________________________________________________________________
		end
	end

	-- RECIPE override
	OVERRIDE.patch_recipes({
		{ name = "water-saline-separation", 
			results = 
			{	
				{"!!"},
				{type="fluid", name="gas-chlorine", amount=25}, -- 40
				{type="fluid", name="liquid-sodium-hydroxide-solution", amount=50},
				{type="fluid", name="gas-hydrogen", amount=25}, -- 60
			}
		}
	})

	-- TECHNOLOGY override (addition to existing ones)
	
	-- !! Important add a subtable not just values in pairs
	
	--double {} !!!!
	local add_technology =
	{{
		type = "unlock-recipe",
		recipe = "solid-sodium-hydroxide-1",
	}}
	
	-- worked!!!!! - but not in desired order (was added at the end instead in order)
	-- data.raw.technology["sodium-processing"].effects[7] = 
	-- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-hydroxide-1",
	-- }
	
	local tableindex
	
	for k,v in ipairs(data.raw.technology["sodium-processing"].effects) do
		--log("k="..tostring(k).." , v="..tostring(v))
		--log("v.tablecontens = "..v.recipe)
		if v.recipe == "solid-sodium-hydroxide" then
			-- save index
			tableindex = k
			break -- exit loop
		end
	end
	
	-- adding recipe "solid-sodium-hydroxide-1" inserted behind original recipe	
	fTbl.insertTable_wIndex(data.raw.technology["sodium-processing"].effects,tableindex + 1, add_technology)
	
-- original technology	
	-- {
	-- type = "technology",
	-- name = "sodium-processing",
	-- icon = "__angelspetrochem__/graphics/technology/sodium-tech.png",
	-- icon_size = 128,
	-- prerequisites =
	-- {
	-- "chlorine-processing-3",
	-- "angels-coal-processing",
	-- },
	-- effects =
	-- {
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium"
	  -- },
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-hydroxide"
	  -- },
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-carbonate"
	  -- },
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-cyanide"
	  -- },
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-hydroxide-solid-sodium-sulfate"
	  -- },
	  -- {
		-- type = "unlock-recipe",
		-- recipe = "solid-sodium-sulfate-separation"
	  -- },
	-- },
	-- unit =
	-- {
	  -- count = 50,
	  -- ingredients = {
	  -- {"science-pack-1", 1},
	  -- {"science-pack-2", 1},
	  -- {"science-pack-3", 1},
	  -- },
	  -- time = 15
	-- },
	-- order = "c-a"
	-- },
		
end

OVERRIDE.execute()
--angelsmods.functions.OV.execute()

--deepcopy doesn't work, seems to link tables instead creating individual tables
--works now and implemented above

-- if data.raw["assembling-machine"]["angels-electrolyser-2"] and data.raw["assembling-machine"]["angels-electrolyser-2"].fluid_boxes then
	-- --local new_fluid_boxes = {table.deepcopy(data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes[3])}
	-- --log(tostring(new_fluid_box)) 
	-- --new_fluid_box[1].pipe_connections = {position = {0, 3}}
	-- --log(new_fluid_box[1].pipe_connections.position[1]..","..new_fluid_box[1].pipe_connections.position[2])
	-- --table.insert(data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes, new_fluid_box)

	-- local new_fluid_boxes = fTbl.copy(data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes,true)
	-- log(#new_fluid_boxes.." before insert")
	-- -- copy fluidbox[3] to end of table
	
	-- -- this one seems to link 3 to 5
	-- --table.insert(new_fluid_boxes, new_fluid_boxes[3])
	
	-- --table copy by values
	-- new_fluid_boxes[5] = fTbl.copy(new_fluid_boxes[3], true)
	
	-- log(#new_fluid_boxes.." after insert")
	-- -- 4th output as middle for working with original recipes
	-- new_fluid_boxes[4].pipe_connections[1] = {position = {0, 3}}
	
	-- -- 5th fluidbox output location
	-- new_fluid_boxes[5].pipe_connections[1] = {position = {2, 3}}
	
	-- -- kill old data
	-- data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes = {}
	-- --data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes = table.deepcopy(new_fluid_boxes)
	
	-- -- copy new values incl. 5th fluidbox
	-- data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes = fTbl.copy(new_fluid_boxes, true)

	-- -- check values in data.raw
	-- for k,v in ipairs(data.raw["assembling-machine"]["angels-electrolyser"].fluid_boxes) do
		-- log("Fbox"..tostring(v).." "..v.pipe_connections[1].position[1]..","..v.pipe_connections[1].position[2])
	-- end
	
	-- --fTbl.log("new_fluid_boxes",new_fluid_boxes,true)
-- end









