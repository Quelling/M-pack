function add_furnace_recipe(data)
  local name = data.name
  local order = data.order
  local subgroup = data.subgroup or "lf-furnace"
  local category = data.category or "crafting"
  local ingredients = data.ingredients
  
  return {
    type = "recipe",
    name = name,
    ingredients = ingredients,
    enabled = false,
    order = "f[loader-furnace]-g[02]",
    subgroup = "smelting-machine",
    energy_required = 5,
    result = name,
    category = category,
  }
end

-- function add_smelting_recipe(result, sorting, ingredients, energy_required)
  -- local result_name = data.
  -- if not result.name then
    -- result.name = "lf-" .. result.result
  -- end

  -- return {
    -- type = "recipe",
    -- name = result.name,
    -- ingredients = ingredients,
    -- results = result.results,
    -- energy_required = energy_required,
    -- enabled = true,
    -- category = sorting.category,
    -- subgroup = sorting.subgroup,
    -- order = sorting.order,

    -- -- result = result.result,
    -- -- result_count = result.amount,
    
    -- -- main_product = result.main_product,
    -- icon = result.icon
  -- }
-- end

