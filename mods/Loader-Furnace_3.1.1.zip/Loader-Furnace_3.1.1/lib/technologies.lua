function add_furnace_tech(data)
  local name = data.name
  local tier = data.tier
  local prerequisites = data.prerequisites
  local unit = data.unit
  local order = data.order
  local icon = data.icon
  local tint = data.tint

  local letter_tier = ""
  if tier == "01" then
    letter_tier = "a"
  end
  if tier == "02" then
    letter_tier = "b"
  end
  if tier == "03" then
    letter_tier = "c"
  end
  if tier == "04" then
    letter_tier = "d"
  end
  if tier == "05" then
    letter_tier = "e"
  end

  return {
    type = "technology",
    name = name .. "-" .. letter_tier,
    -- icon = icon, -- hacky?
    icons = {{icon = icon, tint = tint}},
    
    icon_size = 128,
    effects = {{type = "unlock-recipe", recipe = name .. "-" .. tier}},
    prerequisites = prerequisites,
    unit = unit,
    order = order
  }
end


