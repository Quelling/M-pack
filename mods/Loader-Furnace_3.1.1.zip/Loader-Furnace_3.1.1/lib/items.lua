function add_furnace_item(data)
  local name = data.name
  local subgroup = data.subgroup or "lf-furnace"
  local order = data.order
  -- local icon = data.icon
  local tint = data.tint
  return {
    type = "item",
    name = name,
    icons = {{icon = "__Loader-Furnace__/graphics/icons/lf-icon-gray.png", tint = tint}},
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    order = order,
    subgroup = subgroup,
    place_result = name,
    stack_size = 50
  }
end
