function RGB(colors)
  local r = colors[1]
  local g = colors[2]
  local b = colors[3]
  return ({r=r, g=g, b=b})
end

RGB_00 = RGB{165, 165, 165} -- grey
RGB_01 = RGB{178, 173, 100} -- yellow
RGB_02 = RGB{202, 154, 152} -- red
RGB_03 = RGB{132, 180, 181} -- cyan
RGB_04 = RGB{133, 193, 130} -- green
RGB_05 = RGB{189, 153, 200} -- purple

