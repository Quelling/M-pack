require("lib.colors")
require("lib.entities")

local entities = 
{
  add_furnace_entity{
    name = 'lf-furnace-01',
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed =  1*140/3, -- 13.333 * 3.5
    energy_usage =    1*8640, -- 1*180*48
    icon = "__Loader-Furnace__/graphics/icons/lf-icon-gray.png",
    tint = RGB{178, 173, 100} -- yellow
  },
  
  add_furnace_entity{
    name = 'lf-furnace-02',
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed =  2*140/3,
    energy_usage =    2*8640,
    icon = "__Loader-Furnace__/graphics/icons/lf-icon-gray.png",
    tint = RGB{202, 154, 152} -- red
  },
  
  add_furnace_entity{
    name = 'lf-furnace-03',
    crafting_category = {"smelting", "lf-smelting"},
    crafting_speed = 3*140/3,
    energy_usage = 3*8640,
    icon = "__Loader-Furnace__/graphics/icons/lf-icon-gray.png",
    tint = RGB{132, 180, 181} -- cyan
  }
}
data:extend(entities)

require("lib.items")
local items = 
{
  add_furnace_item
    {
      name = 'lf-furnace-01',
      -- subgroup = "lf-furnace",
      order = "a[lf-furnace]-a[01]",
      tint = RGB{178, 173, 100} -- yellow
    },
  add_furnace_item
    {
      name = 'lf-furnace-02',
      -- subgroup = "lf-furnace",
      order = "a[lf-furnace]-b[02]",
      tint = RGB{202, 154, 152} -- red
    },
  add_furnace_item
    {
      name = 'lf-furnace-03',
      -- subgroup = "lf-furnace",
      order = "a[lf-furnace]-c[03]",
      tint = RGB{132, 180, 181} -- cyan
    }
}
data:extend(items)

require("lib.recipes")

-- Loader Furnace
local recipes = 
  {
    add_furnace_recipe{
      name = "lf-furnace-01",
      ingredients = 
        {
          {"loader", 2},
          {"steel-plate", 50},
          {"electric-furnace", 48},
          {"electronic-circuit", 20},
          {"iron-gear-wheel", 20},
          {"iron-stick", 20}
        },
      order = "a[loader-furnace]-a[lf-furnace-01]",
      subgroup = "smelting-machine",
      category = nil,
    },
    add_furnace_recipe{
      name = "lf-furnace-02",
      ingredients = 
        {
          {"fast-loader", 2},
          {"steel-plate", 50},
          {"lf-furnace-01", 3},
          {"advanced-circuit", 5},
          {"iron-gear-wheel", 20},
          {"iron-stick", 20}
        },
      order = "a[loader-furnace]-b[lf-furnace-02]",
      subgroup = "smelting-machine",
      category = nil,
    },
    add_furnace_recipe{
      name = "lf-furnace-03",
      ingredients = 
        {
          {"express-loader", 2},
          {"steel-plate", 50},
          {"lf-furnace-02", 3},
          {"advanced-circuit", 50},
          {"iron-gear-wheel", 20},
          {"iron-stick", 20},
          {type = "fluid", name = "lubricant", amount = 120}
        },
      order = "a[loader-furnace]-c[lf-furnace-03]",
      subgroup = "smelting-machine",
      category = "crafting-with-fluid",
    },
  }
data:extend(recipes)

-- -- Smelting recipes
-- data:extend(
  -- {
    -- -- Stone Bricks
    -- add_smelting_recipe(
      -- {result = "stone-brick", amount = 2},
      -- {category = "lf-smelting", order = "a", subgroup = "lf-smelting"},
      -- {{name = "stone", amount = 4}},
      -- 7
    -- ),
    -- -- Iron Plate
    -- add_smelting_recipe(
      -- {result = "iron-plate", amount = 2},
      -- {category = "lf-smelting", order = "b", subgroup = "lf-smelting"},
      -- {{name = "iron-ore", amount = 2}},
      -- 7
    -- ),
    -- -- Copper Plate
    -- add_smelting_recipe(
      -- {result = "copper-plate", amount = 2},
      -- {category = "lf-smelting", order = "c", subgroup = "lf-smelting"},
      -- {{name = "copper-ore", amount = 2}},
      -- 7
    -- ),
    -- -- Steel Plate
    -- add_smelting_recipe(
      -- {result = "steel-plate", amount = 2},
      -- {category = "lf-smelting", order = "d", subgroup = "lf-smelting"},
      -- {{name = "iron-plate", amount = 4}},
      -- 7
    -- )
  -- }
-- )


-- Technologies
require("lib.technologies")
local technologies = 
{
  add_furnace_tech
    {
      name = "lf-furnace",
      tier = "01",
      prerequisites = 
        {
          "advanced-material-processing-2",
          -- "loader"
        },
      unit =     
        {
          count = 500, 
          time = 30,      
          ingredients = 
            {
              {"science-pack-1", 1},
              {"science-pack-2", 1}
            } 
        },
      order = "l[loader-furnace]-a[furnace]-a[01]",

      icon = "__Loader-Furnace__/graphics/technology/loader-furnace-gray.png",
      tint = RGB{178, 173, 100} -- yellow

    },
    add_furnace_tech
    {
      name = "lf-furnace",
      tier = "02",
      prerequisites = 
        {
          -- "fast-loader",
          "lf-furnace-a"
          
        },
      unit =     
        {       
          count = 1000,
          time = 60,
          ingredients = 
            {
              {"science-pack-1", 1},
              {"science-pack-2", 1},
              {"science-pack-3", 1}
            }
        },
      order = "l[loader-furnace]-a[furnace]-b[02]",

      icon = "__Loader-Furnace__/graphics/technology/loader-furnace-gray.png",
      tint = RGB{202, 154, 152} -- red

    },
    add_furnace_tech
    {
      name = "lf-furnace",
      tier = "03",
      prerequisites = 
        {
          -- "express-loader",
          "lf-furnace-b"
        },
      unit =     
        {
          count = 2000,
          time = 90,
          ingredients = 
            {
              {"science-pack-1", 1},
              {"science-pack-2", 1},
              {"science-pack-3", 1},
              {"production-science-pack", 1}
            }
        },
      order = "l[loader-furnace]-a[furnace]-c[03]",
      icon = "__Loader-Furnace__/graphics/technology/loader-furnace-gray.png",
      tint = RGB{132, 180, 181} -- cyan
    },
  
}
data:extend(technologies)
