require("prototypes.category")

--vanilla
require("prototypes.furnaces-vanilla")
