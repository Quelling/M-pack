data:extend(
{ 
  {
    type = "recipe",
    name = "single-splitter",
    enabled = "true",
    ingredients = 
    {
      {"electronic-circuit",2},
      {"iron-plate",2}
    },
    result = "single-splitter"
  }
}
)