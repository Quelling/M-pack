data:extend(
{
		 {
			type = "item",
			name = "single-splitter",
			icon = "__Single-Splitter__/graphics/splitter.png",
			icon_size = 32,
			flags = { "goes-to-quickbar" },
			subgroup = "belt",
			place_result="single-splitter",
			stack_size= 50,
		  },
})
	

