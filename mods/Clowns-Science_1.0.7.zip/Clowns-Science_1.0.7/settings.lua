data:extend(
{
	{
		type = "bool-setting",
		name = "allow-space-science-generation",
		setting_type = "startup",
		default_value = true,
	},
 }
 )