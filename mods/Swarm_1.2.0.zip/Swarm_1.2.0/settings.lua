data:extend({
	{
		type = "bool-setting",
		name = "spawners-fragment-units",
		setting_type = "runtime-global",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "units-fragment-units",
		setting_type = "runtime-global",
		default_value = true,
	}
})
