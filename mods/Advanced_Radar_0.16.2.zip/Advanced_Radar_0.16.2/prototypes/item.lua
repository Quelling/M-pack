data:extend({

{
    type = "item",
    name = "advanced-radar",
    icon = "__Advanced_Radar__/graphics/item_icon_advanced_radar.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "z[radar]-a[radar]",
    place_result = "advanced-radar",
    stack_size = 10
  }
  
  })