Advanced_Radar for Factorio 0.16 Changelog

15/12/2017   0.16.2   Fix sprite definitions
             0.16.1   Fix icon size error
             0.16.0   Initial Factorio 0.16 conversion attempt.
24/11/2017   0.15.1   Addition of code to enable blue positioning aid overlay in minimap
27/07/2017   0.15.0   Initial port of Malcolm Cook's mod to Factorio version 0.15
