Advanced_Radar 0.16.2 by Michael Cowgill (ChurchOrganist)

This is simply a port of Malcolm Cooks' AdvancedRadar mod for Factorio 0.16.
Malcolm's code is almost unchanged apart from some alterations to the sprite definitions, required for compatibility with Factorio's 0.16.x format, and a couple of alterations to the entity.lua file to enable the blue shading in the minimap.

This has been tested in Sandbox mode appears to be working OK.
If not please file a bug report at the Github repository.

Hope you enjoy it :)

It is licensed under the MIT license, available in this package in the file  LICENSE.md.

Thank you to Malcolm Cooks for writing the original AdvancedRadar mod.

For more information on this licence please visit: http://opensource.org/licenses/mit-license.html
