data:extend({
	

	--- Thumper
	{
		type = "item",
		name = "Thumper",
		icon = "__Natural_Evolution_Buildings__/graphics/icons/Thumper.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "Natural-Evolution",
		order = "Thumper",
		place_result = "Thumper",
		stack_size = 10
	},

})
