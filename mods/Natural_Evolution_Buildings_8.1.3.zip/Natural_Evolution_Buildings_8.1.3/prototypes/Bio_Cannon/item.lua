data:extend({

	
	-- Hive Buster Turret
	
		{
	type = "item",
	name = "bi-bio-cannon-area",
	icon = "__Natural_Evolution_Buildings__/graphics/icons/biocannon_icon.png",
	icon_size = 32,
	flags = { "goes-to-quickbar" },
	subgroup = "defensive-structure",
	order = "x[turret]-x[gun-turret]",
	place_result = "bi-bio-cannon-area",
	stack_size = 1,
	},
	
})