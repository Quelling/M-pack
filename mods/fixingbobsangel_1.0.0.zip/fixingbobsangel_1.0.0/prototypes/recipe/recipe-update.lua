if data.raw.item["tin-plate"] then
    bobmods.lib.recipe.replace_ingredient("lab", "transport-belt","black-transport-belt")
end