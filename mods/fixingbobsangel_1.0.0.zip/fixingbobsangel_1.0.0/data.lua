--data.lua

require("prototypes.recipe.recipe-update")