require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technologies")

data:extend(
{
  {
    type = "fuel-category",
    name = "electrical"
  },
  {
    type = "recipe-category",
    name = "electrical"
  }
})