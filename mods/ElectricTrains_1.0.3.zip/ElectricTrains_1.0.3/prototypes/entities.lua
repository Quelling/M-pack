local locomotive = util.table.deepcopy(data.raw.locomotive["locomotive"])

locomotive.name = "electric-locomotive"
locomotive.minable.result = "electric-locomotive"
locomotive.weight = 1600
locomotive.max_speed = 1.5
locomotive.max_power = "600kW"
locomotive.reversing_power_modifier = 1.0
locomotive.braking_force = 10
locomotive.friction_force = 0.5
locomotive.burner.fuel_category = "electrical"
locomotive.burner.fuel_inventory_size = 1
locomotive.burner.burnt_inventory_size = 1
locomotive.burner.smoke = nil
locomotive.color = {r = 0, g = 0.33, b = 0.92, a = 0.5}
locomotive.stop_trigger = 
{
  type = "play-sound",
  sound =
  {
    {
      filename = "__base__/sound/train-breaks.ogg",
      volume = 0.3
    }
  }
}

local electricTrainStop = util.table.deepcopy(data.raw["train-stop"]["train-stop"])

electricTrainStop.name = "electric-train-stop"
electricTrainStop.color = {r = 0, g = 0.33, b = 0.92, a = 0.5}
electricTrainStop.minable.result = "electric-train-stop"

data:extend(
{
  locomotive,
  electricTrainStop,
  
  {
    type = "electric-energy-interface",
    name = "charging-station",
    icons = {
      {icon = "__base__/graphics/icons/train-stop.png"},
      {icon = "__ElectricTrains__/graphics/icons/lightning-bolt.png", scale = 0.5, shift = { 10, -10}}
    },
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "not-blueprintable"},
    corpse = "small-remnants",
    -- selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    energy_source =
    {
      type = "electric",
      buffer_capacity = "100MJ",
      usage_priority = "primary-input",
      input_flow_limit = "1950kW",
      output_flow_limit = "0kW",
      drain = "500W"
    },
    charge_cooldown = 45,
    discharge_cooldown = 30,
  },
  
  {
    type = "assembling-machine",
    name = "battery-charging-station",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "battery-charging-station"},
    max_health = 200,
    corpse = "medium-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
    drawing_box = {{-1, -1.5}, {1, 1}},
    animation =
    {
      filename = "__base__/graphics/entity/accumulator/accumulator.png",
      priority = "extra-high",
      width = 124,
      height = 103,
      frame_count = 1,
      shift = {0.6875, -0.203125}
    },
    working_visualisations =
    {
      {
        animation =
        {
        filename = "__base__/graphics/entity/accumulator/accumulator-charge-animation.png",
        width = 138,
        height = 135,
        line_length = 8,
        frame_count = 24,
        shift = {0.46875, -0.640625},
        animation_speed = 1
        }
      }
    },
    crafting_categories = {"electrical"},
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      drain = "3kW"
    },
    energy_usage = "2MW",
    ingredient_count = 1,
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 0.4
      },
      idle_sound = {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 5
    }
  }
})