data:extend(
{
  {
    type = "item-with-entity-data",
    name = "electric-locomotive",
    icon = "__ElectricTrains__/graphics/icons/electric-locomotive.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-f[electric-locomotive]-a",
    place_result = "electric-locomotive",
    stack_size = 5
  },
  
  {
    type = "item",
    name = "electric-train-stop",
    icon = "__base__/graphics/icons/train-stop.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-c[train-stop]-a",
    place_result = "electric-train-stop",
    stack_size = 10
  },
  
  {
    type = "item",
    name = "battery-charging-station",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "production-machine",
    order = "h[train-system]",
    place_result = "battery-charging-station",
    stack_size = 10
  },
  
  {
    type = "item",
    name = "battery-pack",
    icon = "__base__/graphics/technology/battery.png",
    icon_size = 128,
    flags = {"goes-to-main-inventory"},
    fuel_category = "electrical",
    fuel_value = "50MJ",
    fuel_acceleration_multiplier = 1.5,
    burnt_result = "discharged-battery-pack",
    subgroup = "raw-material",
    order = "h[battery]-a[battery-pack]",
    stack_size = 10
  },
  
  {
    type = "item",
    name = "discharged-battery-pack",
    icon = "__ElectricTrains__/graphics/icons/discharged-battery.png",
    icon_size = 128,
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "h[battery]-b[discharged-battery-pack]",
    stack_size = 10
  },
  
  {
    type = "item",
    name = "electric-locomotive-fuel-dummy",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    fuel_category = "electrical",
    fuel_value = "250MJ",
    fuel_acceleration_multiplier = 1.5,
    subgroup = "raw-material",
    order = "h[battery]",
    stack_size = 1
  },
  
  { -- defined to stop Factorio complaining about not having an item to place for the proper charging station
    type = "item",
    name = "charging-station",
    icon = "__base__/graphics/icons/train-stop.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-c[train-stop]-a",
    place_result = "charging-station",
    stack_size = 10
  }
})