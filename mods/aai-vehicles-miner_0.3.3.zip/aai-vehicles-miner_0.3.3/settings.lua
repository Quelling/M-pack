data:extend{
    {
        type = "bool-setting",
        name = "start-with-vehicle-miner",
        setting_type = "startup",
        default_value = true,
    }
}
