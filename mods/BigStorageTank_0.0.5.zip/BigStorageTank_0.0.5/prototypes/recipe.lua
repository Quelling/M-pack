data:extend(
{
  {
    type = "recipe",
    name = "big-storage-tank",
    energy_required = 3,
    enabled = false,
    ingredients =
    {
      {"storage-tank", 15},
      {"steel-plate", 20}
    },
    result= "big-storage-tank"
  }}
)
