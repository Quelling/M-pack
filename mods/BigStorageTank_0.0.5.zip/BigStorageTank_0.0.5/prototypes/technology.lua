data:extend(
{
  {
    type = "technology",
    name = "big-storage-tank",
    icon_size = 128,
    icon = "__base__/graphics/technology/fluid-handling.png",
    prerequisites = {"fluid-handling"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "big-storage-tank"
      },	 
      
    },
    unit =
    {
      count = 300,
      ingredients = {{"science-pack-1", 1},{"science-pack-2", 1}},
      time = 30
    },
    order = "d-a-a"
  }}
)
