data:extend(
{
  {
    type = "item",
    name = "big-storage-tank",
    icon = "__base__/graphics/icons/storage-tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
    order = "z[fluid]-z[storage-tank]",
    place_result = "big-storage-tank",
    stack_size = 5
  }}
)
