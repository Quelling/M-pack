data.raw.item["artillery-turret"].sound =
{
	filename = "__Epic-Artillery-Sounds__/sounds/KABOOM.ogg",
	volume = 1
}

data.raw.gun["artillery-wagon-cannon"].attack_parameters.sound =
{
	filename = "__Epic-Artillery-Sounds__/sounds/KABOOM.ogg",
	volume = 1
}