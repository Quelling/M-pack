data:extend{
	{
		type = 'bool-setting',
		name = 'manual-inventory-sort-buttons',
		setting_type = 'runtime-per-user',
		default_value = false,
	},
	{
		type = 'bool-setting',
		name = 'manual-inventory-sort-on-open',
		setting_type = 'runtime-per-user',
		default_value = false,
	},
	{
		type = 'bool-setting',
		name = 'manual-inventory-sort-self-on-open',
		setting_type = 'runtime-per-user',
		default_value = false,
	},
}
