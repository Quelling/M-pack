data:extend(
{
	
	{
		type = "technology",
		name = "centrifuging-1",
		icon_size = 128,
		icon = "__Clowns-Processing__/graphics/technology/advanced-centrifuging.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "centrifuge-mk2"
			},
			
		},
		prerequisites = {"nuclear-power"},
		unit =
		{
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"production-science-pack", 1}
			},
			time = 30,
			count = 300
		},
		order = "f"
	},
	{
		type = "technology",
		name = "centrifuging-2",
		icon_size = 128,
		icon = "__Clowns-Processing__/graphics/technology/advanced-centrifuging.png",
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "centrifuge-mk3"
			},
		},
		prerequisites = {"centrifuging-1"},
		unit =
		{
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"production-science-pack", 1},
				{"high-tech-science-pack", 1}
			},
			time = 30,
			count = 500
		},
		order = "f"
	},
}
)