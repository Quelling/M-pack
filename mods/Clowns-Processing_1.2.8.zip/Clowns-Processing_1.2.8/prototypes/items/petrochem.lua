data:extend(
{
	{
		type = "item",
		name = "catalyst-metal-violet",
		icon = "__Clowns-Processing__/graphics/icons/catalyst-metal-violet.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "petrochem-raw",
		order = "f",
		stack_size = 200
	},
}
)