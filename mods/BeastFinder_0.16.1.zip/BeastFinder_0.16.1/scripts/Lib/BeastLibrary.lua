log("Module: Welcome to the Library of the Beast")

BeastLibrary = BeastLibrary or {}

BeastLibrary["debug"] = BeastLibrary["debug"] or {}
BeastLibrary.debug.level = 0

function beastlog(level, snake, ...)
	-- output log message using specified serpent call
	-- intended for internal use only (blog, blogb etc.)
	if BeastLibrary.debug.level >= level then
		local msg = ""
		local arg={...}
		for i, v in ipairs(arg) do
			msg = msg .. snake(v)
		end
		log(msg)
	end
end

function blog(level, ...)
	-- Logs msg if level in settings is high enough.
	-- prepends timestamp
	-- wraps each parameter in serpent.line
	beastlog(level, serpent.line, ...)

end

function blogb(level, ...)
	-- As per BeastLibrary.log but wraps each parameter in serpent.block
	beastlog(level, serpent.block, ...)

end

script.on_load(function()

	log("BeastLibrary - script.on_load() - nothin here")

end)