require("mod-gui")

BeastFinder_Status = {}
BeastFinder_Filters = {}
BeastFinder_Matrix = {}

function toolbar_init(player)
	
	blog(2, "<toolbar_init()>")	
	local flow = mod_gui.get_button_flow(player)
	
	if flow["beastfinder-menu-button"] then
		flow["beastfinder-menu-button"].destroy()
	end
	
	if settings["startup"]["BeastFinder-show-toolbar"] then
		if not flow["beastfinder-menu-button"] then
			local button = flow.add
			{
				type = "sprite-button",
				name = "beastfinder-menu-button",
				style = mod_gui.button_style,
				sprite = "BeastFinder-menu-sprite",
				tooltip = {"beastfinder-menu-tooltip"}
			}
			button.style.visible = true
		end
	else
		blog(2, "<toolbar_init()> Menu disabled by user")
	end
	
end

function glob_init()
	
	-- Prepares global arrays (used to save current search items etc. between loads)

	blog(2, "<glob_init()>")
	
	global["BeastFinder"] = global["BeastFinder"] or {}
	global["BeastFinder"]["range"] = global["BeastFinder"]["range"] or 2000
	global["BeastFinder"]["threshold"] = global["BeastFinder"]["threshold"] or 40
	global["BeastFinder"]["bIngredients"] = global["BeastFinder"]["bIngredients"] or false
	global["BeastFinder"]["bProducts"] = global["BeastFinder"]["bProducts"] or true
	global["BeastFinder"]["bInventory"] = global["BeastFinder"]["bInventory"] or true
	global["BeastFinder"]["SearchItems"] = global["BeastFinder"]["SearchItems"] or {}
	global["BeastFinder"]["Tags"] = global["BeastFinder"]["Tags"] or {}

	global["BeastFinder"]["bAutoClearAll"] = global["BeastFinder"]["bAutoClearAll"] or true
	global["BeastFinder"]["bAutoClearItem"] = global["BeastFinder"]["bAutoClearItem"] or false	
	global["BeastFinder"]["bAutoClearGUIclose"] = global["BeastFinder"]["bAutoClearGUIclose"] or false	
	global["BeastFinder"]["intHighlights"] = global["BeastFinder"]["intHighlights"] or 2		-- Default to Large	
	
	blog(3, "<glob_init()> global['BeastFinder2']=", global["BeastFinder"])	
end

function close_guis(player)
	-- Close all GUIs here
	blog(2, "<close_guis()>")
	
	local flow = mod_gui.get_frame_flow(player)
	
	if flow.frame_BeastFinder then
        flow.frame_BeastFinder.destroy()
	end	
	if flow.frame_BeastFinder_settings then
		flow.frame_BeastFinder_settings.destroy()
	end
	
	if global["BeastFinder"]["bAutoClearGUIclose"] then
		ClearTags(player)
	end
end

function gui_init(player)

	blog(2, "<gui_init()>")
	
	-- Close GUI on load (in case it was open during game save)
	close_guis(player)

end

function ToggleSearchGui(player)
	
	-- Close (destroy) GUI if it's open... otherwise create & display it.

	blog(1, "<ToggleSearchGui(" .. player.name .. ")>")

	local flow = mod_gui.get_frame_flow(player)
	if flow.frame_BeastFinder then
        close_guis(player)
	else
		blog(2, "<ToggleSearchGui()> creating gui")
		local frame, prog
		local isHorizontal = settings.startup["BeastFinder-horizontal"] or true
		local iRowsMax = settings.startup["BeastFinder-Rows"].value or 5 
		local iColsMax = settings.startup["BeastFinder-Cols"].value or 2 		
		
		local indexMax = iColsMax * iRowsMax
		global["BeastFinder"]["SearchItems_max"] = indexMax

		frame = flow.add{type = "frame", name = "frame_BeastFinder", style = "frame_Beast_style", direction = "vertical"}

		local table_main = frame.add{type = "table", name = "tab_Beast_main", column_count = 1, style = "table_Beast_style"}

		-- Title
		local table_title = table_main.add{type = "table", name = "tab_BeastFinder_title", column_count = 5, style = "table_Beast_style"}
		if iColsMax > 1 then
			table_title.add{
				type = "sprite",
				name = "bf666_sprite_Beast_ingredients_chkLabel",
				sprite = "BeastFinder-icon-sprite",
				tooltip = {"BeastFinder-icon-tooltip"}
			}
		end

		-- Hack: Use hidden progress bar as a spacer since can't seem to right justify. May use as progress bar if searches are slow.
		if iColsMax > 2 then
			prog = table_title.add{type = "progressbar", name = "progress_BeastFinder", size = 100, value = 0, style = "progressbar_Beast_GreyBack_style"}
			prog.style.minimal_width = (iColsMax - 2) * 60
			prog.style.maximal_width = (iColsMax - 2) * 60
		end
		
		-- Add clear, settings & close X buttons
		table_title.add{
			type = "sprite-button",
			name = "bf666_but_Beast_ClearItems",
			style = "button25_Beast_style",
			sprite = "utility/remove",
			tooltip = {"BeastFinder-clear-items-tooltip"}
		}
		table_title.add{
			type = "sprite-button",
			name = "bf666_but_BeastFinder_settings",
			style = "button25_Beast_style",
			sprite = "BeastFinder-settings-sprite",
			tooltip = {"BeastFinder-settings-tooltip"}
		}		
		table_title.add{
			type = "sprite-button",
			name = "bf666_but_Beast_close",
			style = "button25_Beast_style",
			sprite = "BeastFinder-close-gui-sprite",
			tooltip = {"BeastFinder-close-gui-tooltip"}
		}		

		-- Main array of search buttons
		blog(2, "<ToggleSearchGui()> creating search matrix " .. iRowsMax .. " x " .. iColsMax)
		local table_matrix = table_main.add{type = "table", name = "tab_BeastFinder_matrix", column_count = iColsMax, style = "table_Beast_style"}
		table_matrix.style.right_padding = 2
		table_matrix.style.left_padding = 2
	
		for ind = 1, indexMax do
			local table_submatrix = {}
			if isHorizontal then
				table_submatrix = table_matrix.add{type = "table", name = "tab_BeastFinder_submatrix" .. ind, column_count = 2, style = "table_Beast_style"}
			else
				table_submatrix = table_matrix.add{type = "table", name = "tab_BeastFinder_submatrix" .. ind, column_count = 1, style = "table_Beast_style"}
			end
			
			table_submatrix.add{type = "choose-elem-button", name = "bf666_item_beast_select_" .. ind, elem_type = "signal", signal = global.BeastFinder.SearchItems[ind]}
			table_submatrix.add{
				type = "sprite-button",
				name = "bf666_but_Beast_searchMatrix_".. ind,
				style = "button25_Beast_style",
				sprite = "BeastFinder-search-sprite",
				tooltip = {"BeastFinder-search-tooltip"}
			}
		end
		
		BeastFinder_Matrix = table_matrix
		
		local bfcolspan = 2
		if iColsMax > 1 then
			bfcolspan = 3
		end

		local table_but = table_main.add{type = "table", name = "tab_Beast_but", column_count = bfcolspan, style = "table_Beast_style"}
				
		-- Filters: Ingredient
		local chkframe = table_but.add{type = "frame", name = "frame_BeastFinder_Ingredients", style = "frame_Beast_style", direction = "horizontal"}		
		chkframe.add{
			type = "sprite",
			name = "bf666_sprite_Beast_ingredients_chkLabel",
			sprite = "BeastFinder-ingredients-sprite",
			tooltip = {"BeastFinder-ingredients-tooltip"}
		}
		BeastFinder_Filters.chkIngredients = chkframe.add{
			type = "checkbox",
			name = "bf666_chk_Beast_ingredients",
			style = "checkbox_Beast_style",
			caption = "",
			tooltip = {"BeastFinder-ingredients-tooltip"},
			state = global["BeastFinder"]["bIngredients"]
		}
		-- Hack: Use hidden progress bar as a spacer since can't seem to right justify. May use as progress bar if searches are slow.
		if iColsMax > 1 then
			prog = table_but.add{type = "progressbar", name = "progress_BeastFinder2", size = 100, value = 0, style = "progressbar_Beast_GreyBack_style"}
			prog.style.minimal_width = ((iColsMax - 2) * 60) + 20
			prog.style.maximal_width = ((iColsMax - 2) * 60) + 20
		end
		
		-- Search All
		table_but.add{
			type = "sprite-button",
			name = "bf666_but_Beast_search_all",
			style = "button32_Beast_style",
			sprite = "BeastFinder-search-all-sprite",
			tooltip = {"BeastFinder-search-all-tooltip"}
		}		

		-- Filters: Product
		chkframe = table_but.add{type = "frame", name = "frame_BeastFinder_Products", style = "frame_Beast_style", direction = "horizontal"}

		chkframe.add{
			type = "sprite",
			name = "bf666_sprite_Beast_products_chkLabel",
			sprite = "BeastFinder-products-sprite",
			tooltip = {"BeastFinder-products-tooltip"}
		}
		BeastFinder_Filters.chkProducts = chkframe.add{
			type = "checkbox",
			name = "bf666_chk_Beast_products",
			style = "checkbox_Beast_style",
			caption = "",
			tooltip = {"BeastFinder-products-tooltip"},
			state = global["BeastFinder"]["bProducts"]
		}
		-- Hack: Use hidden progress bar as a spacer since can't seem to right justify. May use as progress bar if searches are slow.
		if iColsMax > 1 then
			prog = table_but.add{type = "progressbar", name = "progress_BeastFinder3", size = 100, value = 0, style = "progressbar_Beast_GreyBack_style"}
			prog.style.minimal_width = ((iColsMax - 2) * 60) + 20
			prog.style.maximal_width = ((iColsMax - 2) * 60) + 20
		end
		
		-- Clear tags button
		table_but.add{
			type = "sprite-button",
			name = "bf666_but_Beast_ClearTags",
			style = "button32_Beast_style",
			sprite = "BeastFinder-clear-tags-sprite",
			tooltip = {"BeastFinder-clear-tags-tooltip"}
		}		
		
		-- Filters: Container	
		chkframe = table_but.add{type = "frame", name = "frame_BeastFinder_Inventory", style = "frame_Beast_style", direction = "horizontal"}
		chkframe.add{
			type = "sprite",
			name = "bf666_but_Beast_inventory_chkLabel",
			sprite = "BeastFinder-inventory-sprite",
			tooltip = {"BeastFinder-inventory-tooltip"}
		}		
		BeastFinder_Filters.chkInventory = chkframe.add{
			type = "checkbox",
			name = "bf666_chk_Beast_inventory",
			style = "checkbox_Beast_style",
			caption = "",
			tooltip = {"BeastFinder-inventory-tooltip"},
			state = global["BeastFinder"]["bInventory"]
		}

		BeastFinder_Status = frame.add{type = "label", name = "bf666_label_status", caption = "moo", style = "label_status_Beast_style", tooltip={"BeastFinder-status-tooltip"}}		
    end
end

function ToggleSettingsGui(player)
	-- Called from settings button on main Gui
	blog(2, "<ToggleSettingsGui()>")
	
	local prog, flow
	flow = mod_gui.get_frame_flow(player)

	if flow.frame_BeastFinder_settings then
        flow.frame_BeastFinder_settings.destroy()
	else
		local frame
		
		flow = mod_gui.get_frame_flow(player)
		frame = flow.add{type = "frame", name = "frame_BeastFinder_settings", style = "frame_Beast_style", direction = "vertical"}
		frame.style.right_padding = 2
		frame.style.bottom_padding = 2
		frame.style.left_padding = 2
		
		local table_title = frame.add{type = "table", name = "tab_BeastFinder_Settings_title", column_count = 3, style = "table_Beast_style"}
		table_title.add{type = "label", name = "label_BeastFinder_Settings_Title", caption = {"BeastFinder-Settings-caption"}, style = "label_Beast_style"}
		-- Hack: grey progess bar as spacer
		prog = table_title.add{type = "progressbar", name = "progress_BeastFinder", size = 100, value = 0, style = "progressbar_Beast_GreyBack_style"}
		prog.style.minimal_width = 100
		prog.style.maximal_width = 100
		table_title.add{
			type = "sprite-button",
			name = "bf666_but_Beast_settings_close",
			style = "button25_Beast_style",
			sprite = "BeastFinder-close-gui-sprite",
			tooltip = {"BeastFinder-close-gui-tooltip"}
		}
				
		-- Range and Threshold settings
		local table_main = frame.add{type = "table", name = "tab_BeastFinder_settings", column_count = 4, style = "table_Beast_style"}		
		table_main.add{type = "label", name = "label_Range", caption = {"BeastFinder-Range-caption"}, style = "label_Beast_style"}
		table_main.add{type = "textfield", name = "bf666_txt_Range", text = global.BeastFinder.range, tooltip = {"BeastFinder-Range-tooltip"}, style = "textfield_Beast_short_style", word_wrap = true}
		table_main.add{type = "label", name = "label_Threshold", caption = {"BeastFinder-Threshold-caption"}, style = "label_Beast_style"}
		table_main.add{type = "textfield", name = "bf666_txt_Threshold", text = global.BeastFinder.threshold, tooltip = {"BeastFinder-Threshold-tooltip"}, style = "textfield_Beast_short_style", word_wrap = true}
		
		-- Auto clear settings
		local table_chk = frame.add{type = "table", name = "tab_BeastFinder_settings_chk", column_count = 1, style = "table_Beast_style"}		
		table_chk.add{
			type = "checkbox",
			name = "bf666_chk_Beast_AutoClear_All",
			style = "checkbox_Beast_style",
			caption = {"BeastFinder-autoclear-all-caption"},
			tooltip = {"BeastFinder-autoclear-all-tooltip"},
			state = global["BeastFinder"]["bAutoClearAll"]
		}		
		table_chk.add{
			type = "checkbox",
			name = "bf666_chk_Beast_AutoClear_Item",
			style = "checkbox_Beast_style",
			caption = {"BeastFinder-autoclear-item-caption"},
			tooltip = {"BeastFinder-autoclear-item-tooltip"},
			state = global["BeastFinder"]["bAutoClearItem"]
		}
		table_chk.add{
			type = "checkbox",
			name = "bf666_chk_Beast_AutoClear_GUIclose",
			style = "checkbox_Beast_style",
			caption = {"BeastFinder-autoclear-GUIclose-caption"},
			tooltip = {"BeastFinder-autoclear-GUIclose-tooltip"},
			state = global["BeastFinder"]["bAutoClearGUIclose"]
		}		
		-- Highlight size
		local table_drop = frame.add{type = "table", name = "tab_BeastFinder_settings_drop", column_count = 5, style = "table_Beast_style"}		
		
		table_drop.add{type = "label", name = "label_Highlights", caption = {"BeastFinder-highlights-caption"}, style = "label_Beast_style"}
		table_drop.add{
			type = "drop-down",
			name = "bf666_drop_Beast_Highlights",
			--style = "dropdown_Beast_style",
			tooltip = {"BeastFinder-highlights-tooltip"},
			items = { {"BeastFinder-highlights-normal"}, {"BeastFinder-highlights-large"} },
			selected_index = global["BeastFinder"]["intHighlights"]
		}	
		-- Hack: grey progess bar as spacer
		prog = table_drop.add{type = "progressbar", name = "progress_BeastFinder", size = 100, value = 0, style = "progressbar_Beast_GreyBack_style"}
		prog.style.minimal_width = 25
		prog.style.maximal_width = 25

		-- Zap (force cleanup) button	
		table_drop.add{type = "label", name = "label_zap", caption = {"BeastFinder-settings-zap-caption"}, style = "label_Beast_style"}
		table_drop.add{
			type = "sprite-button",
			name = "bf666_but_BeastFinder_settings_zap",
			style = "buttonMoo_Beast_style",
			sprite = "BeastFinder-settings-zap-sprite",
			tooltip = {"BeastFinder-settings-zap-tooltip"}
		}
		
	end

end

function CheckNeighbors(ent, mtchSource, mtchName)
	blog(2, "<CheckNeighbors(" .. ent.name .. ", " .. mtchSource .. ", " .. mtchName .. ")>")
	
	-- Used after matches found to group results together on map
	
	-- returns "true" (string) if there is already a match tagged that is too close
	-- returns index of tag (int) if there is an ingredient near a product (so we use different tag icon)
	-- returns "false" (string) if no near neighbors
	
	local pos = ent.position
	local tags = global.BeastFinder.Tags
	local d = global.BeastFinder.threshold
	local tooClose = "false"
	blog(2, "<CheckNeighbors()> entity pos       ", ent.position)
	if tags ~= nil then 
		for i = 1,#tags do			
			--if tags[i].tag.icon.name == mtchName then
				blog(2, "<CheckNeighbors()> matching tag pos ", tags[i].tag)
				if (tags[i].tag.position.x > (pos.x - d)) and (tags[i].tag.position.x < (pos.x + d)) then
					if (tags[i].tag.position.y > (pos.y - d)) and (tags[i].tag.position.y < (pos.y + d)) then
						blog(2, "<CheckNeighbors()> tags[" .. i .."].source = ", tags[i].source)
						if tags[i].tag.icon.type ~= "virtual"  then
							-- ignore this item/fluid tag in favour of the highlight tag
							blog(3, "<CheckNeighbors()> too close but not virtual tag - ignoring")
						elseif (mtchSource == tags[i].source) then
							tooClose = "true"
							blog(3, "<CheckNeighbors()> existing match tag too close: " .. tags[i].tag.position.x .. ", " .. tags[i].tag.position.y)
							break
						elseif mtchSource == "inventory" then
							-- Inventory is allowed close to other sources
							break
						elseif tags[i].source == "combined" then
							-- Already combined - no action required
							tooClose = "true"
							break
						else
							-- we have an ingredient/product/combined too close - change tag to combined icon
							tooClose = i
							break
						end
					end
				end
			--end
		end
	end
	
	return tooClose

end

function checkRecipe(rcp, itms)
	-- Compare recipe products against items we are searching for
	-- returns table source(ingredient/product/inventory), name, type (fluid/item)
	
	--blog(2, "<checkRecipe()> ")
	
	matchesFound = {}
	
	if itms ~= {} then	
		if rcp ~= nil then
			if global["BeastFinder"]["bProducts"] then
				blog(3, "<checkRecipe()> rcp=", rcp.name)
				for j, prd in pairs(rcp.products) do
					--blog(3, "<checkRecipe()> product " .. j .. " = ", prd.name)
					if itms[prd.name] ~= nil then
						matchesFound[#matchesFound+1] = {source = "product", name = prd.name, type = prd.type}
						blog(1, "<checkRecipe()> Product Match!!", matchesFound)
					end
				end
			end
			if global["BeastFinder"]["bIngredients"] then
				--blog(3, "<checkRecipe()> checking ingredients")
				for k, ing in pairs(rcp.ingredients) do
					--blog(3, "<checkRecipe()> ingredient " .. k .. " = ", ing.name)
					if itms[ing.name] ~= nil then
						matchesFound[#matchesFound+1] = {source = "ingredient",name = ing.name, type = ing.type}
						blog(1, "<checkRecipe()> Ingredient Match!!", matchesFound)
					end
				end			
			
			end
		end
	end
	
	--blog(3, "<checkRecipe()> returning count: ", #matchesFound)
	return matchesFound 

end

function checkInventory(inv, itms)
	-- Compare chest inventory against items we are searching for
	-- returns table source(ingredient/product/inventory), name, type (fluid/item)
	
	blog(2, "<checkInventory()>")

	matchesFound = {}
	
	if inv ~= nil then
		contents = inv.get_contents()
		--blogb(3, "<checkInventory()> contents = ", contents)
		for itm, j in pairs(itms) do
			--blog(3, "<checkInventory()>", j, itm)
			if contents[itm] ~= nil then
					matchesFound[#matchesFound+1] = {source = "inventory", name = itm, type = "item"}
					blog(1, "<checkInventory()> Match!!", matchesFound)
				end
			end
		end
		
	--blog(3, "<checkInventory()> returning count: ", #matchesFound)
	return matchesFound 

end

function checkFluidBoxes(boxes, itms)
	-- Compare storage-tank fluidboxes against items we are searching for
	-- returns table source(ingredient/product/inventory), name, type (fluid/item)
	
	blog(2, "<checkFluidBoxes()>")

	matchesFound = {}
	
	if boxes ~= nil then
		for itm, j in pairs(itms) do
			blog(3, "<checkFluidBoxes()>", j, itm)
			for k = 1,#boxes do
				if boxes[k] ~= nil then
					blog(3, "<checkFluidBoxes()> box " .. k .. " fluid=", boxes[k].name)
					if boxes[k].name == itm then
						matchesFound[#matchesFound+1] = {source = "inventory", name = itm, type = "fluid"}
						blog(1, "<checkFluidBoxes()> Match!!", matchesFound)				
					end
				else
					blog(3, "<checkFluidBoxes()> box " .. k .. " fluid=nil")
				end
			end
		end
	end
	
	blog(3, "<checkFluidBoxes()> returning count: ", #matchesFound)
	return matchesFound 

end

function get_player_box(player)
	-- Uses the configured Range to return the search area box
	blog(2, "<get-player_box()>")

	local range_offset = (global.BeastFinder.range) / 2	
	local box = {{player.position.x - range_offset, player.position.y - range_offset}, {player.position.x + range_offset, player.position.y + range_offset}}
	blog(3, "<get-player_box()> = ", box)
	return box	
end

function CombineSources(mtch)
	-- returns source = (ingredient/product/inventory/combined)
	-- where combined is both ingredient & product.
	
	blog(2, "<CombineSources()>")

	local retsource
	local ings = 0
	local prds = 0

	for i= 1,#mtch do
		if mtch[i].source == "ingredient" then
			ings = ings + 1
		end
		if mtch[i].source == "product" then
			prds = prds + 1
		end
	end
	
	if ings > 0 then
		if prds > 0 then
			retsource = "combined"
		else
			retsource = "ingredient"
		end
	elseif prds > 0 then
		retsource = "product"
	else
		retsource = "inventory"
	end
	
	blog(2, "<CombineSources()> ings=" .. ings .. " prds=" .. prds .. " returning " .. retsource)
	
	return retsource
end

function DoSearch(event, startIndex, endIndex)
	-- searches specified area for assembling machines, chests etc. then processes their recipes/contents to find the items required
	
	local HighlightSize = 64
	startIndex = startIndex or 1
	endIndex = endIndex or global["BeastFinder"]["SearchItems_max"]
	blog(2, "<DoSearch(event, " .. startIndex .. ", " .. endIndex .. ")>")
	
	local tags = global.BeastFinder.Tags

	local v = tonumber(global["BeastFinder"].range)
	if v == nil or v <= 0 then
		BeastFinder_Status.caption = "Range must be > 0"
		return
	end

	local v = tonumber(global["BeastFinder"].threshold)
	if v == nil or v <= 0 then
		BeastFinder_Status.caption = "Threshold must be > 0"
		return
	end
	
	local player = game.players[event.player_index]
	local box = get_player_box(player)
	
	local ents
	local matches = {}
	
	-- first get target item names as key in table for quick comparison
	local SrchItms = {}
	--log("doSearch global.BeastFinder.SearchItems = " .. serpent.block(global.BeastFinder.SearchItems))
	local itms = global.BeastFinder.SearchItems
	local searchItemCount = 0
	for i = startIndex, endIndex do
		blog(2, "<DoSearch()> SearchItem[" .. i .. "] =")
		if itms[i] ~= nil then
			SrchItms[itms[i].name] = i
			searchItemCount = searchItemCount + 1
		end
	end
	blogb(3, "<DoSearch()> SrchItms=",SrchItms)
	
	if searchItemCount == 0 then
			blog(1, "<DoSearch()> No search items selected?")
	else
		-- Find all *assembling-machines* in area then check their recipes to see if they match
		blog(2, "<DoSearch()> assembling-machines")
		ents = player.surface.find_entities_filtered{area = box, type = "assembling-machine", force = "player"}
		for j, ent in pairs(ents) do
			--log(serpent.line(ent.name) .. "@" .. serpent.line(ent.position) .. " = " .. serpent.line(ent.recipe.name))
			local mtch = checkRecipe(ent.get_recipe(), SrchItms)
			if #mtch > 0 then
				matches[#matches+1] = {entity = ent, matchSig = mtch}
			end
		end
		blog(3, "<DoSearch()> matches so far = " .. #matches)
		
		-- Find all *furnaces* in area then check their recipes to see if they match
		blog(2, "<DoSearch()> furnaces")
		ents = player.surface.find_entities_filtered{area = box, type = "furnace", force = "player"}
		for j, ent in pairs(ents) do
			--log(serpent.line(ent.name) .. "@" .. serpent.line(ent.position) .. " = " .. serpent.line(ent.previous_recipe.name))
			local mtch = checkRecipe(ent.previous_recipe, SrchItms)
			if #mtch > 0  then
				matches[#matches+1] = {entity = ent, matchSig = mtch}
			end
		end
		blog(3, "<DoSearch()> matches so far = " .. #matches)
		
		-- Find all *containers* in area then check their recipes to see if they match
		if global["BeastFinder"]["bInventory"] then
			blog(2, "<DoSearch()> containers")
			ents = player.surface.find_entities_filtered{area = box, type = "container", force = "player"}
			for j, ent in pairs(ents) do
				--log(serpent.line(ent.name) .. "@" .. serpent.line(ent.position))
				local mtch = checkInventory(ent.get_inventory(defines.inventory.chest), SrchItms)
				if #mtch > 0  then
					matches[#matches+1] = {entity = ent, matchSig = mtch}
				end
			end
			
			blog(2, "<DoSearch()> logistic-containers")
			ents = player.surface.find_entities_filtered{area = box, type = "logistic-container", force = "player"}
			for j, ent in pairs(ents) do
				--log(serpent.line(ent.name) .. "@" .. serpent.line(ent.position))
				local mtch = checkInventory(ent.get_inventory(defines.inventory.chest), SrchItms)
				if #mtch > 0  then
					matches[#matches+1] = {entity = ent, matchSig = mtch}
				end
			end			

			-- Find all *containers* in area then check their recipes to see if they match
			blog(2, "<DoSearch()> storage-tanks")
			ents = player.surface.find_entities_filtered{area = box, type = "storage-tank", force = "player"}
			for j, ent in pairs(ents) do
				log(serpent.line(ent.name) .. "@" .. serpent.line(ent.position))

				local mtch = checkFluidBoxes(ent.fluidbox, SrchItms)
				if #mtch > 0  then
					matches[#matches+1] = {entity = ent, matchSig = mtch}
				end
			end				
		end

		blog(1, "<DoSearch()> Found " .. #matches .. " matches.")
		for i=1,#matches do
			if matches[i].entity ~= nil then
				blog(3, "<DoSearch()> matches " .. i .. ": " .. matches[i].entity.name, matches[i].matchSig)						
			end
		end

		-- now we have list of matches[]
		if #matches > 0 then
		
			-- Prepare some things before the loop
			if global["BeastFinder"]["intHighlights"] == 2 then
				-- Normal size highlights
				HighlightSize = 128
			end
			
			-- Match processing loop
			for k = 1,#matches do
				local ent = matches[k].entity
				local otag
				blog(3, "<DoSearch()> processing match " .. k .. " = " .. ent.name)
				
				-- See if we need to use combined ingredient/product marker (typically if a single entity matches both a product & ingredient)
				local newSource = CombineSources(matches[k].matchSig)
				
				-- See if there are any close neighbors (based on configured Threshold)
				blog(3, "<DoSearch()> About to call CheckNeighbors(" .. serpent.line(ent.name) .. ", " .. serpent.line(newSource).. ")")
				nei = CheckNeighbors(ent, newSource, matches[k].matchSig[1].name)
				
				if nei == "true" then	-- only add tag if there is not a close neighbor
					blog(3, "<DoSearch()> close neighbors - NOT adding tag")
				elseif ( tonumber(nei) ~= nil) then		-- Combining tag (ingredient & product match)
					blog(3, "<DoSearch()> close neighbors - combining tag with index ", nei)
					newtag = {
						icon = {type = "virtual", name = "signal-BeastFinder-pinkgreen-border-round"..HighlightSize},
						position = tags[nei].tag.position,
						target = tags[nei].tag.target
					}					
					tags[nei].tag.destroy()					
					otag = player.force.add_chart_tag(player.surface, newtag)
					tags[nei].tag = otag
					tags[nei].source = "combined"
				elseif nei == "false" then		-- No close neighbors so just add the tag
					blog(3, "<DoSearch()> No close neighbors - adding tag. newSource=", newSource)
					newtag = {
						icon = {},
						position = ent.position,
						target = ent
					}

					--log("newtag1 = " .. serpent.line(newtag))
					--log("ent.type = " .. serpent.line(ent.type))
					if newSource == "inventory" then
						newtag.icon = {type = "virtual", name = "signal-BeastFinder-cyan-border-square"..HighlightSize}
					elseif newSource == "product" then
						newtag.icon = {type = "virtual", name = "signal-BeastFinder-green-border-round"..HighlightSize}
					elseif newSource == "ingredient" then
						newtag.icon = {type = "virtual", name = "signal-BeastFinder-pink-border-round"..HighlightSize}
					else
						newtag.icon = {type = "virtual", name = "signal-BeastFinder-pinkgreen-border-round"..HighlightSize}
					end
		
					--blog(3, "<DoSearch()> global['BeastFinder']=", global["BeastFinder"])	
					-- Add the highlight tag
					blog(3, "<DoSearch()> About to add tag=", newtag)	
					otag = player.force.add_chart_tag(player.surface, newtag)

					blog(3, "<DoSearch()> add return tag=", otag.icon.name)	
					tags[#tags+1] = {tag = otag, source = newSource}
						
					-- Add the item tag
					blog(3, "<DoSearch()> preparing 2nd tag from:", matches[k].matchSig)					
					newtag.icon = {type = matches[k].matchSig[1].type, name = matches[k].matchSig[1].name}
					--blogb(3, "<DoSearch()> Adding 2nd tag = ", newtag)					
					otag = player.force.add_chart_tag(player.surface, newtag)
					tags[#tags+1] = {tag = otag, source = "entity"}
				else
					blog(1, "<DoSearch()> Unexpected return from CheckNeighbors = ", nei)
				end
			end
		end
	end
	
	-- Done. Update status bar.
	local msg = serpent.line(#matches)
	msg = msg .. " 😄"
	
	if (#matches > 0) and (#matches > (#tags / 2)) then
		msg = msg .. " " .. (#tags / 2) .. " ⨀"
	end
	BeastFinder_Status.caption = msg
	blog(2, "<DoSearch()> Done. Status =", msg)

end

function ClearTags(player)

	blogb(3, "<ClearTags)> Tags =", global.BeastFinder.Tags)
	local ii = 0
	if global.BeastFinder.Tags ~= nil then
		for k, tag in pairs (global.BeastFinder.Tags) do
			if tag.tag and tag.tag.valid then
				tag.tag.destroy()
				ii = ii + 1
			end
		end
		global.BeastFinder.Tags = {}
		if mod_gui.get_frame_flow(player).frame_BeastFinder then
			BeastFinder_Status.caption = ii .." Tags cleared"
		end
	end 		
	
end

function ClearItems(player)

	blogb(2, "<ClearItems)>")
	-- Clear them from global so they dont come back!
	global["BeastFinder"]["SearchItems"] = {}
	
	-- Clear the items from the elem chooser
	local subchilds
	if BeastFinder_Matrix ~= nil then
		local subs = BeastFinder_Matrix.children
		if subs ~= nil then
			for k=1,#subs do
				subchilds = subs[k].children
				subchilds[1].elem_value = nil
			end
		else
			-- Didn't find children - probably because the GUI was open in the loaded savegame.
			-- just close the GUI instead (since global is cleared above)
			close_guis(player)
		end
	end 

	
end
script.on_init(function()

	blog(2, "<on_init()>")

    glob_init()

    for _, player in pairs(game.players) do	
		toolbar_init(player)
        gui_init(player, false)
    end

end)

script.on_load(function()

	blog(2, "<on_load()>")

    --glob_init()

end)


script.on_configuration_changed(function(data)
	blog(2, "<on_configuration_changed()>")

	if not data or not data.mod_changes then
		return
	end

	if data.mod_changes["BeastFinder"] then    
		for k, player in pairs (game.players) do
			glob_init()
			toolbar_init(player)
			gui_init(player)
		end 
	end

end)

script.on_event(defines.events.on_player_joined_game, function(event)
	blog(2, "<on_event-on_player_joined_game()>")

	local player = game.players[event.player_index] 
	toolbar_init(player)
	gui_init(player)
end)

script.on_event(defines.events.on_gui_click, function(event) 

    local element = event.element
	local player = game.players[event.player_index]   
	--log("<on_event-on_gui_click(" .. element.name .. ")>")
    if element.name == "beastfinder-menu-button" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		if event.button == defines.mouse_button_type.right then
			ClearTags(player)
		else
			ToggleSearchGui(player)
		end
		
    elseif element.name == "bf666_but_BeastFinder_settings" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		ToggleSettingsGui(player)
		
    elseif element.name == "bf666_but_BeastFinder_settings_zap" then
		-- This searches for tags that match the BeastFinder format and deletes them
		-- This is in contrast to the normal "clear tags" function that deletes only the tags it created.
		-- Useful if things get out of sync... typically during testing, but perhaps after a crash also?
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		local box = get_player_box(player)
		local tgs = player.force.find_chart_tags(player.surface, box)
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")> found matches: ", #tgs)
		local zapCounter = 0
		local Tags2Del = {}
		for i, t in ipairs(tgs) do
			blog(3, "<on_event-on_gui_click(" .. element.name .. ")> Tag " .. i)
			if t.valid then
				if t.icon == nil then 
					local logmsg = "Invalid icon for tag. Serpent: pos=" .. serpent.line(t.position) .. ", tag=" .. serpent.line(t.tag_number)
					if t.last_user ~= nil then logmsg = logmsg .. ", user=" .. t.last_user.name end
					logmsg = logmsg .. ", text=" .. serpent.line(t.text)
					if t.target ~= nil then logmsg = logmsg .. ", target=" .. t.target.name end
					
					blog(3, "<on_event-on_gui_click(" .. element.name .. ")> " .. logmsg)
				else
					blog(3, "<on_event-on_gui_click(" .. element.name .. ")> Tag valid = " .. t.icon.name)
					if t.icon.name:find("^signal%-BeastFinder") ~= nil then
						-- Match for boundry tag - see if any other tags at same location
						for i2,t2 in ipairs(tgs) do
							if t2.valid then
								if t.position.x == t2.position.x then
									if t.position.y == t2.position.y then									
										Tags2Del[#Tags2Del+1] = t2
										blog(3, "<on_event-on_gui_click(" .. element.name .. ")> Tag at same location added for destroy as Tags2Del[" .. #Tags2Del .. "]")
									end
								end
							end
						end
						Tags2Del[#Tags2Del+1] = t
						blog(3, "<on_event-on_gui_click(" .. element.name .. ")> Added for destroy as Tags2Del[" .. #Tags2Del .. "]")
					end
				end
			end
		end
		
		for i = 1,#Tags2Del do
			if Tags2Del[i].valid then
				blog(2, "<on_event-on_gui_click(" .. element.name .. ")> Destroy = " .. i)
				Tags2Del[i].destroy()
				zapCounter = zapCounter + 1
			end
		end
		
		blog(3, "<on_event-on_gui_click(" .. element.name .. ")> zapCounter =" .. zapCounter)
		BeastFinder_Status.caption = tostring(zapCounter) .. " tags zapped."
				
    elseif element.name == "bf666_but_Beast_ClearTags" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		
		ClearTags(player)

    elseif element.name == "bf666_but_Beast_ClearItems" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		
		ClearItems(player)

	elseif element.name == "bf666_but_Beast_search_all" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		if global["BeastFinder"]["bAutoClearAll"] then
			ClearTags(player)
		end
		DoSearch(event)
	
	elseif element.name == "bf666_but_Beast_close" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		close_guis(player)
		
	elseif element.name == "bf666_but_Beast_settings_close" then
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")

		if mod_gui.get_frame_flow(player).frame_BeastFinder_settings then
			mod_gui.get_frame_flow(player).frame_BeastFinder_settings.destroy()
		end

	elseif element.name:find("^bf666_but_Beast_searchMatrix_") ~= nil then
		-- Figure out which individual search button was clicked
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")>")
		index = tonumber(element.name:match("_(%d+)$"))
		blog(2, "<on_event-on_gui_click(" .. element.name .. ")> Index =", index)	
		
		if global["BeastFinder"]["bAutoClearItem"] then
			ClearTags(player)
		end
		
		DoSearch(event, index, index)			
	end			
	
end)

script.on_event(defines.events.on_gui_text_changed, function(event) 

    local element = event.element
	local player = game.players[event.player_index]     
	
	if element.name == "bf666_txt_Range" then
		blog(2, "<on_event-on_gui_text_changed(" .. element.name .. ")> =", element.text)
		global["BeastFinder"].range = element.text
	elseif element.name == "bf666_txt_Threshold" then
		blog(2, "<on_event-on_gui_text_changed(" .. element.name .. ")> =", element.text)
		global["BeastFinder"].threshold = element.text
	end
 
end)

script.on_event(defines.events.on_gui_elem_changed, function(event) 

	if event.element.name:find("^bf666_item_beast_select_") ~= nil then
		local element = event.element
		local player = game.players[event.player_index]     
		blog(2, "<on_event-on_gui_elem_changed(" .. element.name .. ")> =", element.elem_value)
		index = tonumber(element.name:match("_(%d+)$"))
		blog(2, "<on_event-on_gui_elem_changed(" .. element.name .. ")> Index =", index)
				
		global["BeastFinder"]["SearchItems"][index] = element.elem_value 		
		blogb(3, "<on_event-on_gui_elem_changed(" .. element.name  .. ")> Global.BeastFinder =", global["BeastFinder"])
	end	
	
end)

script.on_event(defines.events.on_gui_checked_state_changed, function(event) 

	if event.element.name == "bf666_chk_Beast_ingredients" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bIngredients"] = event.element.state
		
	elseif event.element.name == "bf666_chk_Beast_products" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bProducts"] = event.element.state		
		
	elseif event.element.name == "bf666_chk_Beast_inventory" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bInventory"] = event.element.state		

	elseif event.element.name == "bf666_chk_Beast_AutoClear_All" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bAutoClearAll"] = event.element.state

	elseif event.element.name == "bf666_chk_Beast_AutoClear_Item" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bAutoClearItem"] = event.element.state

	elseif event.element.name == "bf666_chk_Beast_AutoClear_GUIclose" then
		blog(2, "<on_event-on_gui_click(" .. event.element.name .. ")>")
		global["BeastFinder"]["bAutoClearGUIclose"] = event.element.state

	end
	
end)

script.on_event(defines.events.on_gui_selection_state_changed, function(event) 

	if event.element.name == "bf666_drop_Beast_Highlights" then
		blog(2, "<on_event-on_gui_dropdown(" .. event.element.name .. ")>")
		global["BeastFinder"]["intHighlights"] = event.element.selected_index
	end
	
end)