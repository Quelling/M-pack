
-- *** REMOTE INTERFACES *** --

-- Keep separate remote functions for logging if nothing else
function remoteToggleSearchGui(player)
	blog(1, "<remoteToggleSearchGui(" .. player.name .. ")>")
	ToggleSearchGui(player)
end

function remoteReset(player)
	blog(1, "<remoteReset(" .. player.name .. ")>")
	global["BeastFinder"] = {}
	glob_init()
	toolbar_init(player)
	
	player.print("BeastFinder: " .. player.name .. " reset.")
end

remote.add_interface("BeastFinder", {ToggleSearchGui = remoteToggleSearchGui, Reset = remoteReset})

-- *** SHORTCUT EVENTS *** --
					 
script.on_event("beastfinder-hotkey-togglesearchgui", function(event)

	blog(2, "<on_event-beastfinder-hotkey-togglesearchgui(" .. event.name .. ")>")

	ToggleSearchGui(game.players[event.player_index])
	
end)					 