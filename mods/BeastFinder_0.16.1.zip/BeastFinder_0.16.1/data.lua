require("shortcuts")
require("prototypes.BeastStyles")
require("prototypes.BeastFinderSprites")
require("prototypes.BeastFinderSignals")