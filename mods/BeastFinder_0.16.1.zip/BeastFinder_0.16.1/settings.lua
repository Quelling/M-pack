data:extend{
	{
		type = "bool-setting",
		name = "BeastFinder-show-toolbar",
		setting_type = "startup",
		default_value = true,
		order = "a",
	},
	-- {
		-- type = "bool-setting",
		-- name = "BeastFinder-horizontal",
		-- setting_type = "startup",
		-- default_value = true,
		-- order = "b",
	-- },
	{
		type = "int-setting",
		name = "BeastFinder-Rows",
		setting_type = "startup",
		default_value = "5",
		allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
		order = "c",
	},
	{
		type = "int-setting",
		name = "BeastFinder-Cols",
		setting_type = "startup",
		default_value = "2",
		allowed_values = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
		order = "d",
	},

}
