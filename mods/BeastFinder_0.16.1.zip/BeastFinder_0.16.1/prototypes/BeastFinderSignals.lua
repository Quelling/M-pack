data:extend({
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-green-border-round64",
    icon = "__BeastFinder__/graphics/BorderGreen64r.png",
	icon_size = 64,
    subgroup = "virtual-signal-color",
    order = "zz064a"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-pink-border-round64",
    icon = "__BeastFinder__/graphics/BorderPink64r.png",
	icon_size = 64,
    subgroup = "virtual-signal-color",
    order = "zz064b"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-pinkgreen-border-round64",
    icon = "__BeastFinder__/graphics/BorderPinkGreen64r.png",
	icon_size = 64,
    subgroup = "virtual-signal-color",
    order = "zz064c"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-cyan-border-square64",
    icon = "__BeastFinder__/graphics/BorderCyan64s.png",
	icon_size = 64,
    subgroup = "virtual-signal-color",
    order = "zz064d"
  },	
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-green-border-round128",
    icon = "__BeastFinder__/graphics/BorderGreen128r.png",
	icon_size = 128,
    subgroup = "virtual-signal-color",
    order = "zz128a"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-pink-border-round128",
    icon = "__BeastFinder__/graphics/BorderPink128r.png",
	icon_size = 128,
    subgroup = "virtual-signal-color",
    order = "zz128b"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-pinkgreen-border-round128",
    icon = "__BeastFinder__/graphics/BorderPinkGreen128r.png",
	icon_size = 128,
    subgroup = "virtual-signal-color",
    order = "zz128c"
  },
  {
    type = "virtual-signal",
    name = "signal-BeastFinder-cyan-border-square128",
    icon = "__BeastFinder__/graphics/BorderCyan128s.png",
	icon_size = 128,
    subgroup = "virtual-signal-color",
    order = "zz128d"
  }
})