-------------------------------------------------------------------------------
--[[STYLES and BUTTON SPRITES]]--
-------------------------------------------------------------------------------
local style = data.raw["gui-style"].default

data:extend{
    {
        type = "font",
        name = "font_Beast",
        from = "default",
        border = false,
        size = 15
    },
    {
        type = "font",
        name = "font_bold_Beast",
        from = "default-bold",
        border = false,
        size = 15
    },
    {
        type = "font",
        name = "font_invisible_Beast",
        from = "default",
        border = false,
		font_color = {r = 1, g = 1, b = 1, a = 0},
        size = 15		
    },	
}

style.frame_Beast_style =
{
    type="frame_style",
    parent="frame",
    top_padding = 0,
    right_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    resize_row_to_width = true,
    resize_to_row_height = false,
    -- max_on_row = 1,
}
style.sprite_Beast_filter_style =
{
	type="frame_style",
	parent="frame_Beast_style",
	graphical_set =
	{
		type = "monolith",
		top_monolith_border = 1,
		right_monolith_border = 1,
		bottom_monolith_border = 1,
		left_monolith_border = 1,
		monolith_image =
		{
			filename = "__core__/graphics/gui.png",
			priority = "extra-high-no-scale",
			width = 36,
			height = 36,
			x = 75,
			y = 108
		}
	}
}

style.flow_Beast_style =
{
    type = "flow_style",

    top_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    right_padding = 0,

    horizontal_spacing = 2,
    vertical_spacing = 2,
    resize_row_to_width = true,
    resize_to_row_height = false,
    max_on_row = 1,

    graphical_set = { type = "none" },
}

style.table_Beast_style = {
    type = "table_style",
    parent = "table",
    top_padding = 2,
    bottom_padding = 0,
    right_padding = 0,
    left_padding = 0,
    cell_spacing = 0,
    horizontal_spacing = 2,
    vertical_spacing = 2,
}

style.label_Beast_style =
{
    type="label_style",
    parent="label",
    font="font_Beast",
    align = "left",
    top_padding = 1,
    right_padding = 1,
    bottom_padding = 0,
    left_padding = 1,
}

style.label_status_Beast_style =
{
    type="label_style",
    parent="label_Beast_style",
    minimal_width = 48,
	maximal_width = 64,
	single_line = false
}
style.label_title_Beast_style =
{
    type="label_style",
    parent="label",
    font="font_Beast",
    align = "left",
    top_padding = 1,
    right_padding = 1,
    bottom_padding = 0,
    left_padding = 1,
	font_color = {r = 138, b = 7, g =7}
	
}

style.label_Beast_spacing_style =
{
    type="label_style",
    parent="label",
    font="font_invisible_Beast",
    align = "left",
    top_padding = 1,
    right_padding = 1,
    bottom_padding = 1,
    left_padding = 1,
}

style.label_bold_Beast_style =
{
    type="label_style",
    parent="label_Beast_style",
    font="font_bold_Beast",
    default_font_color={r=1, g=1, b=0.5},
    hovered_font_color={r=1, g=1, b=0.5},
}

style.textfield_Beast_style =
{
    type = "textfield_style",
    font="font_bold_Beast",
    align = "left",
    font_color = {},
    default_font_color={r=1, g=1, b=1},
    hovered_font_color={r=1, g=1, b=1},
    selection_background_color= {r=0.66, g=0.7, b=0.83},
    top_padding = 0,
    bottom_padding = 0,
    left_padding = 1,
    right_padding = 5,
    minimal_width = 300,
    maximal_width = 600,
    graphical_set =
    {
        type = "composition",
        filename = "__core__/graphics/gui.png",
        priority = "extra-high-no-scale",
        corner_size = {3, 3},
        position = {16, 0}
    },
}
style.textfield_Beast_short_style =
{
    type = "textfield_style",
    font="font_bold_Beast",
    align = "left",
    font_color = {},
    default_font_color={r=1, g=1, b=1},
    hovered_font_color={r=1, g=1, b=1},
    selection_background_color= {r=0.66, g=0.7, b=0.83},
    top_padding = 0,
    bottom_padding = 0,
    left_padding = 1,
    right_padding = 5,
    minimal_width = 50,
    maximal_width = 100,
    graphical_set =
    {
        type = "composition",
        filename = "__core__/graphics/gui.png",
        priority = "extra-high-no-scale",
        corner_size = {3, 3},
        position = {16, 0}
    },
}
style.textbox_Beast_style =
{
    type = "textbox_style",
    font="font_bold_Beast",
    --align = "left",
    font_color = {},
    default_font_color={r=1, g=1, b=1},
    hovered_font_color={r=1, g=1, b=1},
    selection_background_color= {r=0.66, g=0.7, b=0.83},
    top_padding = 0,
    bottom_padding = 0,
    left_padding = 1,
    right_padding = 5,
    minimal_width = 275,
    minimal_height = 75,
    maximal_width = 275,
    graphical_set =
    {
        type = "composition",
        filename = "__core__/graphics/gui.png",
        priority = "extra-high-no-scale",
        corner_size = {3, 3},
        position = {16, 0}
    },
}

style.button_Beast_style =
{
    type="button_style",
    parent="button",
    font="font_bold_Beast",
    align = "center",
    default_font_color={r=1, g=1, b=1},
    hovered_font_color={r=1, g=1, b=1},
    top_padding = 0,
    right_padding = 0,
    bottom_padding = 0,
    left_padding = 0,
    left_click_sound =
    {
        {
            filename = "__core__/sound/gui-click.ogg",
            volume = 1
        }
    },
}

style.button25_Beast_style =
{
    type="button_style",
    parent="mod_gui_button",
	minimal_width = 25,
	height = 25
}

style.button32_Beast_style =
{
    type="button_style",
    parent="mod_gui_button",
	minimal_width = 32,
	height = 32
}

style.buttonMoo_Beast_style =
{
    type="button_style",
    parent="mod_gui_button",
	minimal_width = 25,
	height = 25,
    left_click_sound =
    {
        {
            filename = "__BeastFinder__/sounds/CowMoooo.ogg",
            volume = 1
        }
    },
}

style.checkbox_Beast_style =
{
    type = "checkbox_style",
    parent="checkbox",
    font = "font_bold_Beast",
    font_color = {r=1, g=1, b=1},
    top_padding = 8,
    bottom_padding = 0,
    left_padding = 5,
    right_padding = 2,
    -- minimal_height = 32,
    -- maximal_height = 32,
}

style.progressbar_Beast_GreyBack_style =
{
	type = "progressbar_style",
	parent="progressbar",
	smooth_size = 50,
	smooth_color = {g = 0.33, b = 0.66},
	width = 100,
	height = 5,
	left_padding = 2,
	right_padding = 2,
	smooth_bar_background =
	{
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		width = 1,
		height = 7,
		x = 225
	}
}

