data:extend(
	{
		{
			type = "recipe",
			name = "Diesel-Locomotive-fluid-locomotive",
			enabled = false,
			energy_required = 4,
			ingredients = {
				{"engine-unit", 20},
				{"electronic-circuit", 10},
				{"storage-tank", 3}
			},
			result = "Diesel-Locomotive-fluid-locomotive",
		}
	}
)