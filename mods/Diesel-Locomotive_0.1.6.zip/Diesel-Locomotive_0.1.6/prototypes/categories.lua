local fluid_fuel_category = {
	type = "fuel-category",
	name = "Diesel-Locomotive-fluid"
}
data:extend({fluid_fuel_category})
