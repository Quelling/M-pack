data:extend({
  {
    type = "recipe",
    name = "space-science-pack",
    enabled = false,
    energy_required = 12,
    ingredients = {{"alien-artifact", 1}
    },
    result = "space-science-pack",
    result_count = 2
  },
})