require("prototypes.item.alien_artifacts")
require("prototypes.recipe")
require("prototypes.technology")
