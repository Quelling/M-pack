data:extend({
    {
        type = "int-setting",
        name = "nuclear-landmines-trigger-radius",
        setting_type = "startup",
        default_value = 15,
        minimum_value = 1,
        maximum_value = 100,
        order = "nuclear-landmines-aa[trigger-radius]",
    },
})