
-- Clone landmine entity and change graphics and settings
local entity = table.deepcopy(data.raw['land-mine']['land-mine'])
entity.name = 'nuclear-landmine'
entity.icon = '__Nuclear Landmines__/graphics/icon.png'
entity.minable.result = 'nuclear-landmine'
entity.picture_safe.filename = '__Nuclear Landmines__/graphics/entity.png'
entity.picture_set.filename = '__Nuclear Landmines__/graphics/entity-set.png'
entity.trigger_radius = settings.startup['nuclear-landmines-trigger-radius'].value

-- Set explosion equal to atomic rocket explosion
entity.action = {
	type = 'direct', 
	action_delivery = table.deepcopy(data.raw['projectile']['atomic-rocket'].action.action_delivery)
}

-- Move explosion effects from target to source
entity.action.action_delivery.source_effects = entity.action.action_delivery.target_effects
entity.action.action_delivery.target_effects = nil

-- Clone item
local item = table.deepcopy(data.raw['item']['land-mine'])
item.name = entity.name
item.icon = entity.icon
item.place_result = entity.name
item.trigger_radius = entity.trigger_radius

-- Clone recipe
local recipe = table.deepcopy(data.raw['recipe']['land-mine'])
recipe.name = item.name
recipe.ingredients = {
	{"land-mine", 1},
	{"atomic-bomb", 1},
}
recipe.result = item.name
recipe.result_count = 1

-- Insert new prototypes
data:extend({
	entity,
	item,
	recipe,
})

-- Make atomic bomb technology unlock nuclear landmines
table.insert(data.raw['technology']['atomic-bomb'].effects, {
	type = 'unlock-recipe',
	recipe = 'nuclear-landmine',
})
