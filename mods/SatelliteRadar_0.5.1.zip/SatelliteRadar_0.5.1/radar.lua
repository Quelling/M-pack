require("advanced-settings")

for i=1,maxlevel,1 do

  local satellite_radar = util.table.deepcopy(data.raw["radar"]["radar"])
  local satellite_radar_item = util.table.deepcopy(data.raw.item["radar"])

  --the time to scan a sector is controlled by this variable: lower energy = faster scanning
  --the energy decays from 10 to 1 as level increases
  energy=10-9*(SatelliteEquation(i))/SatelliteEquation(maxlevel)

  satellite_radar.name = "satellite-radar-"..i
  --the next three lines are the only parameters changed by each level of this mod
  satellite_radar.energy_per_sector = energy.."MJ"
  satellite_radar.max_distance_of_sector_revealed = math.floor(29/7.*i+14)
  satellite_radar.max_distance_of_nearby_sector_revealed = 3+i

  data:extend({satellite_radar})

  satellite_radar_item.name = "satellite-radar-"..i
  satellite_radar_item.place_result = "satellite-radar-"..i

  data:extend({satellite_radar_item})
end
