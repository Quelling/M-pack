data:extend({
  {
    type = "double-setting",
    name = "satellite-radar-scaling",
    setting_type = "startup",
    default_value = 1,
	minimum_value = 0.1,
  }
})