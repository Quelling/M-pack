require("prototypes.entity.gun")
require("prototypes.entity.ship")

table.insert(data.raw["technology"]["automobilism"].effects, {type="unlock-recipe", recipe="basic-ship"})

if data.raw["technology"]["bob-tanks-2"] then
table.insert(data.raw["technology"]["bob-tanks-2"].effects, {type="unlock-recipe", recipe="basic-ship-2"})
table.insert(data.raw["technology"]["bob-tanks-3"].effects, {type="unlock-recipe", recipe="basic-ship-3"})
end