
script.on_configuration_changed(function(data)
	if data.mod_changes ~= nil and data.mod_changes["Ships"] ~= nil and data.mod_changes["Ships"].old_version == nil then
		-- "My Mod" was added to an existing game
	end
	
	
	for k, v in pairs(game.forces) do
        if v.technologies["automobilism"].researched then
            v.recipes["basic-ship"].enabled = true
        end
        if v.technologies["bob-tanks-2"] and v.technologies["bob-tanks-2"].researched then
            v.recipes["basic-ship-2"].enabled = true
        end
        if v.technologies["bob-tanks-3"] and v.technologies["bob-tanks-3"].researched then
            v.recipes["basic-ship-3"].enabled = true
        end
    end
end)

script.on_load(function(data)
	
end)
script.on_init(function(data)
	
end)
