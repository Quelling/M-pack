table.insert(data.raw["technology"]["steel-processing"].effects,{type="unlock-recipe",recipe="repair-pack-mk2"})
table.insert(data.raw["technology"]["titanium-processing"].effects,{type="unlock-recipe",recipe="repair-pack-mk3"})
table.insert(data.raw["technology"]["tungsten-processing"].effects,{type="unlock-recipe",recipe="repair-pack-mk4"})
