data:extend(
{
	{
		type = "recipe",
		name = "napalm-artillery-shell",
		enabled = false,
		energy_required = 120,
		ingredients =
		{
			{"heavy-oil-barrel", 2},
			{"cluster-grenade",1},			
			{"explosive-cannon-shell", 3},
			{"effectivity-module-2", 1},
			{"radar", 1}
		},
		result = "napalm-artillery-shell"
	}
}
)