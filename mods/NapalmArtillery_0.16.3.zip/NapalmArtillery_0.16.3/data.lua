require("prototypes.recipe")
require("prototypes.projectiles")
require("prototypes.item")
require("prototypes.technology")
