local names = require("prototypes.names")
local util = require("prototypes.util")

local tech = {}
tech.loader = {
    type = "technology",
    name = names.tech.loader,
    icon = util.filePath(names.tech.loader, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 20,
        ingredients = {
            {"science-pack-1", 1}
        },
        time = 20
    },
    effects = {
        {
            type = "unlock-recipe",
            recipe = names.loaderChest
        }
        -- {
        --     type = "nothing"
        --     effect_description = {"ammo-loader-tech-ammo", }
        -- }
    },
    prerequisites = {"logistics", "turrets"}
}
tech.requester1 = {
    type = "technology",
    name = names.tech.requester,
    icon = util.filePath(names.tech.requester, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 100,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1}
        },
        time = 20
    },
    effects = {
        {
            type = "unlock-recipe",
            recipe = names.requesterChest
        }
    },
    prerequisites = {"logistic-system", names.tech.loader}
}
tech.vehicles = {
    type = "technology",
    name = names.tech.vehicles,
    icon = util.filePath(names.tech.vehicles, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 50,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1}
        },
        time = 15
    },
    effects = {},
    prerequisites = {names.tech.loader, "automobilism"}
}
tech.burners = {
    type = "technology",
    name = names.tech.burners,
    icon = util.filePath(names.tech.burners, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 35,
        ingredients = {
            {"science-pack-1", 1}
        },
        time = 20
    },
    effects = {},
    prerequisites = {names.tech.loader}
}
tech.artillery = {
    type = "technology",
    name = names.tech.artillery,
    icon = util.filePath(names.tech.artillery, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 300,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
            {"high-tech-science-pack", 1}
        },
        time = 20
    },
    effects = {},
    prerequisites = {names.tech.loader, "artillery"}
}
tech.upgrade = {
    type = "technology",
    name = names.tech.upgrade,
    icon = util.filePath(names.tech.upgrade, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 100,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"military-science-pack", 1}
        },
        time = 20
    },
    effects = {
        {
            type = "unlock-recipe",
            recipe = names.storageChest
        }
    },
    prerequisites = {"logistic-robotics", names.tech.loader}
}
tech.returnItems = {
    type = "technology",
    name = names.tech.returnItems,
    icon = util.filePath(names.tech.returnItems, "technology"),
    icon_size = 64,
    order = "az",
    unit = {
        count = 50,
        ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1}
        },
        time = 15
    },
    prerequisites = {names.tech.storage}
}

-- if (settings.startup["ammo_loader_bypass_research"].value == false) then
for name, t in pairs(tech) do
    data:extend({t})
end
-- end
