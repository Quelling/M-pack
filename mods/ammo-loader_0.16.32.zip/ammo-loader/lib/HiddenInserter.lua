--[[--
Class with unique id's representing the hidden inserters for slots.
@classmod HI
@alias HiddenInserter
]]
local HI = {}
local HiddenInserter = HI

HI.className = "HiddenInserter"
HI.dbName = HI.className
DB.register(HI.dbName)
HI.protoName = "ammo-loader-hidden-inserter"
HI.wire = defines.wire_type.green

HI.objMT = {
    __index = HI
}

function HI._init()
    local list = util.allFind({name = HI.protoName})
    for i = 1, #list do
        local ent = list[i]
        local held = ent.held_stack
        if isValid(held) and (held.valid_for_read) then
            local heldStack = {name = held.name, count = held.count}
            local pickup = ent.pickup_target
            if (heldStack.count > 0) and (isValid(pickup)) then
                local amtPickup = pickup.insert(heldStack)
                heldStack.count = heldStack.count - amtPickup
            end
            local drop = ent.drop_target
            if (heldStack.count > 0) and (isValid(drop)) then
                local amtDrop = drop.insert(heldStack)
                heldStack.count = heldStack.count - amtDrop
            end
        end
        ent.destroy()
    end
    -- DB.new(HI.dbName)
end
Init.registerInitFunc(HI._init)

function HI._onLoad()
    for id, obj in pairs(DB.getAll(HI.dbName)) do
        setmetatable(obj, HI.objMT)
        -- setmetatable(obj.connectedQ, idQ.objMT)
    end
end
Init.registerOnLoadFunc(HI._onLoad)

-- function HI.protoName()
--     return "ammo-loader-hidden-inserter"
-- end
function HI.getFuelStack()
    local fuelName = "ammo-loader-superfuel"
    return {name = fuelName, count = 1000}
end

function HI.dbInsert(self)
    return DB.insert(HI.dbName, self)
end

function HI.getObj(id)
    return DB.getObj(HI.dbName, id)
end

function HI.destroyAll()
    for id, obj in pairs(DB.getAll(HI.dbName)) do
        obj:destroy()
    end
end

function HI.new(slotObj)
    if (not slotObj) or (not slotObj:isValid()) then
        return nil
    end

    local obj = {}
    setmetatable(obj, HI.objMT)

    obj.parentID = slotObj.id
    -- obj.sourcePosition = {}
    -- obj.targetPosition = slotObj.id
    -- obj.itemName = itemName

    local newInserter =
        slotObj.ent.surface.create_entity({name = protoNames.hiddenInserter, position = slotObj:position(), force = slotObj.forceName})
    if not isValid(newInserter) then
        return nil
    end

    -- newInserter.pickup_position = chestObj.ent.position
    -- newInserter.drop_position = SL.position(slotObj)
    -- newInserter.set_filter(1, itemName)
    newInserter.destructible = false
    newInserter.inserter_stack_size_override = 1
    newInserter.burner.inventory.insert(HI.getFuelStack())
    -- newInserter.active = false

    obj.ent = newInserter
    -- obj.controlBehavior = newInserter.get_or_create_control_behavior()
    -- local control = obj.controlBehavior
    -- control.circuit_mode_of_operation = defines.control_behavior.inserter.circuit_mode_of_operation.set_filters
    -- obj.connectedIDs = {}
    -- obj.connectedQ = idQ.new(TC)
    obj.id = HI.dbInsert(obj)

    -- HI.checkCircuits(obj)
    -- local nextLowest = SL.getNextLowestScore(slotObj)
    -- Array.insert(slotObj.inserterIDs, obj)

    return obj
end

-- HI.getControlBehavior = function(self)
--     return self.ent.get_or_create_control_behavior()
-- end

HI.getPickupPosition = function(self)
    if not self.filterName then
        return nil
    end
    return TC.getObj(self.sourceID):position()
end
HI.pickupPosition = HI.getPickupPosition
HI.pickupPos = HI.getPickupPosition

HI.setPickupPosition = function(self, val)
    -- if (not self.sourceID) and (not val) then
    --     return nil
    -- end
    self.ent.pickup_position = val
end

HI.getDropPosition = function(self)
    return self.ent.drop_position
end
HI.dropPosition = HI.getDropPosition
HI.dropPos = HI.getDropPosition

HI.setDropPosition = function(self, val)
    self.ent.drop_position = val
end

HI.getPickupTarget = function(self)
    if (not self.sourceID) then
        return nil
    end
    local chest = TC.getObj(self.sourceID)
    return chest
end
HI.pickupTarget = HI.getPickupTarget

HI.setPickupTarget = function(self, chestObj)
    if (not chestObj) then
        self:setFilter(nil)
    end
    self.sourceID = chestObj.id
    return self:setPickupPosition(chestObj:position())
end

HI.getDropTarget = function(self)
    return self.ent.drop_target
end
HI.dropTarget = HI.getDropTarget

HI.getFilterInfo = function(self)
    return ItemDB.item.get(self.filterName)
end
HI.filterInfo = HI.getFilterInfo
HI.itemInfo = HI.filterInfo
HI.filter = HI.filterInfo

HI.setFilter = function(self, val)
    self.filterName = val
    self.ent.set_filter(1, val)
end

HI.getItemScore = function(self)
    return self:getFilterInfo().score
end

HI.getSlotObj = function(self)
    return SL.getObj(self.parentID)
end
HI.slotObj = HI.getSlotObj
HI.parent = HI.getSlotObj

function HI.isValid(self)
    if (not self) then
        return false
    end
    if (not isValid(self.ent)) or (not self:parent()) then
        return false
    end
    return true
end

function HI.setSourceAndItem(self, chestObj, item)
    if (not chestObj) then
        self.sourceID = nil
        self.filterName = nil
        self:setFilter(nil)
        return
    end
    local it = item or chestObj.provItem
    self:setPickupTarget(chestObj)
    self:setFilter(it)
end

function HI.giveHeld(self)
    local ent = self.ent
    local heldStack = ent.held_stack
    if (not heldStack) or (not heldStack.valid_for_read) then
        return -1
    end
    local amt = heldStack.count
    local itemName = heldStack.name
    local slotObj = self:parent()
    local slot = slotObj:slot()
    if (heldStack.count > 0) and (slotObj ~= nil) then
        local newStack = slotObj:itemStack()
        if (not newStack.name) or (newStack.name == heldStack.name) then
            newStack.name = heldStack.name
            newStack.count = newStack.count + heldStack.count
            slot.set_stack(newStack)
            local slotStack = slotObj:itemStack()
            local remaining = newStack.count - slotStack.count
            heldStack.count = remaining
        end
    end
    local source = self:pickupTarget()
    if (heldStack.count > 0) and (source ~= nil) then
        local amtSource = source.inv.insert(heldStack)
        heldStack.count = heldStack.count - amtSource
    end
    if (heldStack.count > 0) then
        ent.surface.spill_item_stack(ent.position, heldStack)
    end
end

function HI.destroy(self)
    -- if not self then
    --     return nil
    -- end
    -- local insList = self.slotObj.inserterIDs
    -- Array.remove(insList, self.id)
    self:giveHeld()
    DB.deleteID(HI.dbName, self.id)
    self.ent.destroy()
    return true
end
return HiddenInserter
