regroup = {}
regroup.settings = {}
mods = mods or {}
z_debug = false


regroup.settings.custom_order = settings.startup["regroup-custom_order"].value
regroup.settings.graphics_tuning = settings.startup["regroup-graphics_tuning"].value
regroup.settings.ignore_all = settings.startup["regroup-ignore_all"].value
regroup.settings.prevent_hiding = settings.startup["regroup-prevent_hiding"].value
regroup.settings.flow_control = settings.startup["regroup-flow_control"].value
regroup.settings.vanilla = settings.startup["regroup-vanilla"].value
regroup.settings.barreling_sort = settings.startup["regroup-barrel_sorting"].value
regroup.settings.liquid_move = settings.startup["regroup-liquid_move"].value
regroup.settings.dim = settings.startup["regroup-dim"].value
regroup.settings.factorio_extended = settings.startup["regroup-factorio_extended"].value
regroup.settings.hide_canisters = settings.startup["regroup-hide_canisters"].value
regroup.settings.bob = settings.startup["regroup-bob"].value
regroup.settings.bob_electronics = settings.startup["regroup-bob_electronics"].value
regroup.settings.angels = settings.startup["regroup-angels"].value
regroup.settings.angel_move = settings.startup["regroup-angel_move"].value
regroup.settings.yuoki = settings.startup["regroup-yuoki"].value
regroup.settings.nputils = settings.startup["regroup-nputils"].value
regroup.settings.other = settings.startup["regroup-other"].value
regroup.settings.inv_size = settings.startup["regroup-inv_size"].value
regroup.settings.add_trees = settings.startup["regroup-add_trees"].value
regroup.settings.add_dirt = settings.startup["regroup-add_dirt"].value
regroup.settings.add_dust = settings.startup["regroup-add_dust"].value
regroup.settings.add_gems = settings.startup["regroup-add_gems"].value
regroup.settings.bob_inserters = settings.startup["regroup-bob_inserters"].value
regroup.settings.bob_pipes = settings.startup["regroup-bob_pipes"].value
regroup.settings.yuoki_pipe = settings.startup["regroup-yuoki_pipe"].value
regroup.settings.yuoki_tech = settings.startup["regroup-yuoki_tech"].value
regroup.settings.other_mini = settings.startup["regroup-other_mini"].value
regroup.settings.vcoal = settings.startup["regroup-vcoal"].value

if not data.raw["custom-input"] or not data.raw["custom-input"]["bob-inserter-drop-range"] then regroup.settings.bob_inserters = false end

--[[# generate name list
for k,v in pairs(data.raw) do
	if type(v) == "table" then
		for kk,vv in pairs(v) do
			table.insert(rg.name_list,vv.name or kk)
		end
	end
end]]

--# create basic groups
rg.generate_main_groups()


require("mods.presort")
require("mods.vanilla")

require("mods.bobs")
require("mods.5dim")
require("mods.factorio-extended")
require("mods.angels")
require("mods.yuoki")
require("mods.yuoki_engine")
require("mods.yuoki_railway")
require("mods.nputils")
require("mods.other")
require("mods.Bio_Industries")

if regroup.settings.custom_order then require("mods._custom_") end


--# Change Player Inventory Size
if regroup.settings.inv_size then data.raw.player["player"].inventory_size = 120 end

local que = {
	"gathering","production","yuoki",
	"agronomies","resources","resource-refining","casting","smelting","plates",
	"automatization","transport","logistic","energy","atomic",
	"barreling","liquids","water-treatment","chemistry","petrochem-refining",
	"module","intermediate","engines","parts",
	"defense","armor","weaponry","trains-vehicles",
	"decorative","alien","bio-processing","other"
}

--# final tunning
rg.resort_main_groups(que)
rg.add_newRessource_finalize()


-- log a list of all recipes
if z_debug then
	rg.list_ungrouped()
end