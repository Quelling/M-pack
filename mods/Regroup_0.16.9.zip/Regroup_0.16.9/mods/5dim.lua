local allow_changes = regroup.settings.dim

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

if mods["5dim_core"] then
do	--[[gathering]]--
	aadd("rg-gathering-1",				"5d-repair-pack-2",																		"b")
	
	aadd("rg-gathering-2",				"5d-iron-chest-mk2",															"a[0064][2x1]-5dim")
	aadd("rg-gathering-2",				"5d-iron-chest-mk2-2",															"a[0064][1x2]-5dim")
	aadd("rg-gathering-2",				"5d-iron-chest-mk2-3",															"a[0250]-5dim")
	aadd("rg-gathering-2",				"5d-iron-chest-mk3",															"a[0128]-5dim")
	
	aadd("rg-gathering-4",				"5d-storage-tank",																"a[100]-5dim")
	
	aadd("rg-gathering-5",					"burner-mining-drill",																"a[02x02][02.5][0.3]")
	aadd("rg-gathering-5",					"electric-mining-drill",															"a[05x05][03.0][0.5]")
	aadd("rg-gathering-5",					"5d-mining-drill-speed-1",															"a[05x05][03.0][1.0]-5dim")
	aadd("rg-gathering-5",					"5d-mining-drill-speed-2",															"a[05x05][03.0][1.5]-5dim")
	aadd("rg-gathering-5",					"5d-mining-drill-speed-3",															"a[05x05][03.0][2.0]-5dim")
	
	aadd("rg-gathering-6",					"5d-mining-drill-range-1",															"a[07x07][03.0][0.5]-5dim")
	aadd("rg-gathering-6",					"5d-mining-drill-range-2",															"a[09x09][03.0][0.5]-5dim")
	aadd("rg-gathering-6",					"5d-mining-drill-range-3",															"a[13x13][03.0][0.5]-5dim")
	
	aadd("rg-gathering-20",				"5d-water-pumpjack",																	"e")
	
	aadd("rg-gathering-23",				"offshore-pump",																			"a[01200]")
	aadd("rg-gathering-23",				"5d-offshore-pump",																		"a[03600]b")
	aadd("rg-gathering-23",				"5d-offshore-pump-2",																	"a[06000]b")
	aadd("rg-gathering-23",				"pump",																								"b[12000]")
	aadd("rg-gathering-23",				"5d-small-pump",																			"b[36000]b")
	aadd("rg-gathering-23",				"5d-small-pump-2",																		"b[60000]b")
	
	aadd("rg-gathering-24",				"pumpjack",																						"a1b")
	aadd("rg-gathering-24",				"5d-pumpjack-2",																			"a2b")
	aadd("rg-gathering-24",				"5d-pumpjack-3",																			"a3b")
	
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("5d-repair-pack-2","__Regroup__/graphics/icons/repairpack-2.png", 32)
	end
	
end
do	--[[production]]--
	aadd("rg-production-0",				"5d-furnace",																					"b")
	aadd("rg-production-0",				"5d-industrial-furnace",															"c")
	
	aadd("rg-production-1",				"5d-masher",																					"a")
	aadd("rg-production-1",				"5d-masher-2",																				"b")
	
	aadd("rg-production-2",				"electric-furnace",																		"a")
	aadd("rg-production-2",				"5d-electric-furnace",																"b")
	
	aadd("rg-production-4",				"5d-assembling-machine-4",														"a4b")
	aadd("rg-production-4",				"5d-assembling-machine-5",														"a5b")
	
	aadd("rg-production-6",				"5d-oil-refinery-2",																	"a2b")
	aadd("rg-production-6",				"5d-oil-refinery-3",																	"a3b")
	
	aadd("rg-production-7",				"5d-chemical-plant-2",																"a2b")
	aadd("rg-production-7",				"5d-chemical-plant-3",																"a3b")
	
	aadd("rg-production-11",				"5d-trader",																					"b")
	
	if regroup.settings.graphics_tuning then
		if data.raw["assembling-machine"]["assembling-machine-3"] then
			data.raw["assembling-machine"]["assembling-machine-3"].animation = {
				filename = "__Regroup__/graphics/entity/assembling-machine-3-anim.png",
				priority="high",
				width = 142,
				height = 113,
				frame_count = 32,
				line_length = 8,
				shift = {0.84, -0.1}
			}
		end
		if data.raw["assembling-machine"]["assembling-machine-4"] then
			data.raw["assembling-machine"]["assembling-machine-4"].animation = {
				filename = "__Regroup__/graphics/entity/assembling-machine-4-anim.png",
				priority="high",
				width = 142,
				height = 113,
				frame_count = 32,
				line_length = 8,
				shift = {0.84, -0.1}
			}
		end
		if data.raw["assembling-machine"]["assembling-machine-5"] then
			data.raw["assembling-machine"]["assembling-machine-5"].animation = {
				filename = "__Regroup__/graphics/entity/assembling-machine-5-anim.png",
				priority="high",
				width = 142,
				height = 113,
				frame_count = 32,
				line_length = 8,
				shift = {0.84, -0.1}
			}
		end
	end
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("assembling-machine-1", "__Regroup__/graphics/icons/assembling-machine-1.png", 32)
		rg.set_icon("assembling-machine-2", "__Regroup__/graphics/icons/assembling-machine-2.png", 32)
		rg.set_icon("assembling-machine-3", "__Regroup__/graphics/icons/assembling-machine-3.png", 32)
		rg.set_icon("5d-assembling-machine-4", "__Regroup__/graphics/icons/assembling-machine-4.png", 32)
		rg.set_icon("5d-assembling-machine-5", "__Regroup__/graphics/icons/assembling-machine-5.png", 32)
	end
	
end
do	--[[resources]]--
	aadd("rg-resources-0",					"raw-wood",																						"a")
	aadd("rg-resources-0",					"wood",																								"b")
	aadd("rg-resources-0",					"coal",																								"e")
	aadd("rg-resources-0",					"stone",																							"g")
	aadd("rg-resources-0",					"sulfur",																							"h")
	
	aadd("rg-resources-3",					"lead-ore",																						"c")
	aadd("rg-resources-3",					"tin-ore",																						"d")
	aadd("rg-resources-3",					"zinc-ore",																						"e")
	aadd("rg-resources-3",					"bauxite-ore",																				"f")
	aadd("rg-resources-3",					"gold-ore",																						"g")
	
	aadd("rg-resources-4",					"5d-iron-dust",																				"a")
	aadd("rg-resources-4",					"5d-copper-dust",																			"b")
	aadd("rg-resources-4",					"5d-lead-dust",																				"c")
	aadd("rg-resources-4",					"5d-tin-dust",																				"d")
	aadd("rg-resources-4",					"5d-zinc-dust",																				"e")
	aadd("rg-resources-4",					"5d-aluminium-dust",																	"f")
	aadd("rg-resources-4",					"5d-gold-dust",																				"g")
	
	aadd("rg-resources-15",				"5d-coin",																						"a")
	aadd("rg-resources-15",				"5d-coin-to-artifact",																"b")
	aadd("rg-resources-15",				"5d-coin-to-crude-oil",																"c")
	if regroup.settings.add_dust then--[[
		rg.add_newRessource_min_max("iron-ore",						"5d-iron-dust",		1,2,0.2)
		rg.add_newRessource_min_max("copper-ore",					"5d-copper-dust",	1,2,0.2)
		rg.add_newRessource_min_max("lead-ore",						"5d-lead-dust",		1,1,0.2)
		rg.add_newRessource_min_max("tin-ore",							"5d-tin-dust",		1,1,0.2)
		rg.add_newRessource_min_max("zinc-ore",						"5d-zinc-dust",		1,2,0.1)
		rg.add_newRessource_min_max("bauxite-ore",					"5d-aluminium-dust",1,2,0.1)
		rg.add_newRessource_min_max("gold-ore",						"5d-gold-dust",		1,1,0.1)]]
		rg.add_newRessource_min_max("silver-ore",					"5d-silver-dust",		1,1,0.1)
	end
end
do	--[[plates]]--
	aadd("rg-plates-1",						"iron-plate",																					"a")
	aadd("rg-plates-1",						"5d-iron-plate",																			"b")
	aadd("rg-plates-1",						"5d-iron-plate-industrial",														"c")
	aadd("rg-plates-1",						"5d-iron-plate-industrial-dust",											"d")
	
	if i_exist("y-refined-iron") then
		aadd("rg-plates-2",						"copper-plate",																				"a")
		aadd("rg-plates-2",						"5d-copper-plate",																		"b")
		aadd("rg-plates-2",						"5d-copper-plate-industrial",													"c")
		aadd("rg-plates-2",						"5d-copper-plate-industrial-dust",										"d")
	else
		aadd("rg-plates-1",						"copper-plate",																				"g")
		aadd("rg-plates-1",						"5d-copper-plate",																		"h")
		aadd("rg-plates-1",						"5d-copper-plate-industrial",													"i")
		aadd("rg-plates-1",						"5d-copper-plate-industrial-dust",										"j")
	end
	
	aadd("rg-plates-3",						"lead-plate",																					"a")
	aadd("rg-plates-3",						"5d-lead-plate-2",																		"b")
	aadd("rg-plates-3",						"5d-lead-plate-industrial",														"c")
	aadd("rg-plates-3",						"5d-lead-plate-industrial-dust",											"d")
	aadd("rg-plates-3",						"tin-plate",																					"e")
	aadd("rg-plates-3",						"tin-plate-2",																				"f")
	aadd("rg-plates-3",						"5d-tin-plate-industrial",														"g")
	aadd("rg-plates-3",						"5d-tin-plate-industrial-dust",												"h")
	
	aadd("rg-plates-4",						"zinc-plate",																					"a")
	aadd("rg-plates-4",						"5d-zinc-plate-2",																		"b")
	aadd("rg-plates-4",						"5d-zinc-plate-industrial",														"c")
	aadd("rg-plates-4",						"5d-zinc-plate-industrial-dust",											"d")
	aadd("rg-plates-4",						"aluminium-plate",																		"e")
	aadd("rg-plates-4",						"5d-aluminium-plate-2",																"f")
	aadd("rg-plates-4",						"5d-aluminium-plate-industrial",											"g")
	aadd("rg-plates-4",						"5d-aluminium-plate-industrial-dust",									"h")
	
	aadd("rg-plates-5",						"gold-plate",																					"a")
	aadd("rg-plates-5",						"5d-gold-plate-2",																		"b")
	aadd("rg-plates-5",						"5d-gold-plate-industrial",														"c")
	aadd("rg-plates-5",						"5d-gold-plate-industrial-dust",											"d")
	aadd("rg-plates-5",						"steel-plate",																				"e")
	aadd("rg-plates-5",						"5d-steel-plate-industrial",													"f")
	
end
do	--[[automatization]]--
	aadd("rg-automatization-0",		"burner-inserter",																		"a")
	aadd("rg-automatization-0",		"inserter",																						"b")
	aadd("rg-automatization-0",		"long-handed-inserter",																"c")
	aadd("rg-automatization-0",		"5d-inserter-speed1-range3",													"e")
	aadd("rg-automatization-0",		"5d-inserter-speed1-range1-close",										"f")
	aadd("rg-automatization-0",		"5d-inserter-speed1-range2-close",										"g")
	aadd("rg-automatization-0",		"5d-inserter-speed1-range3-close",										"h")
		
	aadd("rg-automatization-1",		"filter-inserter",																		"a")
	aadd("rg-automatization-1",		"5d-inserter-smart-speed2-range2",										"b")
	aadd("rg-automatization-1",		"5d-inserter-smart-speed3-range1",										"c")
	aadd("rg-automatization-1",		"5d-inserter-smart-speed2-range1-close",							"d")
	aadd("rg-automatization-1",		"5d-inserter-smart-speed2-range2-close",							"e")
	aadd("rg-automatization-1",		"5d-inserter-smart-speed3-range1-close",							"f")
		
		
	aadd("rg-automatization-2",		"fast-inserter",																			"a")
	aadd("rg-automatization-2",		"5d-inserter-speed2-range2",													"b")
	aadd("rg-automatization-2",		"5d-inserter-speed2-range3",													"c")
	aadd("rg-automatization-2",		"5d-inserter-speed2-range1-close",										"d")
	aadd("rg-automatization-2",		"5d-inserter-speed2-range2-close",										"e")
	aadd("rg-automatization-2",		"5d-inserter-speed2-range3-close",										"f")
	aadd("rg-automatization-2",		"stack-inserter",																			"g")
	aadd("rg-automatization-2",		"stack-filter-inserter",															"h")
		
	aadd("rg-automatization-3",		"5d-inserter-speed3-range1",													"a")
	aadd("rg-automatization-3",		"5d-inserter-speed3-range2",													"b")
	aadd("rg-automatization-3",		"5d-inserter-speed3-range3",													"c")
	aadd("rg-automatization-3",		"5d-inserter-speed3-range1-close",										"d")
	aadd("rg-automatization-3",		"5d-inserter-speed3-range2-close",										"e")
	aadd("rg-automatization-3",		"5d-inserter-speed3-range3-close",										"f")
		
	aadd("rg-automatization-4",		"5d-basic-inserter-left-90d",													"a")
	aadd("rg-automatization-4",		"5d-fast-inserter-left-90d",													"b")
	aadd("rg-automatization-4",		"5d-extreme-inserter-left-90d",												"c")
	aadd("rg-automatization-4",		"5d-basic-inserter-left-90d-close",										"d")
	aadd("rg-automatization-4",		"5d-fast-inserter-left-90d-close",										"e")
	aadd("rg-automatization-4",		"5d-extreme-inserter-left-90d-close",									"f")
		
	aadd("rg-automatization-5",		"5d-basic-inserter-right-90d",												"a")
	aadd("rg-automatization-5",		"5d-fast-inserter-right-90d",													"b")
	aadd("rg-automatization-5",		"5d-extreme-inserter-right-90d",											"c")
	aadd("rg-automatization-5",		"5d-basic-inserter-right-90d-close",									"d")
	aadd("rg-automatization-5",		"5d-fast-inserter-right-90d-close",										"e")
	aadd("rg-automatization-5",		"5d-extreme-inserter-right-90d-close",								"f")
end
do	--[[transport]]--
	aadd("rg-transport-0",					"5d-mk4-transport-belt",															"f")
	aadd("rg-transport-0",					"5d-mk5-transport-belt",															"g")
	
	aadd("rg-transport-1",					"5d-loader-1",																				"a")
	aadd("rg-transport-1",					"5d-loader-2",																				"b")
	aadd("rg-transport-1",					"5d-loader-3",																				"c")
	aadd("rg-transport-1",					"5d-loader-4",																				"d")
	aadd("rg-transport-1",					"5d-loader-5",																				"e")
	
	aadd("rg-transport-6",					"5d-mk4-transport-belt-to-ground",										"d")
	aadd("rg-transport-6",					"5d-mk5-transport-belt-to-ground",										"e")
	
	aadd("rg-transport-7",					"5d-mk1-transport-belt-to-ground-30",									"a")
	aadd("rg-transport-7",					"5d-mk2-transport-belt-to-ground-30",									"b")
	aadd("rg-transport-7",					"5d-mk3-transport-belt-to-ground-30",									"c")
	aadd("rg-transport-7",					"5d-mk4-transport-belt-to-ground-30",									"d")
	aadd("rg-transport-7",					"5d-mk5-transport-belt-to-ground-30",									"e")
	
	aadd("rg-transport-8",					"5d-mk1-transport-belt-to-ground-50",									"a")
	aadd("rg-transport-8",					"5d-mk2-transport-belt-to-ground-50",									"b")
	aadd("rg-transport-8",					"5d-mk3-transport-belt-to-ground-50",									"c")
	aadd("rg-transport-8",					"5d-mk4-transport-belt-to-ground-50",									"d")
	aadd("rg-transport-8",					"5d-mk5-transport-belt-to-ground-50",									"e")
	
	aadd("rg-transport-9",					"5d-mk4-splitter",																		"g1b")
	aadd("rg-transport-9",					"5d-mk5-splitter",																		"i1b")
	
	aadd("rg-transport-13",				"pipe",																								"b")
	aadd("rg-transport-13",				"5d-pipe-mk2",																				"c")
	aadd("rg-transport-13",				"5d-pipe-mk3",																				"d")
	
	aadd("rg-transport-14",				"pipe-to-ground",																			"b")
	aadd("rg-transport-14",				"5d-pipe-to-ground-mk2",															"c")
	aadd("rg-transport-14",				"5d-pipe-to-ground-mk3",															"d")
	
	aadd("rg-transport-18",				"5d-pipe-to-ground-mk1-30",														"a")
	aadd("rg-transport-18",				"5d-pipe-to-ground-mk2-30",														"b")
	aadd("rg-transport-18",				"5d-pipe-to-ground-mk3-30",														"c")
	
	aadd("rg-transport-19",				"5d-pipe-to-ground-mk1-50",														"a")
	aadd("rg-transport-19",				"5d-pipe-to-ground-mk2-50",														"b")
	aadd("rg-transport-19",				"5d-pipe-to-ground-mk3-50",														"c")
end
do	--[[logistic]]--
	aadd("rg-logistic-1",					"5d-construction-robot-p",														"f")
	
	aadd("rg-logistic-2",					"5d-roboport-2",																			"c")
	aadd("rg-logistic-2",					"5d-roboport-3",																			"f")
	aadd("rg-logistic-2",					"5d-roboport-4",																			"i")
	
	aadd("rg-logistic-5",					"5d-logistic-robot-2",																"c")
	aadd("rg-logistic-5",					"5d-logistic-robot-3",																"f")
	aadd("rg-logistic-5",					"5d-logistic-robot-4",																"h")
	
	aadd("rg-logistic-6",					"5d-construction-robot-2",														"c")
	aadd("rg-logistic-6",					"5d-construction-robot-3",														"f")
	aadd("rg-logistic-6",					"5d-construction-robot-4",														"h")
	
	aadd("rg-logistic-7",					"logistic-chest-storage",												"a[048]")
	aadd("rg-logistic-7",					"5d-storage",															"a[096]-5dim")
	aadd("rg-logistic-7",					"logistic-chest-requester",												"b[048]")
	aadd("rg-logistic-7",					"5d-requester",															"b[096]-5dim")
	aadd("rg-logistic-7",					"logistic-chest-passive-provider",										"c[048]")
	aadd("rg-logistic-7",					"5d-passive",															"c[096]-5dim")
	
	aadd("rg-logistic-8",					"logistic-chest-active-provider",										"a[048]")
	aadd("rg-logistic-8",					"5d-active",															"a[096]-5dim")
	aadd("rg-logistic-8",					"logistic-chest-buffer",												"b[048]")
	aadd("rg-logistic-8",					"5d-logistic-chest-botRecaller",										"c[048]")
	
	aadd("rg-logistic-13",					"5d-aluminium-wire",													"d")
	aadd("rg-logistic-13",					"5d-gold-wire",															"e")
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("5d-roboport-2", "__Regroup__/graphics/icons/roboport2.png", 32)
		
		if data.raw["roboport"]["5d-roboport-2"] then
			data.raw["roboport"]["5d-roboport-2"].base = {
				filename = "__Regroup__/graphics/entity/roboport2-base.png",
				width = 143,
				height = 135,
				shift = {0.5,0.25}
			}
			data.raw["roboport"]["5d-roboport-2"].base_patch = {
				filename = "__Regroup__/graphics/entity/roboport2-base-patch.png",
				priority = "medium",
				width = 69,
				height = 50,
				frame_count = 1,
				shift = {0.03125,0.203125}
			}
			data.raw["roboport"]["5d-roboport-2"].door_animation_up = {
				filename = "__Regroup__/graphics/entity/roboport2-door-up.png",
				priority = "medium",
				width = 52,
				height = 20,
				frame_count = 16,
				shift = {0.015625,-0.890625}
			}
			data.raw["roboport"]["5d-roboport-2"].door_animation_down =  {
				filename = "__Regroup__/graphics/entity/roboport2-door-down.png",
				priority = "medium",
				width = 52,
				height = 22,
				frame_count = 16,
				shift = {0.015625,-0.234375}
			}
			data.raw["roboport"]["5d-roboport-2"].recharging_animation = {
				filename = "__Regroup__/graphics/entity/roboport2-recharging.png",
				priority = "high",
				width = 37,
				height = 35,
				frame_count = 16,
				scale = 1.5,
				animation_speed = 0.5
			}
		end
	end
	if data.raw.recipe["5d-active"] and data.raw.recipe["5d-requester"] then
		data:extend({
			{
				type = "technology",
				name = "logistic-system-2",
				icon = "__base__/graphics/technology/logistic-system.png",
				icon_size = 32,
				effects =
				{
					{
						type = "unlock-recipe",
						recipe = "5d-active"
					},
					{
						type = "unlock-recipe",
						recipe = "5d-requester"
					}
				},
				prerequisites = { "logistic-system"},
				unit = {
					count = 150,
					ingredients =
					{
						{"science-pack-1", 1},
						{"science-pack-2", 1},
						{"science-pack-3", 1}
					},
					time = 30
				},
				order = "c-k-d",
			},
		})
	end
	
end
do	--[[energy]]--
	aadd("rg-energy-1",						"5d-boiler",																				"a[075][24000]-5dim")
	aadd("rg-energy-1",						"5d-boiler-2",																				"a[100][18000]-5dim")
	
	aadd("rg-energy-2",						"5d-steam-engine-2",																		"a[18000]-5dim")
	aadd("rg-energy-2",						"5d-steam-engine-3",																		"a[27000]-5dim")
	
	aadd("rg-energy-3",						"5d-heat-exchanger-2",																		"a[11000]-5dim")

	aadd("rg-energy-4",						"5d-steam-turbine-2",																		"a[06400]-5dim")
	
	aadd("rg-energy-7",						"solar-panel",																				"a[060000]")
	aadd("rg-energy-7",						"5d-solar-panel-2",																			"a[120000]-5dim")
	aadd("rg-energy-7",						"5d-solar-panel-3",																			"a[180000]-5dim")
	
	aadd("rg-energy-11",					"accumulator",																				"a[00300][00300][02000]")
	aadd("rg-energy-11",					"5d-basic-accumulator-2",																	"a[00600][00600][04000]-5dim")
	aadd("rg-energy-11",					"5d-basic-accumulator-3",																	"a[01200][01200][08000]-5dim")
	
	aadd("rg-energy-12",					"small-electric-pole",																		"a[007][005x005]")
	
	aadd("rg-energy-13",					"medium-electric-pole",																		"a[009][007x007]")
	aadd("rg-energy-13",					"5d-electric-pole-4",																		"a[020][015x015]-5dim")	

	aadd("rg-energy-14",					"big-electric-pole",																		"a[030][004x004]")
	aadd("rg-energy-14",					"5d-electric-pole-5",																		"a[050][007x007]-5dim")

	aadd("rg-energy-15",					"substation",																				"a[018][018x018]")
	aadd("rg-energy-15",					"5d-electric-pole-6",																		"a[064][049x049]-5dim")
	
end
do	--[[defense]]--
	aadd("rg-defense-0",						"5d-metal-wall",																			"f")
	
	aadd("rg-defense-1",						"5d-gate",																						"b")
	
	aadd("rg-defense-3",						"flamethrower-turret",																"a")
	aadd("rg-defense-3",						"5d-flamethrower-turret-2",														"a2")
	aadd("rg-defense-3",						"5d-tesla-turret",																		"e")
	aadd("rg-defense-3",						"5d-electric-turret",																	"f")
	
	aadd("rg-defense-4",						"5d-gun-turret-small",																"a")
	aadd("rg-defense-4",						"gun-turret",																					"b")
	aadd("rg-defense-4",						"5d-gun-turret-big",																	"c")
	aadd("rg-defense-4",						"5d-gun-turret-exp",																	"d")
	
	aadd("rg-defense-5",						"5d-laser-turret-small",															"a")
	aadd("rg-defense-5",						"laser-turret",																				"b")
	aadd("rg-defense-5",						"5d-laser-turret-big",																"c")
end
do	--[[armor]]--
	aadd("rg-armor-7",							"exoskeleton-equipment",															"a1")
	aadd("rg-armor-7",							"5d-exoskeleton-mk2-equipment",												"a2")
	aadd("rg-armor-7",							"5d-exoskeleton-mk3-equipment",												"a3")
	aadd("rg-armor-7",							"personal-roboport-equipment",												"c1")
	aadd("rg-armor-7",							"personal-roboport-mk2-equipment",										"c2")
	
	aadd("rg-armor-8",							"solar-panel-equipment",															"a1")
	aadd("rg-armor-8",							"5d-solar-panel-mk2-equipment",												"a2b")
	aadd("rg-armor-8",							"fusion-reactor-equipment",														"b1")
	aadd("rg-armor-8",							"5d-fusion-reactor-mk2-equipment",										"b2b")
	
	aadd("rg-armor-9",							"battery-equipment",																	"a1")
	aadd("rg-armor-9",							"battery-mk2-equipment",															"a2")
	aadd("rg-armor-9",							"5d-battery-mk3-equipment",														"a3b")
	aadd("rg-armor-9",							"5d-battery-mk4-equipment",														"a4b")
	
	aadd("rg-armor-10",						"personal-laser-defense-equipment",										"a1")
	aadd("rg-armor-10",						"5d-personal-blue-laser-defense-equipment",						"b1")
	aadd("rg-armor-10",						"5d-personal-yellow-laser-defense-equipment",					"c1")
	
	aadd("rg-armor-11",						"energy-shield-equipment",														"a1")
	aadd("rg-armor-11",						"energy-shield-mk2-equipment",												"a2")
	aadd("rg-armor-11",						"5d-energy-shield-mk3-equipment",											"a3b")
	aadd("rg-armor-11",						"5d-energy-shield-mk4-equipment",											"a4b")
end
do	--[[intermediate]]--
	aadd("rg-intermediate-1",			"5d-gold-circuit",																		"i")
	
	aadd("rg-intermediate-4",			"iron-gear-wheel",																		"a")
	aadd("rg-intermediate-4",			"5d-tin-gear-wheel",																	"b")
	aadd("rg-intermediate-4",			"5d-zinc-gear-wheel",																	"c")
	aadd("rg-intermediate-4",			"5d-aluminium-gear-wheel",														"d")
	
	if allow_changes and data.raw.recipe["5d-gold-circuit"] then
		data.raw.recipe["5d-gold-circuit"].ingredients =
		{
			{"advanced-circuit", 2},
			{"tin-plate", 5},
			{"5d-gold-wire", 4},
		}
		rg.add_recipe_to_tech("advanced-electronics",		"5d-gold-circuit")
	end
end
do	--[[module]]--
	aadd("rg-module-0",						"5d-welder",																					"i")
	
	aadd("rg-module-4",						"5d-speed-module-4",																	"d")
	aadd("rg-module-4",						"5d-speed-module-5",																	"e")
	
	aadd("rg-module-5",						"5d-productivity-module-4",														"d")
	aadd("rg-module-5",						"5d-productivity-module-5",														"e")
	
	aadd("rg-module-6",						"5d-effectivity-module-4",														"d")
	aadd("rg-module-6",						"5d-effectivity-module-5",														"e")
	
	aadd("rg-module-7",						"5d-pollution-module-1",															"a")
	aadd("rg-module-7",						"5d-pollution-module-2",															"b")
	aadd("rg-module-7",						"5d-pollution-module-3",															"c")
	aadd("rg-module-7",						"5d-pollution-module-4",															"d")
	aadd("rg-module-7",						"5d-pollution-module-5",															"e")
	
	aadd("rg-module-8",						"5d-speed-effectivity-4",															"a")
	aadd("rg-module-8",						"5d-speed-pollution-4",																"b")
	aadd("rg-module-8",						"5d-speed-productivity-4",														"c")
	aadd("rg-module-8",						"5d-pollution-effectivity-4",													"d")
	aadd("rg-module-8",						"5d-pollution-productivity-4",												"e")
	aadd("rg-module-8",						"5d-effectivity-productivity-4",											"f")
	
	aadd("rg-module-9",						"5d-speed-effectivity-5",															"a")
	aadd("rg-module-9",						"5d-speed-pollution-5",																"b")
	aadd("rg-module-9",						"5d-speed-productivity-5",														"c")
	aadd("rg-module-9",						"5d-pollution-effectivity-5",													"d")
	aadd("rg-module-9",						"5d-pollution-productivity-5",												"e")
	aadd("rg-module-9",						"5d-effectivity-productivity-5",											"f")
	
	if data.raw.module["5d-effectivity-productivity-5"] then
		local lim = data.raw.module["5d-effectivity-productivity-5"].limitation
		local lmk = data.raw.module["5d-effectivity-productivity-5"].limitation_message_key
		data.raw.module["5d-speed-productivity-4"].limitation = lim
		data.raw.module["5d-speed-productivity-4"].limitation_message_key = lmk
		data.raw.module["5d-effectivity-productivity-4"].limitation = lim
		data.raw.module["5d-effectivity-productivity-4"].limitation_message_key = lmk
		data.raw.module["5d-pollution-productivity-4"].limitation = lim
		data.raw.module["5d-pollution-productivity-4"].limitation_message_key = lmk
	end
end
do	--[[trains-vehicles]]--
	aadd("rg-trains-2",						"locomotive",																					"a1")
	aadd("rg-trains-2",						"5d-locomotive-reinforced",														"c1b")
	aadd("rg-trains-2",						"5d-locomotive-hs",																		"d1b")
	
	aadd("rg-trains-4",						"cargo-wagon",																				"a1")
	aadd("rg-trains-4",						"5d-cargo-wagon-2",																		"a2b")
	aadd("rg-trains-4",						"5d-cargo-wagon-3",																		"a3b")

	aadd("rg-trains-5",						"fluid-wagon",																				"a")
	aadd("rg-trains-5",						"5d-fluid-wagon-2",																		"a2b")
	aadd("rg-trains-5",						"5d-fluid-wagon-3",																		"a3b")
	
	aadd("rg-vehicles-1",					"5d-artillery",																				"a")
	aadd("rg-vehicles-1",					"5d-tank",																						"b")
	
	aadd("rg-vehicles-2",					"5d-truck",																						"a")
	aadd("rg-vehicles-2",					"5d-boat",																						"b")
	aadd("rg-vehicles-2",					"5d-air-plane",																				"c")
	
	aadd("rg-vehicles-3",					"5d-tank-machine-gun",																"d")
end
do	--[[decorative]]--
	aadd("rg-decorative-1",				"concrete",																						"a")
	aadd("rg-decorative-1",				"5d-concrete-a",																			"b")
	aadd("rg-decorative-1",				"5d-concrete-b",																			"c")
	aadd("rg-decorative-1",				"5d-concrete-b2",																			"d")
	aadd("rg-decorative-1",				"5d-concrete-m",																			"e")
	aadd("rg-decorative-1",				"5d-concrete-r",																			"f")
	aadd("rg-decorative-1",				"5d-concrete-v",																			"g")
	aadd("rg-decorative-1",				"hazard-concrete",																		"h")
	
	aadd("rg-decorative-4",				"5d-lamp",																						"b")
	
	aadd("rg-decorative-8",				"5d-banner-1",																				"a")
	aadd("rg-decorative-8",				"5d-banner-2",																				"b")
	aadd("rg-decorative-8",				"5d-banner-3",																				"c")
	aadd("rg-decorative-8",				"5d-obelisk",																					"d")
	aadd("rg-decorative-8",				"5d-statue",																					"e")
	
	for _,v in pairs(data.raw["item-subgroup"]) do
		if v.group == "decoration" and (v.name == "decoration-letter" or v.name == "decoration-arrow") then
			v.group = "rg-decorative"
			v.order = 16
		end
	end
	
end
do  --[[atomic]]--
	aadd("rg-atomic-0",							"5d-nuclear-reactor-2",																"a2")
	aadd("rg-atomic-0",							"5d-centrifuge-2",																		"f2")
end
do  --[[weaponry]]--
	aadd("rg-weaponry-15",					"artillery-shell",																		"h")
end
do
	--Hide 5Dim Primary Pipes if Bob's mod pipes exist
	if data.raw.item["5d-pipe-mk2"] and data.raw.item["copper-pipe"] then
		ahide("5d-pipe-mk2")
		ahide("5d-pipe-mk3")
		ahide("5d-pipe-to-ground-mk2")
		ahide("5d-pipe-to-ground-mk3")
		ahide("5d-pipe-to-ground-mk1-30")
		ahide("5d-pipe-to-ground-mk2-30")
		ahide("5d-pipe-to-ground-mk3-30")
		ahide("5d-pipe-to-ground-mk1-50")
		ahide("5d-pipe-to-ground-mk2-50")
		ahide("5d-pipe-to-ground-mk3-50")
		rg.r_replace_ingredient_in_all("5d-pipe-mk2",					"copper-pipe")
		rg.r_replace_ingredient_in_all("5d-pipe-mk3",					"steel-pipe")
		rg.r_replace_ingredient_in_all("5d-pipe-mk2",					"copper-pipe")
		rg.r_replace_ingredient_in_all("5d-pipe-mk3",					"steel-pipe")
	end
end	
end	