local allow_changes = regroup.settings.bob

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

if mods["boblibrary"] then
	do	--[[gathering]]--
		aadd("rg-gathering-0",					"brass-axe",																					"c")
		aadd("rg-gathering-0",					"cobalt-axe",																					"d")
		aadd("rg-gathering-0",					"titanium-axe",																				"f")
		aadd("rg-gathering-0",					"tungsten-axe",																				"g")
		aadd("rg-gathering-0",					"diamond-axe",																				"h")
		
		aadd("rg-gathering-2",					"brass-chest",																				"a[0064]-bob")
		aadd("rg-gathering-2",					"titanium-chest",																			"a[0080]-bob")
	
		aadd("rg-gathering-4",					"storage-tank-2",																			"a[050]-bob")
		aadd("rg-gathering-4",					"storage-tank-3",																			"a[075]-bob")
		aadd("rg-gathering-4",					"storage-tank-4",																			"a[100]-bob")
		
		aadd("rg-gathering-5",					"burner-mining-drill",																"a[02x02][02.5][0.3]")
		aadd("rg-gathering-5",					"electric-mining-drill",															"a[05x05][03.0][0.5]")
		aadd("rg-gathering-5",					"bob-mining-drill-1",																"a[05x05][04.5][1.0]-bob")
		aadd("rg-gathering-5",					"bob-mining-drill-2",																"a[05x05][06.0][2.0]-bob")
		aadd("rg-gathering-5",					"bob-mining-drill-3",																"a[05x05][08.0][3.0]-bob")
		aadd("rg-gathering-5",					"bob-mining-drill-4",																"a[05x05][10.0][4.0]-bob")
		aadd("rg-gathering-5",					"bob-mining-drill-5",																"a[05x05][03.0][0.5]-bob")
		
		aadd("rg-gathering-6",					"bob-area-mining-drill-1",															"a[07x07][04.0][0.7]-bob")
		aadd("rg-gathering-6",					"bob-area-mining-drill-2",															"a[11x11][05.0][1.0]-bob")
		aadd("rg-gathering-6",					"bob-area-mining-drill-3",															"a[13x13][06.0][1.2]-bob")
		aadd("rg-gathering-6",					"bob-area-mining-drill-4",															"a[17x17][07.0][1.5]-bob")
		
		aadd("rg-gathering-21",				"water-pump",																					"a[10]")
		aadd("rg-gathering-21",				"water-pump-2",																					"a[20]")
		aadd("rg-gathering-21",				"water-pump-3",																					"a[35]")
		aadd("rg-gathering-21",				"water-pump-4",																					"a[50]")
		aadd("rg-gathering-21",				"water-miner-1",																				"b[02][01]")
		aadd("rg-gathering-21",				"water-miner-2",																				"b[02][02]")
		aadd("rg-gathering-21",				"water-miner-3",																				"b[02][03]")
		aadd("rg-gathering-21",				"water-miner-4",																				"b[02][04]")
		aadd("rg-gathering-21",				"water-miner-5",																				"b[02][05]")
		
		aadd("rg-gathering-22",				"air-pump",																						"a[10]")
		aadd("rg-gathering-22",				"air-pump-2",																					"a[20]")
		aadd("rg-gathering-22",				"air-pump-3",																					"a[35]")
		aadd("rg-gathering-22",				"air-pump-4",																					"a[50]")
		
		aadd("rg-gathering-23",				"offshore-pump",																				"a[01200]")
		aadd("rg-gathering-23",				"pump",																							"b[12000]")
		aadd("rg-gathering-23",				"bob-pump-2",																					"b[18000]-bob")
		aadd("rg-gathering-23",				"bob-pump-3",																					"b[24000]-bob")
		aadd("rg-gathering-23",				"bob-pump-4",																					"b[30000]-bob")
		aadd("rg-gathering-23",				"void-pump",																					"c")
		
		aadd("rg-gathering-24",				"pumpjack",																						"a1")
		aadd("rg-gathering-24",				"bob-pumpjack-1",																			"a2")
		aadd("rg-gathering-24",				"bob-pumpjack-2",																			"a3")
		aadd("rg-gathering-24",				"bob-pumpjack-3",																			"a4")
		aadd("rg-gathering-24",				"bob-pumpjack-4",																			"a5")
		
		if regroup.settings.graphics_tuning then
			rg.set_icon("water-miner-1", "__Regroup__/graphics/icons/pump_water.png", 32)
			rg.set_icon("water-miner-2", "__Regroup__/graphics/icons/pump_water.png", 32)
			rg.set_icon("water-miner-3", "__Regroup__/graphics/icons/pump_water.png", 32)
			rg.set_icon("water-miner-4", "__Regroup__/graphics/icons/pump_water.png", 32)
			rg.set_icon("water-miner-5", "__Regroup__/graphics/icons/pump_water.png", 32)
			rg.set_icon("pumpjack", "__Regroup__/graphics/icons/pump_oil.png", 32)
			rg.set_icon("bob-pumpjack-1", "__Regroup__/graphics/icons/pump_oil.png", 32)
			rg.set_icon("bob-pumpjack-2", "__Regroup__/graphics/icons/pump_oil.png", 32)
			rg.set_icon("bob-pumpjack-3", "__Regroup__/graphics/icons/pump_oil.png", 32)
			rg.set_icon("bob-pumpjack-4", "__Regroup__/graphics/icons/pump_oil.png", 32)
		end
		
		if i_exist("5d-small-pump") and i_exist("bob-pump-2") and allow_changes then
			ahide("bob-pump-2")
			ahide("bob-pump-3")
			ahide("bob-pump-4")
			switch_tech("bob-fluid-handling-3")
			switch_tech("bob-fluid-handling-4")
		end
		
		if i_exist("5d-mining-drill-speed-1") and i_exist("bob-mining-drill-1") and allow_changes then
			ahide("bob-mining-drill-1")
			ahide("bob-mining-drill-2")
			ahide("bob-mining-drill-3")
			ahide("bob-mining-drill-4")
			ahide("bob-mining-drill-5")
			ahide("bob-area-mining-drill-1")
			ahide("bob-area-mining-drill-2")
			ahide("bob-area-mining-drill-3")
			ahide("bob-area-mining-drill-4")
			
			ahide("5d-storage-tank")
			ahide("5d-pumpjack-2")
			ahide("5d-pumpjack-3")
			
			switch_tech("bob-drills-1")
			switch_tech("bob-drills-2")
			switch_tech("bob-drills-3")
			switch_tech("bob-drills-4")
			switch_tech("bob-drills-5")
			switch_tech("bob-area-drills-1")
			switch_tech("bob-area-drills-2")
			switch_tech("bob-area-drills-3")
			switch_tech("bob-area-drills-4")
			
			switch_tech("fluid-handling-2")
			switch_tech("advanced-oil-processing-2")
			
			rg.t_add_recipe_unlock("bob-fluid-handling-2",		"storage-tank-2")
			rg.t_add_recipe_unlock("bob-fluid-handling-3",		"storage-tank-3")
			rg.t_add_recipe_unlock("bob-fluid-handling-4",		"storage-tank-4")
		end
		
	end
	do	--[[production]]--
		aadd("rg-production-0",				"chemical-boiler",																		"g")
		aadd("rg-production-0",				"chemical-steel-furnace",															"h")
		aadd("rg-production-0",				"mixing-furnace",																			"i")
		aadd("rg-production-0",				"mixing-steel-furnace",																"j")
		
		aadd("rg-production-2",				"electric-furnace",																		"a")
		aadd("rg-production-2",				"electric-furnace-2",																	"c")
		aadd("rg-production-2",				"electric-furnace-3",																	"f")
		aadd("rg-production-2",				"electric-mixing-furnace",														"i")
		aadd("rg-production-2",				"chemical-furnace",																		"j")
		aadd("rg-production-2",				"electric-chemical-mixing-furnace",										"k")
		aadd("rg-production-2",				"electric-chemical-mixing-furnace-2",									"l")
		
		aadd("rg-production-4",				"assembling-machine-1",																"a1a")
		aadd("rg-production-4",				"assembling-machine-2",																"a2a")
		aadd("rg-production-4",				"assembling-machine-3",																"a3a")
		aadd("rg-production-4",				"assembling-machine-4",																"a4a")
		aadd("rg-production-4",				"assembling-machine-5",																"a5a")
		aadd("rg-production-4",				"assembling-machine-6",																"a6a")
		
		aadd("rg-production-4",				"electronics-machine-1",															"b1a")
		aadd("rg-production-4",				"electronics-machine-2",															"b2a")
		aadd("rg-production-4",				"electronics-machine-3",															"b3a")
		
		aadd("rg-production-6",				"oil-refinery",																				"a1a")
		aadd("rg-production-6",				"oil-refinery-2",																			"a2a")
		aadd("rg-production-6",				"oil-refinery-3",																			"a3a")
		aadd("rg-production-6",				"oil-refinery-4",																			"a4a")
		
		aadd("rg-production-7",				"chemical-plant-2",																		"a2a")
		aadd("rg-production-7",				"chemical-plant-3",																		"a3a")
		aadd("rg-production-7",				"chemical-plant-4",																		"a4a")
		
		aadd("rg-production-9",			"electrolyser",																				"a1a")
		aadd("rg-production-9",			"electrolyser-1",																			"a2a")
		aadd("rg-production-9",			"electrolyser-2",																			"a3a")
		aadd("rg-production-9",			"electrolyser-3",																			"a4a")
		aadd("rg-production-9",			"electrolyser-4",																			"a5a")
		
		aadd("rg-production-11",			"bob-greenhouse",																			"a")
		aadd("rg-production-11",			"lab-module",																					"b")
		aadd("rg-production-12",			"bob-distillery",																			"c")
		
		if regroup.settings.graphics_tuning then
			rg.set_icon("chemical-furnace", "__Regroup__/graphics/icons/chemical-furnace.png", 32)
			rg.set_icon("assembling-machine-1", "__Regroup__/graphics/icons/assembling-machine-1.png", 32)
			rg.set_icon("assembling-machine-2", "__Regroup__/graphics/icons/assembling-machine-2.png", 32)
			rg.set_icon("assembling-machine-3", "__Regroup__/graphics/icons/assembling-machine-3.png", 32)
			rg.set_icon("assembling-machine-4", "__Regroup__/graphics/icons/assembling-machine-4.png", 32)
			rg.set_icon("assembling-machine-5", "__Regroup__/graphics/icons/assembling-machine-5.png", 32)
			rg.set_icon("assembling-machine-6", "__Regroup__/graphics/icons/assembling-machine-6.png", 32)
			
			if data.raw["assembling-machine"]["assembling-machine-3"] then
				data.raw["assembling-machine"]["assembling-machine-3"].animation = {
					filename = "__Regroup__/graphics/entity/assembling-machine-3-anim.png",
					priority="high",
					width = 142,
					height = 113,
					frame_count = 32,
					line_length = 8,
					shift = {0.84, -0.1}
				}
			end
			if data.raw["assembling-machine"]["assembling-machine-4"] then
				data.raw["assembling-machine"]["assembling-machine-4"].animation = {
					filename = "__Regroup__/graphics/entity/assembling-machine-4-anim.png",
					priority="high",
					width = 142,
					height = 113,
					frame_count = 32,
					line_length = 8,
					shift = {0.84, -0.1}
				}
			end
			if data.raw["assembling-machine"]["assembling-machine-5"] then
				data.raw["assembling-machine"]["assembling-machine-5"].animation = {
					filename = "__Regroup__/graphics/entity/assembling-machine-5-anim.png",
					priority="high",
					width = 142,
					height = 113,
					frame_count = 32,
					line_length = 8,
					shift = {0.84, -0.1}
				}
			end
			if data.raw["assembling-machine"]["assembling-machine-6"] then
				data.raw["assembling-machine"]["assembling-machine-6"].animation = {
					filename = "__Regroup__/graphics/entity/assembling-machine-6-anim.png",
					priority="high",
					width = 142,
					height = 113,
					frame_count = 32,
					line_length = 8,
					shift = {0.84, -0.1}
				}
			end
			if data.raw["assembling-machine"]["chemical-furnace"] then
				data.raw["assembling-machine"]["chemical-furnace"].animation.filename = "__Regroup__/graphics/entity/electric-chemical-furnace.png"
			end
		end
		
		aadd("rg-production-6",				"oil-refinery-2",																			"c")
		aadd("rg-production-6",				"oil-refinery-3",																			"e")
		aadd("rg-production-6",				"oil-refinery-4",																			"g")
		
		aadd("rg-production-7",				"chemical-plant-2",																		"a2")
		aadd("rg-production-7",				"chemical-plant-3",																		"a3")
		aadd("rg-production-7",				"chemical-plant-4",																		"a4")
		
		if i_exist("5d-chemical-plant-2") and allow_changes then
			ahide("oil-refinery-2")
			ahide("oil-refinery-3")
			ahide("oil-refinery-4")
			ahide("chemical-plant-2")
			ahide("chemical-plant-3")
			ahide("chemical-plant-4")
			
			switch_tech("oil-processing-4")
			switch_tech("chemical-plant-4")
			
			rg.t_add_recipe_unlock("chemical-plant-2",			"5d-chemical-plant-2")
			rg.t_add_recipe_unlock("chemical-plant-3",			"5d-chemical-plant-3")
			rg.t_add_recipe_unlock("oil-processing-2",			"5d-oil-refinery-2")
			rg.t_add_recipe_unlock("oil-processing-3",			"5d-oil-refinery-3")
			
			rg.t_remove_recipe_unlock("chemical-plant-2", "chemical-plant-2")
			rg.t_remove_recipe_unlock("chemical-plant-3", "chemical-plant-3")
			rg.t_remove_recipe_unlock("oil-processing-2", "oil-refinery-2")
			rg.t_remove_recipe_unlock("oil-processing-3", "oil-refinery-3")
		end
		
		
		if allow_changes then
			if i_exist("electric-furnace-2") then
				ahide("5d-electric-furnace")
				ahide("electric-furnace-mk2")
				ahide("electric-furnace-mk3")
			end
		end
		
		if regroup.settings.bob_electronics then
			ahide("electronics-machine-1")
			ahide("electronics-machine-2")
			ahide("electronics-machine-3")
			
			switch_tech("electronics-machine-1")
			switch_tech("electronics-machine-2")
			switch_tech("electronics-machine-3")
		end
	end
	do	--[[resources]]--
		aadd("rg-resources-0",				"raw-wood",																						"a")
		aadd("rg-resources-0",				"wood",																							"b")
		aadd("rg-resources-0",				"synthetic-wood",																				"c")
		aadd("rg-resources-0",				"seedling",																						"d")
		aadd("rg-resources-0",				"coal",																							"e")
		aadd("rg-resources-0",				"5d-coal",																						"f")
		aadd("rg-resources-0",				"stone",																						"g")
		aadd("rg-resources-0",				"sulfur",																						"h")
		aadd("rg-resources-0",				"sulfur-2",																						"i")
		
		aadd("rg-resources-3",				"lead-ore",																						"c")
		aadd("rg-resources-3",				"tin-ore",																						"d")
		aadd("rg-resources-3",				"zinc-ore",																						"e")
		aadd("rg-resources-3",				"bauxite-ore",																					"f")
		aadd("rg-resources-3",				"gold-ore",																						"g")
		aadd("rg-resources-3",				"silver-ore",																					"h")
		
		aadd("rg-resources-5",				"cobalt-ore",																					"a")
		aadd("rg-resources-5",				"nickel-ore",																					"b")
		aadd("rg-resources-5",				"quartz",																							"c")
		aadd("rg-resources-5",				"quartz-ore",																					"d")
		aadd("rg-resources-5",				"rutile-ore",																					"e")
		aadd("rg-resources-5",				"tungsten-ore",																				"f")
		aadd("rg-resources-5",				"thorium-ore",																				"g")
		
		
		iadd("rg-resources-8",				"plastic-bar",																				"a")
		aadd("rg-resources-8",				"silicon",																						"b")
		aadd("rg-resources-8",				"bob-silicon-plate",																	"c")
		aadd("rg-resources-8",				"resin",																							"d")
		aadd("rg-resources-8",				"bob-resin-wood",																			"e")
		aadd("rg-resources-8",				"bob-resin-oil",																			"f")
		aadd("rg-resources-8",				"rubber",																							"g")
		aadd("rg-resources-8",				"bob-rubber",																					"h")
		aadd("rg-resources-8",				"carbon",																							"i")
		aadd("rg-resources-8",				"glass",																							"j")
		aadd("rg-resources-8",				"quartz-glass",																				"k")
		
		radd("rg-resources-9",				"plastic-bar",																				"a")
		aadd("rg-resources-9",				"salt",																								"b")
		aadd("rg-resources-9",				"alumina",																						"c")
		aadd("rg-resources-9",				"cobalt-oxide",																				"e")
		iadd("rg-resources-9",				"lithium-cobalt-oxide",																"f")
		iadd("rg-resources-9",				"silicon-powder",																			"g")
		aadd("rg-resources-9",				"lead-oxide",																					"h")
		aadd("rg-resources-9",				"silver-oxide",																				"i")
		aadd("rg-resources-9",				"tungsten-oxide",																			"j")
		
		aadd("rg-resources-10",				"calcium-chloride",																		"a")
		aadd("rg-resources-10",				"lithium-chloride",																		"b")
		radd("rg-resources-10",				"lithium-cobalt-oxide",																"c")
		radd("rg-resources-10",				"silicon-powder",																			"d")
		aadd("rg-resources-10",				"silicon-wafer",																			"e")
		aadd("rg-resources-10",				"silicon-carbide",																		"f")
		aadd("rg-resources-10",				"silicon-nitride",																		"g")
		aadd("rg-resources-10",				"silver-nitrate",																			"h")
		aadd("rg-resources-10",				"petroleum-jelly",																		"i")
		aadd("rg-resources-10",				"lithium-perchlorate",																"j")
		aadd("rg-resources-10",				"sodium-hydroxide",																		"k")
		
		aadd("rg-resources-11",				"ruby-ore",																						"a")
		aadd("rg-resources-11",				"sapphire-ore",																				"b")
		aadd("rg-resources-11",				"emerald-ore",																				"c")
		aadd("rg-resources-11",				"amethyst-ore",																				"d")
		aadd("rg-resources-11",				"topaz-ore",																					"e")
		aadd("rg-resources-11",				"diamond-ore",																				"f")
		aadd("rg-resources-11",				"gem-ore",																						"g")
		aadd("rg-resources-11",				"sort-gem-ore",																				"h")	
		
		aadd("rg-resources-12",				"ruby-3",																							"a")
		aadd("rg-resources-12",				"sapphire-3",																					"b")
		aadd("rg-resources-12",				"emerald-3",																					"c")
		aadd("rg-resources-12",				"amethyst-3",																					"d")
		aadd("rg-resources-12",				"topaz-3",																						"e")
		aadd("rg-resources-12",				"diamond-3",																					"f")
		
		aadd("rg-resources-13",				"ruby-4",																							"a")
		aadd("rg-resources-13",				"sapphire-4",																					"b")
		aadd("rg-resources-13",				"emerald-4",																					"c")
		aadd("rg-resources-13",				"amethyst-4",																					"d")
		aadd("rg-resources-13",				"topaz-4",																						"e")
		aadd("rg-resources-13",				"diamond-4",																					"f")
		
		aadd("rg-resources-14",				"ruby-5",																							"a")
		aadd("rg-resources-14",				"sapphire-5",																					"b")
		aadd("rg-resources-14",				"emerald-5",																					"c")
		aadd("rg-resources-14",				"amethyst-5",																					"d")
		aadd("rg-resources-14",				"topaz-5",																						"e")
		aadd("rg-resources-14",				"diamond-5",																					"f")
		
		if regroup.settings.add_gems then
			rg.add_newRessource_min_max("gem-ore",						"ruby-3",		1,1,0.2)
			rg.add_newRessource_min_max("gem-ore",						"sapphire-3",	1,1,0.2)
			rg.add_newRessource_min_max("gem-ore",						"emerald-3",	1,1,0.1)
			rg.add_newRessource_min_max("gem-ore",						"amethyst-3",	1,1,0.1)
		end
		
	end
	do	--[[plates]]--
		
		aadd("rg-plates-0",						"iron-plate",																					"a")
		aadd("rg-plates-0",						"copper-plate",																				"b")
		aadd("rg-plates-0",						"lead-plate",																					"c")
		aadd("rg-plates-0",						"tin-plate",																					"d")
		aadd("rg-plates-0",						"zinc-plate",																					"e")
		aadd("rg-plates-0",						"aluminium-plate",																		"f")
		aadd("rg-plates-0",						"gold-plate",																					"g")
		
		aadd("rg-plates-6",						"brass-alloy",																				"a")
		aadd("rg-plates-6",						"cobalt-oxide-from-copper",														"b")
		aadd("rg-plates-6",						"bob-lead-plate",																			"c")
		aadd("rg-plates-6",						"silver-from-lead",																		"d")
		aadd("rg-plates-6",						"bob-zinc-plate",																			"e")
		aadd("rg-plates-6",						"bob-aluminium-plate",																"f")
		aadd("rg-plates-6",						"bob-gold-plate",																			"g")
		aadd("rg-plates-6",						"bronze-alloy",																				"h")
		aadd("rg-plates-6",						"tungsten-carbide",																		"i")
		
		aadd("rg-plates-11",						"powdered-tungsten",																	"a")
		aadd("rg-plates-11",						"alumina",																						"b")
		aadd("rg-plates-11",						"lithium",																						"c")
		
		aadd("rg-plates-12",						"cobalt-plate",																				"a")
		aadd("rg-plates-12",						"bob-nickel-plate",																		"b")
		aadd("rg-plates-12",						"nickel-plate",																				"c")
		aadd("rg-plates-12",						"silver-plate",																				"d")
		aadd("rg-plates-12",						"steel-plate",																				"e")
		aadd("rg-plates-12",						"bob-tungsten-plate",																	"f")
		aadd("rg-plates-12",						"tungsten-plate",																			"g")
		aadd("rg-plates-12",						"titanium-plate",																			"h")
		aadd("rg-plates-12",						"bob-titanium-plate",																	"i")
		
		aadd("rg-plates-13",						"copper-tungsten-alloy",															"a")
		aadd("rg-plates-13",						"cobalt-steel-alloy",																	"b")
		aadd("rg-plates-13",						"electrum-alloy",																			"c")
		aadd("rg-plates-13",						"invar-alloy",																				"d")
		aadd("rg-plates-13",						"nitinol-alloy",																			"e")
		aadd("rg-plates-13",						"alien-orange-alloy",																	"f")
		aadd("rg-plates-13",						"alien-blue-alloy",																		"g")
		aadd("rg-plates-13",						"gunmetal-alloy",																			"h")
		
		if regroup.settings.bob_warfare then
			ahide("gunmetal-alloy")
			rg.t_remove_recipe_unlock("zinc-processing", "gunmetal-alloy")
		end
	end
	do	--[[liquids]]--
		
		if not regroup.settings.liquid_move then
			aadd("rg-liquids-1",						"bob-oil-processing",																	"a")
			aadd("rg-liquids-1",						"basic-oil-processing",																"b")
			aadd("rg-liquids-1",						"advanced-oil-processing",														"c")
			aadd("rg-liquids-1",						"oil-processing-with-sulfur",													"d")
			aadd("rg-liquids-1",						"oil-processing-with-sulfur-dioxide",									"e")
			aadd("rg-liquids-1",						"oil-processing-with-sulfur-dioxide-2",								"f")
			aadd("rg-liquids-1",						"oil-processing-with-sulfur-dioxide-3",								"g")
			aadd("rg-liquids-1",						"coal-cracking",																			"h")
			aadd("rg-liquids-1",						"liquid-fuel",																				"i")
			aadd("rg-liquids-1",						"lubricant",																					"j")
			
			aadd("rg-liquids-3",						"water",																							"a")
			aadd("rg-liquids-3",						"pure-water",																					"b")
			aadd("rg-liquids-3",						"pure-water-from-lithia",															"c")
			aadd("rg-liquids-3",						"ground-water",																				"d")
			aadd("rg-liquids-3",						"lithia-water",																				"e")
			aadd("rg-liquids-3",						"pure-water-pump",																		"f")
			aadd("rg-liquids-3",						"bob-liquid-air",																			"g")
			
			else
			aadd("rg-chemistry-0",					"gas-canister",																				"a")
			
			aadd("rg-chemistry-1",					"bob-oil-processing",																	"a")
			aadd("rg-chemistry-1",					"basic-oil-processing",																"b")
			aadd("rg-chemistry-1",					"advanced-oil-processing",														"c")
			aadd("rg-chemistry-1",					"oil-processing-with-sulfur",													"e")
			aadd("rg-chemistry-1",					"oil-processing-with-sulfur-dioxide",									"f")
			aadd("rg-chemistry-1",					"oil-processing-with-sulfur-dioxide-2",								"g")
			aadd("rg-chemistry-1",					"oil-processing-with-sulfur-dioxide-3",								"h")
			aadd("rg-chemistry-1",					"coal-cracking",																			"i")
			aadd("rg-chemistry-1",					"liquid-fuel",																				"j")
			aadd("rg-chemistry-1",					"lubricant",																					"k")
			
			aadd("rg-chemistry-3",					"water",																							"a")
			aadd("rg-chemistry-3",					"pure-water",																					"b")
			aadd("rg-chemistry-3",					"pure-water-from-lithia",															"c")
			aadd("rg-chemistry-3",					"ground-water",																				"d")
			aadd("rg-chemistry-3",					"lithia-water",																				"e")
			aadd("rg-chemistry-3",					"pure-water-pump",																		"f")
			aadd("rg-chemistry-3",					"bob-liquid-air",																			"g")
		end
		if regroup.settings.hide_canisters then
			rhide("empty-canister")
			rhide("gas-canister")
			
			rhide("oxygen-canister")
			rhide("hydrogen-canister")
			rhide("nitrogen-canister")
			rhide("chlorine-canister")
			rhide("hydrogen-chloride-canister")
			rhide("petroleum-gas-canister")
			rhide("liquid-fuel-canister")
			rhide("ferric-chloride-canister")
			
			rhide("empty-oxygen-canister")
			rhide("empty-hydrogen-canister")
			rhide("empty-nitrogen-canister")
			rhide("empty-chlorine-canister")
			rhide("empty-hydrogen-chloride-canister")
			rhide("empty-petroleum-gas-canister")
			rhide("empty-liquid-fuel-canister")
			rhide("empty-ferric-chloride-canister")
			else
		end
		
	end
	do	--[[chemistry]]--
		aadd("rg-chemistry-0",					"sulfuric-acid",																			"a")
		aadd("rg-chemistry-0",					"sulfuric-acid-2",																		"b")
		aadd("rg-chemistry-0",					"sulfur-dioxide",																			"c")
		aadd("rg-chemistry-0",					"nitrogen",																						"d")
		aadd("rg-chemistry-0",					"nitrogen-dioxide",																		"e")
		aadd("rg-chemistry-0",					"nitric-acid",																				"f")
		aadd("rg-chemistry-0",					"tungstic-acid",																			"g")
		aadd("rg-chemistry-0",					"ammonia",																						"h")
		aadd("rg-chemistry-0",					"dinitrogen-tetroxide",																"i")
		aadd("rg-chemistry-0",					"hydrazine",																					"j")
		aadd("rg-chemistry-0",					"hydrogen-peroxide",																	"k")
		aadd("rg-chemistry-0",					"nitric-oxide",																				"l")
		
		aadd("rg-chemistry-1",					"heavy-oil-cracking",																	"i")
		aadd("rg-chemistry-1",					"light-oil-cracking",																	"j")
		aadd("rg-chemistry-1",					"coal-liquefaction",																	"k")
		aadd("rg-chemistry-1",					"ferric-chloride-solution",														"l")
		aadd("rg-chemistry-1",					"petroleum-gas-cracking",															"m")
		
		aadd("rg-chemistry-2",					"solid-fuel-from-heavy-oil",													"a")
		aadd("rg-chemistry-2",					"solid-fuel-from-light-oil",													"b")
		aadd("rg-chemistry-2",					"solid-fuel-from-petroleum-gas",											"c")
		aadd("rg-chemistry-2",					"solid-fuel-from-hydrogen",														"d")
		aadd("rg-chemistry-2",					"enriched-fuel",																			"e")
		aadd("rg-chemistry-2",					"enriched-fuel-from-liquid-fuel",											"f")
		aadd("rg-chemistry-2",					"enriched-fuel-from-hydrazine",												"g")
		
		aadd("rg-chemistry-3",					"water-electrolysis",																	"d")
		aadd("rg-chemistry-3",					"salt-water-electrolysis",														"e")
		aadd("rg-chemistry-3",					"salt-water-electrolysis-2",													"f")
		aadd("rg-chemistry-3",					"lithium-water-electrolysis",													"g")
		aadd("rg-chemistry-3",					"hydrogen-chloride",																	"h")
		aadd("rg-chemistry-3",					"nitroglycerin",																			"i")
		aadd("rg-chemistry-3",					"sulfuric-nitric-acid",																"j")
		aadd("rg-chemistry-3",					"glycerol",																						"k")
		
		if allow_changes and i_exist("nitroglycerin") then
			data.raw.recipe["nitroglycerin"].ingredients = {}
			data.raw.recipe["nitroglycerin"].ingredients =
			{
				{name="sulfur", amount=12},
				{type="fluid", name="nitric-acid", amount=3},
				{type="fluid", name="light-oil", amount=1},
			}
			ahide("sulfuric-nitric-acid")
			ahide("glycerol")
			switch_tech("nitroglycerin-processing")
			rg.t_remove_recipe_unlock("nitroglycerin-processing", "glycerol")
		end
		if regroup.settings.bob_warfare then
			ahide("nitroglycerin")
			ahide("sulfuric-nitric-acid")
			ahide("glycerol")
			switch_tech("nitroglycerin-processing")
			rg.t_remove_recipe_unlock("nitroglycerin-processing", "glycerol")
		end
	end
	do	--[[automatization]]--
		aadd("rg-automatization-0",		"express-inserter",																		"d")
		
		aadd("rg-automatization-1",		"express-filter-inserter",														"g")
		aadd("rg-automatization-1",		"express-filter-inserter",														"b")
		aadd("rg-automatization-1",		"express-stack-filter-inserter",											"j")
		
		aadd("rg-automatization-2",		"stack-filter-inserter",															"h")
		aadd("rg-automatization-2",		"express-stack-inserter",															"i")
		
		aadd("rg-automatization-3",		"express-inserter",																		"g")
		aadd("rg-automatization-3",		"express-stack-inserter",															"h")
		aadd("rg-automatization-3",		"express-stack-filter-inserter",											"i")
		
		if regroup.settings.bob_inserters and i_exist("5d-inserter-speed1-range3") then
			ahide("5d-inserter-speed1-range3","inserter")
			ahide("5d-inserter-speed1-range1-close","inserter")
			ahide("5d-inserter-speed1-range2-close","inserter")
			ahide("5d-inserter-speed1-range3-close","inserter")
			ahide("5d-inserter-speed2-range2","fast-inserter")
			ahide("5d-inserter-speed2-range3","fast-inserter")
			ahide("5d-inserter-speed2-range1-close","fast-inserter")
			ahide("5d-inserter-speed2-range2-close","fast-inserter")
			ahide("5d-inserter-speed2-range3-close","fast-inserter")
			ahide("5d-inserter-speed3-range1","express-inserter")
			ahide("5d-inserter-speed3-range2","express-inserter")
			ahide("5d-inserter-speed3-range3","express-inserter")
			ahide("5d-inserter-speed3-range1-close","express-inserter")
			ahide("5d-inserter-speed3-range2-close","express-inserter")
			ahide("5d-inserter-speed3-range3-close","express-inserter")
			ahide("5d-basic-inserter-left-90d","inserter")
			ahide("5d-basic-inserter-right-90d","inserter")
			ahide("5d-basic-inserter-left-90d-close","inserter")
			ahide("5d-basic-inserter-right-90d-close","inserter")
			ahide("5d-fast-inserter-left-90d","fast-inserter")
			ahide("5d-fast-inserter-right-90d","fast-inserter")
			ahide("5d-fast-inserter-left-90d-close","fast-inserter")
			ahide("5d-fast-inserter-right-90d-close","fast-inserter")
			ahide("5d-extreme-inserter-left-90d","express-inserter")
			ahide("5d-extreme-inserter-right-90d","express-inserter")
			ahide("5d-extreme-inserter-left-90d-close","express-inserter")
			ahide("5d-extreme-inserter-right-90d-close","express-inserter")
			ahide("5d-inserter-smart-speed2-range1-close","filter-inserter")
			ahide("5d-inserter-smart-speed2-range2","filter-inserter")
			ahide("5d-inserter-smart-speed2-range2-close","filter-inserter")
			ahide("5d-inserter-smart-speed3-range1","express-filter-inserter")
			ahide("5d-inserter-smart-speed3-range1-close","express-filter-inserter")
			
			switch_tech("inserters")
			switch_tech("inserters-2")
			switch_tech("inserters-3")
			switch_tech("close")
			switch_tech("close-2")
			switch_tech("close-3")
			switch_tech("side-inserters")
			switch_tech("side-inserters-2")
			switch_tech("side-inserters-3")
			switch_tech("smart-inserters")
		end
	end
	do	--[[transport]]--
		
		aadd("rg-transport-0",					"basic-transport-belt",															"a[13]-bob")
		aadd("rg-transport-0",					"fast-transport-belt",															"a[26]-bob")
		aadd("rg-transport-0",					"express-transport-belt",														"a[40]-bob")
		aadd("rg-transport-0",					"turbo-transport-belt",															"a[53]-bob")
		aadd("rg-transport-0",					"ultimate-transport-belt",														"a[66]-bob")
		
		aadd("rg-transport-6",					"underground-belt",																"a[13]-bob")
		aadd("rg-transport-6",					"fast-underground-belt",														"a[26]-bob")
		aadd("rg-transport-6",					"express-underground-belt",														"a[40]-bob")
		aadd("rg-transport-6",					"turbo-underground-belt",														"a[53]-bob")
		aadd("rg-transport-6",					"ultimate-underground-belt",													"a[66]-bob")
		
		aadd("rg-transport-9",					"splitter",																		"a[13]-bob")
		aadd("rg-transport-9",					"fast-splitter",																"a[26]-bob")
		aadd("rg-transport-9",					"express-splitter",																"a[40]-bob")
		aadd("rg-transport-9",					"turbo-splitter",																"a[53]-bob")
		aadd("rg-transport-9",					"ultimate-splitter",															"a[66]-bob")
		
		aadd("rg-transport-11",					"bob-valve",																	"a")
		
		aadd("rg-transport-13",				"stone-pipe",																		"b")
		aadd("rg-transport-13",				"pipe",																				"c")
		aadd("rg-transport-13",				"copper-pipe",																		"d")
		aadd("rg-transport-13",				"steel-pipe",																		"e")
		aadd("rg-transport-13",				"bronze-pipe",																		"f")
		aadd("rg-transport-13",				"plastic-pipe",																		"g")
		aadd("rg-transport-13",				"brass-pipe",																		"h")
		aadd("rg-transport-13",				"ceramic-pipe",																		"i")
		aadd("rg-transport-13",				"titanium-pipe",																	"j")
		aadd("rg-transport-13",				"tungsten-pipe",																	"k")
		
		aadd("rg-transport-14",				"stone-pipe-to-ground",																"a")
		aadd("rg-transport-14",				"pipe-to-ground",																	"b")
		aadd("rg-transport-14",				"copper-pipe-to-ground",															"c")
		aadd("rg-transport-14",				"steel-pipe-to-ground",																"d")
		aadd("rg-transport-14",				"bronze-pipe-to-ground",															"e")
		aadd("rg-transport-14",				"plastic-pipe-to-ground",															"f")
		aadd("rg-transport-14",				"brass-pipe-to-ground",																"g")
		aadd("rg-transport-14",				"ceramic-pipe-to-ground",															"h")
		aadd("rg-transport-14",				"titanium-pipe-to-ground",															"i")
		aadd("rg-transport-14",				"tungsten-pipe-to-ground",															"j")
		
		if regroup.settings.graphics_tuning then
			local function set_sprite(pic)
				local pic = pic or "u_line_y"
				return {
					filename = "__Regroup__/graphics/entity/"..pic..".png",
					priority = "high",
					width = 64,
					height = 64,
					x = 64,
					scale = 0.5
				}
			end
			
			if i_exist("green-underground-belt") then
			data.raw["underground-belt"]["green-underground-belt"].underground_sprite = set_sprite("u_line_g") end
			if i_exist("purple-underground-belt") then
			data.raw["underground-belt"]["purple-underground-belt"].underground_sprite = set_sprite("u_line_p") end
		end
		
		if allow_changes then
			if i_exist("5d-mk4-transport-belt") then
				ahide("green-transport-belt")
				ahide("green-underground-belt")
				ahide("green-splitter")
				ahide("purple-transport-belt")
				ahide("purple-underground-belt")
				ahide("purple-splitter")
				switch_tech("bob-logistics-4")
				switch_tech("bob-logistics-5")
			end
			if regroup.settings.bob_pipes then
				if data.raw.item["5d-pipe-mk2"] then
					ahide("copper-pipe")
					ahide("steel-pipe")
					ahide("copper-pipe-to-ground")
					ahide("steel-pipe-to-ground")
					rg.r_replace_ingredient_in_all("copper-pipe",					"pipe")
					rg.r_replace_ingredient_in_all("steel-pipe",					"pipe")
					else
				end
				ahide("stone-pipe")
				ahide("bronze-pipe")
				ahide("plastic-pipe")
				ahide("brass-pipe")
				ahide("ceramic-pipe")
				ahide("titanium-pipe")
				ahide("tungsten-pipe")
				ahide("stone-pipe-to-ground")
				ahide("bronze-pipe-to-ground")
				ahide("plastic-pipe-to-ground")
				ahide("brass-pipe-to-ground")
				ahide("ceramic-pipe-to-ground")
				ahide("titanium-pipe-to-ground")
				ahide("tungsten-pipe-to-ground")
				rg.r_replace_ingredient_in_all("bronze-pipe",					"pipe")
				
				if data.raw.item["5d-pipe-mk2"] then
					rg.r_replace_ingredient_in_all("steel-pipe",						"5d-pipe-mk2")
					rg.r_replace_ingredient_in_all("plastic-pipe",					"5d-pipe-mk2")
					rg.r_replace_ingredient_in_all("brass-pipe",						"5d-pipe-mk2")
					rg.r_replace_ingredient_in_all("ceramic-pipe",					"5d-pipe-mk3")
					rg.r_replace_ingredient_in_all("titanium-pipe",				"5d-pipe-mk3")
					rg.r_replace_ingredient_in_all("tungsten-pipe",				"5d-pipe-mk3")
					else
					rg.r_replace_ingredient_in_all("plastic-pipe",					"copper-pipe")
					rg.r_replace_ingredient_in_all("brass-pipe",						"copper-pipe")
					rg.r_replace_ingredient_in_all("ceramic-pipe",					"steel-pipe")
					rg.r_replace_ingredient_in_all("titanium-pipe",				"steel-pipe")
					rg.r_replace_ingredient_in_all("tungsten-pipe",				"steel-pipe")
				end
			end
		end
	end
	do	--[[logistic]]--
		aadd("rg-logistic-0",					"artillery-targeting-remote",													"d")
		
		aadd("rg-logistic-2",					"roboport",																						"a")
		aadd("rg-logistic-2",					"bob-roboport-2",																			"b")
		aadd("rg-logistic-2",					"bob-roboport-3",																			"e")
		aadd("rg-logistic-2",					"bob-roboport-4",																			"h")
		
		aadd("rg-logistic-3",					"bob-logistic-zone-expander",													"f")
		aadd("rg-logistic-3",					"bob-logistic-zone-expander-2",												"g")
		aadd("rg-logistic-3",					"bob-logistic-zone-expander-3",												"h")
		aadd("rg-logistic-3",					"bob-logistic-zone-expander-4",												"i")
		aadd("rg-logistic-3",					"bob-logistic-zone-interface",												"j")
		
		aadd("rg-logistic-4",					"bob-robo-charge-port",																"a")
		aadd("rg-logistic-4",					"bob-robo-charge-port-2",															"b")
		aadd("rg-logistic-4",					"bob-robo-charge-port-3",															"c")
		aadd("rg-logistic-4",					"bob-robo-charge-port-4",															"d")
		aadd("rg-logistic-4",					"bob-robo-charge-port-large",													"e")
		aadd("rg-logistic-4",					"bob-robo-charge-port-large-2",												"f")
		aadd("rg-logistic-4",					"bob-robo-charge-port-large-3",												"g")
		aadd("rg-logistic-4",					"bob-robo-charge-port-large-4",												"h")
		
		aadd("rg-logistic-5",					"logistic-robot",																			"a")
		aadd("rg-logistic-5",					"bob-logistic-robot-2",																"b")
		aadd("rg-logistic-5",					"bob-logistic-robot-3",																"e")
		aadd("rg-logistic-5",					"bob-logistic-robot-4",																"g")
		aadd("rg-logistic-5",					"bob-logistic-robot-5",																"h")
		
		aadd("rg-logistic-6",					"construction-robot",																	"a")
		aadd("rg-logistic-6",					"bob-construction-robot-2",														"b")
		aadd("rg-logistic-6",					"bob-construction-robot-3",														"e")
		aadd("rg-logistic-6",					"bob-construction-robot-4",														"g")
		aadd("rg-logistic-6",					"bob-construction-robot-5",														"h")
		
		aadd("rg-logistic-7",					"logistic-chest-storage",												"a[048]")
		aadd("rg-logistic-7",					"logistic-chest-storage-2",												"a[0??]-bob")
		aadd("rg-logistic-7",					"logistic-chest-storage-3",												"a[080]-bob")
		aadd("rg-logistic-7",					"logistic-chest-requester",												"b[048]")
		aadd("rg-logistic-7",					"logistic-chest-requester-2",											"b[0??]-bob")
		aadd("rg-logistic-7",					"logistic-chest-requester-3",											"b[080]-bob")
		aadd("rg-logistic-7",					"logistic-chest-passive-provider",										"c[048]")
		aadd("rg-logistic-7",					"logistic-chest-passive-provider-2",									"c[0??]-bob")
		aadd("rg-logistic-7",					"logistic-chest-passive-provider-3",									"c[080]-bob")
		
		aadd("rg-logistic-8",					"logistic-chest-active-provider",										"a[048]")
		aadd("rg-logistic-8",					"logistic-chest-active-provider-2",										"a[0??]-bob")
		aadd("rg-logistic-8",					"logistic-chest-active-provider-3",										"a[080]-bob")
		aadd("rg-logistic-8",					"logistic-chest-buffer",												"b[048]")
		aadd("rg-logistic-8",					"logistic-chest-buffer-2",												"b[0??]-bob")
		aadd("rg-logistic-8",					"logistic-chest-buffer-3",												"b[080]-bob")
		
		aadd("rg-logistic-11",					"bob-robochest",														"e")
		aadd("rg-logistic-11",					"bob-robochest-2",														"f")
		aadd("rg-logistic-11",					"bob-robochest-3",														"g")
		aadd("rg-logistic-11",					"bob-robochest-4",														"h")
		
		aadd("rg-logistic-13",					"tinned-copper-cable",																"f")
		aadd("rg-logistic-13",					"insulated-cable",																		"g")
		aadd("rg-logistic-13",					"gilded-copper-cable",																"h")
		
		
		if regroup.settings.graphics_tuning then
			rg.set_icon("bob-roboport-3", "__Regroup__/graphics/icons/roboport2.png", 32)
			rg.set_icon("bob-roboport-4", "__Regroup__/graphics/icons/roboport3.png", 32)
			
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].base.filename = "__Regroup__/graphics/entity/roboport2-base.png"
			end
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].base_patch.filename = "__Regroup__/graphics/entity/roboport2-base-patch.png"
			end
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].base_animation.filename = "__Regroup__/graphics/entity/roboport2-base-animation.png"
			end
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].door_animation_up.filename = "__Regroup__/graphics/entity/roboport2-door-up.png"
			end
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].door_animation_down.filename = "__Regroup__/graphics/entity/roboport2-door-down.png"
			end
			if data.raw["roboport"]["bob-roboport-3"] then
				data.raw["roboport"]["bob-roboport-3"].recharging_animation.filename = "__Regroup__/graphics/entity/roboport2-recharging.png"
			end
			if data.raw["roboport"]["bob-roboport-4"] then
				data.raw["roboport"]["bob-roboport-4"].base.filename = "__Regroup__/graphics/entity/roboport3-base.png"
			end
			if data.raw["roboport"]["bob-roboport-4"] then
				data.raw["roboport"]["bob-roboport-4"].base_patch.filename = "__Regroup__/graphics/entity/roboport3-base-patch.png"
			end
		end
		
		if i_exist("logistic-chest-storage") and i_exist("5d-storage") and allow_changes then
			ahide("logistic-chest-storage-2")
			ahide("logistic-chest-requester-2")
			ahide("logistic-chest-passive-provider-2")
			ahide("logistic-chest-active-provider-2")
		end
		
		if i_exist("bob-roboport-2") and i_exist("5d-roboport-2") and allow_changes then
			ahide("5d-roboport-2")
			ahide("5d-logistic-robot-2")
			ahide("5d-construction-robot-2")
			switch_tech("robots-2")
		end
	end
	do	--[[energy]]--
		aadd("rg-energy-1",						"boiler-2",																					"a[060][51000]-bob")
		aadd("rg-energy-1",						"boiler-3",																					"a[070][66000]-bob")
		aadd("rg-energy-1",						"boiler-4",																					"a[080][81000]-bob")
		aadd("rg-energy-1",						"boiler-5",																					"a[080][81000]-bob")
		
		aadd("rg-energy-2",						"steam-engine-2",																			"a[16000]-bob")
		aadd("rg-energy-2",						"steam-engine-3",																			"a[27000]-bob")
		aadd("rg-energy-2",						"steam-engine-4",																			"a[41000]-bob")
		aadd("rg-energy-2",						"steam-engine-5",																			"a[41000]-bob")
		
		aadd("rg-energy-3",						"heat-exchanger-2",																			"a[15000]-bob")
		aadd("rg-energy-3",						"heat-exchanger-3",																			"a[22000]-bob")
		
		aadd("rg-energy-4",						"steam-turbine",																			"a[05800]")
		aadd("rg-energy-4",						"steam-turbine-2",																			"a[10000]-bob")
		aadd("rg-energy-4",						"steam-turbine-3",																			"a[15800]-bob")
		
		aadd("rg-energy-5",						"fluid-generator",																			"a[02000]-bob")
		aadd("rg-energy-5",						"fluid-generator-2",																		"a[02700]-bob")
		aadd("rg-energy-5",						"fluid-generator-3",																		"a[03500]-bob")
		aadd("rg-energy-5",						"hydrazine-generator",																		"b[04100]-bob")
		
		aadd("rg-energy-7",						"solar-panel",																				"a[060000]")
		aadd("rg-energy-7",						"solar-panel-2",																			"a[090000]-bob")
		aadd("rg-energy-7",						"solar-panel-3",																			"a[135000]-bob")
		aadd("rg-energy-7",						"solar-panel-small",																		"a[026000]-bob")
		aadd("rg-energy-7",						"solar-panel-small-2",																		"a[040000]-bob")
		aadd("rg-energy-7",						"solar-panel-small-3",																		"a[060000]-bob")
		aadd("rg-energy-7",						"solar-panel-large",																		"a[106000]-bob")
		aadd("rg-energy-7",						"solar-panel-large-2",																		"a[160000]-bob")
		aadd("rg-energy-7",						"solar-panel-large-3",																		"a[240000]-bob")
		
		aadd("rg-energy-11",					"accumulator",																				"a[00300][00300][02000]")
		aadd("rg-energy-11",					"slow-accumulator",																			"a[00240][00030][01600]-bob")
		aadd("rg-energy-11",					"slow-accumulator-2",																		"a[00360][00045][02400]-bob")
		aadd("rg-energy-11",					"slow-accumulator-3",																		"a[00540][00064][03600]-bob")
		aadd("rg-energy-11",					"large-accumulator",																		"a[00600][00600][04000]-bob")
		aadd("rg-energy-11",					"large-accumulator-2",																		"a[00900][00900][06000]-bob")
		aadd("rg-energy-11",					"large-accumulator-3",																		"a[01300][01300][09000]-bob")
		aadd("rg-energy-11",					"fast-accumulator",																			"a[00240][00960][01600]-bob")
		aadd("rg-energy-11",					"fast-accumulator-2",																		"a[00360][01400][02400]-bob")
		aadd("rg-energy-11",					"fast-accumulator-3",																		"a[00540][02100][03600]-bob")
		
		aadd("rg-energy-12",					"small-electric-pole",																		"a[007][005x005]")
		
		aadd("rg-energy-13",					"medium-electric-pole",																		"a[009][007x007]")
		aadd("rg-energy-13",					"medium-electric-pole-2",																	"a[011][005x005]-bob")
		aadd("rg-energy-13",					"medium-electric-pole-3",																	"a[013][011x011]-bob")
		aadd("rg-energy-13",					"medium-electric-pole-4",																	"a[015][013x013]-bob")
		
		aadd("rg-energy-14",					"big-electric-pole",																		"a[030][004x004]")
		aadd("rg-energy-14",					"big-electric-pole-2",																		"a[040][004x004]-bob")
		aadd("rg-energy-14",					"big-electric-pole-3",																		"a[050][004x004]-bob")
		aadd("rg-energy-14",					"big-electric-pole-4",																		"a[060][004x004]-bob")
		
		aadd("rg-energy-15",					"substation",																				"a[018][018x018]")
		aadd("rg-energy-15",					"substation-2",																				"a[024][024x024]-bob")
		aadd("rg-energy-15",					"substation-3",																				"a[030][030x030]-bob")
		aadd("rg-energy-15",					"substation-4",																				"a[036][036x036]-bob")
		
		if i_exist("boiler-2") and i_exist("5d-boiler") and allow_changes then
			ahide("boiler-2")
			ahide("boiler-3")
			ahide("boiler-4")
			switch_tech("bob-boiler-1")
			switch_tech("bob-boiler-2")
			switch_tech("bob-boiler-3")
		end
		
		if i_exist("steam-engine-2") and i_exist("5d-steam-engine-2") and allow_changes then
			ahide("steam-engine-2")
			ahide("steam-engine-3")
			switch_tech("steam-engine-generator-1")
			switch_tech("steam-engine-generator-2")
		end
		
		if allow_changes
			and i_not_exist("5d-basic-accumulator-2")
			and i_not_exist("y-accumulator-m")
			and i_exist("slow-accumulator") then
			ahide("accumulator")
		end
		
		if i_exist("5d-solar-panel-2") or i_exist("y_alien_solar") and allow_changes then
			ahide("solar-panel-2")
			ahide("solar-panel-3")
		end
	end
	do	--[[defense]]--
		aadd("rg-defense-0",						"reinforced-wall",																		"d")
		
		aadd("rg-defense-1",						"reinforced-gate",																		"c")
		
		aadd("rg-defense-3",						"flamethrower-turret",																"a")
		aadd("rg-defense-3",						"bob-sniper-turret-1",																"b")
		aadd("rg-defense-3",						"bob-sniper-turret-2",																"c")
		aadd("rg-defense-3",						"bob-sniper-turret-3",																"d")
		
		aadd("rg-defense-4",						"gun-turret",																					"b")
		aadd("rg-defense-4",						"bob-gun-turret-2",																		"d")
		aadd("rg-defense-4",						"bob-gun-turret-3",																		"e")
		aadd("rg-defense-4",						"bob-gun-turret-4",																		"f")
		aadd("rg-defense-4",						"bob-gun-turret-5",																		"g")
		
		aadd("rg-defense-5",						"laser-turret",																				"b")
		aadd("rg-defense-5",						"bob-laser-turret-2",																	"d")
		aadd("rg-defense-5",						"bob-laser-turret-3",																	"e")
		aadd("rg-defense-5",						"bob-laser-turret-4",																	"f")
		aadd("rg-defense-5",						"bob-laser-turret-5",																	"g")
		
		aadd("rg-defense-6",						"artillery-turret",																		"a")
		aadd("rg-defense-6",						"bob-artillery-turret-2",															"b")
		aadd("rg-defense-6",						"bob-artillery-turret-3",															"c")
		
		aadd("rg-defense-8",						"radar",																							"a")
		aadd("rg-defense-8",						"radar-2",																						"b")
		aadd("rg-defense-8",						"radar-3",																						"c")
		aadd("rg-defense-8",						"radar-4",																						"d")
		aadd("rg-defense-8",						"radar-5",																						"e")
	end
	do	--[[armor]]--
		aadd("rg-armor-4",						"light-armor",																				"a")
		aadd("rg-armor-4",						"heavy-armor",																				"b")
		aadd("rg-armor-4",						"heavy-armor-2",																			"b2")
		aadd("rg-armor-4",						"heavy-armor-3",																			"b3")
		aadd("rg-armor-4",						"modular-armor",																			"c")
		
		aadd("rg-armor-5",						"power-armor",																				"a")
		aadd("rg-armor-5",						"power-armor-mk2",																		"a2")
		aadd("rg-armor-5",						"bob-power-armor-mk3",																"a3")
		aadd("rg-armor-5",						"bob-power-armor-mk4",																"a4")
		aadd("rg-armor-5",						"bob-power-armor-mk5",																"a5")
		
		aadd("rg-armor-7",						"exoskeleton-equipment",															"a1")
		aadd("rg-armor-7",						"exoskeleton-equipment-2",														"a2")
		aadd("rg-armor-7",						"exoskeleton-equipment-3",														"a3")
		aadd("rg-armor-7",						"night-vision-equipment",															"b1")
		aadd("rg-armor-7",						"night-vision-equipment-2",														"b2")
		aadd("rg-armor-7",						"night-vision-equipment-3",														"b3")
		aadd("rg-armor-7",						"personal-roboport-equipment",												"c1")
		aadd("rg-armor-7",						"personal-roboport-mk2-equipment",										"c2")
		
		aadd("rg-armor-8",						"solar-panel-equipment",															"a1")
		aadd("rg-armor-8",						"solar-panel-equipment-2",														"a2")
		aadd("rg-armor-8",						"solar-panel-equipment-3",														"a3")
		aadd("rg-armor-8",						"solar-panel-equipment-4",														"a4")
		aadd("rg-armor-8",						"fusion-reactor-equipment",														"b1")
		aadd("rg-armor-8",						"fusion-reactor-equipment-2",													"b2")
		aadd("rg-armor-8",						"fusion-reactor-equipment-3",													"b3")
		aadd("rg-armor-8",						"fusion-reactor-equipment-4",													"b4")
		
		aadd("rg-armor-9",						"battery-equipment",																	"a1")
		aadd("rg-armor-9",						"battery-mk2-equipment",															"a2")
		aadd("rg-armor-9",						"battery-mk3-equipment",															"a3")
		aadd("rg-armor-9",						"battery-mk4-equipment",															"a4")
		aadd("rg-armor-9",						"battery-mk5-equipment",															"a5")
		aadd("rg-armor-9",						"battery-mk6-equipment",															"a6")
		
		aadd("rg-armor-10",						"personal-laser-defense-equipment",										"a1")
		aadd("rg-armor-10",						"personal-laser-defense-equipment-2",									"a2")
		aadd("rg-armor-10",						"personal-laser-defense-equipment-3",									"a3")
		aadd("rg-armor-10",						"personal-laser-defense-equipment-4",									"a4")
		aadd("rg-armor-10",						"personal-laser-defense-equipment-5",									"a5")
		aadd("rg-armor-10",						"personal-laser-defense-equipment-6",									"a6")
		aadd("rg-armor-10",						"discharge-defense-equipment",												"d1")
		
		aadd("rg-armor-11",						"energy-shield-equipment",														"a1")
		aadd("rg-armor-11",						"energy-shield-mk2-equipment",												"a2")
		aadd("rg-armor-11",						"energy-shield-mk3-equipment",												"a3")
		aadd("rg-armor-11",						"energy-shield-mk4-equipment",												"a4")
		aadd("rg-armor-11",						"energy-shield-mk5-equipment",												"a5")
		aadd("rg-armor-11",						"energy-shield-mk6-equipment",												"a6")
		
		aadd("rg-armor-13",						"vehicle-battery-1",																	"a1")
		aadd("rg-armor-13",						"vehicle-battery-2",																	"a2")
		aadd("rg-armor-13",						"vehicle-battery-3",																	"a3")
		aadd("rg-armor-13",						"vehicle-battery-4",																	"a4")
		aadd("rg-armor-13",						"vehicle-battery-5",																	"a5")
		aadd("rg-armor-13",						"vehicle-battery-6",																	"a6")
		
		aadd("rg-armor-14",						"vehicle-big-turret-1",																"a1")
		aadd("rg-armor-14",						"vehicle-big-turret-2",																"a2")
		aadd("rg-armor-14",						"vehicle-big-turret-3",																"a3")
		aadd("rg-armor-14",						"vehicle-big-turret-4",																"a4")
		aadd("rg-armor-14",						"vehicle-big-turret-5",																"a5")
		aadd("rg-armor-14",						"vehicle-big-turret-6",																"a6")
		
		aadd("rg-armor-15",						"vehicle-fusion-cell-1",															"a1")
		aadd("rg-armor-15",						"vehicle-fusion-cell-2",															"a2")
		aadd("rg-armor-15",						"vehicle-fusion-cell-3",															"a3")
		aadd("rg-armor-15",						"vehicle-fusion-cell-4",															"a4")
		aadd("rg-armor-15",						"vehicle-fusion-cell-5",															"a5")
		aadd("rg-armor-15",						"vehicle-fusion-cell-6",															"a6")
		
		aadd("rg-armor-16",						"vehicle-fusion-reactor-1",														"a1")
		aadd("rg-armor-16",						"vehicle-fusion-reactor-2",														"a2")
		aadd("rg-armor-16",						"vehicle-fusion-reactor-3",														"a3")
		aadd("rg-armor-16",						"vehicle-fusion-reactor-4",														"a4")
		aadd("rg-armor-16",						"vehicle-fusion-reactor-5",														"a5")
		aadd("rg-armor-16",						"vehicle-fusion-reactor-6",														"a6")
		
		aadd("rg-armor-17",						"vehicle-laser-defense-1",														"a1")
		aadd("rg-armor-17",						"vehicle-laser-defense-2",														"a2")
		aadd("rg-armor-17",						"vehicle-laser-defense-3",														"a3")
		aadd("rg-armor-17",						"vehicle-laser-defense-4",														"a4")
		aadd("rg-armor-17",						"vehicle-laser-defense-5",														"a5")
		aadd("rg-armor-17",						"vehicle-laser-defense-6",														"a6")
		
		aadd("rg-armor-18",						"vehicle-shield-1",																		"a1")
		aadd("rg-armor-18",						"vehicle-shield-2",																		"a2")
		aadd("rg-armor-18",						"vehicle-shield-3",																		"a3")
		aadd("rg-armor-18",						"vehicle-shield-4",																		"a4")
		aadd("rg-armor-18",						"vehicle-shield-5",																		"a5")
		aadd("rg-armor-18",						"vehicle-shield-6",																		"a6")
		
		aadd("rg-armor-19",						"vehicle-solar-panel-1",															"a1")
		aadd("rg-armor-19",						"vehicle-solar-panel-2",															"a2")
		aadd("rg-armor-19",						"vehicle-solar-panel-3",															"a3")
		aadd("rg-armor-19",						"vehicle-solar-panel-4",															"a4")
		aadd("rg-armor-19",						"vehicle-solar-panel-5",															"a5")
		aadd("rg-armor-19",						"vehicle-solar-panel-6",															"a6")
		
		aadd("rg-armor-20",						"vehicle-engine",																			"a")
		aadd("rg-armor-20",						"vehicle-motor",																			"b")
		aadd("rg-armor-20",						"vehicle-roboport",																		"c")
		aadd("rg-armor-20",						"vehicle-roboport-2",																	"c2")
		aadd("rg-armor-20",						"artillery-wagon",																		"e")
		aadd("rg-armor-20",						"bob-artillery-wagon-2",															"f")
		aadd("rg-armor-20",						"bob-artillery-wagon-3",															"g")
		
		for _,recipe in pairs(data.raw.item) do
			if recipe.subgroup == "vehicle-equipment" then
				rg.get_group_name("rg-armor-23", recipe.name)
				aadd("rg-armor-23",		recipe.name,				"a["..recipe.name.."]")
			end
		end
		
	end
	do	--[[intermediate]]--
		
		aadd("rg-intermediate-1",			"basic-circuit-board",																"a")
		aadd("rg-intermediate-1",			"circuit-board",																			"c")
		aadd("rg-intermediate-1",			"superior-circuit-board",															"e")
		aadd("rg-intermediate-1",			"multi-layer-circuit-board",													"g")
		aadd("rg-intermediate-1",			"advanced-processing-unit",														"h")
		
		aadd("rg-intermediate-2",			"wooden-board",																				"a")
		aadd("rg-intermediate-2",			"phenolic-board",																			"b")
		aadd("rg-intermediate-2",			"fibreglass-board",																		"c")
		aadd("rg-intermediate-2",			"heat-shield-tile",																		"d")
		
		aadd("rg-intermediate-3",			"solder-alloy",																				"d")
		aadd("rg-intermediate-3",			"solder-alloy-lead",																	"e")
		aadd("rg-intermediate-3",			"solder",																							"f")
		aadd("rg-intermediate-3",			"module-case",																				"g")
		aadd("rg-intermediate-3",			"basic-electronic-components",												"h")
		aadd("rg-intermediate-3",			"electronic-components",															"i")
		aadd("rg-intermediate-3",			"intergrated-electronics",														"j")
		aadd("rg-intermediate-3",			"processing-electronics",															"k")
		
		aadd("rg-intermediate-4",			"steel-gear-wheel",																		"e")
		aadd("rg-intermediate-4",			"brass-gear-wheel",																		"f")
		aadd("rg-intermediate-4",			"titanium-gear-wheel",																"g")
		aadd("rg-intermediate-4",			"nitinol-gear-wheel",																	"h")
		aadd("rg-intermediate-4",			"tungsten-gear-wheel",																"i")
		aadd("rg-intermediate-4",			"cobalt-steel-gear-wheel",														"j")
		
		aadd("rg-intermediate-5",			"steel-bearing-ball",																	"a")
		aadd("rg-intermediate-5",			"ceramic-bearing-ball",																"b")
		aadd("rg-intermediate-5",			"nitinol-bearing-ball",																"c")
		aadd("rg-intermediate-5",			"titanium-bearing-ball",															"d")
		aadd("rg-intermediate-5",			"cobalt-steel-bearing-ball",													"e")
		aadd("rg-intermediate-5",			"steel-bearing",																			"f")
		aadd("rg-intermediate-5",			"ceramic-bearing",																		"g")
		aadd("rg-intermediate-5",			"nitinol-bearing",																		"h")
		aadd("rg-intermediate-5",			"titanium-bearing",																		"i")
		aadd("rg-intermediate-5",			"cobalt-steel-bearing",																"j")
		
		aadd("rg-intermediate-7",			"iron-stick",																					"a")
		aadd("rg-intermediate-7",			"explosives",																					"b")
		aadd("rg-intermediate-7",			"cliff-explosives",																		"c")
		aadd("rg-intermediate-7",			"grinding-wheel",																			"d")
		aadd("rg-intermediate-7",			"polishing-wheel",																		"e")
		aadd("rg-intermediate-7",			"polishing-compound",																	"f")
		aadd("rg-intermediate-7",			"bob-seedling",																				"g")
		aadd("rg-intermediate-7",			"bob-basic-greenhouse-cycle",													"h")
		aadd("rg-intermediate-7",			"bob-advanced-greenhouse-cycle",											"i")
		aadd("rg-intermediate-7",			"fertiliser",																					"j")
		aadd("rg-intermediate-7",			"gun-cotton",																					"k")	
		aadd("rg-intermediate-7",			"engine-unit",																				"q")
		aadd("rg-intermediate-7",			"electric-engine-unit",																"r")
		
		aadd("rg-intermediate-8",			"battery",																						"a")
		aadd("rg-intermediate-8",			"lithium-ion-battery",																"b")
		aadd("rg-intermediate-8",			"silver-zinc-battery",																"c")
		
		aadd("rg-intermediate-11",			"flying-robot-frame",																	"a")
		aadd("rg-intermediate-11",			"flying-robot-frame-2",																"b")
		aadd("rg-intermediate-11",			"flying-robot-frame-3",																"c")
		aadd("rg-intermediate-11",			"flying-robot-frame-4",																"d")
		aadd("rg-intermediate-11",			"roboport-chargepad-1",																"e")
		aadd("rg-intermediate-11",			"roboport-chargepad-2",																"f")
		aadd("rg-intermediate-11",			"roboport-chargepad-3",																"g")
		aadd("rg-intermediate-11",			"roboport-chargepad-4",																"h")
		
		aadd("rg-intermediate-12",			"roboport-antenna-1",																	"a")
		aadd("rg-intermediate-12",			"roboport-antenna-2",																	"b")
		aadd("rg-intermediate-12",			"roboport-antenna-3",																	"c")
		aadd("rg-intermediate-12",			"roboport-antenna-4",																	"d")
		aadd("rg-intermediate-12",			"roboport-door-1",																		"e")
		aadd("rg-intermediate-12",			"roboport-door-2",																		"f")
		aadd("rg-intermediate-12",			"roboport-door-3",																		"g")
		aadd("rg-intermediate-12",			"roboport-door-4",																		"h")
		
		aadd("rg-intermediate-13",			"robot-brain-logistic",																"a")
		aadd("rg-intermediate-13",			"robot-brain-logistic-2",															"b")
		aadd("rg-intermediate-13",			"robot-brain-logistic-3",															"c")
		aadd("rg-intermediate-13",			"robot-brain-logistic-4",															"d")
		aadd("rg-intermediate-13",			"robot-brain-construction",														"e")
		aadd("rg-intermediate-13",			"robot-brain-construction-2",													"f")
		aadd("rg-intermediate-13",			"robot-brain-construction-3",													"g")
		aadd("rg-intermediate-13",			"robot-brain-construction-4",													"h")
		
		aadd("rg-intermediate-14",			"robot-tool-construction",														"a")
		aadd("rg-intermediate-14",			"robot-tool-construction-2",													"b")
		aadd("rg-intermediate-14",			"robot-tool-construction-3",													"c")
		aadd("rg-intermediate-14",			"robot-tool-construction-4",													"d")
		aadd("rg-intermediate-14",			"robot-tool-logistic",																"e")
		aadd("rg-intermediate-14",			"robot-tool-logistic-2",															"f")
		aadd("rg-intermediate-14",			"robot-tool-logistic-3",															"g")
		aadd("rg-intermediate-14",			"robot-tool-logistic-4",															"h")
		
		aadd("rg-intermediate-15",			"robot-brain-combat",																	"a")
		aadd("rg-intermediate-15",			"robot-brain-combat-2",																"b")
		aadd("rg-intermediate-15",			"robot-brain-combat-3",																"c")
		aadd("rg-intermediate-15",			"robot-brain-combat-4",																"d")
		aadd("rg-intermediate-15",			"robot-tool-combat",																	"e")
		aadd("rg-intermediate-15",			"robot-tool-combat-2",																"f")
		aadd("rg-intermediate-15",			"robot-tool-combat-3",																"g")
		aadd("rg-intermediate-15",			"robot-tool-combat-4",																"h")
		
		aadd("rg-intermediate-16",			"low-density-structure",															"a")
		aadd("rg-intermediate-16",			"satellite",																					"b")
		aadd("rg-intermediate-16",			"rocket-silo",																				"c")
		aadd("rg-intermediate-16",			"rocket-part",																				"d")
		aadd("rg-intermediate-16",			"rocket-control-unit",																"e")
		aadd("rg-intermediate-16",			"rocket-fuel",																				"f")
		aadd("rg-intermediate-16",			"nuclear-fuel",																				"g")
		
		
		if false and allow_changes and i_exist("module-case") and i_exist("solder") then
			ahide("module-case",					"solder")
			for tech_name,tech in pairs(data.raw.technology) do
				if tech.unit.ingredients then
					for i,ingredient in pairs(tech.unit.ingredients) do
						if ingredient[1] == "module-case" then
							data.raw.technology[tech_name].unit.ingredients[i][1] = "solder"
						end
					end
				end
			end
		end
		
		if regroup.settings.graphics_tuning then
			rg.set_icon("science-pack-4", "__Regroup__/graphics/icons/science-pack4.png", 32)
			rg.set_icon("science-pack-gold", "__Regroup__/graphics/icons/science-pack-gold.png", 32)
		end
	end
	do	--[[module]]--
		
		aadd("rg-module-0",						"lab-2",																							"b")
		aadd("rg-module-0",						"lab-alien",																					"c")
		
		aadd("rg-module-0",						"beacon-2",																						"g")
		aadd("rg-module-0",						"beacon-3",																						"h")
		
		aadd("rg-module-1",						"logistic-science-pack",															"i")
		aadd("rg-module-1",						"science-pack-4",																			"j")
		aadd("rg-module-1",						"science-pack-gold",																	"k")
		aadd("rg-module-1",						"alien-science-pack",																	"l")
		aadd("rg-module-1",						"alien-science-pack-blue",														"m")
		aadd("rg-module-1",						"alien-science-pack-orange",													"n")
		aadd("rg-module-1",						"alien-science-pack-purple",													"o")
		aadd("rg-module-1",						"alien-science-pack-yellow",													"p")
		aadd("rg-module-1",						"alien-science-pack-green",														"q")
		aadd("rg-module-1",						"alien-science-pack-red",															"r")
		
		if data.raw["item-subgroup"]["speed-module"] then
			aadd("speed-module",					"speed-module",																				"a")
			aadd("speed-module",					"speed-module-2",																			"b")
			aadd("speed-module",					"speed-module-3",																			"c")
		end
		if data.raw["item-subgroup"]["productivity-module"] then
			aadd("productivity-module",		"productivity-module",																"a")
			aadd("productivity-module",		"productivity-module-2",															"b")
			aadd("productivity-module",		"productivity-module-3",															"c")
		end
		if data.raw["item-subgroup"]["effectivity-module"] then
			aadd("effectivity-module",		"effectivity-module",																	"a")
			aadd("effectivity-module",		"effectivity-module-2",																"b")
			aadd("effectivity-module",		"effectivity-module-3",																"c")
		end
		
		for _,v in pairs(data.raw["item-subgroup"]) do
			if v.group == "module-intermediates" then v.group = "rg-module" end
			if v.group == "bobmodules"			 then v.group = "rg-module" end
			if v.name  == "god-module"			 then v.order = "f-0g" end
		end
		
		if allow_changes and i_exist("module-contact") then
			ahide("5d-speed-module-4")
			ahide("5d-speed-module-5")
			ahide("5d-productivity-module-4")
			ahide("5d-productivity-module-5")
			ahide("5d-effectivity-module-4")
			ahide("5d-effectivity-module-5")
			ahide("5d-pollution-module-1")
			ahide("5d-pollution-module-2")
			ahide("5d-pollution-module-3")
			ahide("5d-pollution-module-4")
			ahide("5d-pollution-module-5")
			ahide("5d-speed-effectivity-4")
			ahide("5d-speed-pollution-4")
			ahide("5d-speed-productivity-4")
			ahide("5d-pollution-effectivity-4")
			ahide("5d-pollution-productivity-4")
			ahide("5d-effectivity-productivity-4")
			ahide("5d-speed-effectivity-5")
			ahide("5d-speed-pollution-5")
			ahide("5d-speed-productivity-5")
			ahide("5d-pollution-effectivity-5")
			ahide("5d-pollution-productivity-5")
			ahide("5d-effectivity-productivity-5")
		end
		
	end
	do	--[[weaponry]]--
		aadd("rg-weaponry-0",					"pistol",																							"a")
		aadd("rg-weaponry-0",					"submachine-gun",																			"b")
		aadd("rg-weaponry-0",					"shotgun",																						"c")
		aadd("rg-weaponry-0",					"combat-shotgun",																			"d")
		aadd("rg-weaponry-0",					"flamethrower",																				"e")
		aadd("rg-weaponry-0",					"rocket-launcher",																		"f")
		aadd("rg-weaponry-0",					"rifle",																							"g")
		aadd("rg-weaponry-0",					"sniper-rifle",																				"h")
		aadd("rg-weaponry-0",					"laser-rifle",																				"i")
		aadd("rg-weaponry-0",					"laser-beam-rifle",																		"j")
		
		aadd("rg-weaponry-1",					"shot",																								"c")
		aadd("rg-weaponry-1",					"cordite",																						"d")
		aadd("rg-weaponry-1",					"bullet-casing",																			"e")
		aadd("rg-weaponry-1",					"flamethrower-ammo",																	"h")	
		
		aadd("rg-weaponry-2",					"bullet",																							"a")
		aadd("rg-weaponry-2",					"ap-bullet",																					"b")
		aadd("rg-weaponry-2",					"he-bullet",																					"c")
		aadd("rg-weaponry-2",					"flame-bullet",																				"d")
		aadd("rg-weaponry-2",					"acid-bullet",																				"e")
		aadd("rg-weaponry-2",					"poison-bullet",																			"f")
		aadd("rg-weaponry-2",					"electric-bullet",																		"g")
		aadd("rg-weaponry-2",					"uranium-bullet",																			"h")
		
		aadd("rg-weaponry-4",					"bullet-magazine",																"a")
		aadd("rg-weaponry-4",					"firearm-magazine",																"b")
		aadd("rg-weaponry-4",					"piercing-rounds-magazine",														"c")
		aadd("rg-weaponry-4",					"uranium-rounds-magazine",														"d")
		
		aadd("rg-weaponry-4",					"magazine",																		"e")
		aadd("rg-weaponry-4",					"ap-bullet-magazine",															"f")
		aadd("rg-weaponry-4",					"he-bullet-magazine",															"g")
		aadd("rg-weaponry-4",					"flame-bullet-magazine",														"h")
		aadd("rg-weaponry-4",					"acid-bullet-magazine",															"i")
		aadd("rg-weaponry-4",					"poison-bullet-magazine",														"j")
		aadd("rg-weaponry-4",					"electric-bullet-magazine",														"k")
		
		aadd("rg-weaponry-6",					"shotgun-shell-casing",																"a")
		aadd("rg-weaponry-6",					"shotgun-shell",																			"b")
		aadd("rg-weaponry-6",					"piercing-shotgun-shell",															"c")

		aadd("rg-weaponry-7",					"better-shotgun-shell",																"d")
		aadd("rg-weaponry-7",					"shotgun-ap-shell",																		"e")
		aadd("rg-weaponry-7",					"shotgun-explosive-shell",														"f")
		aadd("rg-weaponry-7",					"shotgun-flame-shell",																"g")
		aadd("rg-weaponry-7",					"shotgun-acid-shell",																	"h")
		aadd("rg-weaponry-7",					"shotgun-poison-shell",																"i")
		aadd("rg-weaponry-7",					"shotgun-electric-shell",															"j")
		aadd("rg-weaponry-7",					"shotgun-uranium-shell",															"k")
		
		aadd("rg-weaponry-8",					"bullet-projectile",																	"a")
		aadd("rg-weaponry-8",					"ap-bullet-projectile",																"b")
		aadd("rg-weaponry-8",					"he-bullet-projectile",																"c")
		aadd("rg-weaponry-8",					"flame-bullet-projectile",														"d")
		aadd("rg-weaponry-8",					"acid-bullet-projectile",															"e")
		aadd("rg-weaponry-8",					"poison-bullet-projectile",														"f")
		aadd("rg-weaponry-8",					"electric-bullet-projectile",													"g")
		aadd("rg-weaponry-8",					"uranium-bullet-projectile",													"h")
		
		aadd("rg-weaponry-9",					"laser-rifle-battery-case",														"a")
		aadd("rg-weaponry-9",					"laser-rifle-battery",																"b")
		aadd("rg-weaponry-9",					"laser-beam-rifle-ammo",															"c")
		aadd("rg-weaponry-9",					"laser-rifle-battery-ruby",														"d")
		aadd("rg-weaponry-9",					"laser-rifle-battery-sapphire",												"e")
		aadd("rg-weaponry-9",					"laser-rifle-battery-emerald",												"f")
		aadd("rg-weaponry-9",					"laser-rifle-battery-amethyst",												"g")
		aadd("rg-weaponry-9",					"laser-rifle-battery-topaz",													"h")
		aadd("rg-weaponry-9",					"laser-rifle-battery-diamond",												"i")
		
		aadd("rg-weaponry-10",					"grenade",																						"a")
		aadd("rg-weaponry-10",					"cluster-grenade",																		"b")
		aadd("rg-weaponry-10",					"land-mine",																					"c")
		aadd("rg-weaponry-10",					"slowdown-mine",																			"d")
		aadd("rg-weaponry-10",					"poison-mine",																				"e")
		aadd("rg-weaponry-10",					"distractor-mine",																		"f")
		
		aadd("rg-weaponry-11",					"defender-robot",																			"a")
		aadd("rg-weaponry-11",					"distractor-robot",																		"b")
		aadd("rg-weaponry-11",					"destroyer-robot",																		"c")
		aadd("rg-weaponry-11",					"bob-laser-robot",																		"d")
		aadd("rg-weaponry-11",					"combat-robot-dispenser-equipment",										"e")
		
		aadd("rg-weaponry-12",					"slowdown-capsule",																		"a")
		aadd("rg-weaponry-12",					"poison-capsule",																			"b")
		aadd("rg-weaponry-12",					"defender-capsule",																		"c")
		aadd("rg-weaponry-12",					"distractor-capsule",																	"d")
		aadd("rg-weaponry-12",					"destroyer-capsule",																	"e")
		aadd("rg-weaponry-12",					"bob-laser-robot-capsule",														"f")
		aadd("rg-weaponry-12",					"discharge-defense-remote",														"g")
		
		aadd("rg-weaponry-14",					"piercing-rocket-warhead",														"a")
		aadd("rg-weaponry-14",					"electric-rocket-warhead",														"b")
		aadd("rg-weaponry-14",					"explosive-rocket-warhead",														"c")
		aadd("rg-weaponry-14",					"poison-rocket-warhead",															"d")
		aadd("rg-weaponry-14",					"flame-rocket-warhead",																"e")
		aadd("rg-weaponry-14",					"acid-rocket-warhead",																"f")
		
		aadd("rg-weaponry-15",					"cannon-shell",																				"a")
		aadd("rg-weaponry-15",					"explosive-cannon-shell",															"b")
		aadd("rg-weaponry-15",					"uranium-cannon-shell",																"c")
		aadd("rg-weaponry-15",					"explosive-uranium-cannon-shell",											"d")
		aadd("rg-weaponry-15",					"scatter-cannon-shell",																"e")
		
		aadd("rg-weaponry-16",					"rocket",																							"a")
		aadd("rg-weaponry-16",					"explosive-rocket",																		"b")
		aadd("rg-weaponry-16",					"bob-rocket",																					"c")
		aadd("rg-weaponry-16",					"bob-piercing-rocket",																"d")
		aadd("rg-weaponry-16",					"bob-explosive-rocket",																"e")
		aadd("rg-weaponry-16",					"bob-flame-rocket",																		"f")
		aadd("rg-weaponry-16",					"bob-acid-rocket",																		"g")
		aadd("rg-weaponry-16",					"bob-poison-rocket",																	"h")
		aadd("rg-weaponry-16",					"bob-electric-rocket",																"i")
		aadd("rg-weaponry-16",					"atomic-bomb",																				"k")
		
		aadd("rg-weaponry-17",					"artillery-shell",																		"a")
		aadd("rg-weaponry-17",					"poison-artillery-shell",															"b")
		aadd("rg-weaponry-17",					"explosive-artillery-shell",													"c")
		aadd("rg-weaponry-17",					"distractor-artillery-shell",													"d")
		
		aadd("rg-weaponry-18",					"rocket-body",																				"b")
		aadd("rg-weaponry-18",					"rocket-warhead",																			"c")
		aadd("rg-weaponry-18",					"rocket-engine",																			"d")
	end
	do	--[[trains-vehicles]]--
		aadd("rg-trains-2",						"locomotive",																					"a1")
		aadd("rg-trains-2",						"bob-locomotive-2",																		"a2")
		aadd("rg-trains-2",						"bob-locomotive-3",																		"a3")
		aadd("rg-trains-2",						"bob-armoured-locomotive",														"b1")
		aadd("rg-trains-2",						"bob-armoured-locomotive-2",													"b2")
		
		aadd("rg-trains-4",						"cargo-wagon",																				"a1")
		aadd("rg-trains-4",						"bob-cargo-wagon-2",																	"a2")
		aadd("rg-trains-4",						"bob-cargo-wagon-3",																	"a3")
		aadd("rg-trains-4",						"bob-armoured-cargo-wagon",														"b1")
		aadd("rg-trains-4",						"bob-armoured-cargo-wagon-2",													"b2")
		aadd("rg-trains-4",						"bob-armoured-cargo-wagon-3",													"b3")
		
		aadd("rg-trains-5",						"fluid-wagon",																				"a")
		aadd("rg-trains-5",						"bob-fluid-wagon-2",																	"a2")
		aadd("rg-trains-5",						"bob-fluid-wagon-3",																	"a3")
		aadd("rg-trains-5",						"bob-armoured-fluid-wagon",														"b1")
		aadd("rg-trains-5",						"bob-armoured-fluid-wagon-2",													"b2")
		
		aadd("rg-vehicles-0",					"bob-tank-2",																					"c")
		aadd("rg-vehicles-0",					"bob-tank-3",																					"d")
		aadd("rg-vehicles-0",					"bob-robot-tank",																			"e")
		
		aadd("rg-vehicles-3",					"tank-machine-gun",																		"a")
		aadd("rg-vehicles-3",					"vehicle-machine-gun",																"b")
		aadd("rg-vehicles-3",					"tank-cannon-2",																			"c")
		aadd("rg-vehicles-3",					"tank-cannon-3",																			"d")
		aadd("rg-vehicles-3",					"tank-artillery-1",																		"e")
		aadd("rg-vehicles-3",					"tank-artillery-2",																		"f")
		aadd("rg-vehicles-3",					"gatling-gun",																				"g")
		aadd("rg-vehicles-3",					"tank-laser",																					"h")
	end
	do	--[[alien]]--
		aadd("rg-alien-3",							"alien-artifact",																			"a")
		aadd("rg-alien-3",							"alien-artifact-red",																	"b")
		aadd("rg-alien-3",							"alien-artifact-orange",															"c")
		aadd("rg-alien-3",							"alien-artifact-yellow",															"d")
		aadd("rg-alien-3",							"alien-artifact-green",																"e")
		aadd("rg-alien-3",							"alien-artifact-blue",																"f")
		aadd("rg-alien-3",							"alien-artifact-purple",															"g")
		
		aadd("rg-alien-4",							"small-alien-artifact",																"a")
		aadd("rg-alien-4",							"small-alien-artifact-red",														"b")
		aadd("rg-alien-4",							"small-alien-artifact-orange",												"c")
		aadd("rg-alien-4",							"small-alien-artifact-yellow",												"d")
		aadd("rg-alien-4",							"small-alien-artifact-green",													"e")
		aadd("rg-alien-4",							"small-alien-artifact-blue",													"f")
		aadd("rg-alien-4",							"small-alien-artifact-purple",												"g")
		
		aadd("rg-alien-7",							"alien-acid",																					"a")
		aadd("rg-alien-7",							"alien-explosive",																		"b")
		aadd("rg-alien-7",							"alien-fire",																					"c")
		aadd("rg-alien-7",							"alien-poison",																				"d")
		
		aadd("rg-alien-9",							"alien-acid-in-tanker",																"a")
		aadd("rg-alien-9",							"alien-explosive-in-tanker",													"b")
		aadd("rg-alien-9",							"alien-fire-in-tanker",																"c")
		aadd("rg-alien-9",							"alien-poison-in-tanker",															"d")
	end
	do  --[[atomic]]--
	end
	do --[[barreling]]--
		aadd("rg-barreling-0",					"gas-canister",																				"b")
		aadd("rg-barreling-0",					"empty-canister",																			"c")
		
		aadd("rg-barreling-3",					"fill-water-barrel",																	"a")
		aadd("rg-barreling-3",					"fill-lithia-water-barrel",														"b")
		aadd("rg-barreling-3",					"fill-crude-oil-barrel",															"c")
		aadd("rg-barreling-3",					"bob-fill-crude-oil-barrel",													"d")
		aadd("rg-barreling-3",					"fill-heavy-oil-barrel",															"e")
		aadd("rg-barreling-3",					"fill-light-oil-barrel",															"f")
		aadd("rg-barreling-3",					"fill-lubricant-barrel",															"g")
		aadd("rg-barreling-3",					"fill-sulfuric-acid-barrel",													"h")
		aadd("rg-barreling-3",					"fill-nitric-acid-barrel",														"i")
		aadd("rg-barreling-3",					"fill-alien-acid-barrel",															"j")
		aadd("rg-barreling-3",					"fill-alien-explosive-barrel",												"k")
		aadd("rg-barreling-3",					"fill-alien-fire-barrel",															"l")
		aadd("rg-barreling-3",					"fill-alien-poison-barrel",														"m")
		
		
		aadd("rg-barreling-4",					"oxygen-canister",																		"a")
		aadd("rg-barreling-4",					"hydrogen-canister",																	"b")
		aadd("rg-barreling-4",					"nitrogen-canister",																	"c")
		aadd("rg-barreling-4",					"chlorine-canister",																	"d")
		aadd("rg-barreling-4",					"hydrogen-chloride-canister",													"e")
		aadd("rg-barreling-4",					"petroleum-gas-canister",															"f")
		aadd("rg-barreling-4",					"liquid-fuel-canister",																"g")
		aadd("rg-barreling-4",					"ferric-chloride-canister",														"h")
		
		aadd("rg-barreling-5",					"empty-water-barrel",																	"a")
		aadd("rg-barreling-5",					"empty-lithia-water-barrel",													"b")
		aadd("rg-barreling-5",					"empty-crude-oil-barrel",															"c")
		aadd("rg-barreling-5",					"bob-empty-crude-oil-barrel",													"d")
		aadd("rg-barreling-5",					"empty-heavy-oil-barrel",															"e")
		aadd("rg-barreling-5",					"empty-light-oil-barrel",															"f")
		aadd("rg-barreling-5",					"empty-lubricant-barrel",															"g")
		aadd("rg-barreling-5",					"empty-sulfuric-acid-barrel",													"h")
		aadd("rg-barreling-5",					"empty-nitric-acid-barrel",														"i")
		aadd("rg-barreling-5",					"empty-alien-acid-barrel",														"j")
		aadd("rg-barreling-5",					"empty-alien-explosive-barrel",												"k")
		aadd("rg-barreling-5",					"empty-alien-fire-barrel",														"l")
		aadd("rg-barreling-5",					"empty-alien-poison-barrel",													"m")
		
		aadd("rg-barreling-6",					"empty-oxygen-canister",															"a")
		aadd("rg-barreling-6",					"empty-hydrogen-canister",														"b")
		aadd("rg-barreling-6",					"empty-nitrogen-canister",														"c")
		aadd("rg-barreling-6",					"empty-chlorine-canister",														"d")
		aadd("rg-barreling-6",					"empty-hydrogen-chloride-canister",										"e")
		aadd("rg-barreling-6",					"empty-petroleum-gas-canister",												"f")
		aadd("rg-barreling-6",					"empty-liquid-fuel-canister",													"g")
		aadd("rg-barreling-6",					"empty-ferric-chloride-canister",											"h")
	end
end