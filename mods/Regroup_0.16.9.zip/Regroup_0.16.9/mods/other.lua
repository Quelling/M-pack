local allow_changes = regroup.settings.other

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

do --[[gathering]]--
	-- theyre made out of meat
	aadd("rg-gathering-0",				"bone-axe",																						"j")
	
	-- warehousing
	aadd("rg-gathering-2",				"storehouse-basic",																		"a[0150]")
	aadd("rg-gathering-2",				"warehouse-basic",																		"a[0800]")
	
	-- void chest
	aadd("rg-gathering-2",				"void-chest",																					"e")
	
	-- natural evolution
	aadd("rg-gathering-2",				"Artifact-collector",																	"f")
	
	-- theyre made out of meat
	aadd("rg-gathering-2",				"meat-chest",																					"g")

	-- ammo loader plus
	aadd("rg-gathering-2",				"fuel-loader-chest",																					"h")
	aadd("rg-gathering-2",				"ammo-loader-chest",																					"i")
	
	-- Storage Tank
	aadd("rg-gathering-4",				"storage-tank2",																			"a[100]-stor")
	
	-- mini machines
	aadd("rg-gathering-4",				"mini-tank-1",																				"a[012]-mini")
	aadd("rg-gathering-4",				"mini-tank-2",																				"a[025]-mini")
	aadd("rg-gathering-4",				"mini-tank-3",																				"a[037]-mini")
	aadd("rg-gathering-4",				"mini-tank-4",																				"a[050]-mini")
	
	aadd("rg-gathering-7",				"mini-miner-1",																				"a[04x04][02.5][0.4]-mini")
	aadd("rg-gathering-7",				"mini-miner-2",																				"a[04x04][04.0][0.8]-mini")
	aadd("rg-gathering-7",				"mini-miner-3",																				"a[04x04][05.2][1.6]-mini")
	aadd("rg-gathering-7",				"mini-miner-4",																				"a[04x04][06.5][2.4]-mini")
	aadd("rg-gathering-7",				"mini-miner-5",																				"a[04x04][08.0][3.2]-mini")
	
	aadd("rg-gathering-24",				"mini-pumpjack-1",																		"g")
	aadd("rg-gathering-24",				"mini-pumpjack-2",																		"h")
	aadd("rg-gathering-24",				"mini-pumpjack-3",																		"i")
	aadd("rg-gathering-24",				"mini-pumpjack-4",																		"j")
	
	-- other quarries
	aadd("rg-gathering-9",				"burner-quarry",																			"a")
	aadd("rg-gathering-9",				"nuclear-quarry",																			"e")
	aadd("rg-gathering-9",				"alien-quarry",																				"f")
	aadd("rg-gathering-9",				"omega-drill",																				"g")
	aadd("rg-gathering-9",				"deep-mine",																					"h")
	aadd("rg-gathering-9",				"deep-mine-2",																				"i")
	
	-- quarry
	aadd("rg-gathering-9",				"quarry",																							"b")
	aadd("rg-gathering-9",				"quarry-mk2",																					"c")
	aadd("rg-gathering-9",				"quarry-mk3",																					"d")
	
	-- VTK Deep Core Mining Drill
	aadd("rg-gathering-9",				"vtk-deepcore-mining-drill",													"j")
	aadd("rg-gathering-9",				"vtk-deepcore-mining-drill-advanced",									"k")
	
	-- waterwell
	aadd("rg-gathering-20",				"water-well-pump",																		"d")
	
	-- stone waterwell
	aadd("rg-gathering-20",				"stone-waterwell",																		"f")
	
	-- aquifer drill
	aadd("rg-gathering-20",				"aquifer-drill",																			"g")
	
	-- geothermal
	aadd("rg-gathering-20",				"geothermal-well",																		"h")
	
	--[[if i_exist("stone-waterwell") and allow_changes then
		--Hide Water Well Pemp  in favor of Stone Waterwell
		ahide("water-well-pump")
		--Hide Water Miners in favor of Stone Waterwell
		ahide("water-miner-1")
		ahide("water-miner-2")
		ahide("water-miner-3")
		ahide("water-miner-4")
		ahide("water-miner-5")
		--Hide Water Pumps in favor of Stone Waterwell
		ahide("water-pump")
		ahide("water-pump-1")
		ahide("water-pump-2")
		ahide("water-pump-3")
		ahide("water-pump-4")
		ahide("water-pump-5")
		--Hide Aquifer Drill in favor of Stone Waterwell
		ahide("aquifer-drill")
		elseif i_exist("water-well-pump") and allow_changes then
		--Hide Water Miners in favor of Waterwell Pump
		ahide("water-miner-1")
		ahide("water-miner-2")
		ahide("water-miner-3")
		ahide("water-miner-4")
		ahide("water-miner-5")
		--Hide Water Pumps in favor of Waterwell Pump
		ahide("water-pump")
		ahide("water-pump-1")
		ahide("water-pump-2")
		ahide("water-pump-3")
		ahide("water-pump-4")
		ahide("water-pump-5")
		--Hide Aquifer Drill in favor of Waterwell Pump
		ahide("aquifer-drill")
		elseif i_exist("aquifer-drill") and allow_changes then
		--Hide Water Miners in favor of Aquifer Drill
		ahide("water-miner-1")
		ahide("water-miner-2")
		ahide("water-miner-3")
		ahide("water-miner-4")
		ahide("water-miner-5")
		--Hide Water Pumps in favor of Aquifer Drill
		ahide("water-pump")
		ahide("water-pump-1")
		ahide("water-pump-2")
		ahide("water-pump-3")
		ahide("water-pump-4")
		ahide("water-pump-5")
		elseif i_exist("water-miner-1") and allow_changes then
		--Hide Water Pumps in favor of Water Miner
		ahide("water-pump")
		ahide("water-pump-1")
		ahide("water-pump-2")
		ahide("water-pump-3")
		ahide("water-pump-4")
		ahide("water-pump-5")
	end]]	
end
do --[[production]]--
	aadd("rg-production-2",				"lf-furnace-01",																"f")
	aadd("rg-production-2",				"lf-furnace-02",																"g")
	aadd("rg-production-2",				"lf-furnace-03",																"h")


	-- advanced electric furnace
	aadd("rg-production-0",				"advanced-electric-furnace",													"k")
	
	-- assembly zero
	aadd("rg-production-5",				"assembling-machine-0",																"d")
	aadd("rg-production-5",				"assembling-machine-x",																"e")
	aadd("rg-production-5",				"assembling-machine-z",																"f")
	
	-- robot army
	aadd("rg-production-5",				"droid-assembling-machine",														"h")
	aadd("rg-production-5",				"droid-guard-station",																"i")
	
	-- flare stack
	aadd("rg-production-0",				"electric-stone-furnace",															"d")
	aadd("rg-production-0",				"electric-steel-furnace",															"j")
	
	aadd("rg-production-14",			"vent-stack",																					"i")
	aadd("rg-production-14",			"flare-stack",																				"j")
	
	aadd("rg-production-14",			"incinerator",																				"k")
	aadd("rg-production-14",			"electric-incinerator",																"l")
	
	--[[if allow_changes and data.raw.recipe["vent-stack"] then
		data.raw.recipe["vent-stack"].enabled = "false"
		data.raw.recipe["vent-stack"].hidden = "false"
		data.raw.recipe["flare-stack"].enabled = "false"
		data.raw.recipe["flare-stack"].hidden = "false"
		data.raw.recipe["incinerator"].enabled = "false"
		data.raw.recipe["incinerator"].hidden = "false"
		data.raw.recipe["electric-incinerator"].enabled = "false"
		data.raw.recipe["electric-incinerator"].hidden = "false"
		rg.t_add_recipe_unlock("oil-processing"  , "vent-stack")
		rg.t_add_recipe_unlock("oil-processing"  , "flare-stack")
		rg.t_add_recipe_unlock("oil-processing-2",			"incinerator")
		rg.t_add_recipe_unlock("oil-processing-2",			"electric-incinerator")
	end]]
	
	
	-- mini machines
	aadd("rg-production-2",				"mini-furnace-1",																			"b")
	aadd("rg-production-2",				"mini-furnace-2",																			"d")
	aadd("rg-production-2",				"mini-furnace-3",																			"f")
	
	aadd("rg-production-5",				"mini-assembler-1",																		"a1d")
	aadd("rg-production-5",				"mini-assembler-2",																		"a2d")
	aadd("rg-production-5",				"mini-assembler-3",																		"a3d")
	aadd("rg-production-5",				"mini-assembler-4",																		"a4d")
	aadd("rg-production-5",				"mini-assembler-5",																		"a5d")
	aadd("rg-production-5",				"mini-assembler-6",																		"a6d")
	
	aadd("rg-production-6",				"mini-refinery-1",																		"b1")
	aadd("rg-production-6",				"mini-refinery-2",																		"b2")
	aadd("rg-production-6",				"mini-refinery-3",																		"b3")
	aadd("rg-production-6",				"mini-refinery-4",																		"b4")
	
	aadd("rg-production-8",				"mini-chem-plant-1",																	"b1")
	aadd("rg-production-8",				"mini-chem-plant-2",																	"b2")
	aadd("rg-production-8",				"mini-chem-plant-3",																	"b3")
	aadd("rg-production-8",				"mini-chem-plant-4",																	"b4")
	
	aadd("rg-production-10",			"mini-electrolyser-1",																"b1")
	aadd("rg-production-10",			"mini-electrolyser-2",																"b2")
	aadd("rg-production-10",			"mini-electrolyser-3",																"b3")
	aadd("rg-production-10",			"mini-electrolyser-4",																"b4")
	
	if regroup.settings.graphics_tuning then
		if data.raw["assembling-machine"]["mini-assembler-3"] then
			v = data.raw["assembling-machine"]["mini-assembler-3"].animation
			v.filename = "__Regroup__/graphics/entity/assembling-machine-3-anim.png"
			v.priority="high"
			v.width = 142
			v.height = 113
			v.frame_count = 32
			v.line_length = 8
			v.shift = {0.84*0.66                    , -0.1*0.66}
			v.scale = 0.66
		end
		rg.set_icon("mini-assembler-1"           , "__Regroup__/graphics/icons/mini-assembling-machine-1.png")
		rg.set_icon("mini-assembler-2"           , "__Regroup__/graphics/icons/mini-assembling-machine-2.png")
		rg.set_icon("mini-assembler-3"           , "__Regroup__/graphics/icons/mini-assembling-machine-3.png")
	end
	
	-- chem flip
	aadd("rg-production-10",				"electrolyser-flipped",																"bb")
	aadd("rg-production-10",				"electrolyser-2-flipped",															"cb")
	aadd("rg-production-10",				"electrolyser-3-flipped",															"db")
	aadd("rg-production-10",				"electrolyser-4-flipped",															"eb")
	
	-- tree farm
	aadd("rg-production-11",				"tf-field",																						"f")
	aadd("rg-production-11",				"tf-fieldmk2",																				"g")
	
	-- sawmill/lumberjack
	aadd("rg-production-11",				"sawmill",																						"h")
	aadd("rg-production-11",				"seeder",																							"i")
	
	-- charging station
	aadd("rg-production-13",			"charging-station",																		"a")
	aadd("rg-production-13",			"charging-station-rapid",															"b")
	
	-- reverse factory
	aadd("rg-production-14",			"reverse-factory",																		"a")
	aadd("rg-production-14",			"reverse-factory-1",																	"a2")
	aadd("rg-production-14",			"reverse-factory-2",																	"a3")
	
	-- recycle
	aadd("rg-production-14",			"recycling-machine-1",																"b")
	aadd("rg-production-14",			"recycling-machine-2",																"c")
	aadd("rg-production-14",			"recycling-machine-3",																"d")
	
	-- aquafarm
	aadd("rg-production-14",			"aquafarm",																						"e")
	
	-- conman construction manager
	aadd("rg-production-14",			"conman",																							"f")
	
	-- factorissimo
	aadd("rg-production-15",			"factory-1",																					"a")
	aadd("rg-production-15",			"factory-2",																					"b")
	aadd("rg-production-15",			"factory-3",																					"c")
	
	-- avatars
	aadd("rg-production-17",			"avatar-assembling-machine",													"a")
	aadd("rg-production-17",			"avatar-remote-deployment-unit",											"b")
	aadd("rg-production-17",			"avatar-control-center",															"c")
	aadd("rg-production-17",			"avatar",																							"d")
	
	-- air filtering
	aadd("rg-production-18",			"air-filter-machine",																	"a")
	aadd("rg-production-18",			"air-filter-machine-mk2",															"b")
	aadd("rg-production-18",			"air-filter-machine-mk3",															"c")
	
	-- aai industry
	aadd("rg-production-5",				"burner-assembling-machine",													"00")
	
	aadd("rg-production-14",			"fuel-processor",																			"g")
	aadd("rg-production-14",			"bob-distillery",																			"h")
	
	for _,v in pairs(data.raw["item-subgroup"]) do
		if v.name == "recycling-machine" then v.group = "rg-production" end
	end
end
do --[[resources]]--
	aadd("rg-resources-0",					"alien-bioconstruct",																						"h")
	aadd("rg-resources-1",					"rg-coal",																						"h")
	
	-- theyre made out of meat
	aadd("rg-resources-1",					"compress-meat",																			"m")
	
	-- vtk deep core mining
	aadd("rg-resources-4",					"vtk-deepcore-mining-iron-ore-chunk",								"h")
	aadd("rg-resources-4",					"vtk-deepcore-mining-copper-ore-chunk",								"i")
	aadd("rg-resources-4",					"vtk-deepcore-mining-coal-chunk",									"j")
	aadd("rg-resources-4",					"vtk-deepcore-mining-stone-chunk",									"k")
	aadd("rg-resources-4",					"vtk-deepcore-mining-uranium-ore-chunk",							"l")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore1-chunk-refining",					"m")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore2-chunk-refining",					"n")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore3-chunk-refining",					"o")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore4-chunk-refining",					"p")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore5-chunk-refining",					"q")
	aadd("rg-resources-4",					"vtk-deepcore-mining-angels-ore6-chunk-refining",					"r")
	
	-- deep mining
	aadd("rg-resources-8",					"deep-mining",																				"a")
end
do --[[plates]]--
	-- only smelting
	aadd("rg-plates-11",						"steelspc",																						"e")
end
do --[[chemistry]]--
	-- avatars
	aadd("rg-chemistry-0",				"copper-chloride",																		"q")
	aadd("rg-chemistry-0",				"dimethyldichlorosilane",															"r")
	aadd("rg-chemistry-0",				"silicone",																						"s")
	
	-- bergius process
	aadd("rg-chemistry-1",				"bergius-process",																		"c")
	aadd("rg-chemistry-3",				"coal-liquefaction",																	"c")
	
	-- Specialized Oil Refineries
	aadd("rg-chemistry-2",				"specialized-refining-heavy-oil",											"f")
	aadd("rg-chemistry-2",				"specialized-refining-light-oil",											"g")
	aadd("rg-chemistry-2",				"specialized-refining-petroleum",											"h")
	
	-- natural evolution
	aadd("rg-chemistry-1",				"NE_nutrient-solution",																"j")
	aadd("rg-chemistry-1",				"NE_basic-alien-nutrientant",													"j")
	aadd("rg-chemistry-3",				"NE_enhanced-nutrient-solution",											"j")
	aadd("rg-chemistry-3",				"NE_enhanced-alien-nutrientant",											"j")
	aadd("rg-chemistry-3",				"NE_alien-revitalization",														"l")
	
	-- n-tech chemistry
	aadd("rg-chemistry-1",				"basic-desulphurized-oil-processing",									"e")
	aadd("rg-chemistry-1",				"advanced-desulphurized-oil-processing",							"f")
	
	aadd("rg-chemistry-3",				"crude-oil-desulphurization",													"e")
	aadd("rg-chemistry-3",				"water-purification",																	"a")
	
	-- natural evolution
	iadd("rg-chemistry-11",				"NE_alien_toxin")
	iadd("rg-chemistry-11",				"NE_alien_toxin-in-tanker")
	iadd("rg-chemistry-11",				"NE_nutrient-solution-in-tanker")
	iadd("rg-chemistry-11",				"NE_basic-alien-nutrientant-in-tanker")
	iadd("rg-chemistry-11",				"NE_enhanced-nutrient-solution-in-tanker")
	iadd("rg-chemistry-11",				"NE_enhanced-alien-nutrientant-in-tanker")
	iadd("rg-chemistry-11",				"NE_alien-revitalization-in-tanker")
	iadd("rg-chemistry-11",				"NE_revitalization-solition-in-tanker")
	
	-- advanced machines
	aadd("rg-chemistry-10",				"extreme-oil-processing",															"a")
	aadd("rg-chemistry-10",				"extreme-heavy-oil-cracking",													"b")
	
	-- personal teleporter
	aadd("rg-chemistry-11",				"liquid-alien-artifacts",															"j")
	
-- geothermal
	aadd("rg-chemistry-12",				"geothermal-exchange",																"a")
	aadd("rg-chemistry-12",				"geothermal-exchange-green",													"b")
	aadd("rg-chemistry-12",				"geothermal-exchange-blue",														"c")
	aadd("rg-chemistry-12",				"geothermal-exchange-purple",													"d")
	aadd("rg-chemistry-12",				"geothermal-exchange-flipped",												"e")
	aadd("rg-chemistry-12",				"geothermal-exchange-flipped-green",									"f")
	aadd("rg-chemistry-12",				"geothermal-exchange-flipped-blue",										"g")
	aadd("rg-chemistry-12",				"geothermal-exchange-flipped-purple",									"h")
	aadd("rg-chemistry-12",				"geothermal-exchange-2",															"i")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-green",												"j")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-blue",													"k")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-purple",												"l")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-flipped",											"m")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-flipped-green",								"n")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-flipped-blue",									"o")
	aadd("rg-chemistry-12",				"geothermal-exchange-2-flipped-purple",								"p")
end
do --[[automatization]]--
	-- KPOT Titanium
	aadd("rg-automatization-0",		"titanium-long-handed-inserter",											"d")
	
	-- burner filter inserter
	aadd("rg-automatization-1",		"burner-filter-inserter",															"a")
	
	-- natural evolution
	aadd("rg-automatization-1",		"combat-inserter",																		"j")
end
do --[[transport]]--
	-- loaders
	aadd("rg-transport-1",					"loader",																							"a")
	aadd("rg-transport-1",					"fast-loader",																				"b")
	aadd("rg-transport-1",					"express-loader",																			"c")
	aadd("rg-transport-1",					"green-loader",																				"d")
	aadd("rg-transport-1",					"faster-loader",																			"d")
	aadd("rg-transport-1",					"purple-loader",																			"e")
	aadd("rg-transport-1",					"extremely-fast-loader",															"f")
  if i_exist("faster-loader") and i_exist("green-loader") then
		--ahide("green-loader")
		--ahide("purple-loader")
	end
	
	-- miniloaders
	aadd("rg-transport-2",					"miniloader",																					"a")
	aadd("rg-transport-2",					"fast-miniloader",																		"b")
	aadd("rg-transport-2",					"express-miniloader",																	"c")
	aadd("rg-transport-2",					"turbo-miniloader",																	"d")
	aadd("rg-transport-2",					"green-miniloader",																		"e")
	aadd("rg-transport-2",					"purple-miniloader",																	"f")
	aadd("rg-transport-2",					"ultra-fast-miniloader",															"g")
	aadd("rg-transport-2",					"extreme-fast-miniloader",														"h")
	aadd("rg-transport-2",					"ultra-express-miniloader",														"i")
	aadd("rg-transport-2",					"extreme-express-miniloader",													"j")
	aadd("rg-transport-2",					"ultimate-miniloader",																"j")
	
	aadd("rg-transport-3",					"filter-miniloader",																	"a")
	aadd("rg-transport-3",					"fast-filter-miniloader",															"b")
	aadd("rg-transport-3",					"express-filter-miniloader",													"c")
	aadd("rg-transport-3",					"turbo-filter-miniloader",													"d")
	aadd("rg-transport-3",					"green-filter-miniloader",														"e")
	aadd("rg-transport-3",					"purple-filter-miniloader",														"f")
	aadd("rg-transport-3",					"ultra-fast-filter-miniloader",												"g")
	aadd("rg-transport-3",					"extreme-fast-filter-miniloader",											"h")
	aadd("rg-transport-3",					"ultra-express-filter-miniloader",										"i")
	aadd("rg-transport-3",					"extreme-express-filter-miniloader",									"j")
	aadd("rg-transport-3",					"ultimate-filter-miniloader",													"k")
	
	-- belt sorter
	aadd("rg-transport-4",					"belt-sorter1",																				"k")
	aadd("rg-transport-4",					"belt-sorter2",																				"l")
	aadd("rg-transport-4",					"belt-sorter3",																				"m")
	
	-- Deadlock Stacking
	aadd("rg-transport-4",					"bob-beltbox-1",																				"n")
	aadd("rg-transport-4",					"bob-beltbox-2",																				"o")
	aadd("rg-transport-4",					"bob-beltbox-3",																				"p")
	aadd("rg-transport-4",					"bob-beltbox-4",																				"q")
	aadd("rg-transport-4",					"bob-beltbox-5",																				"r")
	
	-- ultimate belts
	aadd("rg-transport-0",					"ultra-fast-belt",																		"j")
	aadd("rg-transport-0",					"extreme-fast-belt",																	"k")
	aadd("rg-transport-0",					"ultra-express-belt",																	"l")
	aadd("rg-transport-0",					"extreme-express-belt",																"m")
	aadd("rg-transport-0",					"ultimate-transport-belt",														"n")
	
	aadd("rg-transport-6",					"ultra-fast-underground-belt",												"h")
	aadd("rg-transport-6",					"extreme-fast-underground-belt",											"i")
	aadd("rg-transport-6",					"ultra-express-underground-belt",											"j")
	aadd("rg-transport-6",					"extreme-express-underground-belt",										"k")
	aadd("rg-transport-6",					"ultimate-underground-belt",													"l")
	
	aadd("rg-transport-9",					"ultra-fast-splitter",																"k")
	aadd("rg-transport-9",					"extreme-fast-splitter",															"l")
	aadd("rg-transport-9",					"ultra-express-splitter",															"m")
	aadd("rg-transport-9",					"extreme-express-splitter",														"n")
	aadd("rg-transport-9",					"ultimate-splitter",																	"o")
	
	-- single splitter
	aadd("rg-transport-9",					"single-splitter",																		"p")
	
	-- pipe cleaner
	aadd("rg-transport-10",					"pipe-cleaner",																				"i")
	
	-- smart splitter
	aadd("rg-transport-6",					"subterranean-belt",																	"h")
	aadd("rg-transport-6",					"fast-subterranean-belt",															"i")
	aadd("rg-transport-6",					"express-subterranean-belt",													"j")
	
	aadd("rg-transport-9",					"smartsplitter",																			"q")
	
	-- compound splitter
	aadd("rg-transport-9",					"compound-splitter-endcap",														"k")
	aadd("rg-transport-9",					"compound-splitter-lane",															"l")
	aadd("rg-transport-9",					"compound-splitter-buffer",														"m")
	aadd("rg-transport-9",					"compound-splitter-priority-totem",										"n")
	aadd("rg-transport-9",					"cs-express-transport-belt",													"o")
	aadd("rg-transport-9",					"compound-splitter-round-robin-totem",								"p")
	
	-- hacked splitter
	aadd("rg-transport-9",					"hacked-splitter",																		"b")
	aadd("rg-transport-9",					"hacked-fast-splitter",																"d")
	aadd("rg-transport-9",					"hacked-express-splitter",														"f")
	aadd("rg-transport-9",					"hacked-green-splitter",															"h")
	aadd("rg-transport-9",					"hacked-purple-splitter",															"j")
	
	-- subterrain
	aadd("rg-transport-14",				"subterranean-pipe",																	"k")
	
	-- flow control
	aadd("rg-transport-11",					"check-valve",																				"a")
	aadd("rg-transport-11",					"overflow-valve",																			"e")
	aadd("rg-transport-11",					"underflow-valve",																		"d")
	
	aadd("rg-transport-15",				"pipe-stone-straight",																"b")
	aadd("rg-transport-15",				"pipe-straight",																			"c")
	aadd("rg-transport-15",				"pipe-copper-straight",																"d")
	aadd("rg-transport-15",				"pipe-steel-straight",																"e")
	aadd("rg-transport-15",				"pipe-bronze-straight",																"f")
	aadd("rg-transport-15",				"pipe-plastic-straight",															"g")
	aadd("rg-transport-15",				"pipe-brass-straight",																"h")
	aadd("rg-transport-15",				"pipe-ceramic-straight",															"i")
	aadd("rg-transport-15",				"pipe-titanium-straight",															"j")
	aadd("rg-transport-15",				"pipe-tungsten-straight",															"k")
	
	aadd("rg-transport-16",				"pipe-stone-junction",																"a")
	aadd("rg-transport-16",				"pipe-junction",																			"b")
	aadd("rg-transport-16",				"pipe-copper-junction",																"c")
	aadd("rg-transport-16",				"pipe-steel-junction",																"d")
	aadd("rg-transport-16",				"pipe-bronze-junction",																"e")
	aadd("rg-transport-16",				"pipe-plastic-junction",															"f")
	aadd("rg-transport-16",				"pipe-brass-junction",																"g")
	aadd("rg-transport-16",				"pipe-ceramic-junction",															"h")
	aadd("rg-transport-16",				"pipe-titanium-junction",															"i")
	aadd("rg-transport-16",				"pipe-tungsten-junction",															"j")
	
	aadd("rg-transport-17",				"pipe-stone-elbow",																		"a")
	aadd("rg-transport-17",				"pipe-elbow",																					"b")
	aadd("rg-transport-17",				"pipe-copper-elbow",																	"c")
	aadd("rg-transport-17",				"pipe-steel-elbow",																		"d")
	aadd("rg-transport-17",				"pipe-bronze-elbow",																	"e")
	aadd("rg-transport-17",				"pipe-plastic-elbow",																	"f")
	aadd("rg-transport-17",				"pipe-brass-elbow",																		"g")
	aadd("rg-transport-17",				"pipe-ceramic-elbow",																	"h")
	aadd("rg-transport-17",				"pipe-titanium-elbow",																"i")
	aadd("rg-transport-17",				"pipe-tungsten-elbow",																"j")
	
	if allow_changes and i_exist("pipe-elbow") and i_exist("catalyst-metal-carrier") then
		ahide("bob-valve")
		ahide("check-valve")
		ahide("overflow-valve")
	end
	
	-- flow control bob
	aadd("rg-transport-11",					"check-valve",																				"a")
	aadd("rg-transport-11",					"overflow-valve",																			"e")
	aadd("rg-transport-11",					"underflow-valve",																		"g")
	
	aadd("rg-transport-14",				"express-pump",																				"k")
	
	aadd("rg-transport-15",				"pipe-stone-straight",																"a")
	aadd("rg-transport-15",				"pipe-straight",																			"b")
	aadd("rg-transport-15",				"pipe-copper-straight",																"c")
	aadd("rg-transport-15",				"pipe-steel-straight",																"d")
	aadd("rg-transport-15",				"pipe-bronze-straight",																"e")
	aadd("rg-transport-15",				"pipe-plastic-straight",															"f")
	aadd("rg-transport-15",				"pipe-brass-straight",																"g")
	aadd("rg-transport-15",				"pipe-ceramic-straight",															"h")
	aadd("rg-transport-15",				"pipe-titanium-straight",															"i")
	aadd("rg-transport-15",				"pipe-tungsten-straight",															"j")
	
	aadd("rg-transport-16",				"pipe-stone-junction",																"a")
	aadd("rg-transport-16",				"pipe-junction",																			"b")
	aadd("rg-transport-16",				"pipe-copper-junction",																"c")
	aadd("rg-transport-16",				"pipe-steel-junction",																"d")
	aadd("rg-transport-16",				"pipe-bronze-junction",																"e")
	aadd("rg-transport-16",				"pipe-plastic-junction",															"f")
	aadd("rg-transport-16",				"pipe-brass-junction",																"g")
	aadd("rg-transport-16",				"pipe-ceramic-junction",															"h")
	aadd("rg-transport-16",				"pipe-titanium-junction",															"i")
	aadd("rg-transport-16",				"pipe-tungsten-junction",															"j")
	
	aadd("rg-transport-17",				"pipe-stone-elbow",																		"a")
	aadd("rg-transport-17",				"pipe-elbow",																					"b")
	aadd("rg-transport-17",				"pipe-copper-elbow",																	"c")
	aadd("rg-transport-17",				"pipe-steel-elbow",																		"d")
	aadd("rg-transport-17",				"pipe-bronze-elbow",																	"e")
	aadd("rg-transport-17",				"pipe-plastic-elbow",																	"f")
	aadd("rg-transport-17",				"pipe-brass-elbow",																		"g")
	aadd("rg-transport-17",				"pipe-ceramic-elbow",																	"h")
	aadd("rg-transport-17",				"pipe-titanium-elbow",																"i")
	aadd("rg-transport-17",				"pipe-tungsten-elbow",																"j")
	
	-- factorissimo
	aadd("rg-transport-60",				"factory-input-pipe",																	"a")
	aadd("rg-transport-60",				"factory-output-pipe",																"b")
	aadd("rg-transport-60",				"fish-output",																				"c")
	
	-- personal teleporter
	aadd("rg-transport-61",				"Teleporter_Beacon",																	"a")
	
	-- teleportation
	aadd("rg-transport-61",				"teleportation-beacon",																"b")
	
	if regroup.settings.bob_pipes then
		ahide("pipe-stone-straight")
		ahide("pipe-copper-straight")
		ahide("pipe-steel-straight")
		ahide("pipe-bronze-straight")
		ahide("pipe-plastic-straight")
		ahide("pipe-brass-straight")
		ahide("pipe-ceramic-straight")
		ahide("pipe-titanium-straight")
		ahide("pipe-tungsten-straight")
		
		ahide("pipe-stone-junction")
		ahide("pipe-copper-junction")
		ahide("pipe-steel-junction")
		ahide("pipe-bronze-junction")
		ahide("pipe-plastic-junction")
		ahide("pipe-brass-junction")
		ahide("pipe-ceramic-junction")
		ahide("pipe-titanium-junction")
		ahide("pipe-tungsten-junction")
		
		ahide("pipe-stone-elbow")
		ahide("pipe-copper-elbow")
		ahide("pipe-steel-elbow")
		ahide("pipe-bronze-elbow")
		ahide("pipe-plastic-elbow")
		ahide("pipe-brass-elbow")
		ahide("pipe-ceramic-elbow")
		ahide("pipe-titanium-elbow")
		ahide("pipe-tungsten-elbow")
	end
	
	-- flow control
	if false == true and allow_changes and i_exist("pipe-elbow") and i_exist("catalyst-metal-carrier") then
		ahide("bob-valve")
		ahide("check-valve")
		ahide("overflow-valve")
		ahide("express-pump")
	end
	
	if regroup.settings.graphics_tuning and i_exist("small-pump-4") or i_exist("5d-small-pump") then
		rg.set_icon("small-pump"                 ,"__base__/graphics/icons/small-pump.png")
	end
end
do --[[logistic]]--
	aadd("rg-logistic-1",					"robotMiningSite",																				"f")
	aadd("rg-logistic-1",					"robotMiningSite-new",																				"f")
	aadd("rg-logistic-1",					"robotMiningSite-large",																				"g")
	aadd("rg-logistic-1",					"robotMiningSite-extra",																				"h")
	aadd("rg-logistic-1",					"mining-robot",																				"i")

	-- color blueprint book redux
	aadd("rg-logistic-0",					"red-book",																						"a1")
	aadd("rg-logistic-0",					"orange-book",																				"a2")
	aadd("rg-logistic-0",					"yellow-book",																				"a3")
	aadd("rg-logistic-0",					"green-book",																					"a4")
	aadd("rg-logistic-0",					"purple-book",																				"a5")
	aadd("rg-logistic-0",					"magenta-book",																				"a6")
	aadd("rg-logistic-0",					"blueprint-book",																			"a7")
	aadd("rg-logistic-0",					"black-book",																					"a8")
	aadd("rg-logistic-0",					"white-book",																					"a9")
	
	-- theyre made out of meat
	aadd("rg-logistic-2",					"meat-roboport",																			"i")
	
	aadd("rg-logistic-1"	,				"meat-robot",																					"e")
	
	-- upgrade planer
	aadd("rg-logistic-0",					"upgrade-builder",																		"d")

	-- wide chests
	aadd("rg-logistic-0",					"merge-chest-selector",																"e")
	
	-- oil patch organizer
	aadd("rg-logistic-0",					"oil-organizer",																			"j")
	
	-- natural evolution
	aadd("rg-logistic-0",					"attractor-on",																				"m")
	aadd("rg-logistic-0",					"attractor-off",																			"n")
	
	-- nanobots
	aadd("rg-logistic-1",					"gun-nano-emitter",																		"a")
	aadd("rg-logistic-1",					"ammo-nano-constructors",															"b")
	aadd("rg-logistic-1",					"ammo-nano-termites",																	"c")
	
	aadd("rg-logistic-2",					"roboport-interface",																	"j")
	
	-- VTK Deep Core Mining Drill
	aadd("rg-logistic-0",					"vtk-deepcore-mining-planner",												"i")
	
	aadd("rg-logistic-1",					"vtk-deepcore-mining-drone",													"d")
	
	-- warehousing
	aadd("rg-logistic-10",				"storehouse-storage",																	"a")
	aadd("rg-logistic-10",				"storehouse-buffer",																	"b")
	aadd("rg-logistic-10",				"storehouse-requester",																"c")
	aadd("rg-logistic-10",				"storehouse-passive-provider",												"d")
	aadd("rg-logistic-10",				"storehouse-active-provider",													"e")
	aadd("rg-logistic-10",				"warehouse-storage",																	"f")
	aadd("rg-logistic-10",				"warehouse-buffer",																		"g")
	aadd("rg-logistic-10",				"warehouse-requester",																"h")
	aadd("rg-logistic-10",				"warehouse-passive-provider",													"i")
	aadd("rg-logistic-10",				"warehouse-active-provider",													"j")
	
	-- aai
	aadd("rg-logistic-0",					"zone-planner",																				"j")
	aadd("rg-logistic-0",					"unit-remote-control",																"k")
	
	aadd("rg-logistic-14",				"zone-control",																				"a")
	aadd("rg-logistic-14",				"unit-control",																				"b")
	aadd("rg-logistic-14",				"unitdata-control",																		"c")
	aadd("rg-logistic-14",				"tile-scan",																					"d")
	aadd("rg-logistic-14",				"unit-scan",																					"e")
	aadd("rg-logistic-14",				"unitdata-scan",																			"f")
	aadd("rg-logistic-14",				"zone-scan",																					"g")
	
	aadd("rg-logistic-15",				"vehicle-deployer",																		"c")
	aadd("rg-logistic-15",				"vehicle-depot",																			"d")
	
	-- yarm
	aadd("rg-logistic-0",					"resource-monitor",																		"l")
	
	-- bob fusion robots
	aadd("rg-logistic-5",					"logistic-robot-fusion",															"j")
	aadd("rg-logistic-6",					"construction-robot-fusion",													"j")
	
	-- nuclear robots
	aadd("rg-logistic-5",					"logistic-robot-nuclear",															"k")
	aadd("rg-logistic-6",					"construction-robot-nuclear",													"k")
	
	-- skan fusion robots
	aadd("rg-logistic-5",					"skan-logistic-robot-fusion",													"l")
	aadd("rg-logistic-6",					"skan-construction-robot-fusion",											"l")
	
	-- factorissimo
	aadd("rg-logistic-8",					"factory-requester-chest",														"j")
	
	aadd("rg-logistic-16",				"factory-circuit-input",															"i")
	aadd("rg-logistic-16",				"factory-circuit-output",															"j")
	
	-- time tools
	aadd("rg-logistic-16",				"clock-combinator",																		"d")
	
	-- crafting combinator
	aadd("rg-logistic-16",				"crafting_combinator_crafting-combinator",						"e")
	aadd("rg-logistic-16",				"crafting_combinator_recipe-combinator",							"f")
	aadd("rg-logistic-16",				"item-sensor",																				"g")
	aadd("rg-logistic-16",				"crafting_combinator_FML_blueprint-data-prototype_entity",	"m")
	
	-- bonus combinator
	aadd("rg-logistic-16",				"bonus-combinator",																		"h")
	
	-- location combinator
	aadd("rg-logistic-16",				"location-combinator",																"i")
	
	-- pushbutton
	aadd("rg-logistic-17",				"pushbutton",																					"j")
	
	-- robot army
	aadd("rg-logistic-0",					"droid-pickup-tool",																	"k")
	aadd("rg-logistic-0",					"droid-selection-tool",																"l")
	
	aadd("rg-logistic-17",				"droid-counter",																			"a")
	aadd("rg-logistic-17",				"droid-settings",																			"b")
	
	aadd("rg-logistic-18",				"droid-smg",																					"a")
	aadd("rg-logistic-18",				"droid-smg-dummy",																		"b")
	aadd("rg-logistic-18",				"droid-rocket",																				"c")
	aadd("rg-logistic-18",				"droid-rocket-dummy",																	"d")
	aadd("rg-logistic-18",				"droid-rifle",																				"e")
	aadd("rg-logistic-18",				"droid-rifle-dummy",																	"f")
	aadd("rg-logistic-18",				"terminator",																					"g")
	aadd("rg-logistic-18",				"terminator-dummy",																		"h")
	aadd("rg-logistic-18",				"droid-flame",																				"i")
	aadd("rg-logistic-18",				"droid-flame-dummy",																	"j")
	
	-- nixie tubes
	aadd("rg-logistic-19",				"nixie-tube",																					"e")
	aadd("rg-logistic-19",				"nixie-tube-alpha",																		"f")
	aadd("rg-logistic-19",				"nixie-tube-small",																		"g")
	
	-- smart display
	aadd("rg-logistic-19",				"smart-display-visible",															"h")
	
	-- pavement drive assist
	aadd("rg-logistic-19",				"pda-road-sign-speed-limit",													"a")
	aadd("rg-logistic-19",				"pda-road-sign-speed-unlimit",												"b")
end
do --[[energy]]--
	aadd("rg-energy-2",						"basic-fluid-generator-rampant-arsenal",																		"o")
	aadd("rg-energy-2",						"active-steam-turbine",																		"p")
	aadd("rg-energy-9",						"texugo-wind-turbine",																		"p")
	aadd("rg-energy-9",						"texugo-wind-turbine2",																		"q")
	aadd("rg-energy-9",						"texugo-wind-turbine3",																		"r")
	-- alternative steam
	aadd("rg-energy-1",						"electric-boiler",																		"a[100][09000]")
	
	aadd("rg-energy-3",						"low-heat-exchanger",																	"a[36000]")
	
	aadd("rg-energy-5",						"chemical-fired-reactor",															"g")
	-- geothermal
	aadd("rg-energy-3",						"geothermal-heat-exchanger",													"a[00400]")
	
	-- theyre made out of meat
	aadd("rg-energy-1",						"meat-boiler",																				"a[070][25000]")

	-- aai industry
	aadd("rg-energy-1",						"fat-boiler",																					"g")
	
	aadd("rg-energy-2",						"rotary-motion-engine",																"f")
	
	aadd("rg-energy-5",						"burner-turbine",																			"c[04900]")
	
	aadd("rg-energy-10",					"art-fusion-reactor",																	"a")
	
	aadd("rg-energy-12",					"small-iron-electric-pole",														"a[007][005x005]b")
	
	-- suit plug continued
	aadd("rg-energy-11",						"suit-outlet",																				"z")
	
	-- advanced electric
	aadd("rg-energy-7",						"advanced-solar",																			"h")
	aadd("rg-energy-7",						"elite-solar",																				"i")
	aadd("rg-energy-7",						"ultimate-solar",																			"j")
	
	aadd("rg-energy-11",						"advanced-accumulator",																"n")
	aadd("rg-energy-11",						"elite-accumulator",																	"o")
	aadd("rg-energy-11",						"ultimate-accumulator",																"p")
	
	-- lighted poles plus
	aadd("rg-energy-12",						"lighted-small-electric-pole",												"a[007][005x005]b")
	
	aadd("rg-energy-13",						"lighted-medium-electric-pole",												"a[009][007x007]b")
	aadd("rg-energy-13",						"lighted-medium-electric-pole-2",											"a[011][005x005]a2")
	aadd("rg-energy-13",						"lighted-medium-electric-pole-3",											"a[013][011x011]a2")
	aadd("rg-energy-13",						"lighted-medium-electric-pole-4",											"a[015][013x013]a2")
	
	aadd("rg-energy-14",						"lighted-big-electric-pole",													"a[030][004x004]b")
	aadd("rg-energy-14",						"lighted-big-electric-pole-2",												"a[040][004x004]a2")
	aadd("rg-energy-14",						"lighted-big-electric-pole-3",												"a[050][004x004]a2")
	aadd("rg-energy-14",						"lighted-big-electric-pole-4",												"a[060][004x004]a2")
	
	aadd("rg-energy-15",						"lighted-substation",																	"a[018][018x018]b")
	aadd("rg-energy-15",						"lighted-substation-2",																"a[024][024x024]a2")
	aadd("rg-energy-15",						"lighted-substation-3",																"a[030][030x030]a2")
	aadd("rg-energy-15",						"lighted-substation-4",																"a[036][036x036]a2")
	
	aadd("rg-energy-13",						"lighted-5d-electric-pole-4",													"a[020][015x015]b2")	
	
	aadd("rg-energy-14",						"lighted-5d-electric-pole-5",													"a[050][007x007]b2")
	
	aadd("rg-energy-15",						"lighted-5d-electric-pole-6",													"a[064][049x049]b2")
	
	aadd("rg-energy-13",						"lighted-medium-electric-pole-mk2",										"a[011][009x009]c2")
	aadd("rg-energy-13",						"lighted-medium-electric-pole-mk3",										"a[013][011x011]c2")
	
	aadd("rg-energy-14",						"lighted-big-electric-pole-mk2",											"a[040][004x004]c2")
	aadd("rg-energy-14",						"lighted-big-electric-pole-mk3",											"a[060][004x004]c2")
	
	aadd("rg-energy-15",						"lighted-substation-mk2",															"a[028][028x028]c2")
	aadd("rg-energy-15",						"lighted-substation-mk3",															"a[042][042x042]c2")
	
	aadd("rg-energy-15",						"lighted-bi-large-substation",												"a[025][100x100]b")
	
	aadd("rg-energy-12",						"lighted-bi-big-wooden-pole",													"a[007][004x004]b")
	aadd("rg-energy-12",						"lighted-bi_huge_wooden_pole",												"a[064][004x004]b")
	
	aadd("rg-energy-12",						"lighted-small-iron-electric-pole",										"a[007][005x005]b")
	
	aadd("rg-energy-12",						"lighted-y_signal_pole",															"a[048][003x003]2")
	
	aadd("rg-energy-15",						"lighted-y-substation-m",															"a[048][032x032]2")
	aadd("rg-energy-15",						"lighted-y-substation-h",															"a[064][064x064]2")
	
	-- KPOT Titanium
	aadd("rg-energy-13",						"titanium-electric-pole",															"k")
	aadd("rg-energy-13",						"lighted-titanium-electric-pole",											"kb")
	
	-- rail power system
	aadd("rg-energy-13",						"rail-electric-pole",																	"l")
	
	-- electric train
	aadd("rg-energy-9",						"power-provider",																			"i")
	
	-- tesseract
	aadd("rg-energy-9",						"tesseract",																					"j")
	
end
do --[[module]]--
	-- mini machines
	aadd("rg-module-0",						"mini-beacon-1",																			"e1a")
	aadd("rg-module-0",						"mini-beacon-2",																			"e2a")
	aadd("rg-module-0",						"mini-beacon-3",																			"e3a")
	
	-- advanced machines
	aadd("rg-module-0",						"advanced-beacon",																		"e2")
	
	-- module insterter
	aadd("rg-module-0",						"module-inserter",																		"j")
	
	-- wormmus config
	aadd("rg-module-1",						"space-science-pack",																	"h")
	
	-- aai industry
	aadd("rg-module-0",						"burner-lab",																					"e")
	
	-- science cost tweaker
	aadd("rg-module-0",						"sct-lab-1",																					"ab")
	aadd("rg-module-0",						"sct-lab-2",																					"ac")
	aadd("rg-module-0",						"sct-lab-3",																					"ad")
	aadd("rg-module-0",						"sct-lab-4",																					"ae")
	
	aadd("rg-module-1",						"sct-bm4-plating",																		"01")
	aadd("rg-module-1",						"sct-bm4-injector",																		"02")
	aadd("rg-module-1",						"sct-bm4-supercoils",																	"03")
	aadd("rg-module-1",						"sct-bm4-capbank",																		"04")
	aadd("rg-module-1",						"sct-t1-ironcore",																		"05")
	aadd("rg-module-1",						"sct-t1-magnet-coils",																"06")
	aadd("rg-module-1",						"sct-t2-reaction-nodes",															"07")
	aadd("rg-module-1",						"sct-t2-instruments",																	"08")
	aadd("rg-module-1",						"sct-t2-microcircuits",																"09")
	aadd("rg-module-1",						"sct-t2-micro-wafer",																	"10")
	aadd("rg-module-1",						"sct-t2-wafer-stamp",																	"11")
	aadd("rg-module-1",						"sct-t3-flash-fuel",																	"12")
	aadd("rg-module-1",						"sct-t3-laser-foci",																	"13")
	aadd("rg-module-1",						"sct-t3-laser-emitter",																"14")
	aadd("rg-module-1",						"sct-t3-femto-lasers",																"15")
	aadd("rg-module-1",						"sct-t3-atomic-sensors",															"16")
	aadd("rg-module-1",						"sct-t4-bioprocessor",																"17")
	aadd("rg-module-1",						"sct-t4-overclocker",																	"18")
	aadd("rg-module-1",						"sct-bm4-part1",																			"19")
	aadd("rg-module-1",						"sct-bm4-part1a",																			"20")
	aadd("rg-module-1",						"sct-bm4-part1b",																			"21")
	aadd("rg-module-1",						"sct-bm4-part1c",																			"22")
	aadd("rg-module-1",						"sct-bm4-part2",																			"23")
	aadd("rg-module-1",						"sct-bm4-part2a",																			"24")
	aadd("rg-module-1",						"sct-bm4-part2b",																			"25")
	aadd("rg-module-1",						"sct-bm4-part2c",																			"26")
	aadd("rg-module-1",						"sct-bm4-part3",																			"27")
	aadd("rg-module-1",						"sct-bm4-part3a",																			"28")
	aadd("rg-module-1",						"sct-bm4-part3b",																			"29")
	aadd("rg-module-1",						"sct-bm4-part3c",																			"30")
	aadd("rg-module-1",						"sct-bm4-part3d",																			"31")
	aadd("rg-module-1",						"sct-bm4-part4",																			"32")
	aadd("rg-module-1",						"sct-bm4-part4a",																			"33")
	aadd("rg-module-1",						"sct-bm4-part4b",																			"34")
	aadd("rg-module-1",						"sct-bm4-part4c",																			"35")
	aadd("rg-module-1",						"sct-bm4-part4d",																			"36")
	aadd("rg-module-1",						"sct-bm4-part5",																			"37")
	aadd("rg-module-1",						"sct-bm4-part5a",																			"38")
	aadd("rg-module-1",						"sct-bm4-part5b",																			"39")
	aadd("rg-module-1",						"sct-bm4-part5c",																			"40")
	aadd("rg-module-1",						"sct-bm4-part5d",																			"41")
	
	-- modular charge packs
	aadd("rg-module-1",						"chargepack-enhanced-electrodes-1",										"z1")
	aadd("rg-module-1",						"chargepack-enhanced-electrodes-2",										"z2")
	aadd("rg-module-1",						"chargepack-enhanced-electrodes-3",										"z3")
	aadd("rg-module-1",						"chargepack-electrodes-1",														"z4")
	aadd("rg-module-1",						"chargepack-electrodes-2",														"z5")
	aadd("rg-module-1",						"chargepack-electrodes-3",														"z6")
	
	-- lumberjack
	aadd("rg-module-10",						"seeder-module-01",																		"a")
	aadd("rg-module-10",						"seeder-module-02",																		"b")
	aadd("rg-module-10",						"seeder-module-03",																		"c")
	aadd("rg-module-10",						"seeder-module-04",																		"d")
	aadd("rg-module-10",						"seeder-module-05",																		"e")
end
do --[[defense]]--
	-- mini machines
	aadd("rg-defense-8",						"mini-radar-1",																				"a1")
	aadd("rg-defense-8",						"mini-radar-2",																				"a2")
	aadd("rg-defense-8",						"mini-radar-3",																				"a3")
	aadd("rg-defense-8",						"mini-radar-4",																				"a4")
	aadd("rg-defense-8",						"mini-radar-5",																				"a5")
	
	-- natural evolution buildings
	aadd("rg-defense-0",						"ne-living-wall",																			"i")
	aadd("rg-defense-0",						"ne-living-wall-refresh",															"j")
	aadd("rg-defense-0",						"ne-living-wall-exhausted",														"k")
	
	aadd("rg-defense-6",						"bio-turret",																					"d")
	aadd("rg-defense-6",						"NE-gun-turret",																			"e")
	aadd("rg-defense-6",						"NE-rocket-turret",																		"f")
	
	-- scattergun turret
	aadd("rg-defense-6",						"scattergun-turret",																	"g")
	
	-- dectorio
	aadd("rg-defense-0",						"dect-wood-wall",																			"a")
	aadd("rg-defense-0",						"dect-chain-wall",																		"b")
	aadd("rg-defense-0",						"dect-concrete-wall",																	"e")
	aadd("rg-defense-0",						"concrete-wall",																			"f")
	
	aadd("rg-defense-1",						"dect-hazard-gate",																		"d")
	
	-- reinforced walls
	aadd("rg-defense-0",						"acid-resist-wall",																		"g")
	aadd("rg-defense-0",						"damage-reflect-wall",																"h")
	
	-- aai
	aadd("rg-defense-0",						"steel-wall",																					"l")
	
	-- force field
	aadd("rg-defense-2",						"forcefield-emitter",																	"f")
	
	-- robot army
	aadd("rg-defense-2",						"patrol-pole",																				"m")
	aadd("rg-defense-2",						"lighted-patrol-pole",																"n")
	
	-- ion cannon
	aadd("rg-defense-2",						"orbital-ion-cannon",																	"h")
	aadd("rg-defense-2",						"ion-cannon-targeter",																"i")
	
	aadd("rg-defense-8",						"auto-targeter",																			"g")
	
end
do --[[intermediate]]--
	-- VTK Deep Core Mining Drill
  aadd("rg-intermediate-6",			"vtk-deepcore-mining-ore-chunk-refining",							"g")
  aadd("rg-intermediate-6",			"vtk-deepcore-mining-stone-chunk-refining",						"h")
  aadd("rg-intermediate-6",			"vtk-deepcore-mining-coal-chunk-refining",						"i")
	aadd("rg-intermediate-6",			"vtk-deepcore-mining-iron-ore-chunk-refining",				"j")
  aadd("rg-intermediate-6",			"vtk-deepcore-mining-copper-ore-chunk-refining",			"k")
  aadd("rg-intermediate-6",			"vtk-deepcore-mining-uranium-ore-chunk-refining",			"l")
	
	-- lumberjack
	aadd("rg-intermediate-7",			"sawmill-tree",																				"k")
	
	-- advanced machines
	aadd("rg-intermediate-7",			"filter-air",																					"n")
	aadd("rg-intermediate-7",			"air-filter-recycling",																"o")
	
	-- air filtering
	aadd("rg-intermediate-7",			"used-air-filter",																		"p")
	aadd("rg-intermediate-7",			"unused-air-filter",																	"q")
	
	-- tree farm
	aadd("rg-intermediate-7",			"tf-germling",																				"l")
	aadd("rg-intermediate-7",			"tf-coral-seed",																			"m")
	
	-- aai industry
	aadd("rg-intermediate-7",			"stone-tablet",																				"n")
	aadd("rg-intermediate-7",			"motor",																							"o")
	aadd("rg-intermediate-7",			"electric-motor",																			"p")
	
	-- natural evolution
	aadd("rg-intermediate-7",			"Building_Materials",																	"q")
	
	-- avatars
	aadd("rg-intermediate-9",			"actuator",																						"a")
	aadd("rg-intermediate-9",			"avatar-arm",																					"b")
	aadd("rg-intermediate-9",			"avatar-leg",																					"c")
	aadd("rg-intermediate-9",			"avatar-head",																				"d")
	aadd("rg-intermediate-9",			"avatar-torso",																				"e")
	aadd("rg-intermediate-9",			"avatar-internals",																		"f")
	aadd("rg-intermediate-9",			"avatar-skin",																				"g")
	
	-- theyre made out of meat
	aadd("rg-intermediate-17",		"dry-meat",																						"d")
	aadd("rg-intermediate-17",		"process-meat",																				"d")
	aadd("rg-intermediate-17",		"solid-fuel-meat",																		"d")

	-- aai
	aadd("rg-intermediate-18",		"vehicle-fuel",																				"z")
	
	-- personal teleporter
	aadd("rg-intermediate-9",			"TeleporterCore",																			"z")
	
end
do --[[trains-vehicles]]--
	-- beautiful bridge railway
	aadd("rg-trains-0",						"bbr-rail-wood",																			"a2")
	aadd("rg-trains-0",						"bbr-rail-iron",																			"a3")
	aadd("rg-trains-0",						"bbr-rail-brick",																			"a4")
	aadd("rg-trains-0",						"bbr-straight-rail-wood",															"b2")
	aadd("rg-trains-0",						"bbr-straight-rail-iron",															"b3")
	aadd("rg-trains-0",						"bbr-straight-rail-brick",														"b4")
	aadd("rg-trains-0",						"bbr-curved-rail-wood",																"c2")
	aadd("rg-trains-0",						"bbr-curved-rail-iron",																"c3")
	aadd("rg-trains-0",						"bbr-curved-rail-brick",															"c4")
	
	-- smart trains
	aadd("rg-trains-1",						"smart-train-stop",																		"a2")
	
	-- rail power system
	aadd("rg-trains-0",						"powered-rail",																				"p")
	aadd("rg-trains-4",						"hybrid-train",																				"p")
	
	-- logistic train network
	aadd("rg-trains-1",						"logistic-train-stop",																"a3")
	
	-- farl
	aadd("rg-trains-2",						"farl",																								"l")
	aadd("rg-trains-2",						"farl-roboport",																			"m")
	
	-- folk logistic wagon
	aadd("rg-trains-2",						"folk-logistic-wagon",																"n")
	aadd("rg-trains-4",						"rail-tanker",																				"o")
	
	-- tankwerkz
	aadd("rg-vehicles-1",					"hydra-tank",																					"f")
	aadd("rg-vehicles-1",					"light-tank",																					"g")
	aadd("rg-vehicles-1",					"flame-tank",																					"h")
	aadd("rg-vehicles-1",					"heavy-tank",																					"i")
	
	aadd("rg-vehicles-5",					"hiex-cannon-shell",																	"a")
	aadd("rg-vehicles-5",					"ap-cannon-shell",																		"c")
	aadd("rg-vehicles-5",					"heavy-mg-ammo",																			"d")
	aadd("rg-vehicles-5",					"hydra-rocket",																				"e")
	aadd("rg-vehicles-5",					"tank-flame-thrower-ammo",														"f")
	aadd("rg-vehicles-5",					"heavy-mg",																						"g")
	aadd("rg-vehicles-5",					"hydra-rocket-launcher",															"h")
	aadd("rg-vehicles-5",					"flame-tank-flame-thrower",														"i")
	
	-- aircraft
	aadd("rg-vehicles-2",					"cargo-plane",																				"d")
	aadd("rg-vehicles-2",					"flying-fortress",																		"e")
	aadd("rg-vehicles-2",					"gunship",																						"f")
	aadd("rg-vehicles-2",					"jet",																								"g")
	
	aadd("rg-vehicles-5",					"high-explosive-cannon-shell",												"b")
	
	-- vehicle wagon
	aadd("rg-vehicles-3",					"winch",																							"j")
	
	-- aai
	aadd("rg-vehicles-1",					"vehicle-warden",																			"h")
	aadd("rg-vehicles-1",					"vehicle-chaingunner",																"i")
	aadd("rg-vehicles-3",					"vehicle-miner",																			"a")
	aadd("rg-vehicles-3",					"vehicle-miner-mk2",																	"b")
	aadd("rg-vehicles-3",					"vehicle-miner-mk3",																	"c")
	aadd("rg-vehicles-3",					"vehicle-miner-mk4",																	"d")
	aadd("rg-vehicles-3",					"vehicle-miner-mk5",																	"e")
	aadd("rg-vehicles-3",					"vehicle-hauler",																			"f")
	aadd("rg-vehicles-3",					"vehicle-flame-tumbler",															"h")
	aadd("rg-vehicles-3",					"vehicle-laser-tank",																	"i")
	aadd("rg-vehicles-3",					"vehicle-flame-tank",																	"j")
	
	-- truck
	aadd("rg-vehicles-3",					"dumper-truck",																				"g")
	
	-- batteries not included
	aadd("rg-trains-3",						"bni_electric-locomotive",														"g")
	
	-- electric trains
	aadd("rg-trains-3",						"electric-locomotive-mk1",																"a")
	aadd("rg-trains-3",						"electric-locomotive-mk2",														"b")
	aadd("rg-trains-3",						"electric-locomotive-mk3",														"c")
	
	aadd("rg-trains-3",						"electric-cargo-wagon",																"d")
	aadd("rg-trains-3",						"electric-cargo-wagon-mk2",														"e")
	aadd("rg-trains-3",						"electric-cargo-wagon-mk3",														"f")
	
	-- electric vehicles
	aadd("rg-trains-3",						"electric-vehicles-electric-locomotive",							"h")
	aadd("rg-vehicles-0",					"electric-vehicles-electric-tank",										"f")
	aadd("rg-vehicles-1",					"electric-vehicles-electric-car",											"g")
	
	-- fusion locomotive
	aadd("rg-trains-3",						"fusion-locomotive-mk1",							"i")
	aadd("rg-trains-3",						"fusion-locomotive-mk2",							"j")
	aadd("rg-trains-3",						"fusion-locomotive-mk3",							"k")
	
	-- vehicle wagon
	aadd("rg-trains-2",						"vehicle-wagon",																			"p")
	
	-- diesel locomotive
	aadd("rg-trains-4",						"fluid-locomotive",																		"k")
	
	-- fusion train
	aadd("rg-trains-2",						"fusion-locomotive",																	"q")
	aadd("rg-trains-2",						"nuclear-train-vehicle-rampant-arsenal",																	"r")
	aadd("rg-trains-1",						"railloader-placemet-proxy",																	"f")
	aadd("rg-trains-1",						"railunloader-placemet-proxy",																	"g")
	aadd("rg-trains-45",					"advanced-car-vehicle-rampant-arsenal",																	"b")
	aadd("rg-trains-45",					"nuclear-car-vehicle-rampant-arsenal",																	"c")
	aadd("rg-trains-45",					"advanced-tank-vehicle-rampant-arsenal",																"d")
	aadd("rg-trains-45",					"nuclear-tank-vehicle-rampant-arsenal",																	"f")
	aadd("rg-trains-46",					"heli-item",																	"a")
	aadd("rg-trains-46",					"heli-pad-item",																	"b")
	
end
do --[[armor]]--
	-- tiny start
	aadd("rg-armor-4",						"tiny-armor-mk0",																			"0")
	aadd("rg-armor-4",						"tiny-armor-mk1",																			"1")
	aadd("rg-armor-4",						"tiny-armor-mk2",																			"2")

	-- theyre made out of meat
	aadd("rg-armor-4",						"bone-armor",																					"d")

	-- advanced power armor
	aadd("rg-armor-5",						"power-armor-mk6",																		"g")
	aadd("rg-armor-5",						"power-armor-mk7",																		"h")
	
	-- afraid of dark
	aadd("rg-armor-7",						"perfect-night-glasses",															"g")
	
	-- portal research
	aadd("rg-armor-7",						"personal-microwave-antenna-equipment",								"i")
	
	-- suit plug continued
	aadd("rg-armor-7",						"suit-plug",																					"d")
	
	-- teleportation
	aadd("rg-armor-7",						"teleportation-portal",																"h")
	aadd("rg-armor-7",						"teleportation-equipment",														"i")
	aadd("rg-armor-13",						"Personal-Teleporter",																"g")
	
	-- battteries not included
	aadd("rg-armor-9",						"bni_battery-pack",																		"o")
	aadd("rg-armor-9",						"bni_battery-pack-2",																	"p")
	aadd("rg-armor-9",						"bni_battery-pack-empty",															"q")
	aadd("rg-armor-9",						"bni_battery-pack-2-empty",														"r")
	
	-- modular chargepacks
	aadd("rg-armor-9",						"chargepack-small",																		"g")
	aadd("rg-armor-9",						"chargepack-small-fullycharged",											"h")
	aadd("rg-armor-9",						"chargepack-small-fullycharged-normal",								"i")
	aadd("rg-armor-9",						"chargepack-small-fullycharged-rapid",								"j")
	aadd("rg-armor-9",						"chargepack-large",																		"k")
	aadd("rg-armor-9",						"chargepack-large-fullycharged",											"l")
	aadd("rg-armor-9",						"chargepack-large-fullycharged-normal",								"m")
	aadd("rg-armor-9",						"chargepack-large-fullycharged-rapid",								"n")
	
	aadd("rg-armor-20",						"bni_charging-station",																"g")
	aadd("rg-armor-20",						"bni_rapid-charging-station",													"h")
	
	-- advanced personal defense
	aadd("rg-armor-10",						"advanced-laser-defense-equipment",										"g")
	
	-- nanobots
	aadd("rg-armor-12",						"equipment-bot-chip-items",														"a")
	aadd("rg-armor-12",						"equipment-bot-chip-launcher",												"b")
	aadd("rg-armor-12",						"equipment-bot-chip-trees",														"c")
	aadd("rg-armor-12",						"equipment-bot-chip-feeder",													"d")
	aadd("rg-armor-12",						"equipment-bot-chip-nanointerface",										"e")
	aadd("rg-armor-12",						"belt-immunity-equipment",														"f")
	
	aadd("rg-armor-20",						"shuttle-lite",																				"a")
	aadd("rg-armor-20",						"electric-vehicles-lo-voltage-transformer",						"b")
	aadd("rg-armor-20",						"electric-vehicles-hi-voltage-transformer",						"c")
	aadd("rg-armor-20",						"electric-vehicles-regen-brake-controller",						"d")
	
	-- train caller
	aadd("rg-armor-21",						"trainCallerEquipment",																"e")
	
	-- induction charging
	aadd("rg-armor-20",						"induction-coil",																			"f")
end
do --[[weaponry]]--
	-- explosive termites
	aadd("rg-weaponry-0",					"explosive-termites",																	"l")
	aadd("rg-weaponry-0",					"alien-explosive-termites",														"m")
	
	-- AAI Vehicles Warden
	aadd("rg-weaponry-1",					"electroshock-pulse-ammo",														"i")
	
	-- theyre made out of meat
	aadd("rg-weaponry-1",					"meat-burger",																				"j")
	
	-- KPOT Titanium
	aadd("rg-weaponry-4",					"titanium-firearm-magazine",													"m")
	
	-- aai
	aadd("rg-weaponry-1",					"flamejet-ammo",																			"h") 
	
	aadd("rg-weaponry-14",				"laser-cannon-battery-focussed",											"g") 
	aadd("rg-weaponry-14",				"laser-cannon-battery-piercing",											"h") 
	
	aadd("rg-weaponry-15",				"cannon-shell-precision",															"f")
	aadd("rg-weaponry-15",				"explosive-cannon-shell-precision",										"g")
	
	-- robot army
	aadd("rg-weaponry-13",				"defender-unit",																			"a")
	aadd("rg-weaponry-13",				"defender-unit-dummy",																"a2")
	aadd("rg-weaponry-13",				"distractor-unit",																		"b")
	aadd("rg-weaponry-13",				"distractor-unit-dummy",															"b2")
	aadd("rg-weaponry-13",				"destroyer-unit",																			"c")
	aadd("rg-weaponry-13",				"destroyer-unit-dummy",																"c2")
	
	-- theyre made out of meat
	aadd("rg-weaponry-4",					"bone-bullets",																				"l")
	
	-- natural evolution buildings
	aadd("rg-weaponry-3",					"bi-basic_dart_magazine_c",														"k2")
	aadd("rg-weaponry-3",					"bi-standard_dart_magazine_c",													"l2")
	aadd("rg-weaponry-3",					"bi-enhanced_dart_magazine_c",													"m2")
	aadd("rg-weaponry-3",					"bi-poison_dart_magazine_c",													"n2")
	
	aadd("rg-weaponry-4",					"firearm-magazine_c",															"a1b")
	aadd("rg-weaponry-4",					"copper-bullet-magazine",														"d")
	aadd("rg-weaponry-4",					"copper-bullet-magazine_c",														"e")
	aadd("rg-weaponry-4",					"piercing-rounds-magazine",														"f")
	aadd("rg-weaponry-4",					"piercing-rounds-magazine_c",													"g")
	aadd("rg-weaponry-4",					"uranium-rounds-magazine",														"h")
	aadd("rg-weaponry-4",					"uranium-rounds-magazine_c",													"i")
	aadd("rg-weaponry-4",					"Biological-bullet-magazine",													"j")
	aadd("rg-weaponry-4",					"Biological-bullet-magazine_c",													"k")
	
	aadd("rg-weaponry-10",				"bio_land_mine",																			"g")
	
	aadd("rg-weaponry-16",				"NE-Napalm-Rocket",																		"j")
	
	-- clown nuclear
	aadd("rg-weaponry-16",				"plutonium-atomic-bomb",															"k")
	aadd("rg-weaponry-16",				"thermonuclear-bomb",																	"l")
end
do --[[decorative]]--
	-- dectorio
	--[[aadd("rg-decorative-0",				"dect-base-water",																		"c")
		aadd("rg-decorative-0",				"dect-base-water-green",															"d")
		aadd("rg-decorative-0",				"dect-base-dirt",																			"e")
		aadd("rg-decorative-0",				"dect-base-sand",																			"f")
		aadd("rg-decorative-0",				"dect-base-sand-dark",																"g")
		aadd("rg-decorative-0",				"dect-base-grass",																		"h")
		aadd("rg-decorative-0",				"dect-base-grass-dry",																"i")
	aadd("rg-decorative-0",				"dect-base-red-desert",																"j")
	aadd("rg-decorative-0",				"dect-base-red-desert-dark",													"k")
	
	aadd("rg-decorative-1",				"dect-concrete-grid",																	"l")
	aadd("rg-decorative-1",				"dect-stone-gravel",																	"m")
	aadd("rg-decorative-1",				"dect-iron-gravel",																		"n")
	aadd("rg-decorative-1",				"dect-copper-gravel",																	"o")
	aadd("rg-decorative-1",				"dect-paint-hazard",																	"p")
	aadd("rg-decorative-1",				"dect-paint-emergency",																"q")
	aadd("rg-decorative-1",				"dect-paint-radiation",																"r")
	aadd("rg-decorative-1",				"dect-paint-safety",																	"s")
	aadd("rg-decorative-1",				"dect-paint-danger",																	"t")
	aadd("rg-decorative-1",				"dect-paint-caution",																	"u")
	aadd("rg-decorative-1",				"dect-paint-defect",																	"v")
	aadd("rg-decorative-1",				"dect-paint-operations",															"w")
	
	
	aadd("rg-decorative-8",				"dect-sign-wood",																			"m")
	aadd("rg-decorative-8",				"dect-sign-steel",																		"n")
	aadd("rg-decorative-8",				"dect-traffic-bollard",																"o")
	
	aadd("rg-decorative-9",				"dect-wood-floor",																		"db")]]
	
	aadd("rg-decorative-4",				"dect-small-lamp-glow",																"r")
	
	for _,v in pairs(data.raw["item-subgroup"]) do
		if v.group == "logistics" then
			if v.name == "Arci-asphalt-1" then
				v.group = "rg-decorative"
				v.order = 10
				elseif v.name == "Arci-asphalt-2" then
				v.group = "rg-decorative"
				v.order = 11
				elseif v.name == "Arci-asphalt-3" then
				v.group = "rg-decorative"
				v.order = 12
			end
			elseif v.group == "dectorio" then
			if v.name == "decoratives" then
				v.group = "rg-decorative"
				v.order = 13
				elseif v.name == "flooring-basic" then
				v.group = "rg-decorative"
				v.order = 14
				elseif v.name == "flooring-painted" then
				v.group = "rg-decorative"
				v.order = 15
				elseif v.name == "landscaping" then
				v.group = "rg-decorative"
				v.order = 16
				elseif v.name == "signs" then
				v.group = "rg-decorative"
				v.order = 17
				else
				v.group = "rg-decorative"
				v.order = 18
			end
		end
	end
	
	-- theyre made out of meat
	aadd("rg-decorative-6",				"bone-floor",	                            						"e")
	
	-- landfill
	aadd("rg-decorative-0",				"water-bomb",																					"a")
	aadd("rg-decorative-0",				"water-be-gone",																			"b")
	
	-- text plates
	aadd("rg-decorative-1",				"small-iron-blank",																		"o")
	aadd("rg-decorative-1",				"textplate-small-iron",																"o")
	aadd("rg-decorative-1",				"large-iron-blank",																		"p")
	aadd("rg-decorative-1",				"textplate-large-iron",																"p")
	aadd("rg-decorative-1",				"small-copper-blank",																	"q")
	aadd("rg-decorative-1",				"textplate-small-copper",															"q")
	aadd("rg-decorative-1",				"large-copper-blank",																	"r")
	aadd("rg-decorative-1",				"textplate-large-copper",															"r")
	
	-- color coding
	aadd("rg-decorative-1",				"fire-hazard-concrete",																"j")
	
	-- afraid of dark
	aadd("rg-decorative-4",				"balloon-light",																"j")
	aadd("rg-decorative-4",				"short-balloon-light",															"k")
	
	aadd("rg-decorative-2",				"concrete-red",																				"a")
	aadd("rg-decorative-2",				"concrete-orange",																		"b")
	aadd("rg-decorative-2",				"concrete-yellow",																		"c")
	aadd("rg-decorative-2",				"concrete-green",																			"d")
	aadd("rg-decorative-2",				"concrete-cyan",																			"e")
	aadd("rg-decorative-2",				"concrete-blue",																			"f")
	aadd("rg-decorative-2",				"concrete-purple",																		"g")
	aadd("rg-decorative-2",				"concrete-magenta",																		"h")
	aadd("rg-decorative-2",				"concrete-white",																			"i")
	aadd("rg-decorative-2",				"concrete-black",																			"j")
	
	aadd("rg-decorative-2",				"refined-concrete-red",																"k")
	aadd("rg-decorative-2",				"refined-concrete-orange",														"l")
	aadd("rg-decorative-2",				"refined-concrete-yellow",														"m")
	aadd("rg-decorative-2",				"refined-concrete-green",															"n")
	aadd("rg-decorative-2",				"refined-concrete-cyan",															"o")
	aadd("rg-decorative-2",				"refined-concrete-blue",															"p")
	aadd("rg-decorative-2",				"refined-concrete-purple",														"q")
	aadd("rg-decorative-2",				"refined-concrete-magenta",														"r")
	aadd("rg-decorative-2",				"refined-concrete-white",															"s")
	aadd("rg-decorative-2",				"refined-concrete-black",															"t")
	
	aadd("rg-decorative-3",				"small-lamp-red",																			"a")
	aadd("rg-decorative-3",				"small-lamp-orange",																	"b")
	aadd("rg-decorative-3",				"small-lamp-yellow",																	"c")
	aadd("rg-decorative-3",				"small-lamp-green",																		"d")
	aadd("rg-decorative-3",				"small-lamp-cyan",																		"e")
	aadd("rg-decorative-3",				"small-lamp-blue",																		"f")
	aadd("rg-decorative-3",				"small-lamp-purple",																	"g")
	aadd("rg-decorative-3",				"small-lamp-magenta",																	"h")
	aadd("rg-decorative-3",				"small-lamp-white",																		"i")
	aadd("rg-decorative-3",				"small-lamp-black",																		"j")
	
	-- concrete lamppost
	aadd("rg-decorative-8",				"concrete-lamp",																			"i")
	aadd("rg-decorative-8",				"concrete-lamppost",																	"j")
	
	-- bright lamp
	aadd("rg-decorative-8",				"bright-lamp",																				"k")
	
	-- more floors
	aadd("rg-decorative-9",				"decal1",																							"a")
	aadd("rg-decorative-9",				"experiment",																					"b")
	aadd("rg-decorative-9",				"checkerboard",																				"c")
	aadd("rg-decorative-9",				"wood-floor",																					"d")
	aadd("rg-decorative-9",				"herringbone",																				"e")
	aadd("rg-decorative-9",				"darkwood",																						"f")
	
	aadd("rg-decorative-10",				"lava",																								"a")
	aadd("rg-decorative-10",				"snow",																								"b")
	aadd("rg-decorative-10",				"tar",																								"c")
	aadd("rg-decorative-10",				"toxic",																							"d")
	aadd("rg-decorative-10",				"mf_dirt",																						"e")
	aadd("rg-decorative-10",				"mf_dirt_dark",																				"f")
	aadd("rg-decorative-10",				"mf_sand_light",																			"g")
	aadd("rg-decorative-10",				"mf_sand_dark",																				"h")
	aadd("rg-decorative-10",				"mf_grass_dry",																				"i")
	aadd("rg-decorative-10",				"mf_green_grass",																			"j")
	aadd("rg-decorative-10",				"asphalt",																						"k")
	aadd("rg-decorative-10",				"cobblestone",																				"l")
	aadd("rg-decorative-10",				"gravel",																							"m")
	aadd("rg-decorative-10",				"redbrick",																						"n")
	aadd("rg-decorative-10",				"yellowbrick",																				"o")
	aadd("rg-decorative-10",				"reinforced-concrete",																"p")
	aadd("rg-decorative-10",				"smooth-concrete",																		"q")
	aadd("rg-decorative-10",				"road-line",																					"r")
	aadd("rg-decorative-10",				"alien-metal",																				"s")
	aadd("rg-decorative-10",				"circuit-floor",																			"t")
	aadd("rg-decorative-10",				"diamond-plate",																			"u")
	aadd("rg-decorative-10",				"hexagonb",																						"v")
	aadd("rg-decorative-10",				"metal-scraps",																				"w")
	aadd("rg-decorative-10",				"rusty-metal",																				"x")
	
	aadd("rg-decorative-11",				"rusty-grate",																				"a")
	aadd("rg-decorative-11",				"arrow-grate",																				"b")
	aadd("rg-decorative-11",				"fast-arrow-grate",																		"c")
	aadd("rg-decorative-11",				"express-arrow-grate",																"d")
	aadd("rg-decorative-11",				"nitinol-arrow-grate",																"e")
	aadd("rg-decorative-11",				"titanium-arrow-grate",																"f")
	
	aadd("rg-decorative-12",				"mf-concrete-red",																		"a")
	aadd("rg-decorative-12",				"mf-concrete-orange",																	"b")
	aadd("rg-decorative-12",				"mf-concrete-gold",																		"c")
	aadd("rg-decorative-12",				"mf-concrete-yellow",																	"d")
	aadd("rg-decorative-12",				"mf-concrete-green",																	"e")
	aadd("rg-decorative-12",				"mf-concrete-limegreen",															"f")
	aadd("rg-decorative-12",				"mf-concrete-skyblue",																"g")
	aadd("rg-decorative-12",				"mf-concrete-blue",																		"h")
	aadd("rg-decorative-12",				"mf-concrete-magenta",																"i")
	aadd("rg-decorative-12",				"mf-concrete-pink",																		"j")
	aadd("rg-decorative-12",				"mf-concrete-purple",																	"k")
	aadd("rg-decorative-12",				"mf-concrete-white",																	"l")
	aadd("rg-decorative-12",				"mf-concrete-darkgrey",																"m")
	aadd("rg-decorative-12",				"mf-concrete-black",																	"n")
	
	aadd("rg-decorative-13",				"sand_dark_blueprint",																"a")
	aadd("rg-decorative-13",				"sand_light_blueprint",																"b")
	aadd("rg-decorative-13",				"dirt_blueprint",																			"c")
	aadd("rg-decorative-13",				"dirt_dark_blueprint",																"d")
	aadd("rg-decorative-13",				"mf_grass_dry_blueprint",															"e")
	aadd("rg-decorative-13",				"mf_green_grass_blueprint",														"f")
	
	-- natural evolution
	aadd("rg-decorative-2",				"decelerate_concrete",																"k")
	
	aadd("rg-decorative-8",				"battle_marker",																			"k")
end
do --[[alien]]--
	-- natural evolution
	for _,v in pairs(data.raw["item-subgroup"]) do
		if v.group == "Natural-Evolution" then v.group = "rg-alien" end
	end
	
	aadd("rg-alien-1",							"TerraformingStation",																"a")
	aadd("rg-alien-1",							"Artifact-collector-area",														"b")
	
	-- loot chest
	aadd("rg-alien-1",				"artifact-loot-chest",																			"c")
	
	-- natural evolution buildings
	aadd("rg-alien-3",							"alien-artifact",																			"a")
	
	aadd("rg-alien-4",							"small-alien-artifact",																"a")
	
end
do --[[atomic]]--
	-- logistic reactor
	aadd("rg-atomic-0",							"logistic-reactor",																		"d")
	
	-- nuclear fuel
	aadd("rg-atomic-5",							"uranium-235",																				"a")
	aadd("rg-atomic-5",							"uranium-238",																				"b")
	aadd("rg-atomic-5",							"plutonium",																					"c")
	aadd("rg-atomic-5",							"mox-fuel-cell",																			"d")
	aadd("rg-atomic-5",							"uranium-fuel-cell",																	"e")
	aadd("rg-atomic-5",							"breeder-fuel-cell",																	"f")
	aadd("rg-atomic-5",							"uranium-processing",																	"g")
	aadd("rg-atomic-5",							"nuclear-fuel-reprocessing",													"h")
	aadd("rg-atomic-5",							"breeder-fuel-reprocessing",													"i")
	aadd("rg-atomic-5",							"kovarex-enrichment-process",													"j")
	aadd("rg-atomic-5",							"used-up-uranium-fuel-cell",													"k")
	aadd("rg-atomic-5",							"used-up-breeder-fuel-cell",													"l")
		
	-- clown nuclear
	aadd("rg-atomic-6",							"thorium-processing",																	"a")
	aadd("rg-atomic-6",							"mixed-oxide",																				"b")
	aadd("rg-atomic-6",							"thorium-nuclear-fuel-reprocessing",									"c")
	aadd("rg-atomic-6",							"thorium-mixed-oxide",																"d")
	aadd("rg-atomic-6",							"thorium-fuel-cell",																	"e")
	
	aadd("rg-atomic-9",							"depleted-uranium-reprocessing",											"a")
	aadd("rg-atomic-9",							"clowns-centrifuging-80%",														"b")
	aadd("rg-atomic-9",							"clowns-centrifuging-75%",														"c")
	aadd("rg-atomic-9",							"clowns-centrifuging-70%",														"d")
	aadd("rg-atomic-9",							"clowns-centrifuging-65%",														"e")
	aadd("rg-atomic-9",							"clowns-centrifuging-55%",														"f")
	aadd("rg-atomic-9",							"clowns-centrifuging-45%",														"g")
	aadd("rg-atomic-9",							"clowns-centrifuging-35%",														"h")
	aadd("rg-atomic-9",							"clowns-centrifuging-20%-ore",												"i")
	aadd("rg-atomic-9",							"clowns-centrifuging-20%-hexafluoride",								"j")
end
do --[[other]]--
	-- test mode
	aadd("rg-other-0",							"mjollnir",																						"a")
	aadd("rg-other-0",							"tm-solar-panel",																			"b")
	aadd("rg-other-0",							"tm-electric-pole",																		"c")
	
	-- magnet
	aadd("rg-other-0",							"magnet",																							"d")
	
	-- spawn belt
	aadd("rg-other-1",							"spawn-belt",																					"a")
	aadd("rg-other-1",							"void-belt",																					"b")
	
	-- belt sorter
	aadd("rg-other-1",							"belt-sorter-everythingelse",													"c")
	
	if allow_changes and regroup.settings.other and data.raw.recipe["spawn-belt"] then
		data.raw.recipe["spawn-belt"].enabled = "false"
		data.raw.recipe["spawn-belt"].hidden = "false"
		data.raw.recipe["void-belt"].enabled = "false"
		data.raw.recipe["void-belt"].hidden = "false"
		rg.t_add_recipe_unlock("logistics-3"     , "spawn-belt")
		rg.t_add_recipe_unlock("logistics-3"     , "void-belt")
	end
	
	-- black market
	for _                                       ,v in pairs(data.raw["item-subgroup"]) do
		if v.group == "black-market-group" then v.group = "rg-other" end
	end
	aadd("rg-other-2",							"ucoin",																							"a")
	
	-- signals
	if data.raw["item-group"]["signals"] then data.raw["item-group"]["signals"].icon = "__Regroup__/graphics/icons/cat/signals.png" end
	
	-- recycle 
	local m = {
		__index = function (data)
			if groups_supported and not groups_supported["rg-alien"] then 
				groups_supported["rg-alien"]   = "__Regroup__/graphics/icons/cat/r/r_alien.png"
				groups_supported["rg-armor"]   = "__Regroup__/graphics/icons/cat/r/r_armor.png"
				groups_supported["rg-atom"]   = "__Regroup__/graphics/icons/cat/r/r_atomic.png"
				groups_supported["rg-automatization"] = "__Regroup__/graphics/icons/cat/r/r_automatization.png"
				groups_supported["rg-chemistry"]  = "__Regroup__/graphics/icons/cat/r/r_chemistry.png"
				groups_supported["rg-decorative"]  = "__Regroup__/graphics/icons/cat/r/r_decorative.png"
				groups_supported["rg-defense"]   = "__Regroup__/graphics/icons/cat/r/r_defense.png"
				groups_supported["rg-energy"]   = "__Regroup__/graphics/icons/cat/r/r_energy.png"
				groups_supported["rg-engines"]   = "__Regroup__/graphics/icons/cat/r/r_engines.png"
				groups_supported["rg-gathering"]  = "__Regroup__/graphics/icons/cat/r/r_gathering.png"
				groups_supported["rg-intermediate"] = "__Regroup__/graphics/icons/cat/r/r_intermediate.png"
				groups_supported["rg-chemistry"]   = "__Regroup__/graphics/icons/cat/r/r_chemistry.png"
				groups_supported["rg-logistic"]  = "__Regroup__/graphics/icons/cat/r/r_logistic.png"
				groups_supported["rg-module"]   = "__Regroup__/graphics/icons/cat/r/r_module.png"
				groups_supported["rg-other"]   = "__Regroup__/graphics/icons/cat/r/r_other.png"
				groups_supported["rg-parts"]   = "__Regroup__/graphics/icons/cat/r/r_parts.png"
				groups_supported["rg-plates"]   = "__Regroup__/graphics/icons/cat/r/r_plates.png"
				groups_supported["rg-production"]  = "__Regroup__/graphics/icons/cat/r/r_production.png"
				groups_supported["rg-refining"]  = "__Regroup__/graphics/icons/cat/r/r_refining.png"
				groups_supported["rg-resources"]  = "__Regroup__/graphics/icons/cat/r/r_resources.png"
				groups_supported["rg-trains-vehicles"] = "__Regroup__/graphics/icons/cat/r/r_trains-vehicles.png"
				groups_supported["rg-transport"]  = "__Regroup__/graphics/icons/cat/r/r_transport.png"
				groups_supported["rg-weaponry"]  = "__Regroup__/graphics/icons/cat/r/r_weaponry.png"
				groups_supported["rg-yuoki"]   = "__Regroup__/graphics/icons/cat/r/r_yuoki.png"
			end
			return data
		end
	}
	if not dry411smods then dry411smods = {} end
	setmetatable(dry411smods                    , m)
end
do  --[[barreling]]--
	-- automatic barrelling
	aadd("rg-barreling-0",					"auto-barrelling-machine-1",													"e")
	aadd("rg-barreling-0",					"auto-barrelling-machine-2",													"f")
end
do  --[[misc]]--
	--mini machines
	if i_exist("green-transport-belt") and (i_exist("5d-assembling-machine-4") or i_exist("rapid-transport-belt-mk1")) then 
		switch_tech("mechanical-engineer")
		switch_tech("mechanical-engineer-2")
	end
	if regroup.settings.other_mini and i_exist("mini-assembler-1") then
		ahide("beacon",									"mini-beacon-1")
		ahide("radar",									"mini-radar-1")
		ahide("electric-furnace",				"mini-furnace-1")
		ahide("oil-refinery",						"mini-refinery-1")
		ahide("chemical-plant",					"mini-chem-plant-1")
		ahide("assembling-machine-1",		"mini-assembler-1")
		ahide("assembling-machine-2",		"mini-assembler-2")
		ahide("assembling-machine-3",		"mini-assembler-3")
		--ahide("pumpjack",								"mini-pumpjack-1")
		if i_exist("storage-tank-mk2") then
			ahide("electric-furnace-mk2",		"mini-furnace-2")
			ahide("electric-furnace-mk3",		"mini-furnace-3")
			ahide("assembling-machine-4",		"mini-assembler-4")
			ahide("assembling-machine-5",		"mini-assembler-5")
			ahide("storage-tank-mk2", "mini-tank-2")
			ahide("mini-tank-3")
			ahide("mini-tank-4")
			ahide("oil-refinery-mk2",				"mini-refinery-2")
			ahide("oil-refinery-mk3",				"mini-refinery-3")
			ahide("mini-refinery-4")
			ahide("chemical-plant-mk2",			"mini-chem-plant-2")
			ahide("chemical-plant-mk3",			"mini-chem-plant-3")
			ahide("mini-chem-plant-4")
			ahide("radar-mk2",							"mini-radar-2")
			--ahide("pumpjack-mk2",						"mini-pumpjack-2")
			--ahide("mini-pumpjack-3")
			--ahide("mini-pumpjack-4")
		end
		if i_exist("5d-storage-tank") then
			ahide("5d-electric-furnace",		"mini-furnace-2")
			ahide("5d-assembling-machine-4","mini-assembler-4")
			ahide("5d-assembling-machine-5","mini-assembler-5")
			ahide("mini-assembler-6")
			ahide("5d-storage-tank", "mini-tank-2")
			ahide("mini-tank-3")
			ahide("mini-tank-4")
			ahide("5d-oil-refinery-2",			"mini-refinery-2")
			ahide("5d-oil-refinery-3",			"mini-refinery-3")
			ahide("mini-refinery-4")
			ahide("5d-chemical-plant-2",		"mini-chem-plant-2")
			ahide("5d-chemical-plant-3",		"mini-chem-plant-3")
			ahide("mini-chem-plant-4")
			ahide("5d-pumpjack-2",					"mini-pumpjack-2")
			ahide("5d-pumpjack-3",					"mini-pumpjack-3")
			ahide("mini-pumpjack-4")
		end
		if i_exist("storage-tank-2") then
			ahide("electric-furnace-2")
			ahide("electric-furnace-3")
			ahide("assembling-machine-4",		"mini-assembler-4")
			ahide("assembling-machine-5",		"mini-assembler-5")
			ahide("assembling-machine-6")
			ahide("electrolyser",						"mini-electrolyser-1")
			ahide("electrolyser-1",					"mini-electrolyser-2")
			ahide("electrolyser-2",					"mini-electrolyser-3")
			ahide("electrolyser-3",					"mini-electrolyser-4")
			ahide("electrolyser-4")
			ahide("beacon-2",								"mini-beacon-2")
			ahide("beacon-3",								"mini-beacon-3")
			ahide("beacon-4",								"mini-beacon-4")
			ahide("radar-2",								"mini-radar-2")
			ahide("radar-3",								"mini-radar-3")
			ahide("radar-4",								"mini-radar-4")
			ahide("radar-5",								"mini-radar-5")
			ahide("oil-refinery-2",					"mini-refinery-2")
			ahide("oil-refinery-3",					"mini-refinery-3")
			ahide("oil-refinery-4",					"mini-refinery-4")
			ahide("chemical-plant-2",				"mini-chem-plant-2")
			ahide("chemical-plant-3",				"mini-chem-plant-3")
			ahide("chemical-plant-4",				"mini-chem-plant-4")
			ahide("storage-tank",						"mini-tank-1")
			ahide("storage-tank-2",					"mini-tank-2")
			ahide("storage-tank-3",					"mini-tank-3")
			ahide("storage-tank-4",					"mini-tank-4")
			--ahide("bob-pumpjack-1",					"mini-pumpjack-2")
			--ahide("bob-pumpjack-2",					"mini-pumpjack-3")
			--ahide("bob-pumpjack-3",					"mini-pumpjack-4")
			--ahide("bob-pumpjack-4")
		end
	end
end