local allow_changes = regroup.settings.factorio_extended

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

if mods["FactorioExtended-Core"] then
do	--[[gathering]]--
	aadd("rg-gathering-0",					"titanium-axe",																				"f")
	
	aadd("rg-gathering-1",					"repair-pack-mk2",																		"c")
	aadd("rg-gathering-1",					"repair-pack-mk3",																		"e")
	
	aadd("rg-gathering-2",					"titanium-chest",																			"a[0096]")
	
	aadd("rg-gathering-4",					"storage-tank-mk2",																		"a[100]c")
	
	aadd("rg-gathering-6",					"basic-mining-drill-mk2",															"a2c")
	
	aadd("rg-gathering-23",					"pump-mk2",																						"a2c")
	
	aadd("rg-gathering-24",					"pumpjack-mk2",																				"a2c")
	
  if i_exist("5d-mining-drill-speed-1") and i_exist("bob-mining-drill-1") and allow_changes then
		ahide("storage-tank-mk2")
		ahide("basic-mining-drill-mk2")
		ahide("pump-mk2")
		ahide("pumpjack-mk2")
	end
	
	
end
do	--[[production]]--
	aadd("rg-production-2",				"electric-furnace-mk2",																"e")
	aadd("rg-production-2",				"electric-furnace-mk3",																"h")
	
	aadd("rg-production-4",				"assembling-machine-4",																"a4c")
	aadd("rg-production-4",				"assembling-machine-5",																"a5c")
	
	aadd("rg-production-6",				"oil-refinery-mk2",																		"a2c")
	aadd("rg-production-6",				"oil-refinery-mk3",																		"a3c")
	
	aadd("rg-production-7",				"chemical-plant-mk2",																	"a2c")
	aadd("rg-production-7",				"chemical-plant-mk3",																	"a3c")

	if i_exist("electric-furnace-2") and i_exist("5d-electric-furnace") and allow_changes then
		ahide("electric-furnace-mk2")
		ahide("electric-furnace-mk3")
	end
end
do	--[[resources]]--
	aadd("rg-resources-9",					"titanium-ore",																				"j")
end
do	--[[plates]]--
	aadd("rg-plates-13",						"titanium-alloy",																			"i")
end
do	--[[liquids]]--
end
do	--[[chemistry]]--
end
do	--[[automatization]]--
	aadd("rg-automatization-2",		"blistering-inserter",																"i")
	aadd("rg-automatization-2",		"furious-inserter",																		"j")
	
	aadd("rg-automatization-3",		"furious-long-handed-inserter",												"i")
	aadd("rg-automatization-3",		"filter-long-handed-inserter",												"j")
end
do	--[[transport]]--
	aadd("rg-transport-0",					"blistering-transport-belt",													"db")
	aadd("rg-transport-0",					"furious-transport-belt",															"i")

	aadd("rg-transport-6",					"blistering-transport-belt-to-ground",								"e")
	aadd("rg-transport-6",					"furious-transport-belt-to-ground",										"f")

	aadd("rg-transport-9",					"blistering-splitter",																"h1c")
	aadd("rg-transport-9",					"furious-splitter",																		"i1c")
	
	aadd("rg-transport-13",				"pipe-mk2",																						"z")
	aadd("rg-transport-14",				"pipe-to-ground-mk2",																	"z")
		
	if allow_changes and (i_exist("bronze-pipe") or i_exist("5d-pipe-mk2")) then
		ahide("pipe-mk2")
		ahide("pipe-to-ground-mk2")
	end
end
do	--[[logistic]]--
	aadd("rg-logistic-2",					"roboport-mk2",																				"d")
	aadd("rg-logistic-2",					"roboport-mk3",																				"g")
	
	aadd("rg-logistic-5",					"logistic-robot-mk2",																	"d")
	aadd("rg-logistic-6",					"construction-robot-mk2",															"e")
	
	aadd("rg-logistic-7",					"titanium-logistic-chest-storage",										"a3")
	aadd("rg-logistic-7",					"titanium-logistic-chest-requester",									"b3")
	aadd("rg-logistic-7",					"titanium-logistic-chest-passive-provider",						"c3")
	
	aadd("rg-logistic-8",					"logistic-chest-active-provider",											"a1")
	aadd("rg-logistic-8",					"titanium-logistic-chest-active-provider",						"a3")
	aadd("rg-logistic-8",					"titanium-logistic-chest-buffer",											"b3")
end
do	--[[energy]]--
	aadd("rg-energy-1",						"boiler-mk2",																					"a[000][36000]")
	aadd("rg-energy-1",						"boiler-mk3",																					"a[000][36000]")
	
	aadd("rg-energy-2",						"steam-engine",																				"a")
	aadd("rg-energy-2",						"steam-engine-mk2",																		"bc")
	aadd("rg-energy-2",						"steam-engine-mk3",																		"cc")

	aadd("rg-energy-3",						"heat-exchanger-mk2",																	"b2c")
	aadd("rg-energy-3",						"heat-exchanger-mk3",																	"b3c")
	
	aadd("rg-energy-4",						"steam-turbine-mk2",																	"a2c")
	aadd("rg-energy-4",						"steam-turbine-mk3",																	"a3c")
	
	aadd("rg-energy-6",						"accumulator",																				"a")
	aadd("rg-energy-6",						"accumulator-mk2",																		"bc")
	aadd("rg-energy-6",						"accumulator-mk3",																		"cc")

	aadd("rg-energy-7",						"solar-panel",																				"a")
	aadd("rg-energy-7",						"solar-panel-mk2",																		"bc")
	aadd("rg-energy-7",						"solar-panel-mk3",																		"cc")
	
	aadd("rg-energy-12",						"small-electric-pole",																"a[007][005x005]")
	
	aadd("rg-energy-13",						"medium-electric-pole",																"a[009][007x007]")
	aadd("rg-energy-13",						"medium-electric-pole-mk2",														"a[011][009x009]c")
	aadd("rg-energy-13",						"medium-electric-pole-mk3",														"a[013][011x011]c")
	
	aadd("rg-energy-14",						"big-electric-pole",																	"a[030][004x004]")
	aadd("rg-energy-14",						"big-electric-pole-mk2",															"a[040][004x004]c")
	aadd("rg-energy-14",						"big-electric-pole-mk3",															"a[060][004x004]c")
	
	aadd("rg-energy-15",						"substation",																					"a[018][018x018]")
	aadd("rg-energy-15",						"substation-mk2",																			"a[028][028x028]c")
	aadd("rg-energy-15",						"substation-mk3",																			"a[042][042x042]c")
end
do	--[[defense]]--
	aadd("rg-defense-0",						"iron-wall",																					"g")
	aadd("rg-defense-0",						"steel-wall",																					"h")
	aadd("rg-defense-0",						"titanium-wall",																			"i")
	
	aadd("rg-defense-1",						"iron-gate",																					"d")
	aadd("rg-defense-1",						"steel-gate",																					"e")
	aadd("rg-defense-1",						"titanium-gate",																			"f")
	
	aadd("rg-defense-4",						"gun-turret",																					"b")
	aadd("rg-defense-4",						"gun-turret-mk2",																			"h")
	
	aadd("rg-defense-5",						"laser-turret",																				"b")
	aadd("rg-defense-5",						"laser-turret-mk2",																		"h")

	aadd("rg-defense-8",						"radar",																							"a")
	aadd("rg-defense-8",						"radar-mk2",																					"bc")
end
do	--[[armor]]--
	aadd("rg-armor-5",							"power-armor-mk3",																		"a3c")
	aadd("rg-armor-5",							"power-armor-mk4",																		"a4c")
	
	aadd("rg-armor-7",							"personal-roboport-equipment",												"c")
	aadd("rg-armor-7",							"personal-roboport-mk2-equipment",										"c2")
	aadd("rg-armor-7",							"personal-roboport-mk3-equipment",										"c3c")
	
	aadd("rg-armor-8",							"solar-panel-equipment",															"a1")
	aadd("rg-armor-8",							"solar-panel-mk2-equipment",													"a2c")
	aadd("rg-armor-8",							"fusion-reactor-equipment",														"b1")
	aadd("rg-armor-8",							"fusion-reactor-mk2-equipment",												"b2c")
	
	aadd("rg-armor-9",							"battery-equipment",																	"a1")
	aadd("rg-armor-9",							"battery-mk2-equipment",															"a2")
	aadd("rg-armor-9",							"battery-mk3-equipment",															"a3c")
	
	aadd("rg-armor-11",						"energy-shield-equipment",														"a1")
	aadd("rg-armor-11",						"energy-shield-mk2-equipment",												"a2")
	aadd("rg-armor-11",						"energy-shield-mk3-equipment",												"a3c")
end
do	--[[intermediate]]--
	aadd("rg-intermediate-7",			"pollution-filter",																		"m")
end
do	--[[module]]--
end
do	--[[atomic]]--
	aadd("rg-atomic-0",							"centrifuge-mk2",																			"f2c")
	aadd("rg-atomic-0",							"centrifuge-mk3",																			"f3c")
end
do	--[[weaponry]]--
	aadd("rg-weaponry-4",					"shattering-bullet-magazine",													"l")
	
	aadd("rg-weaponry-6",					"shattering-shotgun-shell",														"d")
end
do	--[[trains-vehicles]]--
	aadd("rg-trains-2",						"locomotive",																					"a1")
	aadd("rg-trains-2",						"locomotive-mk2",																			"a2c")
	aadd("rg-trains-2",						"locomotive-mk3",																			"a3c")
	
	aadd("rg-trains-4",						"cargo-wagon",																				"a1")
	aadd("rg-trains-4",						"cargo-wagon-mk2",																		"a2c")
	aadd("rg-trains-4",						"cargo-wagon-mk3",																		"a3c")
	
	aadd("rg-trains-5",						"fluid-wagon",																				"a")
	aadd("rg-trains-5",						"fluid-wagon-mk2",																		"a2c")
	aadd("rg-trains-5",						"fluid-wagon-mk3",																		"a3c")
end
do	--[[alien]]--
end
do  --[[atomic]]--
end
end