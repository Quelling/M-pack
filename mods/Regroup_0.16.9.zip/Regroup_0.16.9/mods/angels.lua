local allow_changes = regroup.settings.angels

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end
if mods["angelsrefining"] and regroup.settings.angel_move then
	do	--[[gathering]]--
		-- angel's petrochem
		aadd("rg-gathering-20",				"angels-natural-gas",																	"h")
		
		aadd("rg-gathering-4",				"angels-storage-tank-3",															"a[020]")
		aadd("rg-gathering-4",				"angels-storage-tank-2",															"a[080]")
		aadd("rg-gathering-4",				"angels-storage-tank-1",															"a[125]")
		aadd("rg-gathering-4",				"angels-pressure-tank-1",															"a[350]")
		
		-- angel's logistics
		aadd("rg-gathering-2",				"angels-big-chest",																		"a[0060]-angel")
		
		-- angel's warehousing
		aadd("rg-gathering-2",				"angels-warehouse",																		"a[0768]-angel")
		
		aadd("rg-gathering-3",				"silo",																							"a")
		aadd("rg-gathering-3",				"silo-ore1",																					"b1")
		aadd("rg-gathering-3",				"silo-ore2",																					"b2")
		aadd("rg-gathering-3",				"silo-ore3",																					"b3")
		aadd("rg-gathering-3",				"silo-ore4",																					"b4")
		aadd("rg-gathering-3",				"silo-ore5",																					"b5")
		aadd("rg-gathering-3",				"silo-ore6",																					"b6")
		aadd("rg-gathering-3",				"silo-coal",																					"c")
		
		-- angel's water treatment
		aadd("rg-gathering-20",				"seafloor-pump",																			"i")
		
		aadd("rg-gathering-20",				"heavy-pump",																					"j")
	end
	do	--[[plates]]--
		aadd("rg-plates-1",						"angels-iron-pebbles-smelting",												"e")
		aadd("rg-plates-1",						"angels-iron-nugget-smelting",												"f")
		
		if i_exist("y-refined-iron") then
			aadd("rg-plates-2",						"angels-copper-pebbles-smelting",											"e")
			aadd("rg-plates-2",						"angels-copper-nugget-smelting",											"f")
			else
			aadd("rg-plates-1",						"angels-copper-pebbles-smelting",											"j")
			aadd("rg-plates-1",						"angels-copper-nugget-smelting",											"k")
		end
	end
	do	--[[production]]--
		-- angel's petrochem
		aadd("rg-production-6",				"oil-refinery-2",																			"b2")
		aadd("rg-production-6",				"oil-refinery-3",																			"b3")
		aadd("rg-production-6",				"oil-refinery-4",																			"b4")
		
		aadd("rg-production-7",				"angels-chemical-plant",															"b1")
		aadd("rg-production-7",				"angels-chemical-plant-2",														"b2")
		aadd("rg-production-7",				"angels-chemical-plant-3",														"b3")
		aadd("rg-production-7",				"angels-chemical-plant-4",														"b4")
		aadd("rg-production-7",				"advanced-chemical-plant",														"b5")
		aadd("rg-production-7",				"advanced-chemical-plant-2",													"b6")
		
		aadd("rg-production-9",				"angels-electrolyser",																"b1")
		aadd("rg-production-9",				"angels-electrolyser-2",															"b2")
		aadd("rg-production-9",				"angels-electrolyser-3",															"b3")
		aadd("rg-production-9",				"angels-electrolyser-4",															"b4")
		
		aadd("rg-production-14",			"angels-flare-stack",																	"m")
		
		aadd("rg-production-18",			"angels-air-filter",																	"d")
		aadd("rg-production-18",			"angels-air-filter-2",																"d2")
		
		aadd("rg-production-19",			"steam-cracker",																			"a1")
		aadd("rg-production-19",			"steam-cracker-2",																		"a2")
		aadd("rg-production-19",			"steam-cracker-3",																		"a3")
		aadd("rg-production-19",			"steam-cracker-4",																		"a4")
		
		aadd("rg-production-19",			"separator",																					"b1")
		aadd("rg-production-19",			"separator-2",																				"b2")
		aadd("rg-production-19",			"separator-3",																				"b3")
		aadd("rg-production-19",			"separator-4",																				"b4")
		
		aadd("rg-production-20",			"gas-refinery-small",																	"a1")
		aadd("rg-production-20",			"gas-refinery-small-2",																"a2")
		aadd("rg-production-20",			"gas-refinery-small-3",																"a3")
		aadd("rg-production-20",			"gas-refinery-small-4",																"a4")
		
		aadd("rg-production-20",			"gas-refinery",																				"b1")
		aadd("rg-production-20",			"gas-refinery-2",																			"b2")
		aadd("rg-production-20",			"gas-refinery-3",																			"b3")
		aadd("rg-production-20",			"gas-refinery-4",																			"b4")
		
		-- angel's water treatment
		aadd("rg-production-16",			"hydro-plant",																				"d")
		aadd("rg-production-16",			"hydro-plant-2",																			"e")
		aadd("rg-production-16",			"clarifier",																					"f")
		aadd("rg-production-16",			"salination-plant",																		"g")
		aadd("rg-production-16",			"salination-plant-2",																	"h")
		aadd("rg-production-16",			"washing-plant",																			"i")
		aadd("rg-production-16",			"washing-plant-2",																		"j")
		aadd("rg-production-16",			"cooling-tower",																			"k")
		
		-- angel's refining
		aadd("rg-production-1",				"burner-ore-crusher",																	"c")
		aadd("rg-production-1",				"ore-crusher",																				"d1")
		aadd("rg-production-1",				"ore-crusher-2",																			"d2")
		aadd("rg-production-1",				"ore-crusher-3",																			"d3")
		aadd("rg-production-1",				"ore-sorting-facility",																"e1")
		aadd("rg-production-1",				"ore-sorting-facility-2",															"e2")
		aadd("rg-production-1",				"ore-sorting-facility-3",															"e3")
		aadd("rg-production-1",				"ore-sorting-facility-4",															"e4")

		aadd("rg-production-21",			"ore-floatation-cell",																"a1")
		aadd("rg-production-21",			"ore-floatation-cell-2",															"a2")
		aadd("rg-production-21",			"ore-floatation-cell-3",															"a3")
		aadd("rg-production-21",			"ore-leaching-plant",																	"b1")
		aadd("rg-production-21",			"ore-leaching-plant-2",																"b2")
		aadd("rg-production-21",			"ore-leaching-plant-3",																"b3")
		aadd("rg-production-21",			"ore-refinery",																				"c1")
		aadd("rg-production-21",			"ore-refinery-2",																			"c2")
		aadd("rg-production-21",			"ore-refinery-3",																			"c3")

		aadd("rg-production-22",			"liquifier",																					"a1")
		aadd("rg-production-22",			"liquifier-2",																				"a2")
		aadd("rg-production-22",			"liquifier-3",																				"a3")
		aadd("rg-production-22",			"liquifier-4",																				"a4")
		aadd("rg-production-22",			"electro-whinning-cell",															"b1")
		aadd("rg-production-22",			"electro-whinning-cell-2",														"b2")
		aadd("rg-production-22",			"electro-whinning-cell-3",														"b3")

		aadd("rg-production-23",			"thermal-extractor",																	"a")
		aadd("rg-production-23",			"filtration-unit",																		"b1")
		aadd("rg-production-23",			"filtration-unit-2",																	"b2")
		aadd("rg-production-23",			"crystallizer",																				"c1")
		aadd("rg-production-23",			"crystallizer-2",																			"c2")
		aadd("rg-production-23",			"ore-powderizer",																			"d1")
		aadd("rg-production-23",			"ore-powderizer-2",																		"d2")
		aadd("rg-production-23",			"ore-powderizer-3",																		"d3")
		
		-- angel's smelting
		aadd("rg-production-24",			"blast-furnace",																			"a1")
		aadd("rg-production-24",			"blast-furnace-2",																		"a2")
		aadd("rg-production-24",			"blast-furnace-3",																		"a3")
		aadd("rg-production-24",			"blast-furnace-4",																		"a4")
		aadd("rg-production-24",			"angels-chemical-furnace",														"b1")
		aadd("rg-production-24",			"angels-chemical-furnace-2",													"b2")
		aadd("rg-production-24",			"angels-chemical-furnace-3",													"b3")
		aadd("rg-production-24",			"angels-chemical-furnace-4",													"b4")

		aadd("rg-production-25",			"powder-mixer",																				"a1")
		aadd("rg-production-25",			"powder-mixer-2",																			"a2")
		aadd("rg-production-25",			"powder-mixer-3",																			"a3")
		aadd("rg-production-25",			"powder-mixer-4",																			"a4")
		aadd("rg-production-25",			"induction-furnace",																	"b1")
		aadd("rg-production-25",			"induction-furnace-2",																"b2")
		aadd("rg-production-25",			"induction-furnace-3",																"b3")
		aadd("rg-production-25",			"induction-furnace-4",																"b4")

		aadd("rg-production-26",			"casting-machine",																		"a1")
		aadd("rg-production-26",			"casting-machine-2",																	"a2")
		aadd("rg-production-26",			"casting-machine-3",																	"a3")
		aadd("rg-production-26",			"casting-machine-4",																	"a4")
		aadd("rg-production-26",			"ore-processing-machine",															"b1")
		aadd("rg-production-26",			"ore-processing-machine-2",														"b2")
		aadd("rg-production-26",			"ore-processing-machine-3",														"b3")
		aadd("rg-production-26",			"ore-processing-machine-4",														"b4")

		aadd("rg-production-27",			"pellet-press",																				"a1")
		aadd("rg-production-27",			"pellet-press-2",																			"a2")
		aadd("rg-production-27",			"pellet-press-3",																			"a3")
		aadd("rg-production-27",			"pellet-press-4",																			"a4")
		aadd("rg-production-27",			"sintering-oven",																			"a1")
		aadd("rg-production-27",			"sintering-oven-2",																		"a2")
		aadd("rg-production-27",			"sintering-oven-3",																		"a3")
		aadd("rg-production-27",			"sintering-oven-4",																		"a4")

		aadd("rg-production-28",			"strand-casting-machine",															"a1")
		aadd("rg-production-28",			"strand-casting-machine-2",														"a2")
		aadd("rg-production-28",			"strand-casting-machine-3",														"a3")
		aadd("rg-production-28",			"strand-casting-machine-4",														"a4")
		
		-- angel's bio-processing
		aadd("rg-production-29",			"algae-farm",																					"a1")
		aadd("rg-production-29",			"algae-farm-2",																				"a2")
		aadd("rg-production-29",			"crop-farm",																					"b1")
		aadd("rg-production-29",			"temperate-farm",																			"b2")
		aadd("rg-production-29",			"desert-farm",																				"b3")
		aadd("rg-production-29",			"swamp-farm",																					"b4")
		aadd("rg-production-29",			"bio-aboretum-temperate",															"c1")
		aadd("rg-production-29",			"bio-aboretum-swamp",																	"c2")

		aadd("rg-production-30",			"composter",																					"a")
		aadd("rg-production-30",			"seed-extractor",																			"b")
		aadd("rg-production-30",			"bio-press",																					"c")
		aadd("rg-production-30",			"bio-processor",																			"d")
		aadd("rg-production-30",			"nutrient-extractor",																	"e")
	end
	do	--[[resources]]--
		-- angel's petrochem
		aadd("rg-resources-1",					"pellet-coke",																				"j")
		aadd("rg-resources-1",					"stone-crushed", 													 						"k")
		
		-- angel's water treatment
		aadd("rg-resources-1",					"solid-salt",																				"l")
		aadd("rg-resources-1",					"solid-salt-from-saline",																	"m")
		aadd("rg-resources-1",					"solid-nodule",																				"o")
		aadd("rg-resources-1",					"solid-limestone",																			"p")
		aadd("rg-resources-1",					"solid-clay",																				"q")
		aadd("rg-resources-1",					"solid-sand",																				"r")
		
		aadd("rg-resources-3",					"nodule-crystallization-1",														"k")
		aadd("rg-resources-3",					"nodule-crystallization-2",														"l")
		
		aadd("rg-resources-7",					"nodule-crushed",																			"h")
		aadd("rg-resources-7",					"nodule-slurry-washing",															"i")
		aadd("rg-resources-7",					"nodule-concentrated-slurry-washing",									"j")
		aadd("rg-resources-7",					"nodule-pebbles-washing",															"k")
		aadd("rg-resources-7",					"nodule-crushed-washing",															"k")
		
		aadd("rg-resources-8",					"angels-glass",																				"j1b")
	end
	do	--[[liquids]]--
	end
	do	--[[chemistry]]--
		-- angel's petrochem
		aadd("rg-chemistry-0",				"gas-compressed-air",																"w")
		aadd("rg-chemistry-0",				"converter-other-gas-compressed-air",												"w")
		
		-- angel's water treatment
		aadd("rg-chemistry-3",				"water-separation",																	"m")
		aadd("rg-chemistry-3",				"water-synthesis",																	"n")
		
		aadd("rg-chemistry-11",				"dirt-water-separation",															"a")
		aadd("rg-chemistry-11",				"water-mineralized",																"b")
		aadd("rg-chemistry-11",				"yellow-waste-water-purification-yi",												"c")
		aadd("rg-chemistry-11",				"water-thermal-lithia",																"d")
		aadd("rg-chemistry-11",				"yellow-waste-water-purification",													"e")
		aadd("rg-chemistry-11",				"red-waste-water-purification",														"f")
		aadd("rg-chemistry-11",				"green-waste-water-purification",													"g")
		aadd("rg-chemistry-11",				"greenyellow-waste-water-purification",												"h")
		aadd("rg-chemistry-11",				"water-saline",																				"i")
		aadd("rg-chemistry-11",				"coolant-cool-steam",																	"j")
		
		aadd("rg-chemistry-13",				"washing-1",																					"a")
		aadd("rg-chemistry-13",				"washing-2",																					"b")
		aadd("rg-chemistry-13",				"washing-3",																					"c")
		aadd("rg-chemistry-13",				"washing-4",																					"d")
		aadd("rg-chemistry-13",				"washing-5",																					"e")
		aadd("rg-chemistry-13",				"water-viscous-mud",																	"f")
		aadd("rg-chemistry-13",				"nodule-crushed-liquifying",													"g")
		aadd("rg-chemistry-13",				"solid-geodes",																				"h")
		
		aadd("rg-chemistry-14",				"coolant",																						"a")
		aadd("rg-chemistry-14",				"coolant-clean",																			"b")
		aadd("rg-chemistry-14",				"coolant-used-filtration-1",													"c")
		aadd("rg-chemistry-14",				"coolant-used-filtration-2",													"d")
		aadd("rg-chemistry-14",				"coolant-cool-300",																		"e")
		aadd("rg-chemistry-14",				"coolant-cool-200",																		"f")
		aadd("rg-chemistry-14",				"coolant-cool-100",																		"g")
	end
	do	--[[automatization]]--
	end
	do	--[[transport]]--
		-- angel's petrochem
		aadd("rg-transport-11",					"valve-check",																				"a2")
		aadd("rg-transport-11",					"valve-return",																				"b")
		aadd("rg-transport-11",					"valve-overflow",																			"c2")
		aadd("rg-transport-11",					"valve-underflow",																		"d2")
		aadd("rg-transport-11",					"valve-converter",																		"e")
		aadd("rg-transport-11",					"angels-fluid-splitter-2-way",												"f")
		aadd("rg-transport-11",					"angels-fluid-splitter-3-way",												"g")
	end
	do	--[[logistic]]--
		-- angel's logistic
		aadd("rg-logistic-2",					"construction-roboport",												"g")
		aadd("rg-logistic-2",					"cargo-roboport",														"h")
		aadd("rg-logistic-2",					"cargo-hub",															"i")
		aadd("rg-logistic-2",					"cargo-box",															"j")
		
		aadd("rg-logistic-3",					"angels-zone-expander",													"k")
		aadd("rg-logistic-3",					"angels-zone-expander-2",												"l")
		aadd("rg-logistic-3",					"angels-construction-zone-expander",									"m")
		aadd("rg-logistic-3",					"angels-construction-zone-expander-2",									"n")
		aadd("rg-logistic-3",					"angels-relay-station",													"o")
		aadd("rg-logistic-3",					"angels-relay-station-2",												"p")
		aadd("rg-logistic-3",					"angels-charging-station",												"q")
		
		aadd("rg-logistic-5",					"cargo-robot",															"i")
		aadd("rg-logistic-5",					"cargo-robot-2",														"i")
		
		aadd("rg-logistic-6",					"angels-construction-robot",											"j")
		
		-- angel's warehouse
		aadd("rg-logistic-7",					"logistic-chest-storage",												"a[048]")
		aadd("rg-logistic-7",					"angels-logistic-chest-storage",										"a[060]-angel")
		aadd("rg-logistic-7",					"logistic-chest-requester",												"b[048]")
		aadd("rg-logistic-7",					"angels-logistic-chest-requester",										"b[060]-angel")
		aadd("rg-logistic-7",					"logistic-chest-passive-provider",										"c[048]")
		aadd("rg-logistic-7",					"angels-logistic-chest-passive-provider",								"c[060]-angel")
		
		aadd("rg-logistic-8",					"logistic-chest-active-provider",										"a[048]")
		aadd("rg-logistic-8",					"angels-logistic-chest-active-provider",								"a[060]-angel")
		aadd("rg-logistic-8",					"logistic-chest-buffer",												"b[048]")
		aadd("rg-logistic-8",					"angels-logistic-chest-buffer",											"b[060]-angel")
		
		aadd("rg-logistic-9",					"silo-storage",																				"a")
		aadd("rg-logistic-9",					"silo-buffer",																				"b")
		aadd("rg-logistic-9",					"silo-requester",																			"c")
		aadd("rg-logistic-9",					"silo-passive-provider",															"d")
		aadd("rg-logistic-9",					"silo-active-provider",																"e")
		aadd("rg-logistic-9",					"angels-warehouse-buffer",														"f")
		aadd("rg-logistic-9",					"angels-warehouse-storage",														"g")
		aadd("rg-logistic-9",					"angels-warehouse-requester",													"h")
		aadd("rg-logistic-9",					"angels-warehouse-passive-provider",									"i")
		aadd("rg-logistic-9",					"angels-warehouse-active-provider",										"j")
		
		--angel's logistics
		if i_exist("angels-big-chest") and i_exist("logistic-chest-storage") and i_exist("5d-storage") and allow_changes then
			ahide("logistic-chest-storage-2")
			ahide("logistic-chest-requester-2")
			ahide("logistic-chest-passive-provider-2")
			ahide("logistic-chest-active-provider-2")
		end
	end
	do	--[[energy]]--
		-- angel's petrochem
		aadd("rg-energy-1",						"angels-electric-boiler",															"a[080][15000]")
	end
	do	--[[defense]]--
	end
	do	--[[armor]]--
		--angel's components
		aadd("rg-armor-22",						"angels-burner-generator-vequip",											"a")
		aadd("rg-armor-22",						"angels-fusion-reactor-vequip",												"b")
		aadd("rg-armor-22",						"angels-repair-roboport-vequip",											"c")
		aadd("rg-armor-22",						"angels-construction-roboport-vequip",								"d")
		aadd("rg-armor-22",						"angels-heavy-energy-shield-vequip",									"e")
		aadd("rg-armor-22",						"angels-rocket-defense-equipment-vequip",							"f")
	end
	do	--[[intermediate]]--
	end
	do	--[[trains-vehicles]]--
		aadd("rg-vehicles-0",					"angels-crawler",																			"ab")
		aadd("rg-vehicles-0",					"angels-heavy-tank",																	"f")
		
		aadd("rg-trains-2",						"crawler-locomotive",																	"zangels-a")
		aadd("rg-trains-2",						"crawler-locomotive-wagon",														"zangels-b")
		aadd("rg-trains-2",						"crawler-wagon",																			"zangels-c")
		aadd("rg-trains-2",						"crawler-bot-wagon",																	"zangels-d")
		
		aadd("rg-trains-4",						"petro-locomotive-1",																	"zangels-a")
		
		aadd("rg-trains-4",						"petro-tank1",																				"zangels-b")
		aadd("rg-trains-4",						"petro-tank2",																				"zangels-c")
	end
	do	--[[module]]--
	end
	do	--[[weaponry]]--
		aadd("rg-weaponry-14",					"heavy-cannon-shell",																"e")
	end
	do	--[[alien]]--
		aadd("rg-alien-2",								"petri-dish",																				"a")
		aadd("rg-alien-2",								"substrate-dish",																		"b")
		aadd("rg-alien-2",								"alien-pre-artifact",																"c")
		aadd("rg-alien-2",								"alien-pre-artifact-base",													"d")
		aadd("rg-alien-2",								"alien-pre-artifact-blue",													"e")
		aadd("rg-alien-2",								"alien-pre-artifact-green",													"f")
		aadd("rg-alien-2",								"alien-pre-artifact-orange",												"g")
		aadd("rg-alien-2",								"alien-pre-artifact-purple",												"h")
		aadd("rg-alien-2",								"alien-pre-artifact-red",														"i")
		aadd("rg-alien-2",								"alien-pre-artifact-yellow",												"j")
		
		aadd("rg-alien-5",								"alien-air-filtering",															"a")
		aadd("rg-alien-5",								"alien-bacteria",																		"b")
		aadd("rg-alien-5",								"alien-goo",																				"c")
		aadd("rg-alien-5",								"alien-egg-red",																		"d")
		aadd("rg-alien-5",								"alien-egg-green",																	"e")
		aadd("rg-alien-5",								"alien-egg-blue",																		"f")
	end
	do  --[[atomic]]--
	end
	do --[[barreling]]--
		aadd("rg-barreling-0",					"barreling-pump",																			"e")
	end
	do --[[decorative]]--
		-- angel's water treatment
		aadd("rg-decorative-0",				"solid-mud-landfill",																	"aa")
	end
	do --[[other]]--
	end
end

if mods["angelsrefining"] then
	-- Replace Refining Groups
	do
		--angel's refining
		if regroup.settings.angel_move then
			rg.add_main_group("resource-refining")
			rg.add_main_group("water-treatment")
			rg.add_main_group("bio-processing")
			rg.add_main_group("petrochem-refining")
			rg.add_main_group("smelting")
			else
			rg.add_main_group("resource-refining")
			rg.add_main_group("water-treatment")
			rg.add_main_group("angels-void")
			rg.add_main_group("bio-processing")
			rg.add_main_group("fluid-control")
			rg.add_main_group("petrochem-refining")
			rg.add_main_group("smelting")
			rg.add_main_group("casting")
			--[[if i_exist("angels-ore1") then
				data.raw["item-group"]["resource-refining"].icon = "__Regroup__/graphics/icons/cat/resource-refining.png"
				data.raw["item-group"]["resource-refining"].icon_size = 64
				data.raw["item-group"]["water-treatment"].icon = "__Regroup__/graphics/icons/cat/water-treatment.png"
				data.raw["item-group"]["water-treatment"].icon_size = 64
				data.raw["item-group"]["angels-void"].icon = "__Regroup__/graphics/icons/cat/angels-void.png"
				data.raw["item-group"]["angels-void"].icon_size = 64
				end
				--angel's bio processing
				if i_exist("algae-green") then
				data.raw["item-group"]["bio-processing"].icon = "__Regroup__/graphics/icons/cat/bio-processing.png"
				data.raw["item-group"]["bio-processing"].icon_size = 64
				end
				--angel's pretrochem
				if i_exist("catalyst-metal-carrier") then
				data.raw["item-group"]["angels-fluid-control"].icon = "__Regroup__/graphics/icons/cat/fluid-control.png"
				data.raw["item-group"]["angels-fluid-control"].icon_size = 64
				data.raw["item-group"]["petrochem-refining"].icon = "__Regroup__/graphics/icons/cat/petrochem-refining.png"
				data.raw["item-group"]["petrochem-refining"].icon_size = 64
				end
				--angel's smelting
				if i_exist("angels-solder") then
				data.raw["item-group"]["angels-smelting"].icon = "__Regroup__/graphics/icons/cat/smelting.png"
				data.raw["item-group"]["angels-smelting"].icon_size = 64
				data.raw["item-group"]["angels-casting"].icon = "__Regroup__/graphics/icons/cat/casting.png"
				data.raw["item-group"]["angels-casting"].icon_size = 64
			end]]
		end
		
		for _,v in pairs(data.raw["item-subgroup"]) do
			if regroup.settings.angel_move then
				if v.group == "resource-refining" then v.group = "rg-resources"
					elseif v.group == "water-treatment" then v.group = "rg-chemistry"
					elseif v.group == "angels-void" then v.group = "rg-chemistry"
					elseif v.group == "bio-processing" then v.group = "rg-alien"
					elseif v.group == "bio-processing-alien" then v.group = "rg-alien"
					elseif v.group == "angels-fluid-control" then v.group = "rg-transport"
					elseif v.group == "petrochem-refining" then v.group = "rg-chemistry"
					elseif v.group == "angels-smelting" then v.group = "rg-smelting"
				elseif v.group == "angels-casting" then v.group = "rg-plates" end
				else
				if v.group == "resource-refining" then v.group = "rg-resource-refining"
					elseif v.group == "water-treatment" then v.group = "rg-water-treatment"
					elseif v.group == "angels-void" then v.group = "rg-angels-void"
					elseif v.group == "bio-processing" then v.group = "rg-bio-processing"
					elseif v.group == "bio-processing-alien" then v.group = "rg-alien"
					elseif v.group == "angels-fluid-control" then v.group = "rg-fluid-control"
					elseif v.group == "petrochem-refining" then v.group = "rg-petrochem-refining"
					elseif v.group == "angels-smelting" then v.group = "rg-smelting"
				elseif v.group == "angels-casting" then v.group = "rg-casting" end
			end
		end
	end
end	