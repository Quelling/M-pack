
--# create list of ungrouped
local ungrouped = rg.ungrouped()
local recipes = data.raw.recipe
local eg = {}
local ag = {}
local yuoki = false

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

do --[[
	for a, name in pairs(data.raw["item"]) do
		if (not (name.subgroup == nil)) then
			if not (string.sub(name.subgroup,1,3) == "rg-") then
				--_log(name.name.." --> "..name.subgroup)
				aadd(name.subgroup, name.name, name.order)
			else
				--rPrint(name, 10000, "\t["..tostring(name.subgroup).."] ")
			end
		end
	end
	for a, name in pairs(data.raw["recipe"]) do
		if (not (name.subgroup == nil)) then
			if not (string.sub(name.subgroup,1,3) == "rg-") then
				aadd(name.subgroup, name.name, name.order)
			end
		end
	end
--]]end

do
	yuoki = i_exist("ye_overheater")
	
	-- barreling
	aadd("rg-barreling-0",					"empty-barrel",																				"b")
	
	-- Hide Bob's mod canisters
	if regroup.settings.hide_canisters then
		ahide("gas-canister")
		switch_tech("gas-canisters")
	end
	
	-- Yuoki
	if yuoki then
		rg.add_main_group("engines")
		rg.add_main_group("agronomies")
		
		for i=0,9 do rg.get_group_name("rg-engines-"..i,"") end
		for i=0,25 do rg.get_group_name("rg-agronomies-"..i,"") end
	end
	-- Yuoki
	for _,item in pairs(data.raw.item) do
		if yuoki then
			if item.subgroup == "yie-engines"		then item.group = "rg-engines";    item.subgroup = "rg-engines-0" --Engines
				elseif item.subgroup == "yie-exp"			then item.group = "rg-engines";    item.subgroup = "rg-engines-1" --temporary experimental stuff
				elseif item.subgroup == "yie-fluids"		then item.group = "rg-engines";    item.subgroup = "rg-engines-2" --all fluids (MF)
				elseif item.subgroup == "yie-parts"			then item.group = "rg-engines";    item.subgroup = "rg-engines-3" --building parts
				elseif item.subgroup == "yie-processed"		then item.group = "rg-engines";    item.subgroup = "rg-engines-4" --products
				elseif item.subgroup == "yie_tubes"		then item.group = "rg-engines";    item.subgroup = "rg-engines-5" --tubes
				elseif item.subgroup == "yie_machinery"		then item.group = "rg-engines";    item.subgroup = "rg-engines-6" --machinery
				elseif item.subgroup == "yie_machinery2"	then item.group = "rg-engines";    item.subgroup = "rg-engines-7" --machinery2
				elseif item.subgroup == "yie_fluid_handle"	then item.group = "rg-engines";    item.subgroup = "rg-engines-8" --fluid handling
				elseif item.subgroup == "yie_agromachinery"	then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-0" --agriculture machinery
				elseif item.subgroup == "yie_agroproducts"	then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-1" --agriculture products
				elseif item.subgroup == "yie_agro_package"	then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-2" --agriculture packages
				elseif item.subgroup == "yie_animals"		then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-3" --ranch stuff
				elseif item.subgroup == "yie_dnaline"		then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-4" --DNA-Line
				elseif item.subgroup == "yie_farming"		then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-5" --farming stuff
				elseif item.subgroup == "yie_fish"			then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-6" --fish-stuff
				elseif item.subgroup == "yie_trades"		then item.group = "rg-agronomies"; item.subgroup = "rg-agronomies-7" --trade stuff
			end
		end
	end
	for _,recipe in pairs(recipes) do
		--Move Liquids to Chemistry
		if regroup.settings.liquid_move then
			if (recipe.group == "rg-liquids") then
				recipe.group = "rg-chemistry"
				aadd("rg-chemistry-"..string.sub(tostring(recipe.subgroup), 13),			recipe.name)
				elseif (string.sub(tostring(recipe.subgroup), 0, 11) == "rg-liquids") then
				recipe.group = "rg-chemistry"
				aadd("rg-chemistry-"..string.sub(tostring(recipe.subgroup), 13),			recipe.name,			"z["..recipe.name.."]")
			end
		end
		
		-- Barreling
		if (recipe.subgroup == "liquid-fill") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-3",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-3",	recipe.name)
			end
			elseif (recipe.subgroup == "liquid-empty") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-5",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-5",	recipe.name)
			end
			elseif (recipe.subgroup == "fill-barrel") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-3",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-3",	recipe.name)
			end
			elseif (recipe.subgroup == "empty-barrel") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-5",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-5",	recipe.name)
			end
			elseif (recipe.subgroup == "bob-barrel") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-3",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-3",	recipe.name)
			end
			elseif (recipe.subgroup == "bob-empty-barrel") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-5",	recipe.name, "a["..recipe.name.."]")
				else
				aadd("rg-barreling-5",	recipe.name)
			end
			elseif (recipe.subgroup == "bob-gas-bottle" or recipe.subgroup == "bob-canister") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-4",	recipe.name, "ay["..recipe.name.."]")
				else
				aadd("rg-barreling-4",	recipe.name)
			end
			elseif (recipe.subgroup == "bob-empty-gas-bottle" or recipe.subgroup == "bob-empty-canister") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-6",	recipe.name, "az["..recipe.name.."]")
				else
				aadd("rg-barreling-6",	recipe.name)
			end
			elseif (recipe.subgroup == "yie_fluid_handle" or group == "yuoki_liquids") and (recipe.main_product == "ye_canister") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-5",	recipe.name, "ax["..recipe.name.."]")
				else
				aadd("rg-barreling-5",	recipe.name)
			end
		end
		
		-- Yuoki
		if yuoki then
			if recipe.subgroup == "yie-engines" then --Engines
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-0"
				recipe.order = 0
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "y_refine_machinery" then --machinery
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-1"
				recipe.order = 1
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_machinery" then --machinery
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-1"
				recipe.order = 1
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_machinery2" then --machinery2
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-2"
				recipe.order = 2
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie-fluids" then --all fluids (MF)
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-3"
				recipe.order = 3
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "y-parts" then --building parts
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-4"
				recipe.order = 4
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie-parts" then --building parts
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-4"
				recipe.order = 4
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_tubes" then --tubes
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-5"
				recipe.order = 5
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie-processed" then --products
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-6"
				recipe.order = 6
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie-exp" then --temporary experimental stuff
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-7"
				recipe.order = 7
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_fluid_handle" then
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-8"
				recipe.order = 8
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "y-fluid" then --fluid handling
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-9"
				recipe.order = 9
				table.insert(eg,recipe.name)
				elseif string.find(recipe.name,"empty")
				and recipe.subgroup == "yie_fluid_handle" then --fluid handling
				recipe.group = "rg-engines"
				recipe.subgroup = "rg-engines-9"
				recipe.order = 9
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "y_refine_raws" then --agriculture products
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-2"
				recipe.order = 2
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "y_ultimate_products" then --agriculture products
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-2"
				recipe.order = 2
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agromachinery" then --agriculture machinery
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-10"
				recipe.order = 10
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agroproducts" then --agriculture products
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-11"
				recipe.order = 11
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agroproducts_crafted" then --agriculture crafted products
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-12"
				recipe.order = 12
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agro_package" then --agriculture packages
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-13"
				recipe.order = 13
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agro_package_l2" then --agriculture packages
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-13"
				recipe.order = 13
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agroproducts_packages" then --agriculture packages
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-13"
				recipe.order = 13
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_agro_package_12" then --agriculture packages
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-14"
				recipe.order = 14
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_trades_line1" then --harvest stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-15"
				recipe.order = 15
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_trades_line2" then --harvest stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-16"
				recipe.order = 16
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_farming" then --harvest stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-17"
				recipe.order = 17
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_animals" then --ranch stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-18"
				recipe.order = 18
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_fish" then --fish-stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-19"
				recipe.order = 19
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_dnaline" then --DNA-Line
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-20"
				recipe.order = 20
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_trades_import_line1" then --import stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-21"
				recipe.order = 21
				table.insert(eg,recipe.name)
				elseif recipe.subgroup == "yie_engines_import_a" then --import stuff
				recipe.group = "rg-agronomies"
				recipe.subgroup = "rg-agronomies-21"
				recipe.order = 21
				table.insert(eg,recipe.name)
			end
		end
		
		-- Hide Yuoki Canisters
		if regroup.settings.hide_canisters and (recipe.subgroup == "yie_fluid_handle") and (recipe.main_product == "ye_canister") then
			ahide(recipe.name)
		end
		
		-- Hide Bob's mod canisters
		if regroup.settings.hide_canisters and (recipe.subgroup == "bob-gas-bottle" or recipe.subgroup == "bob-empty-gas-bottle") then
			ahide(recipe.name)
		end
	end	
end	

do	--[[TECH]]--
	if regroup.settings.yuoki_tech and yuoki and data.raw.technology["yi-basic-mechanical-force"] == nil then
		-- yuoki_engines-3
		-- yuoki_agronomie-3
		
		for _,r in pairs(eg) do
			rg.add_recipe_to_tech("yuoki_engines",r)
		end
		for _,r in pairs(ag) do
			rg.add_recipe_to_tech("yuoki_agronomie",r)
		end
	end
end	
