local allow_changes = regroup.settings.yuoki_eng

local eg = {}
local ag = {}

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end
do --[[barreling]]--
	aadd("rg-barreling-0",					"ye_canister_recipe",																			"d")
end
do	--[[TECH]]--
	if regroup.settings.yuoki_tech and i_exist("ye_overheater") and data.raw.technology["yi-basic-mechanical-force"] == nil then
		
		data:extend({
			{
				type = "technology",
				name = "yuoki_engines",
				icon = "__Regroup__/graphics/icons/tech/yuoki_engines.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[g]"
			},
			{
				type = "technology",
				name = "yuoki_engines-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_engines.png",
				icon_size = 64,
				prerequisites = {"yuoki_engines"},
				effects = {},
				unit = {
					count = 25,
					time = 45,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-2[g]"
			},
			{
				type = "technology",
				name = "yuoki_engines-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_engines.png",
				icon_size = 64,
				prerequisites = {"yuoki_engines-2"},
				effects = {},
				unit = {
					count = 50,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[g]"
			}
		})
		data:extend({
			{
				type = "technology",
				name = "yuoki_agronomie",
				icon = "__Regroup__/graphics/icons/tech/yuoki_agronomie.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[h]"
			},
			{
				type = "technology",
				name = "yuoki_agronomie-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_agronomie.png",
				icon_size = 64,
				prerequisites = {"yuoki_agronomie"},
				effects = {},
				unit = {
					count = 25,
					time = 45,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-2[h]"
			},
			{
				type = "technology",
				name = "yuoki_agronomie-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_agronomie.png",
				icon_size = 64,
				prerequisites = {"yuoki_agronomie-2"},
				effects = {},
				unit = {
					count = 50,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[h]"
			}
		})
		
		do --# engines
			rg.add_recipe_to_tech("yuoki_engines",				"ye_canmachine_recipe")
			rg.add_recipe_to_tech("yuoki_engines",				"ye_canister2plates_smelt")
		end
		do --# agronomies
			rg.add_recipe_to_tech("yuoki_agronomie",				"y_unlimited_wood")
			rg.add_recipe_to_tech("yuoki_agronomie",				"ye_granulate_trifitan_recipe")
			rg.add_recipe_to_tech("yuoki_agronomie",				"ye_granulate_vuger_recipe")
			rg.add_recipe_to_tech("yuoki_agronomie",				"ye_granulate_corn_recipe")
			rg.add_recipe_to_tech("yuoki_agronomie",				"ye_biofuel_recipe")
			rg.add_recipe_to_tech("yuoki_agronomie",				"ye_slurry2ethanol_recipe")
		end
	end
end
