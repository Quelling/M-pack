local allow_changes = regroup.settings.vanilla

for i=0,10 do rg.get_group_name("rg-barreling-"..i,"") end
for i=0,20 do rg.get_group_name("rg-armor-"..i,"") end
for i=0,20 do rg.get_group_name("rg-liquids-"..i,"") end
for i=0,20 do rg.get_group_name("rg-chemistry-"..i,"") end

do	--[[gathering]]--
	aadd("rg-gathering-0",					"iron-axe",																						"a")
	aadd("rg-gathering-0",					"steel-axe",																					"b")
	
	aadd("rg-gathering-1",					"repair-pack",																				"a")
	
	aadd("rg-gathering-2",					"wooden-chest",																				"a[0016]")
	aadd("rg-gathering-2",					"iron-chest",																					"a[0032]")
	aadd("rg-gathering-2",					"steel-chest",																				"a[0048]")
	
	aadd("rg-gathering-4",					"storage-tank",																				"a[025]")
	
	aadd("rg-gathering-5",					"burner-mining-drill",																"a[02x02][02.5][0.3]")
	aadd("rg-gathering-5",					"electric-mining-drill",															"a[05x05][03.0][0.5]")
	
	
	aadd("rg-gathering-20",					"offshore-pump",																		"a")
	aadd("rg-gathering-20",					"pumpjack",																					"b")
	aadd("rg-gathering-20",					"pump",																							"c")
	
end
do	--[[production]]--
	aadd("rg-production-0",				"stone-furnace",																			"a")
	aadd("rg-production-0",				"steel-furnace",																			"c")
	aadd("rg-production-0",				"electric-furnace",																		"d")
	
	aadd("rg-production-4",				"assembling-machine-1",																"a1")
	aadd("rg-production-4",				"assembling-machine-2",																"a2")
	aadd("rg-production-4",				"assembling-machine-3",																"a3")
	
	aadd("rg-production-6",				"oil-refinery",																				"a")
	
	aadd("rg-production-7",				"chemical-plant",																			"a")
end
do	--[[resources]]--
	aadd("rg-resources-0",					"raw-wood",																						"a")
	aadd("rg-resources-0",					"wood",																								"b")
	aadd("rg-resources-0",					"sulfur",																							"h")
	
	aadd("rg-resources-2",					"coal",																								"a")
	aadd("rg-resources-2",					"solid-fuel",																					"b")
	
	aadd("rg-resources-3",					"stone",																							"a")
	aadd("rg-resources-3",					"iron-ore",																						"b")
	aadd("rg-resources-3",					"copper-ore",																					"c")
	
	aadd("rg-resources-4",					"uranium-ore",																				"g")
	
  if regroup.settings.vcoal then
	data:extend({
		{
			type = "recipe",
			name = "rg-coal",
			icon = "__base__/graphics/icons/coal-dark-background.png",
			icon_size = 32,
			category = "smelting",
			subgroup = "rg-resources-1",
			order = "b",
			energy_required = 35,
			enabled = true,
			ingredients = {{"raw-wood",25}},
			hidden = false,
			result = "coal",
			result_count = 10
		},
	})
	aadd("rg-resources-0",					"rg-coal",																							"c2")
  end
end
do	--[[plates]]--
	aadd("rg-plates-0",						"iron-plate",																					"a")
	aadd("rg-plates-0",						"copper-plate",																				"d")
	
	aadd("rg-plates-1",						"steel-plate",																				"a")
	
end
do	--[[liquids]]--
	aadd("rg-liquids-0",						"empty-barrel",																				"a")
	
	aadd("rg-liquids-1",						"fill-crude-oil-barrel",															"a")
	
	aadd("rg-liquids-3",						"empty-crude-oil-barrel",															"a")
	aadd("rg-liquids-3",						"lubricant",																					"b")
	
	aadd("rg-liquids-4",						"crude-oil-barrel",																		"a")
	
	aadd("rg-liquids-5",						"basic-oil-processing",																"b")
	aadd("rg-liquids-5",						"advanced-oil-processing",														"c")
	
end
do	--[[chemistry]]--
	aadd("rg-chemistry-0",					"sulfuric-acid",																			"a")
	
	aadd("rg-chemistry-2",					"heavy-oil-cracking",																	"a")
	aadd("rg-chemistry-2",					"light-oil-cracking",																	"b")
	aadd("rg-chemistry-2",					"coal-liquefaction",																	"c")
	
	aadd("rg-chemistry-3",					"solid-fuel-from-light-oil",													"a")
	aadd("rg-chemistry-3",					"solid-fuel-from-heavy-oil",													"b")
	aadd("rg-chemistry-3",					"solid-fuel-from-petroleum-gas",											"c")
	
	aadd("rg-chemistry-5",					"plastic-bar",																				"a")
	
end
do	--[[automatization]]--
	aadd("rg-automatization-0",		"burner-inserter",																		"a")
	aadd("rg-automatization-0",		"inserter",																						"b")
	aadd("rg-automatization-0",		"long-handed-inserter",																"c")
	
	aadd("rg-automatization-1",		"filter-inserter",																		"a")
	aadd("rg-automatization-1",		"stack-filter-inserter",															"i")
	
	aadd("rg-automatization-2",		"fast-inserter",																			"a")
	aadd("rg-automatization-2",		"stack-inserter",																			"h")
	
end
do	--[[transport]]--
	aadd("rg-transport-0",					"transport-belt",																			"a")
	aadd("rg-transport-0",					"fast-transport-belt",																"b")
	aadd("rg-transport-0",					"express-transport-belt",															"c")
	
	aadd("rg-transport-1",					"loader",																							"a")
	aadd("rg-transport-1",					"fast-loader",																				"b")
	aadd("rg-transport-1",					"express-loader",																			"c")
	
	aadd("rg-transport-6",					"underground-belt",																		"a")
	aadd("rg-transport-6",					"fast-underground-belt",															"b")
	aadd("rg-transport-6",					"express-underground-belt",														"c")
	
	aadd("rg-transport-9",					"splitter",																						"a")
	aadd("rg-transport-9",					"fast-splitter",																			"c")
	aadd("rg-transport-9",					"express-splitter",																		"e")
	
	aadd("rg-transport-12",					"pipe",																								"a")
	
	aadd("rg-transport-12",					"pipe-to-ground",																			"b")
	
	if regroup.settings.graphics_tuning then
		if i_exist("fast-underground-belt") then
			data.raw["underground-belt"]["fast-underground-belt"].underground_sprite.filename = "__Regroup__/graphics/entity/u_line_r.png" end
		if i_exist("express-underground-belt") then
			data.raw["underground-belt"]["express-underground-belt"].underground_sprite.filename = "__Regroup__/graphics/entity/u_line_b.png" end
		if i_exist("pipe-to-ground") then
			data.raw["pipe-to-ground"]["pipe-to-ground"].underground_sprite = {
				filename = "__Regroup__/graphics/entity/u_pipe_1.png",
				priority = "high",
				width = 64,
				height = 64,
				x = 64,
				scale = 0.5
			}
		end
	end
	
end
do	--[[logistic]]--
	aadd("rg-logistic-0",					"blueprint-book",																			"a")
	aadd("rg-logistic-0",					"blueprint",																					"b")
	aadd("rg-logistic-0",					"deconstruction-planner",															"c")
	aadd("rg-logistic-0",					"artillery-targeting-remote",													"d")
	
	aadd("rg-logistic-1",					"roboport",																						"a")
	aadd("rg-logistic-1",					"logistic-robot",																			"b")
	aadd("rg-logistic-1",					"construction-robot",																	"c")
	
	aadd("rg-logistic-7",					"logistic-chest-storage",															"a1")
	aadd("rg-logistic-7",					"logistic-chest-requester",														"b1")
	aadd("rg-logistic-7",					"logistic-chest-passive-provider",										"c1")
	aadd("rg-logistic-7",					"logistic-chest-active-provider",											"d1")
	aadd("rg-logistic-7",					"logistic-chest-buffer",															"e1")
	
	aadd("rg-logistic-13",					"copper-cable",																				"a")
	aadd("rg-logistic-13",					"red-wire",																						"b")
	aadd("rg-logistic-13",					"green-wire",																					"c")
	
	aadd("rg-logistic-16",					"arithmetic-combinator",															"a")
	aadd("rg-logistic-16",					"decider-combinator",																	"b")
	aadd("rg-logistic-16",					"constant-combinator",																"c")
	
	aadd("rg-logistic-19",					"programmable-speaker",																"c")
	aadd("rg-logistic-19",					"power-switch",																				"d")
end
do	--[[energy]]--
	aadd("rg-energy-1",						"boiler",																							"a[050][36000]")
	
	aadd("rg-energy-2",						"steam-engine",																				"a[00900]")
		
	aadd("rg-energy-3",						"heat-exchanger",																			"a[10000]")
	
	aadd("rg-energy-7",						"solar-panel",																				"a")
	
	aadd("rg-energy-11",					"accumulator",																				"a")
	
	aadd("rg-energy-12",					"small-electric-pole",																"a[007][005x005]")
	aadd("rg-energy-12",					"medium-electric-pole",																"b[009][007x007]")
	aadd("rg-energy-12",					"big-electric-pole",																	"c[030][004x004]")
	aadd("rg-energy-12",					"substation",																					"d[018][018x018]")
	
end
do	--[[defense]]--
	aadd("rg-defense-0",						"stone-wall",																					"c")
	
	aadd("rg-defense-1",						"gate",																								"a")
	
	aadd("rg-defense-3",						"gun-turret",																					"a")
	aadd("rg-defense-3",						"flamethrower-turret",																"b")
	aadd("rg-defense-3",						"laser-turret",																				"c")
	
	aadd("rg-defense-8",						"radar",																							"a")
	
end
do	--[[armor]]--
	aadd("rg-armor-3",							"light-armor",																				"a")
	aadd("rg-armor-3",							"heavy-armor",																				"b")
	aadd("rg-armor-3",							"modular-armor",																			"c")
	aadd("rg-armor-3",							"power-armor",																				"d")
	aadd("rg-armor-3",							"power-armor-mk2",																		"e")
	
	aadd("rg-armor-4",							"exoskeleton-equipment",															"a")
	aadd("rg-armor-4",							"night-vision-equipment",															"b")
	aadd("rg-armor-4",							"personal-roboport-equipment",												"c")
	aadd("rg-armor-4",							"personal-roboport-mk2-equipment",										"c2")
	
	aadd("rg-armor-7",							"solar-panel-equipment",															"a")
	aadd("rg-armor-7",							"fusion-reactor-equipment",														"b")
	aadd("rg-armor-7",							"battery-equipment",																	"c")
	aadd("rg-armor-7",							"battery-mk2-equipment",															"d")
	
	aadd("rg-armor-8",							"personal-laser-defense-equipment",										"a")
	aadd("rg-armor-8",							"fusion-reactor-equipment",														"b")
	aadd("rg-armor-8",							"discharge-defense-equipment",												"c")
	
	aadd("rg-armor-9",							"energy-shield-equipment",														"a")
	aadd("rg-armor-9",							"energy-shield-mk2-equipment",												"b")
	
	aadd("rg-armor-10",						"artillery-wagon",																		"a")
end
do	--[[weapons]]--
	aadd("rg-weaponry-0",					"pistol",																							"a")
	aadd("rg-weaponry-0",					"submachine-gun",																			"b")
	aadd("rg-weaponry-0",					"shotgun",																						"c")
	aadd("rg-weaponry-0",					"combat-shotgun",																			"d")
	aadd("rg-weaponry-0",					"flamethrower",																				"e")
	aadd("rg-weaponry-0",					"rocket-launcher",																		"f")
	
	aadd("rg-weaponry-1",					"firearm-magazine",																		"a")
	aadd("rg-weaponry-1",					"piercing-rounds-magazine",														"b")
	aadd("rg-weaponry-1",					"uranium-rounds-magazine",														"c")
	aadd("rg-weaponry-1",					"shotgun-shell",																			"d")
	aadd("rg-weaponry-1",					"piercing-shotgun-shell",															"e")
	aadd("rg-weaponry-1",					"flamethrower-ammo",																	"f")
	aadd("rg-weaponry-1",					"rocket",																							"g")
	aadd("rg-weaponry-1",					"explosive-rocket",																		"h")
	aadd("rg-weaponry-1",					"atomic-bomb",																				"i")
	
	aadd("rg-weaponry-9",					"grenade",																						"a")
	aadd("rg-weaponry-9",					"cluster-grenade",																		"b")
	aadd("rg-weaponry-9",					"land-mine",																					"c")
	
	aadd("rg-weaponry-11",					"slowdown-capsule",																		"a")
	aadd("rg-weaponry-11",					"poison-capsule",																			"b")
	aadd("rg-weaponry-11",					"defender-capsule",																		"c")
	aadd("rg-weaponry-11",					"distractor-capsule",																	"d")
	aadd("rg-weaponry-11",					"destroyer-capsule",																	"e")
	aadd("rg-weaponry-11",					"discharge-defense-remote",														"f")
	
	aadd("rg-weaponry-15",					"cannon-shell",																				"a")
	aadd("rg-weaponry-15",					"explosive-cannon-shell",															"b")
	aadd("rg-weaponry-15",					"uranium-cannon-shell",																"c")
	aadd("rg-weaponry-15",					"explosive-uranium-cannon-shell",											"d")
	aadd("rg-weaponry-15",					"artillery-shell",																		"e")
	
	aadd("rg-weaponry-16",					"artillery-turret",																		"b")
end
do	--[[intermediate]]--	
	aadd("rg-intermediate-1",			"electronic-circuit",																	"b")
	aadd("rg-intermediate-1",			"advanced-circuit",																		"d")
	aadd("rg-intermediate-1",			"processing-unit",																		"f")
	
	aadd("rg-intermediate-4",			"iron-gear-wheel",																		"a")
	
	aadd("rg-intermediate-4",			"fish",																								"a")
	aadd("rg-intermediate-4",			"raw-fish",																						"b")
	aadd("rg-intermediate-4",			"iron-stick",																					"c")
	aadd("rg-intermediate-4",			"explosives",																					"d")
	aadd("rg-intermediate-4",			"cliff-explosives",																		"e")
	aadd("rg-intermediate-4",			"battery",																						"f")
	aadd("rg-intermediate-4",			"engine-unit",																				"g")
	aadd("rg-intermediate-4",			"electric-engine-unit",																"h")
	aadd("rg-intermediate-4",			"flying-robot-frame",																	"i")
	

	aadd("rg-intermediate-8",			"low-density-structure",															"a")
	aadd("rg-intermediate-8",			"satellite",																					"b")
	aadd("rg-intermediate-8",			"rocket-silo",																				"c")
	aadd("rg-intermediate-8",			"rocket-part",																				"d")
	aadd("rg-intermediate-8",			"rocket-control-unit",																"e")
	aadd("rg-intermediate-8",			"rocket-fuel",																				"f")
	aadd("rg-intermediate-8",			"nuclear-fuel",																				"g")
	
end
do	--[[module]]--
	aadd("rg-module-0",						"lab",																								"a")
	aadd("rg-module-0",						"beacon",																							"f")
	
	aadd("rg-module-1",						"science-pack-1",																			"a")
	aadd("rg-module-1",						"science-pack-2",																			"b")
	aadd("rg-module-1",						"science-pack-3",																			"c")
	aadd("rg-module-1",						"military-science-pack",															"d")
	aadd("rg-module-1",						"production-science-pack",														"e")
	aadd("rg-module-1",						"high-tech-science-pack",															"f")
	
	aadd("rg-module-4",						"speed-module",																				"a")
	aadd("rg-module-4",						"speed-module-2",																			"b")
	aadd("rg-module-4",						"speed-module-3",																			"c")
	
	aadd("rg-module-5",						"productivity-module",																"a")
	aadd("rg-module-5",						"productivity-module-2",															"b")
	aadd("rg-module-5",						"productivity-module-3",															"c")
	
	aadd("rg-module-6",						"effectivity-module",																	"a")
	aadd("rg-module-6",						"effectivity-module-2",																"b")
	aadd("rg-module-6",						"effectivity-module-3",																"c")
end
do	--[[trains-vehicles]]--
	aadd("rg-trains-0",						"rail",																								"a")
	aadd("rg-trains-0",						"straight-rail",																			"b")
	aadd("rg-trains-0",						"curved-rail",																				"e")
	
	aadd("rg-trains-1",						"train-stop",																					"a")
	aadd("rg-trains-1",						"rail-signal",																				"b")
	aadd("rg-trains-1",						"rail-chain-signal",																	"c")
	
	aadd("rg-trains-2",						"locomotive",																					"a")
	
	aadd("rg-trains-4",						"cargo-wagon",																				"a")
	
	aadd("rg-trains-5",						"fluid-wagon",																				"a")
	
	aadd("rg-vehicles-0",					"car",																								"a")
	aadd("rg-vehicles-0",					"tank",																								"b")
	
	aadd("rg-vehicles-3",					"tank-machine-gun",																		"a")
	aadd("rg-vehicles-3",					"vehicle-machine-gun",																"b")
	
end
do	--[[decorative]]--
	aadd("rg-decorative-0",				"landfill",																						"a")
	aadd("rg-decorative-0",				"stone-brick",																				"b")
	aadd("rg-decorative-0",				"concrete",																						"c")
	aadd("rg-decorative-0",				"refined-concrete",																		"d")
	aadd("rg-decorative-0",				"hazard-concrete",																		"e")
	aadd("rg-decorative-0",				"refined-hazard-concrete",														"f")
	
	aadd("rg-decorative-4",				"small-lamp",																					"a")
	
end
do  --[[atomic]]--
	aadd("rg-atomic-0",							"nuclear-reactor",																		"a1")
	
	aadd("rg-atomic-2",							"heat-pipe",																					"a1")
	
	aadd("rg-atomic-3",							"centrifuge",																					"a1")
	
	aadd("rg-atomic-4",							"steam-turbine",																			"a1")
	
	aadd("rg-atomic-5",							"uranium-235",																				"a")
	aadd("rg-atomic-5",							"uranium-238",																				"b")
	aadd("rg-atomic-5",							"uranium-fuel-cell",																	"c")
	aadd("rg-atomic-5",							"uranium-processing",																	"e")
	aadd("rg-atomic-5",							"kovarex-enrichment-process",													"f")
	aadd("rg-atomic-5",							"nuclear-fuel-reprocessing",													"g")
	aadd("rg-atomic-5",							"used-up-uranium-fuel-cell",													"h")
end
do  --[[barreling]]--
	aadd("rg-barreling-0",					"empty-barrel",																				"a")
end