local allow_changes = regroup.settings.other

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

do --[[gathering]]--
	aadd("rg-gathering-2",				"bi-large-wooden-chest",															"a[0064]-bio")
	aadd("rg-gathering-2",				"bi-huge-wooden-chest",															"a[0064]-bio")
	aadd("rg-gathering-2",				"bi-giga-wooden-chest",															"a[0064]-bio")
end
do --[[production]]--
	aadd("rg-production-11",				"bi_recipe_bio_farm",																		"a")
	aadd("rg-production-11",				"bi_recipe_greenhouse",																		"b")
	aadd("rg-production-11",				"bi_recipe_bio_garden",																		"c")
	aadd("rg-production-11",				"bi_recipe_arboretum",																		"d")
	aadd("rg-production-11",				"bi-cokery",																				"e")
	aadd("rg-production-11",				"bi-bioreactor",																			"f")
	aadd("rg-production-11",				"bi-stone-crusher",																			"g")
	aadd("rg-production-11",				"bi-cokery",																				"h")
	aadd("rg-production-11",				"bi-bioreactor",																			"i")
	aadd("rg-production-11",				"bi-stone-crusher",																			"g")
	
	aadd("rg-production-12",				"bi-burner-mining-drill-disassemble",														"a")
	aadd("rg-production-12",				"bi-steel-furnace-disassemble",																"b")
	
	if allow_changes and data.raw.recipe["bob-greenhouse"] and data.raw.recipe["bi_recipe_bio_farm"] then
		ahide("bob-greenhouse")
		ahide("bob-basic-greenhouse-cycle")
		ahide("bob-advanced-greenhouse-cycle")
		
		switch_tech("bob-greenhouse")
	end
	
end
do --[[resources]]--
	aadd("rg-resources-0",				"bi_recipe_burner_mining_drill_disassemble",															"j")
	aadd("rg-resources-0",				"bi_recipe_stone_furnace_disassemble",																	"k")
	aadd("rg-resources-0",				"bi_recipe_burner_inserter_disassemble",																"l")
	aadd("rg-resources-0",				"bi_recipe_long_handed_inserter_disassemble",															"m")
	aadd("rg-resources-0",				"bi_recipe_steel_furnace_disassemble",																	"n")
	
	aadd("rg-resources-1",					"bi_recipe_logs_mk1",																				"a03")
	aadd("rg-resources-1",					"bi_recipe_logs_mk2",																				"a04")
	aadd("rg-resources-1",					"bi_recipe_logs_mk3",																				"a05")
	aadd("rg-resources-1",					"bi_recipe_logs_mk4",																				"a06")
	aadd("rg-resources-1",					"bi_recipe_arboretum_r1",																			"a07")
	aadd("rg-resources-1",					"bi_recipe_arboretum_r2",																			"a08")
	aadd("rg-resources-1",					"bi_recipe_arboretum_r3",																			"a09")
	aadd("rg-resources-1",					"bi_recipe_arboretum_r4",																			"a10")
	aadd("rg-resources-1",					"bi_recipe_arboretum_r5",																			"a11")
	aadd("rg-resources-1",					"bi_recipe_woodpulp",																				"a12")
	aadd("rg-resources-1",					"bi_recipe_ash_1",																					"b")
	aadd("rg-resources-1",					"bi_recipe_ash_2",																					"c")
	aadd("rg-resources-1",					"bi_recipe_charcoal",																				"d")
	aadd("rg-resources-1",					"bi_recipe_charcoal_2",																				"e")
	aadd("rg-resources-1",					"bi_recipe_coal",																					"f")
	aadd("rg-resources-1",					"bi_recipe_coal_2",																					"g")
	aadd("rg-resources-1",					"bi_recipe_coke_coal",																				"i")
	aadd("rg-resources-1",					"bi_recipe_pellete_coal_2",																			"j")
	aadd("rg-resources-1",					"bi_recipe_crushed_stone", 													 						"k")
	
	aadd("rg-resources-8",					"bi_recipe_plastic_1",																				"l1")
	aadd("rg-resources-8",					"bi_recipe_plastic_2",																				"l2")
	
	aadd("rg-resources-9",					"titanium-2-ore",																					"k")
	
	if i_exist("bi-woodpulp") then
		if regroup.settings.add_trees then
			rg.add_newRessource_min_max("raw-wood",						"bi-woodpulp",1,3,0.7)
		end
		if regroup.settings.add_dirt then
			rg.add_newRessource_min_max("coal",							"bi-ash",1,2,0.2)
			rg.add_newRessource_min_max("stone",							"stone-crushed",1,2,0.1)
		end
	end
end
do --[[plates]]--
end
do --[[chemistry]]--
	aadd("rg-chemistry-0",				"bi_recipe_cellulose_1", 																	"m")
	aadd("rg-chemistry-0",				"bi_recipe_cellulose_2", 																	"n")
	
	aadd("rg-chemistry-0",				"liquid-air",																		"t")
	aadd("rg-chemistry-0",				"bob-liquid-air",																	"u")
	aadd("rg-chemistry-0",				"bi_recipe_liquid_air",																"v")
	
	aadd("rg-chemistry-2",				"bi_recipe_biomass_1",                          							"c")
	aadd("rg-chemistry-2",				"bi_recipe_biomass_2",                          							"d")
	aadd("rg-chemistry-2",				"bi_recipe_biomass_3",                          							"e")
	aadd("rg-chemistry-2",				"bi_recipe_biomass_conversion_1",														"f")
	aadd("rg-chemistry-2",				"bi_recipe_biomass_conversion_2",														"g")
	aadd("rg-chemistry-2",				"bi_recipe_biomass_conversion_3",														"h")
	aadd("rg-chemistry-2",				"bi_recipe_clean_air_1",                          							"j")
	aadd("rg-chemistry-2",				"bi_recipe_clean_air_2",                         							"k")
	
	aadd("rg-chemistry-2",				"air-cracking",																				"d")
	aadd("rg-chemistry-2",				"carbon-dioxide",																			"e")
	aadd("rg-chemistry-2",				"ammonia",																						"f")
	
	--aadd("rg-chemistry-3",				"solid-fuel-from-methylhydrazine",										"e")
	
	--aadd("rg-chemistry-7",				"hydrogen-sulfide",																		"a")
	--aadd("rg-chemistry-7",				"sulfur-dioxide-from-hydrogen-sulfide",								"b")
	--aadd("rg-chemistry-7",				"sulfur-from-sulfur-dioxide",													"c")
	--aadd("rg-chemistry-7",				"sulfur-dioxide",																			"d")
	--aadd("rg-chemistry-7",				"sulfur-trioxide",																		"e")
	--aadd("rg-chemistry-7",				"disulfuric-acid",																		"f")
	--aadd("rg-chemistry-7",				"sulfuric-acid-from-disulfuric-acid",									"g")
	aadd("rg-chemistry-7",				"bi_recipe_acid",																						"h")
	aadd("rg-chemistry-7",				"bi_recipe_sulfur",																					"i")
	aadd("rg-chemistry-7",				"bi_recipe_sulfur_angels",																		"j")
	
	aadd("rg-chemistry-8",				"methanol",																						"a")
	aadd("rg-chemistry-8",				"methylamine",																				"b")
	aadd("rg-chemistry-8",				"dimethylamine",																			"c")
	aadd("rg-chemistry-8",				"methylhydrazine",																		"d")
	aadd("rg-chemistry-8",				"dimethylhydrazine",																	"e")
	aadd("rg-chemistry-8",				"dinitrogen-tetroxide",																"f")
	aadd("rg-chemistry-8",				"dinitrogen-tetroxide-container",											"g")
	
	aadd("rg-chemistry-0",				"bi_recipe_nitrogen",																				"w")
	aadd("rg-chemistry-4",				"bi-liquid-co2",																			"x")
	aadd("rg-chemistry-9",				"bi-cellulose",                            						"y")
	
end
do --[[automatization]]--
end
do --[[transport]]--
	aadd("rg-transport-13",				"bi-wood-pipe",																				"a")
	
	aadd("rg-transport-14",				"bi-pipe-to-ground-wood",															"a")
end
do --[[logistic]]--
end
do --[[energy]]--
	aadd("rg-energy-1",						"bio_boiler",																					"a[075][48000]")
	aadd("rg-energy-1",						"bi_recipe_boiler",																					"a[075][48000]")
	aadd("rg-energy-1",						"bi_recipe_solar_boiler_panel",															"a[100][13000]")
	
	aadd("rg-energy-8",						"bi_recipe_bio_solar_farm",																	"j")
	
	aadd("rg-energy-11",					"bi_recipe_accumulator",																	"a[20000][20000][12000]-bio")
	
	aadd("rg-energy-12",					"bi-big-wooden-pole",																	"a[007][004x004]")
	aadd("rg-energy-12",					"bi_recipe_huge_wooden_pole",																"a[064][004x004]")
	
	aadd("rg-energy-15",					"bi_recipe_huge_substation",																"a[025][100x100]")
end
do --[[module]]--
	aadd("rg-module-0",						"lab-module",																					"d")
end
do --[[defense]]--
	aadd("rg-defense-0",						"bi-wooden-fence",																		"a2")
	
	aadd("rg-defense-6",						"bi_recipe_dart_turret",																	"h")
	aadd("rg-defense-6",						"bi_recipe_bio_cannon",																		"i")
	
	aadd("rg-defense-3",						"bi_recipe_bio_cannon_basic_ammo",															"p")
	aadd("rg-defense-3",						"bi_recipe_bio_cannon_poison_ammo",															"q")
	aadd("rg-defense-3",						"seed-bomb-basic",																		"s")
	aadd("rg-defense-3",						"seed-bomb-standard",																	"t")
	aadd("rg-defense-3",						"seed-bomb-advanced",																	"u")
end
do --[[intermediate]]--
	aadd("rg-intermediate-4",			"bi_recipe_battery",																						"g")
	
	aadd("rg-intermediate-7",			"bi_recipe_seedling_mk1",																			"h1")
	aadd("rg-intermediate-7",			"bi_recipe_seedling_mk2",																			"h2")
	aadd("rg-intermediate-7",			"bi_recipe_seedling_mk3",																			"h3")
	aadd("rg-intermediate-7",			"bi_recipe_seedling_mk4",																			"h4")
	aadd("rg-intermediate-7",			"bi_recipe_fertiliser_1",																			"i1")
	aadd("rg-intermediate-7",			"bi_recipe_fertiliser_2",																			"i2")
	aadd("rg-intermediate-7",			"bi_recipe_adv_fertiliser_1",																		"i3")
	aadd("rg-intermediate-7",			"bi_recipe_adv_fertiliser_2",																		"i4")
	aadd("rg-intermediate-7",			"bi_recipe_seed_1",																					"j1")
	aadd("rg-intermediate-7",			"bi_recipe_seed_2",																					"j2")
	aadd("rg-intermediate-7",			"bi_recipe_seed_3",																					"j3")
	aadd("rg-intermediate-7",			"bi_recipe_seed_4",																					"j4")
	
	if allow_changes and i_exist("bi_recipe_bio_farm") then
		if i_exist("bob-seedling") then
			rhide("bi_recipe_seedling_mk1")
			rhide("bi_recipe_seedling_mk2")
			rhide("bi_recipe_seedling_mk3")
			rhide("bi_recipe_seedling_mk4")
		else rhide("bob-seedling") end
		ahide("bob-fertiliser")
		switch_tech("bob-fertiliser")
	end
	
end
do --[[trains-vehicles]]--
	aadd("rg-trains-0",						"bi-rail-wood",																				"a1")
	aadd("rg-trains-0",						"bi-straight-rail-wood",															"b2")
	aadd("rg-trains-0",						"bi-rail-wood-bridge",																"f")
	aadd("rg-trains-0",						"bi_rail_power",																"g")
	aadd("rg-trains-0",						"bi_recipe_power_to_rail_pole",																"h")
end
do --[[armor]]--
end
do --[[weaponry]]--
	aadd("rg-weaponry-3",					"bi_recipe_basic_dart_magazine",													"k")
	aadd("rg-weaponry-3",					"bi_recipe_standard_dart_magazine",													"l")
	aadd("rg-weaponry-3",					"bi_recipe_enhanced_dart_magazine",													"m")
	aadd("rg-weaponry-3",					"bi_recipe_poison_dart_magazine",													"n")
	
	aadd("rg-weaponry-10",					"bi-seed-bomb-basic",																"g")
	aadd("rg-weaponry-10",					"bi-seed-bomb-standard",															"h")
	aadd("rg-weaponry-10",					"bi-seed-bomb-advanced",															"i")
		
end
do --[[decorative]]--
	aadd("rg-decorative-6",				"bi_recipe_solar_mat",                            						"d")
end
do --[[alien]]--
end
do --[[atomic]]--
end
do --[[other]]--
end
do  --[[barreling]]--
end
do  --[[misc]]--
end