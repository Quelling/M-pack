local barreling_groups = {"crafting-with-fluid", "air-pump", "barreling-pump", "angels-barrels"}
local ab = {}

do  --[[barreling]]--
	
	--Hide Bob's Gas Canisters
	
	--[[for _, recipe in pairs(data.raw["fluid"]) do
		local lname = string.lower(recipe.name)
		_log("Fluid Name: %s",recipe.name)
		if (string.find(lname,"-gas-") and (string.sub(lname, 0, 4) == "gas-") and (string.sub(lname, -4) == "-gas")) then
				if (lname == "fill-canister") or (lname == "fill-gas-canister") then
					aadd("rg-barreling-4",				lname,																											"a["..recipe.name.."]")
				else if (lname == "empty-filled-canister") or (lname == "empty-filled-gas-canister") then
					aadd("rg-barreling-6",				lname,																											"a["..recipe.name.."]")
				end
				_log("Recipe Gas Name: %s",dumpvar(recipe.name))
			end
		else
			if i_exist(recipe.name.."-barrel") or i_exist("fill-"..recipe.name.."-barrel") then
				if (regroup.settings.barreling_sort) then
					aadd("rg-barreling-1",				recipe.name.."-barrel",																											"a["..recipe.name.."]")
					aadd("rg-barreling-3",				"fill-"..recipe.name.."-barrel",																						"a["..recipe.name.."]")
					aadd("rg-barreling-5",				"empty-"..recipe.name.."-barrel",																						"a["..recipe.name.."]")
				else
				aadd("rg-barreling-1",				recipe.name.."-barrel")
					aadd("rg-barreling-3",				"fill-"..recipe.name.."-barrel")
					aadd("rg-barreling-5",				"empty-"..recipe.name.."-barrel")
				end
			else
				if (regroup.settings.barreling_sort) then
					aadd("rg-barreling-2",				recipe.name.."-barrel",																											"a["..recipe.name.."]")
					aadd("rg-barreling-4",				"fill-"..recipe.name.."-barrel",																						"a["..recipe.name.."]")
					aadd("rg-barreling-6",				"empty-"..recipe.name.."-barrel",																						"a["..recipe.name.."]")
				else
					aadd("rg-barreling-2",				recipe.name.."-barrel")
					aadd("rg-barreling-4",				"fill-"..recipe.name.."-barrel")
					aadd("rg-barreling-6",				"empty-"..recipe.name.."-barrel")
				end
			end
		end
		--Move Canisters to Barreling
		if (i_exist(recipe.name.."-canister") and recipe.subgroup == "bob-gas-bottle" or recipe.subgroup == "bob-empty-gas-bottle") then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-4",	recipe.name, "ay["..recipe.name.."]")
				else
				aadd("rg-barreling-4",	recipe.name)
			end
			elseif (i_exist("empty-"..recipe.name.."-canister") and (recipe.subgroup == "bob-gas-bottle" or recipe.subgroup == "bob-empty-gas-bottle")) then
			if (regroup.settings.barreling_sort) then
				aadd("rg-barreling-6",	recipe.name, "az["..recipe.name.."]")
				else
				aadd("rg-barreling-6",	recipe.name)
			end
	end]]
end							