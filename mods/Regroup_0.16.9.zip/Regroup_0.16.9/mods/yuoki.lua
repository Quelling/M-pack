local allow_changes = regroup.settings.yuoki

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

if mods["Yuoki"] then
do --[[gathering]]--
	--Yuoki Industries
	aadd("rg-gathering-0",					"y-axe-duro",																					"e")
	aadd("rg-gathering-0",					"y-axe-durotal-recipe",																"e")
	aadd("rg-gathering-0",					"y_quantrinum_hammer",																"i")
	
	aadd("rg-gathering-1",					"y-repair-durotal",																		"d")
	aadd("rg-gathering-1",					"y-repair-krakon",																		"f")
	aadd("rg-gathering-1",					"y_repair_quantrinum",																"g")
	
	aadd("rg-gathering-2",					"y_c11",																							"a[0030]")
	aadd("rg-gathering-2",					"y_sc11",																							"a[0060]")
	aadd("rg-gathering-2",					"y_c22",																							"a[0100]")
	aadd("rg-gathering-2",					"y_cg33",																							"a[0130]")
	aadd("rg-gathering-2",					"y_sc44",																							"a[0220]")
	
	aadd("rg-gathering-4",					"y_buffer_station",																		"a[030]")
	aadd("rg-gathering-4",					"y-tank-1000",																				"a[040]")
	aadd("rg-gathering-4",					"y-tank-4500",																				"a[090]")
	aadd("rg-gathering-4",					"y-tank-8000",																				"a[240]")
	aadd("rg-gathering-4",					"y-tank-24k",																					"a[500]")
	
	if not allow_changes then
		if regroup.settings.yuoki_tech then
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-axe-durotal-recipe")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-tank-1000")
			rg.add_recipe_to_tech("yuoki_liquids-3",				"y-tank-8000")
		end
		else
		ahide("brass-axe",						"mining-tool")
		ahide("cobalt-axe",					"mining-tool")
		ahide("tungsten-axe",					"mining-tool")
		ahide("y-axe-duro",					"mining-tool")
		ahide("y-axe-durotal-recipe")
		ahide("y-tank-1000",					"5d-storage-tank")
		ahide("y-tank-8000",					"y-tank-1000")
		ahide("storage-tank-2",				"storage-tank")
		ahide("storage-tank-3",				"storage-tank")
		ahide("storage-tank-4",				"storage-tank")
		rg.t_add_recipe_unlock("bob-fluid-handling-2",		"5d-storage-tank")
	end
	
	aadd("rg-gathering-8",					"y-mining-drill",																			"a")
	aadd("rg-gathering-8",					"y-mining-drill-e2",																	"b")
	aadd("rg-gathering-8",					"y_mc_e2_mining_drill",																"c")
	aadd("rg-gathering-8",					"y-underground-drill",																"d")
	aadd("rg-gathering-8",					"y_mc_underground_drill",															"e")
	aadd("rg-gathering-8",					"yi-mine-impact",																			"f")
	aadd("rg-gathering-8",					"yi-mine-plasma",																			"g")
	
	aadd("rg-gathering-22",				"y-water-gen",																				"f")
	aadd("rg-gathering-22",				"y-water-gen-e",																			"g")
	aadd("rg-gathering-22",				"y-water-gen-recipe-e",																"h")
	aadd("rg-gathering-22",				"y_water_mixer",																			"i")
	
	if i_exist("water-miner-1") and allow_changes and regroup.settings.bob then
		ahide("water-miner-2")
		ahide("water-miner-3")
		ahide("water-miner-4")
		ahide("water-miner-5")
		switch_tech("water-miner-2")
		switch_tech("water-miner-3")
		switch_tech("water-miner-4")
		switch_tech("water-miner-5")
	end
	
end
do --[[production]]--
	aadd("rg-production-3",				"y-crusher",																					"a")
	aadd("rg-production-3",				"y_crusher2",																					"b")
	aadd("rg-production-3",				"y_crusher2_recipe",																	"b")
	aadd("rg-production-3",				"y-dirtwasher",																				"c")
	aadd("rg-production-3",				"y_mc_dirtwasher",																		"d")
	aadd("rg-production-3",				"y-water-mixer",																			"e")
	aadd("rg-production-3",				"y-heat-form-press",																	"f")
	aadd("rg-production-3",				"y_formpress2",																				"g")
	aadd("rg-production-3",				"y_maintance_workshop",																"h")
	aadd("rg-production-3",				"y_basement_factory",																	"i")
	
	
	aadd("rg-production-5",				"y_smelter",																					"d")
	aadd("rg-production-5",				"y_charger",																					"e")
	aadd("rg-production-5",				"y-atomic-quantum-composer",													"f")
	aadd("rg-production-5",				"y-alien-infuser",																		"g")
	
end
do --[[resources]]--
	aadd("rg-resources-2",					"y-wooden-brikett",																		"c")
	aadd("rg-resources-2",					"y-coal-brikett",																			"d")
	aadd("rg-resources-2",					"y-mixed-fuel",																				"e")
	aadd("rg-resources-2",					"y-coaldust-mixing-recipe",														"e")
	aadd("rg-resources-2",					"y-mixed-fuel-loaded",																"f")
	aadd("rg-resources-2",					"y-mixfuel-load-recipe",															"f")
	aadd("rg-resources-2",					"y-wooden-brikett-packed",														"g")
	aadd("rg-resources-2",					"y-coal-stack",																				"h")
	aadd("rg-resources-2",					"y-infused-mud",																			"i")
	aadd("rg-resources-2",					"y-fuel-cell-c",																			"j")
	aadd("rg-resources-2",					"y-sgtrade-ic1-recipe",																"j")
	
	aadd("rg-resources-3",					"y-res1",																							"h")
	aadd("rg-resources-3",					"y-res2",																							"i")
	
	if regroup.settings.add_trees then
		rg.add_newRessource_min_max("raw-wood",						"y_organic_dust",1,4,0.5)
	end
	if regroup.settings.add_dirt then
		rg.add_newRessource_min_max("coal",							"y-dirt",1,2,0.3  ,"y-coal-dust",1,2,0.2)
		rg.add_newRessource_min_max("stone",							"y-dirt",1,2,0.3)
		rg.add_newRessource_min_max("iron-ore",						"y-dirt",1,2,0.2)
		rg.add_newRessource_min_max("copper-ore",					"y-dirt",1,2,0.2)
		rg.add_newRessource_min_max("lead-ore",						"y-dirt",1,1,0.2,  "y-toxic-dust",1,2,0.2)
		rg.add_newRessource_min_max("tin-ore",						"y-dirt",1,2,0.2)
		rg.add_newRessource_min_max("zinc-ore",						"y-dirt",1,2,0.2,  "y-toxic-dust",1,1,0.2)
		rg.add_newRessource_min_max("bauxite-ore",					"y-dirt",1,1,0.3)
		rg.add_newRessource_min_max("cobalt-ore",					"y-dirt",1,2,0.2)
		rg.add_newRessource_min_max("nickel-ore",					"y-dirt",1,1,0.2,  "y-toxic-dust",1,1,0.2)
		rg.add_newRessource_min_max("rutile-ore",					"y-dirt",1,2,0.2,  "y-toxic-dust",1,2,0.2)
		rg.add_newRessource_min_max("silver-ore",					"y-dirt",1,1,0.2)
		rg.add_newRessource_min_max("tungsten-ore",					"y-dirt",1,2,0.2,  "y-toxic-dust",1,2,0.2)
		rg.add_newRessource_min_max("sulfur",							"y-toxic-dust",1,2,0.3)
		rg.add_newRessource_min_max("y-res1",							"y-toxic-dust",1,2,0.2)
		rg.add_newRessource_min_max("y-res2",							"y-toxic-dust",1,2,0.2)
	end
	if regroup.settings.add_dust then
		rg.add_newRessource_min_max("y-res1",							"y-crush-yres1",1,1,0.2)
		rg.add_newRessource_min_max("y-res2",							"y-crush-yres2",1,1,0.2)
	end
end
do --[[plates]]--
	aadd("rg-plates-1",						"y-refined-iron",																			"g")
	aadd("rg-plates-1",						"y_hps_pureiron_recipe",															"h")
	
	if i_exist("5d-iron-plate") then
		aadd("rg-plates-2",						"y-refined-copper",																		"g")
		aadd("rg-plates-2",						"y_hps_purecopper_recipe",														"h")
		
		aadd("rg-plates-5",						"y_hps_steel_recipe",																	"g")
	else
		aadd("rg-plates-1",						"y-refined-copper",																		"k")
		aadd("rg-plates-1",						"y_hps_purecopper_recipe",														"l")
		
		aadd("rg-plates-0",						"y_hps_steel_recipe",																	"i")
	end
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("y-refined-iron", "__Regroup__/graphics/icons/pure-iron.png")
		rg.set_icon("y-refined-copper", "__Regroup__/graphics/icons/pure-copper.png")
		
		rg.set_icon("y_hps_pureiron_recipe", "__Regroup__/graphics/icons/heat-iron.png")
		rg.set_icon("y_hps_purecopper_recipe", "__Regroup__/graphics/icons/heat-copper.png")
		
		rg.set_icon("y_hps_steel_recipe", "__Regroup__/graphics/icons/heat-steel.png")
	end
	
end
do --[[liquids]]--
	if allow_changes and data.raw.fluid["lithia-water"] and i_exist("y-unicomp-raw") then
		data:extend({
			{
				type="recipe-category",
				name="rg-watergen-recipe" 
			},
			{
				type = "recipe",
				name = "rg-lithia-water",
				icon = "__Regroup__/graphics/icons/lithia-water.png",
				icon_size = 32,
				category = "rg-watergen-recipe",
				energy_required = 5,
				enabled = true,
				ingredients = {
					{"y_organic_dust",7}
				},
				results = {{type="fluid",name="lithia-water",amount=140}},
				main_product = "lithia-water",
				hidden = false,
				subgroup = "rg-liquids-3",
				order = "b"
			},
		})
		table.insert(data.raw["assembling-machine"]["y-water-gen"].crafting_categories,"rg-watergen-recipe")
		if regroup.settings.yuoki_tech then
			rg.add_recipe_to_tech("yuoki_liquids",				"rg-lithia-water")
		end
	end
	
	if regroup.settings.liquid_move then
		aadd("rg-chemistry-0",					"liquid-air",																					"z")
		
		aadd("rg-chemistry-10",				"y-water-gen-fluid-recipe",														"a")
		aadd("rg-chemistry-10",				"rg-lithia-water",																			"b")
		aadd("rg-chemistry-10",				"bob-liquid-air",																			"c")
		aadd("rg-chemistry-10",				"y_water_mix_recipe",																	"d")
		
		aadd("rg-chemistry-11",				"y-con_water",																				"a")
		aadd("rg-chemistry-11",				"y-liquid-uc2",																				"b")
		else
		aadd("rg-liquids-0",						"liquid-air",																					"t")
		
		aadd("rg-liquids-3",						"y-water-gen-fluid-recipe",														"a")
		aadd("rg-liquids-3",						"rg-lithia-water",																			"b")
		aadd("rg-liquids-3",						"bob-liquid-air",																			"c")
		aadd("rg-liquids-3",						"y_water_mix_recipe",																	"d")
		
		aadd("rg-liquids-5",						"y-con_water",																				"a")
		aadd("rg-liquids-5",						"y-liquid-uc2",																				"b")
	end
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("y-con_water", "__Regroup__/graphics/icons/y-con-water.png")
	end
	
end
do --[[chemistry]]-- 
	radd("rg-chemistry-0",				"y-sulfuric-acid-recipe",  "a")
	aadd("rg-chemistry-4",					"y_coal2liquid",																			"a")
	aadd("rg-chemistry-4",					"y_ft_recipe",																				"b")
	aadd("rg-chemistry-4",					"y_rawsyngas1_recipe",																"c")
	aadd("rg-chemistry-4",					"y_rawsyngas2_recipe",																"d")
	aadd("rg-chemistry-4",					"y_refinehydrogen_recipe",														"e")
	aadd("rg-chemistry-9",					"y_hydrogen",																					"p")
	aadd("rg-chemistry-9",					"y_syngas_clean",																			"q")
	aadd("rg-chemistry-9",					"y_syngas_raw",																				"r")
	
end
do --[[automatization]]--
	aadd("rg-automatization-0",		"y-inserter-fast",																		"i")
	aadd("rg-automatization-0",		"y-inserter-s4",																			"j")
		
	aadd("rg-automatization-1",		"y-inserter-smart",																		"k")
	aadd("rg-automatization-1",		"y-inserter-smart-long",															"l")
		
	aadd("rg-automatization-2",		"y_inserter_diagonal",																"j")
		
	aadd("rg-automatization-4",		"y_inserter_smart_LL",																"h")
	aadd("rg-automatization-4",		"y_inserter_smart_leftR2",														"i")
	aadd("rg-automatization-4",		"y_inserter_evade_shortL",														"j")
		
	aadd("rg-automatization-5",		"y_inserter_smart_RR",																"h")
	aadd("rg-automatization-5",		"y_inserter_smart_rightR2",														"i")
	aadd("rg-automatization-5",		"y_inserter_evade_shortR",														"j")
	if regroup.settings.bob_inserters then
		ahide("y-inserter-s4",				"inserter")
		ahide("y-inserter-fast",				"fast-inserter")
		ahide("y-inserter-smart",			"filter-inserter")
		ahide("y-inserter-smart-long",		"filter-inserter")
		ahide("y_inserter_smart_LL",		"filter-inserter")
		ahide("y_inserter_smart_RR",		"filter-inserter")
		ahide("y_inserter_diagonal",		"inserter")
		ahide("y_inserter_smart_leftR2",	"filter-inserter")
		ahide("y_inserter_smart_rightR2",	"filter-inserter")
		ahide("y_inserter_evade_shortL",	"inserter")
		ahide("y_inserter_evade_shortR",	"inserter")
		else
		if regroup.settings.yuoki_tech then
			rg.add_recipe_to_tech("yuoki_industries",			"y-inserter-fast")
			rg.add_recipe_to_tech("yuoki_industries",			"y-inserter-smart")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-inserter-s4")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-inserter-smart-long")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_inserter_smart_LL")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_inserter_smart_leftR2")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_inserter_evade_shortL")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_inserter_diagonal")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_inserter_smart_RR")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_inserter_smart_rightR2")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_inserter_evade_shortR")
		end
	end
	
end
do --[[transport]]--
	aadd("rg-transport-11",					"y_flowcheck_10",																			"g")
	aadd("rg-transport-11",					"y-valve-direction-buffer",														"h")
		
	aadd("rg-transport-20",				"y-pipe-v",																						"a")
	aadd("rg-transport-20",				"y-pipe-h",																						"b")
	aadd("rg-transport-20",				"y-pipe-hc",																					"c")
	aadd("rg-transport-20",				"y-pipe-ec",																					"d")
	aadd("rg-transport-20",				"y-pipe-to-ground-hc",																"e")
	aadd("rg-transport-20",				"y-pipe-to-ground-ec",																"f")
		
	
	if not regroup.settings.yuoki_pipe then
		if regroup.settings.yuoki_tech then
			rg.add_recipe_to_tech("yuoki_liquids",				"y-pipe-v")
			rg.add_recipe_to_tech("yuoki_liquids",				"y-pipe-h")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_flowcheck_10_recipe")
			
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-pipe-hc")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-pipe-ec")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-pipe-to-ground-hc")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-pipe-to-ground-ec")
		end
		else
		ahide("y-pipe-h",						"pipe")
		ahide("y-pipe-v",						"pipe")
		if data.raw.item["5d-pipe-mk2"] then
			ahide("y-pipe-hc",						"5d-pipe-mk2")
			ahide("y-pipe-to-ground-hc",		"5d-pipe-mk2")
			ahide("y-pipe-ec",						"5d-pipe-mk3")
			ahide("y-pipe-to-ground-ec",		"5d-pipe-mk3")
			else
			ahide("y-pipe-hc",						"pipe")
			ahide("y-pipe-to-ground-hc",		"pipe")
			ahide("y-pipe-ec",						"pipe")
			ahide("y-pipe-to-ground-ec",		"pipe")
		end
		ahide("y-valve-direction-buffer",	"valve")
	end
end
do --[[logistic]]--
	aadd("rg-logistic-2",					"yi_roboport",																				"c")
	
	aadd("rg-logistic-5",					"yi_logistic-robot",																	"i")
	aadd("rg-logistic-6",					"yi_construction-robot",															"i")
	
	aadd("rg-logistic-11",					"y-rare-chest-log",																		"a")
	aadd("rg-logistic-11",					"y-rare-m1bunker-log",																"b")
	aadd("rg-logistic-11",					"y_pc22",																							"c")
	aadd("rg-logistic-11",					"y_rc22",																							"d")
end
do --[[energy]]--
	aadd("rg-energy-1",						"y-boiler-t2",																				"g")
	aadd("rg-energy-1",						"y-boiler-t3",																				"h")
	aadd("rg-energy-1",						"y-boiler-iv",																				"i")
	aadd("rg-energy-1",						"y_boiler4_mc",																				"j")
	aadd("rg-energy-1",						"y_boiler_sh",																				"k")
	
	aadd("rg-energy-2",						"y-notfall-generator-s2",															"c")
	aadd("rg-energy-2",						"y-small-stirling-engine",														"d")
	aadd("rg-energy-2",						"y-stirling-solar-dish",															"e")
	aadd("rg-energy-2",						"y-steam-turbine",																		"f")
	aadd("rg-energy-2",						"y-steam-turbine-mk3",																"g")
	aadd("rg-energy-2",						"y_steam_turbine_mc",																	"h")
	aadd("rg-energy-2",						"y-obninsk-turbine",																	"i")
	aadd("rg-energy-2",						"y-meg-s",																						"j")
	aadd("rg-energy-2",						"y-beg",																							"k")
	aadd("rg-energy-2",						"y-heg",																							"l")
	aadd("rg-energy-2",						"y-heg",																							"m")
	
	aadd("rg-energy-5",						"y-obninsk-reactor",																	"f")
	aadd("rg-energy-5",						"y_obninsk_mc",																				"g")
	aadd("rg-energy-5",						"y-seg",																							"h")
	aadd("rg-energy-5",						"y-seg-p",																						"i")
	aadd("rg-energy-5",						"y-notfall-generator-s1",															"j")
		
	aadd("rg-energy-6",						"y-accumulator-m",																		"c")
	aadd("rg-energy-6",						"y-accumulator-m-t2",																	"d")
	aadd("rg-energy-6",						"y-accumulator-mt2-recipe",														"d")
	aadd("rg-energy-6",						"y-accumulator-b",																		"e")
	aadd("rg-energy-6",						"y-accumulator-b-t2",																	"f")
	aadd("rg-energy-6",						"y-accumulator-bt2-recipe",														"f")
	aadd("rg-energy-6",						"y-accumulator-b-tx",																	"g")
	aadd("rg-energy-6",						"y-accumulator-btx-recipe",														"g")
	aadd("rg-energy-6",						"y-accumulator-crystal-m",														"h")
	aadd("rg-energy-6",						"y-ups-flywheel-b",																		"i")
	aadd("rg-energy-6",						"y_compensator_25",																		"j")
	aadd("rg-energy-6",						"y-accumulator-s",																		"k")
	aadd("rg-energy-6",						"y-accumulator-s-t2",																	"l")
	aadd("rg-energy-6",						"yi_obelisk_A3_5X",																		"m")

	aadd("rg-energy-8",						"y-solar-dish-recipe",																"g")
	aadd("rg-energy-8",						"y_alien_solar",																			"h")
	aadd("rg-energy-8",						"y_alien_solar2",																			"i")
	
	aadd("rg-energy-12",						"y_signal_pole",																			"a[048][003x003]")
	
	aadd("rg-energy-15",						"y-substation-m",																			"a[048][032x032]")
	aadd("rg-energy-15",						"y-substation-h",																			"a[064][064x064]")
	
	if not allow_changes then
		
		if regroup.settings.yuoki_tech then
			rg.add_recipe_to_tech("yuoki_energy",					"y-seg-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-seg-p-recipe")
		end
		
		else
		ahide("5d-basic-accumulator-3")
		ahide("y-notfall-generator-s1")
		ahide("y-seg")
		ahide("y-seg-p")
		ahide("y-accumulator-s")
		ahide("y-accumulator-s-t2")
		ahide("yi_obelisk_A3_5X")
		
		switch_tech("electric-energy-accumulators-3")
		switch_tech("engine-3")
	end
end
do --[[defense]]--
	aadd("rg-defense-0",						"y-mud-wall",																					"h")
	aadd("rg-defense-0",						"y-rare-wall-basic",																	"i")
	aadd("rg-defense-0",						"y-rare-wall-adv",																		"j")
	aadd("rg-defense-0",						"y_wall22_hardic",																		"k")
	aadd("rg-defense-0",						"y-wall-forcefield",																	"l")
	
	aadd("rg-defense-7",						"y_turret_flame",																			"a")
	aadd("rg-defense-7",						"y_turret_plasma",																		"b")
	aadd("rg-defense-7",						"y-laser-def-s4",																			"c")
	aadd("rg-defense-7",						"y_laser_onhwall_recipe",															"c")
	aadd("rg-defense-7",						"y_turret_gun2f12",																		"d")
	aadd("rg-defense-7",						"y-gun-turret-mk2-recipe",														"d")
	aadd("rg-defense-7",						"y_turret_gun1f12",																		"e")
	aadd("rg-defense-7",						"y-gun-turret-mk3-recipe",														"e")
	aadd("rg-defense-7",						"y_turret_laser22f12",																"f")
	aadd("rg-defense-7",						"y_laser_mk1_recipe",																	"f")
	aadd("rg-defense-7",						"y-weapon-ztt",																				"g")
	
	aadd("rg-defense-8",						"yi_radar",																						"d")
	
	if allow_changes and i_exist("y-unicomp-raw") then
		ahide("radar-4")
		ahide("radar-5")
		switch_tech("radars-3")
		switch_tech("radars-4")
		else
		aadd("rg-defense-8",						"yi_radar",																						"g")
	end
end
do --[[weaponry]]--
	aadd("rg-weaponry-1",					"y-bullet-case",																			"g")
	
	aadd("rg-weaponry-10",					"yi_mine_impact",																			"h")
	aadd("rg-weaponry-10",					"yi_mine_plasma",																			"i")
	
	aadd("rg-weaponry-19",					"y-ammo-hohlspitz",																		"a")
	aadd("rg-weaponry-19",					"y-ammo-krakon",																			"b")
	aadd("rg-weaponry-19",					"y-ammo-explosiv",																		"c")
	aadd("rg-weaponry-19",					"y-ammo-biggun",																			"d")
	aadd("rg-weaponry-19",					"y-ammo-poison",																			"e")
	aadd("rg-weaponry-19",					"y-ammo-acid-2",																			"f")
	aadd("rg-weaponry-19",					"y-ammo-acid-medium-recipe",													"g")
	aadd("rg-weaponry-19",					"y_ammo_case",																				"h")
	aadd("rg-weaponry-19",					"y_ammo_flame",																				"i")
	aadd("rg-weaponry-19",					"y_ammo_plasma",																			"j")
end
do --[[alien]]--
	aadd("rg-alien-6",							"y-alien-artifact-recipe",														"a")
	
end
do --[[intermediate]]--
	aadd("rg-intermediate-8",			"y-battery-single-use1",															"d")
	aadd("rg-intermediate-8",			"y-battery-single-use2",															"e")
	aadd("rg-intermediate-8",			"y-battery-single-use3",															"f")
	aadd("rg-intermediate-8",			"y-battery-singleuse1-recipe",												"d")
	aadd("rg-intermediate-8",			"y-battery-singleuse2-recipe",												"e")
	aadd("rg-intermediate-10",			"engine-unit",																				"g")
	aadd("rg-intermediate-10",			"electric-engine-unit",																"h")
	
end
do --[[parts]]--
	if i_exist("y-unicomp-raw") then rg.add_main_group("parts") end
	
	aadd("rg-parts-1",							"y-dirt",																							"a")
	aadd("rg-parts-1",							"y-digfdirt-recipe",																	"a")
	aadd("rg-parts-1",							"y-digfdirt2-recipe",																	"b")
	aadd("rg-parts-1",							"y-coal-dust",																				"c")
	aadd("rg-parts-1",							"y-crush-yres1",																			"d")
	aadd("rg-parts-1",							"y-crush-unicomp-raw-recipe",													"d")
	aadd("rg-parts-1",							"y-crush-yres2",																			"e")
	aadd("rg-parts-1",							"y-crush-fuel-raw-recipe",														"e")
	aadd("rg-parts-1",							"y-filtering-dust-recipe",														"f")
	aadd("rg-parts-1",							"y-crush-blue_whead-recipe",													"g")
	aadd("rg-parts-1",							"y-crush-green_whead-recipe",													"h")
	aadd("rg-parts-1",							"y-richdust",																					"i")
	aadd("rg-parts-1",							"y-mixing-rich-recipe",																"i")
	
	aadd("rg-parts-2",							"y-c_mud",																						"a")
	aadd("rg-parts-2",							"y-release-cwater",																		"a")
	aadd("rg-parts-2",							"y-wash-special-recipe",															"b")
	aadd("rg-parts-2",							"y-toxic-dust",																				"c")
	aadd("rg-parts-2",							"y-dry_mud",																					"d")
	aadd("rg-parts-2",							"y-pressed_dry_mud-recipe",														"d")
	aadd("rg-parts-2",							"y_slag_granulate",																		"e")
	aadd("rg-parts-2",							"y-slag",																							"f")
	aadd("rg-parts-2",							"y-unicomp-raw",																			"g")
	aadd("rg-parts-2",							"y-unicomp-a2",																				"h")
	aadd("rg-parts-2",							"y-press-richdust-recipe",														"h")
	aadd("rg-parts-2",							"y-orange-stuff",																			"i")
	aadd("rg-parts-2",							"y-smelt-richdust-recipe",														"i")
	aadd("rg-parts-2",							"y-crystal2",																					"j")
	aadd("rg-parts-2",							"y-raw-fuelnium",																			"k")
	
	aadd("rg-parts-3",							"y-pure-iron",																				"a")
	aadd("rg-parts-3",							"y_pure_iron_wtool_recipe",														"b")
	aadd("rg-parts-3",							"y-pure-copper",																			"c")
	aadd("rg-parts-3",							"y_pure_copper_wtool_recipe",													"d")
	aadd("rg-parts-3",							"y-refined-yres1",																		"e")
	aadd("rg-parts-3",							"y-smelt-crush-res1-recipe",													"e")
	aadd("rg-parts-3",							"y-refined-yres2",																		"f")
	aadd("rg-parts-3",							"y-smelt-crush-res2-recipe",													"f")
	aadd("rg-parts-3",							"y_slag_brick",																				"g")
	aadd("rg-parts-3",							"y_slag_brick_recipe",																"g")
	aadd("rg-parts-3",							"y_slag_brick_burn_recipe",														"h")
	aadd("rg-parts-3",							"y-wash-dirt-recipe",																	"i")
	
	aadd("rg-parts-4",							"y_drillhead",																				"a")
	aadd("rg-parts-4",							"y_drillhead_broken",																	"b")
	aadd("rg-parts-4",							"y_drillhead_repair_recipe",													"c")
	aadd("rg-parts-4",							"y_toolhead",																					"d")
	aadd("rg-parts-4",							"y_toolhead_broken",																	"e")
	aadd("rg-parts-4",							"y_toolhead_repair_recipe",														"f")
	aadd("rg-parts-4",							"y_block_cold",																				"g")
	aadd("rg-parts-4",							"y_block_heat",																				"h")
	
	aadd("rg-parts-5",							"y-heat-pipe",																				"a")
	aadd("rg-parts-5",							"y-bluegear",																					"b")
	aadd("rg-parts-5",							"y_structure_element",																"c")
	aadd("rg-parts-5",							"y_structure_vessel",																	"d")
	aadd("rg-parts-5",							"y_blocked_capa",																			"f")
	aadd("rg-parts-5",							"y-basic-t1-mf",																			"g")
	aadd("rg-parts-5",							"y-basic-st1-mf-recipe",															"g")
	aadd("rg-parts-5",							"y-basic-t2-mf",																			"h")
	aadd("rg-parts-5",							"y-basic-st2-mf-recipe",															"h")
	aadd("rg-parts-5",							"y_structure_electric",																"i")
	
	aadd("rg-parts-6",							"y-conductive-wire-1",																"a")
	aadd("rg-parts-6",							"y-conductive-coil-1",																"b")
	aadd("rg-parts-6",							"yi_magnetron",																				"c")
	aadd("rg-parts-6",							"y_dotzetron",																				"d")
	aadd("rg-parts-6",							"y_chip_plate",																				"e")
	aadd("rg-parts-6",							"y-chip-1",																						"f")
	aadd("rg-parts-6",							"y-chip1-recipe",																			"f")
	aadd("rg-parts-6",							"y-chip-2",																						"g")
	aadd("rg-parts-6",							"y-chip2-recipe",																			"g")
	
	aadd("rg-parts-7",							"y_organic_dust",																			"a")
	aadd("rg-parts-7",							"y_granulate_wood_recipe",														"a")
	aadd("rg-parts-5",							"y_gauge",																						"b")
	aadd("rg-parts-5",							"y_gauge_analog_recipe",															"b")
	aadd("rg-parts-7",							"y_catalyst_base",																		"c")
	aadd("rg-parts-7",							"y_usedcatalyst",																			"d")
	aadd("rg-parts-7",							"y_catalyst_bp",																			"e")
	aadd("rg-parts-7",							"y_catalyst_ft",																			"f")
	aadd("rg-parts-7",							"y_regcatbp_recipe",																	"g")
	aadd("rg-parts-7",							"y_regcatft_recipe",																	"h")
	
	aadd("rg-parts-8",							"y-fuel-reactor",																			"a")
	aadd("rg-parts-8",							"y-infused-uca2",																			"b")
	aadd("rg-parts-8",							"y_crystal2_combined",																"c")
	aadd("rg-parts-8",							"y_modul_science",																		"d")
	aadd("rg-parts-8",							"y_data_crystal_recipe",															"e")
	aadd("rg-parts-8",							"y-crystal-cnd",																			"f")
	aadd("rg-parts-8",							"y-quantrinum",																				"g")
	aadd("rg-parts-8",							"y_quantrinum_infused",																"h")
	aadd("rg-parts-8",							"y_quantrinum_infusion_recipe",												"i")
	
end
do --[[yuoki]]--
	if i_exist("y-unicomp-raw") then rg.add_main_group("yuoki") end
	
	aadd("rg-yuoki-0",							"ye_green_ultimate",																	"a")
	aadd("rg-yuoki-0",							"ye_science_ultimate",																"b")
	aadd("rg-yuoki-0",							"y-atomic-constructor",																"c")
	aadd("rg-yuoki-0",							"y-fame-gen",																					"d")
	aadd("rg-yuoki-0",							"y-stargate",																					"e")
	aadd("rg-yuoki-0",							"y_trade_ultimate",																		"f")
	
	aadd("rg-yuoki-1",							"y-ac-wood2uc-recipe",																"a")
	aadd("rg-yuoki-1",							"y-ac-coal2uc-recipe",																"b")
	aadd("rg-yuoki-1",							"y-ac-stone2uc-recipe",																"c")
	aadd("rg-yuoki-1",							"y-ac-copper2uc-recipe",															"d")
	aadd("rg-yuoki-1",							"y-ac-iron2uc-recipe",																"e")
	aadd("rg-yuoki-1",							"y-ac-uc42uc-recipe",																	"f")
	aadd("rg-yuoki-1",							"y-ac-fuel2uc-recipe",																"g")
	aadd("rg-yuoki-1",							"y-uc2liquid-recipe",																	"h")
	
	aadd("rg-yuoki-2",							"y-ac-mud2uc-recipe",																	"a")
	aadd("rg-yuoki-2",							"y-ac-toxic2uc-recipe",																"b")
	aadd("rg-yuoki-2",							"y-ac-slag2uc-recipe",																"c")
	aadd("rg-yuoki-2",							"y-ac-crystal2uc-recipe",															"d")
	aadd("rg-yuoki-2",							"y-heavyoil2uc-recipe",																"e")
	aadd("rg-yuoki-2",							"y-lightoil2uc-recipe",																"f")
	aadd("rg-yuoki-2",							"y-lubricant2uc-recipe",															"g")
	aadd("rg-yuoki-2",							"y-petroleum-recipe",																	"h")
	aadd("rg-yuoki-2",							"y-battery-rip1-recipe",															"i")
	aadd("rg-yuoki-2",							"y_alien_artis1_recipe",															"j")
	
	aadd("rg-yuoki-3",							"y-ac-uc2wood-recipe",																"a")
	aadd("rg-yuoki-3",							"y-ac-uc2coal-recipe",																"b")
	aadd("rg-yuoki-3",							"y-ac-uc2stone-recipe",																"c")
	aadd("rg-yuoki-3",							"y-ac-uc2copper-recipe",															"d")
	aadd("rg-yuoki-3",							"y-ac-uc2iron-recipe",																"e")
	aadd("rg-yuoki-3",							"y-ac-uc2uc4-recipe",																	"f")
	aadd("rg-yuoki-3",							"y-ac-uc2fuel-recipe",																"g")
	aadd("rg-yuoki-3",							"y-liquid2uc-recipe",																	"h")
	
	aadd("rg-yuoki-4",							"y-ac-uc2plastic-recipe",															"a")
	aadd("rg-yuoki-4",							"y_uc2catalyst",																			"b")
	aadd("rg-yuoki-4",							"y-uc2crudeoil-recipe",																"c")
	aadd("rg-yuoki-4",							"y-battery-rip2-recipe",															"d")
	aadd("rg-yuoki-4",							"y_alien_artis2_recipe",															"e")
	
	aadd("rg-yuoki-5",							"y_exchange_a1_recipe",																"a")
	aadd("rg-yuoki-5",							"y_exchange_a4_recipe",																"b")
	aadd("rg-yuoki-5",							"y_exchange_a2_recipe",																"c")
	aadd("rg-yuoki-5",							"y_exchange_a3_recipe",																"d")
	
	aadd("rg-yuoki-6",							"y_exchange_b1_recipe",																"a")
	aadd("rg-yuoki-6",							"y_exchange_b4_recipe",																"b")
	aadd("rg-yuoki-6",							"y_exchange_b2_recipe",																"c")
	aadd("rg-yuoki-6",							"y_exchange_b3_recipe",																"d")
	
	aadd("rg-yuoki-7",							"n-y-ac-uc2b1-recipe",																"a")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b2-recipe",																"b")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b3-recipe",																"c")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b4-recipe",																"d")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b5-recipe",																"e")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b6-recipe",																"f")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b7-recipe",																"g")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b8-recipe",																"h")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b9-recipe",																"i")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b10-recipe",																"j")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b11-recipe",																"k")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b12-recipe",																"l")
	aadd("rg-yuoki-7",							"n-y-ac-uc2b13-recipe",																"m")
	aadd("rg-yuoki-7",							"y_ac_uc2uranore_recipe",															"n")
	
	aadd("rg-yuoki-8",							"n-y-ac-uc2r1-recipe",																"a")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r2-recipe",																"b")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r3-recipe",																"c")
	aadd("rg-yuoki-8",							"y-ac-ucrb4-recipe",																	"d")
	aadd("rg-yuoki-8",							"n-y-ac-ucrb4-recipe",																"d")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r5-recipe",																"e")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r6-recipe",																"f")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r7-recipe",																"g")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r8-recipe",																"h")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r9-recipe",																"i")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r10-recipe",																"j")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r11-recipe",																"k")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r12-recipe",																"l")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r13-recipe",																"m")
	aadd("rg-yuoki-8",							"n-y-ac-uc2r14-recipe",																"n")
	aadd("rg-yuoki-7",							"y_ac_uran2uc_recipe",																"o")
	
	aadd("rg-yuoki-9",							"yi_slayerfame_recipe",																"a")
	aadd("rg-yuoki-9",							"y-fame",																							"b")
	aadd("rg-yuoki-9",							"y_fame_tech_recipe",																	"b")
	aadd("rg-yuoki-9",							"y_greensign",																				"c")
	aadd("rg-yuoki-9",							"y_greensign_ulti-recipe",														"c")
	aadd("rg-yuoki-9",							"ye_science_blue",																		"d")
	aadd("rg-yuoki-9",							"ye_science_blue_recipe",															"d")
	aadd("rg-yuoki-9",							"ypfw_trader_sign",																		"e")
	aadd("rg-yuoki-9",							"y_rwtechsign",																				"f")
	
	if regroup.settings.graphics_tuning then
		rg.set_icon("y-battery-rip1-recipe", "__Regroup__/graphics/icons/battery2unicom.png")
		rg.set_icon("y_alien_artis1_recipe", "__Regroup__/graphics/icons/artifact2unicom.png")
		rg.set_icon("y-battery-rip2-recipe", "__Regroup__/graphics/icons/unicom2battery.png")
		rg.set_icon("y_alien_artis2_recipe", "__Regroup__/graphics/icons/unicom2artifact.png")
	end
	
end
do --[[module]]--
	aadd("rg-module-0",						"ye_green_ultimate",																	"g")
	aadd("rg-module-0",						"ye_science_ultimate",																"h")
	aadd("rg-module-0",						"yi_beacon",																					"i")
	
	aadd("rg-module-2",						"y-speed-module-1",																		"a")
	aadd("rg-module-2",						"y_modul_blue1-recipe",																"aa")
	aadd("rg-module-2",						"y-speed-module-2",																		"b")
	aadd("rg-module-2",						"y_modul_blue2-recipe",																"ba")
	aadd("rg-module-2",						"y-green-module-1",																		"c")
	aadd("rg-module-2",						"y_modul_green1_recipe",															"ca")
	aadd("rg-module-2",						"y-green-module-2",																		"d")
	aadd("rg-module-2",						"y_modul_green2_recipe",															"da")
	aadd("rg-module-2",						"y_modul_green_op",																		"e")
	
	aadd("rg-module-3",						"y_modul_red1",																				"a")
	aadd("rg-module-3",						"y_modul_red2",																				"b")
	aadd("rg-module-3",						"y-pink-module-1",																		"c")
	aadd("rg-module-3",						"y-pink-module-2",																		"d")
	aadd("rg-module-3",						"y-pink-module-3",																		"e")
	
end
do --[[armor]]--
	aadd("rg-armor-5",							"yi_armor_gray",																			"a")
	aadd("rg-armor-5",							"yi_armor_red",																				"b")
	aadd("rg-armor-5",							"yi_armor_gold",																			"c")
	aadd("rg-armor-5",							"yi_walker_a",																				"d")
	aadd("rg-armor-5",							"yi_walker_c",																				"e")
	aadd("rg-armor-5",							"yi_pld_equipment",																		"f")
	
	aadd("rg-armor-6",							"yi_equip_shield_a",																	"a")
	aadd("rg-armor-6",							"yi_equip_battery_a",																	"b")
	aadd("rg-armor-6",							"yi_equip_generator_a",																"c")
	aadd("rg-armor-6",							"yi_equip_legs_a",																		"d")
	aadd("rg-armor-6",							"yi_minigun",																					"e")
	aadd("rg-armor-6",							"yi_equip_shield_b",																	"f")
	aadd("rg-armor-6",							"yi_lasergun",																				"g")
	aadd("rg-armor-6",							"yi_ammo_energie",																		"h")
	aadd("rg-armor-6",							"yi_equip_roboport",																	"i")
	aadd("rg-armor-6",							"yi_equip_pld_recipe",																"j")
	
end
do --[[decorative]]--
	aadd("rg-decorative-4",				"y_lamp_red",																					"c")
	aadd("rg-decorative-4",				"y_lamp_green",																				"d")
	aadd("rg-decorative-4",				"y_lamp_blue",																				"e")
	aadd("rg-decorative-4",				"y_lamp_yellow",																			"f")
	aadd("rg-decorative-4",				"y-tinylamp",																					"g")
	aadd("rg-decorative-4",				"y-powerlamp",																				"h")
	aadd("rg-decorative-4",				"y-lamp-alien",																				"i")
	aadd("rg-decorative-4",				"y_old_bodenlampe",																		"j")
	aadd("rg-decorative-4",				"y_lampe_neotix",																			"k")
	aadd("rg-decorative-4",				"y_lampe_yuoki",																			"l")
	aadd("rg-decorative-4",				"y_lampe_corner",																			"m")
	aadd("rg-decorative-4",				"y_lampe_44basement_a",																"o")
	aadd("rg-decorative-4",				"y_lampe_44basement_b",																"p")
	aadd("rg-decorative-4",				"y_lampe_66basement",																	"q")
	
	
	aadd("rg-decorative-6",				"y_tile_slagfilled",																	"a")
	aadd("rg-decorative-6",				"y_tile_slagpattern",																	"e")
	aadd("rg-decorative-6",				"y_tile_slagbricks",																	"g")
	
	aadd("rg-decorative-8",				"yi_bug1",																						"i")
	aadd("rg-decorative-8",				"yi-monument1",																				"j")
	aadd("rg-decorative-8",				"yi_hny1",																						"k")
	aadd("rg-decorative-8",				"yi_hny2",																						"l")
	
	aadd("rg-decorative-14",				"yir_wood4_tile",																			"e")
end
do --[[other]]--
	
end
do --[[TECH]]--

	if regroup.settings.yuoki_tech and i_exist("y-unicomp-raw") and data.raw.technology["yi-basic-mechanical-force"] == nil then
		
		local s_pack = "high-tech-science-pack"
		if data.raw.tool["science-pack-4"] then s_pack = "science-pack-4" end
		data:extend({
			{
				type = "technology",
				name = "yuoki_technology",
				icon = "__Regroup__/graphics/icons/tech/yuoki_research.png",
				icon_size = 64,
				unit = {
					count = 15,
					time = 30,
					ingredients = {
						{"science-pack-1",1}
					}
				},
				order = "y-0"
			},
			{
				type = "technology",
				name = "yuoki_industries",
				icon = "__Regroup__/graphics/icons/tech/yuoki_industries.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[a]"
			},
			{
				type = "technology",
				name = "yuoki_energy",
				icon = "__Regroup__/graphics/icons/tech/yuoki_energy.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[b]"
			},
			{
				type = "technology",
				name = "yuoki_liquids",
				icon = "__Regroup__/graphics/icons/tech/yuoki_liquids.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[c]"
			},
			{
				type = "technology",
				name = "yuoki_def",
				icon = "__Regroup__/graphics/icons/tech/yuoki_defence.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[d]"
			},
			{
				type = "technology",
				name = "yuoki_atomics",
				icon = "__Regroup__/graphics/icons/tech/yuoki_atomics.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries", "yuoki_energy", "yuoki_liquids"},
				effects = {},
				unit = {
					count = 50,
					time = 120,
					ingredients = {
						{"science-pack-1",4},
						{"science-pack-2",3},
						{"science-pack-3",2},
						{s_pack,1}
					}
				},
				order = "y-1[e]"
			}
		})
		data:extend({
			{
				type = "technology",
				name = "yuoki_industries-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_industries.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries"},
				effects = {},
				unit = {
					count = 25,
					time = 45,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-2[a]"
			},
			{
				type = "technology",
				name = "yuoki_industries-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_industries.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries-2"},
				effects = {},
				unit = {
					count = 50,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[a]"
			},
			{
				type = "technology",
				name = "yuoki_industries-4",
				icon = "__Regroup__/graphics/icons/tech/yuoki_industries.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries-3"},
				effects = {},
				unit = {
					count = 75,
					time = 90,
					ingredients = {
						{"science-pack-1",4},
						{"science-pack-2",3},
						{"science-pack-3",2},
						{s_pack,1}
					}
				},
				enabled = false,
				order = "y-4[a]"
			},
			{
				type = "technology",
				name = "yuoki_energy-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_energy.png",
				icon_size = 64,
				prerequisites = {"yuoki_energy"},
				effects = {},
				unit = {
					count = 50,
					time = 45,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				enabled = false,
				order = "y-2[b]"
			},
			{
				type = "technology",
				name = "yuoki_energy-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_energy.png",
				icon_size = 64,
				prerequisites = {"yuoki_energy-2"},
				effects = {},
				unit = {
					count = 75,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[b]"
			},
			{
				type = "technology",
				name = "yuoki_liquids-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_liquids.png",
				icon_size = 64,
				prerequisites = {"yuoki_liquids"},
				effects = {},
				unit = {
					count = 50,
					time = 45,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				enabled = false,
				order = "y-2[c]"
			},
			{
				type = "technology",
				name = "yuoki_liquids-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_liquids.png",
				icon_size = 64,
				prerequisites = {"yuoki_liquids-2"},
				effects = {},
				unit = {
					count = 75,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[c]"
			},
			{
				type = "technology",
				name = "yuoki_def-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_defence.png",
				icon_size = 64,
				prerequisites = {"yuoki_def","yuoki_industries-2"},
				effects = {},
				unit = {
					count = 50,
					time = 45,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				enabled = false,
				order = "y-2[d]"
			},
			{
				type = "technology",
				name = "yuoki_def-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_defence.png",
				icon_size = 64,
				prerequisites = {"yuoki_def-2","yuoki_industries-3"},
				effects = {},
				unit = {
					count = 75,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[d]"
			},
			{
				type = "technology",
				name = "yuoki_atomics-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_atomics.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries-2","yuoki_energy-2","yuoki_liquids-2","yuoki_atomics"},
				effects = {},
				unit = {
					count = 75,
					time = 150,
					ingredients = {
						{"science-pack-1",4},
						{"science-pack-2",3},
						{"science-pack-3",2},
						{s_pack,1}
					}
				},
				enabled = false,
				order = "y-2[e]"
			},
			{
				type = "technology",
				name = "yuoki_atomics-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_atomics.png",
				icon_size = 64,
				prerequisites = {"yuoki_industries-3","yuoki_energy-3","yuoki_atomics-2"},
				effects = {},
				unit = {
					count = 100,
					time = 180,
					ingredients = {
						{"science-pack-1",4},
						{"science-pack-2",3},
						{"science-pack-3",2},
						{s_pack,1}
					}
				},
				enabled = false,
				order = "y-3[e]"
			}
		})
		
		-- yuoki_technology
		-- yuoki_industries-4
		-- yuoki_energy-3
		-- yuoki_liquids-3
		-- yuoki_def-3
		-- yuoki_atomics-3
		
		do --# gathering
			rg.add_recipe_to_tech("yuoki_industries",			"y-mining-drill-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-underground-drill-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-mc_underground-drill-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-dirtwasher-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_c11_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-mining-drill-e2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_c22_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_cg33_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-repair-durotal-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_mc_dirtwasher_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_mc_e2_mining_drill_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_mc_underground_drill_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_sc44_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y-repair-krakon-recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_quantrinum_hammer_recipe")
			
			rg.add_recipe_to_tech("yuoki_liquids",				"y-water-gen-recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y-water-gen-fluid-recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"rg-lithia-water")
			rg.add_recipe_to_tech("yuoki_liquids",				"y-tank-4500-recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_buffer_station")
			
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-water-gen-recipe-e")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y_water_mixer_recipe")
			
			rg.add_recipe_to_tech("yuoki_liquids-3",				"y-tank-24k")
			
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y_repair_quantrinum-recipe")
		end
		do --# production
			rg.add_recipe_to_tech("yuoki_industries",			"y-crusher-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_smelter_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-water-mixer")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_crusher2_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-heat-form-press-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_charger_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_formpress2_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-atomic-quantum-composer-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_maintance_workshop_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y-alien-infuser-recipe")
		end
		do --# plates
			rg.add_recipe_to_tech("yuoki_industries",			"y-refined-iron")
			rg.add_recipe_to_tech("yuoki_industries",			"y-refined-copper")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_hps_pureiron_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_hps_purecopper_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_hps_steel_recipe")
		end
		do --# chemistry
			rg.add_recipe_to_tech("yuoki_liquids",				"y_coal2liquid")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_ft_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_rawsyngas1_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_rawsyngas2_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_refinehydrogen_recipe")
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y_water_mix_recipe")
		end
		do --# automatization
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-inserter-s4-recipe")
		end
		do --# transport
			rg.add_recipe_to_tech("yuoki_liquids",				"y_flowcheck_10_recipe")
		end
		do --# logistic
			rg.add_recipe_to_tech("yuoki_industries-2",			"yi_roboport_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"yi_logistic-robot_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"yi_construction-robot_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-rare-chest-log-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-rare-m1bunker-log-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_pc22_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_rc22_recipe")
		end
		do --# energy
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_obninsk_mc_recipe")
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_steam_turbine_mc_recipe")
			
			rg.add_recipe_to_tech("yuoki_energy",					"y-substation-m-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-accumulator-m-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-accumulator-mt2-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-notfall-generator-s2-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-steam-turbine-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-boiler-t2-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-boiler-t3-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-boiler-iv-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-meg-s-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-solar-dish-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-wooden-brikett-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-coal-brikett-recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y-coaldust-mixing-recipe")
			
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-substation-h-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-accumulator-b-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-accumulator-bt2-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-ups-flywheel-b-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-obninsk-turbine-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-obninsk-reactor-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-beg-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y_alien_solar_recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-mixfuel-load-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-wooden-brikett-packed-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-coal-stack-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-infused-mud-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-tinylamp-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-powerlamp-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y-lamp-alien-recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y_old_bodenlampe_recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y_lampe_neotix_recipe")
			rg.add_recipe_to_tech("yuoki_energy-2",				"y_lampe_yuoki_recipe")
			
			rg.add_recipe_to_tech("yuoki_energy-3",				"y-accumulator-btx-recipe")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y-accumulator-crystal-m-recipe")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y_compensator_25_recipe")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y-heg-recipe")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y_boiler_sh")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y_alien_solar2_recipe")
			
		end
		do --# defense
			rg.add_recipe_to_tech("yuoki_def",						"y-mud-wall-recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y-rare-wall-basic-recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y_turret_flame_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y-gun-turret-mk2-recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y-bullet-case-recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y_ammo_case_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y_ammo_flame_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"y-ammo-hohlspitz-recipe")
			
			rg.add_recipe_to_tech("yuoki_def-2",					"y-rare-wall-adv-recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y_turret_plasma_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y-gun-turret-mk3-recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y_laser_mk1_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_radar_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y-ammo-krakon-recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y-ammo-biggun-recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"y_ammo_plasma_recipe")
			
			rg.add_recipe_to_tech("yuoki_def-3",					"y_wall22_hardic_recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y-wall-forcefield-recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y_laser_onhwall_recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y-weapon-ztt-recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y-ammo-explosiv-recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y-ammo-poison-recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"y-ammo-acid-medium-recipe")
		end
		do --# parts
			rg.add_recipe_to_tech("yuoki_industries",			"y-heat-pipe-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-bluegear-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_structure_element_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_structure_vessel_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_dotzetron_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_chip_plate_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y_gauge_analog_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_drillhead_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_toolhead_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-basic-st1-mf-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-conductive-wire-1-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"yi_magnetron_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-chip1-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-basic-st2-mf-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-conductive-coil-1-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-chip2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_blocked_capa_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_drillhead_repair_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_toolhead_repair_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries",			"y-crush-unicomp-raw-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-crush-fuel-raw-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-smelt-crush-res1-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-unicomp-raw-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-pure-iron-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-pure-copper-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-digfdirt-recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-release-cwater")
			rg.add_recipe_to_tech("yuoki_industries",			"y-wash-dirt-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-filtering-dust-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-smelt-crush-res2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-mixing-rich-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-smelt-richdust-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_block_cold_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_block_heat_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-quantrinum-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_data_crystal_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-crystal-cnd-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-digfdirt2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-press-richdust-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-pressed_dry_mud-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_slag_granulate_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_slag_brick_recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_pure_iron_wtool_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_pure_copper_wtool_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-crush-blue_whead-recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-crush-green_whead-recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_quantrinum_infusion_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-wash-special-recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_slag_brick_burn_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-raw-fuelnium-recipe")
			
			rg.add_recipe_to_tech("yuoki_energy",					"y-coaldust-recipe")
			
			rg.add_recipe_to_tech("yuoki_energy-3",				"y-fuel-reactor-recipe")
			rg.add_recipe_to_tech("yuoki_energy-3",				"y-infused-uca2-recipe")
			
			rg.add_recipe_to_tech("yuoki_liquids",				"y_granulate_wood_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_catalyst_bp_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_catalyst_ft_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_regcatbp_recipe")
			rg.add_recipe_to_tech("yuoki_liquids",				"y_regcatft_recipe")
			
			rg.add_recipe_to_tech("yuoki_liquids-2",				"y-sulfuric-acid-recipe")
		end
		do --# intermediate
			rg.add_recipe_to_tech("yuoki_industries",			"y_blocked_capa_recipe")
			rg.add_recipe_to_tech("yuoki_industries",			"y-battery-singleuse1-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-battery-singleuse2-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-battery-single-use3-recipe")
		end
		do --# yuoki
			rg.add_recipe_to_tech("y-atomic-constructor-recipe")
			rg.add_recipe_to_tech("y-ac-wood2uc-recipe")
			rg.add_recipe_to_tech("y-ac-coal2uc-recipe")
			rg.add_recipe_to_tech("y-ac-stone2uc-recipe")
			rg.add_recipe_to_tech("y-ac-copper2uc-recipe")
			rg.add_recipe_to_tech("y-ac-iron2uc-recipe")
			rg.add_recipe_to_tech("y-ac-uc42uc-recipe")
			rg.add_recipe_to_tech("y-ac-fuel2uc-recipe")
			rg.add_recipe_to_tech("y-uc2liquid-recipe")
			rg.add_recipe_to_tech("y-ac-uc2wood-recipe")
			rg.add_recipe_to_tech("y-ac-uc2coal-recipe")
			rg.add_recipe_to_tech("y-ac-uc2stone-recipe")
			rg.add_recipe_to_tech("y-ac-uc2copper-recipe")
			rg.add_recipe_to_tech("y-ac-uc2iron-recipe")
			rg.add_recipe_to_tech("y-ac-uc2uc4-recipe")
			rg.add_recipe_to_tech("y-ac-uc2fuel-recipe")
			rg.add_recipe_to_tech("y-liquid2uc-recipe")
			rg.add_recipe_to_tech("y_exchange_a1_recipe")
			rg.add_recipe_to_tech("y_exchange_a4_recipe")
			rg.add_recipe_to_tech("y_exchange_a2_recipe")
			rg.add_recipe_to_tech("y_exchange_a3_recipe")
			rg.add_recipe_to_tech("y_exchange_b1_recipe")
			rg.add_recipe_to_tech("y_exchange_b4_recipe")
			rg.add_recipe_to_tech("y_exchange_b2_recipe")
			rg.add_recipe_to_tech("y_exchange_b3_recipe")
			rg.add_recipe_to_tech("yi_slayerfame_recipe")
			
			rg.add_recipe_to_tech("n-y-ac-uc2b1-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b3-recipe")
			rg.add_recipe_to_tech("y-ac-ucrb4-recipe")
			rg.add_recipe_to_tech("n-y-ac-ucrb4-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b5-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b6-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b7-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b8-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b9-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b10-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b11-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b12-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2b13-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r1-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r2-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r3-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r4-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r5-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r6-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r7-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r8-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r9-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r10-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r11-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r12-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r13-recipe")
			rg.add_recipe_to_tech("n-y-ac-uc2r14-recipe")
			
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y_fame_tech_recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-ac-mud2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-ac-toxic2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-ac-slag2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-ac-crystal2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-heavyoil2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-lightoil2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-lubricant2uc-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-petroleum-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-battery-rip1-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y_alien_artis1_recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-ac-uc2plastic-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y_uc2catalyst")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-uc2crudeoil-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y-battery-rip2-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-2",				"y_alien_artis2_recipe")
			
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y-stargate-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y-fame-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y_greensign_ulti-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"ye_science_blue_recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"ypfw_trader_sign")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y_rwtechsign")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y-fame-gen-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y-sgtrade-ic1-recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"ye_green_ultimate_recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"ye_science_ultimate_recipe")
			rg.add_recipe_to_tech("yuoki_atomics-3",				"y_trade_ultimate")
		end
		do --# module
			rg.add_recipe_to_tech("yuoki_industries-2",			"yi_beacon_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_modul_blue1-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_modul_blue2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_modul_green1_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_modul_green2_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y-pink-module-1-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_modul_red1_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_modul_red2_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-pink-module-2-recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y-pink-module-3-recipe")
			
			rg.add_recipe_to_tech("yuoki_industries-4",			"y_modul_green_op_recipe")
		end
		do --# armor
			rg.add_recipe_to_tech("yuoki_def",						"yi_armor_gray_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_armor_red_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_armor_gold_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_walker_a_recipe")
			rg.add_recipe_to_tech("yuoki_def-3",					"yi_walker_c_recipe")
			
			rg.add_recipe_to_tech("yuoki_def",						"yi_equip_shield_a_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_equip_battery_a_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_equip_generator_a_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_equip_legs_a_recipe")
			rg.add_recipe_to_tech("yuoki_def",						"yi_minigun_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_equip_shield_b_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_lasergun_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_ammo_energie_recipe")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_equip_roboport")
			rg.add_recipe_to_tech("yuoki_def-2",					"yi_equip_pld_recipe")
		end
		do --# decorative
			rg.add_recipe_to_tech("yuoki_industries",			"y_tile_slagfilled_recipe")
			rg.add_recipe_to_tech("yuoki_industries-2",			"y_tile_slagpattern_recipe")
			rg.add_recipe_to_tech("yuoki_industries-3",			"y_tile_slagbricks_recipe")
			
			rg.add_recipe_to_tech("yuoki_energy",					"y_lamp_red_recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y_lamp_green_recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y_lamp_blue_recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"y_lamp_yellow_recipe")
			rg.add_recipe_to_tech("yuoki_energy",					"yi_bug1_recipe")
			
			rg.add_recipe_to_tech("yuoki_energy-3",				"yi-monument1-recipe")
		end
		
	end
end
end