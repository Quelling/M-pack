local allow_changes = regroup.settings.nputils

if i_exist("n-cable") and allow_changes then
	data.raw["item-group"]["NPUtils"].icon = "__Regroup__/graphics/icons/cat/NPUtils.png"
	data.raw["item-group"]["NPUtils"].icon_size = 64
end
if i_exist("n-small-pole") and allow_changes then
	data.raw["item-group"]["NPUtils-War"].icon = "__Regroup__/graphics/icons/cat/NPUtils-War.png"
	data.raw["item-group"]["NPUtils-War"].icon_size = 64
end

do	--[[gathering]]--
end
do	--[[production]]--
end
do	--[[resources]]--
end
do	--[[plates]]--
end
do	--[[liquids]]--
end
do	--[[chemistry]]--
end
do	--[[automatization]]--
end
do	--[[transport]]--
end
do	--[[logistic]]--
end
do	--[[energy]]--
end
do	--[[defense]]--
end
do	--[[armor]]--
end
do	--[[intermediate]]--
end
do	--[[module]]--
end
do	--[[weaponry]]--
end
do	--[[trains-vehicles]]--
	aadd("rg-vehicles-4",					"n-survivalist-car",																	"a")
	aadd("rg-vehicles-4",					"n-survivalist-c-car",																"b")
	aadd("rg-vehicles-4",					"n-survivalist-g-car",																"c")
	aadd("rg-vehicles-4",					"n-survivalist-r-car",																"d")
	aadd("rg-vehicles-4",					"n-s-survivalist-car",																"e")
	aadd("rg-vehicles-4",					"n-s-survivalist-c-car",															"f")
	aadd("rg-vehicles-4",					"n-s-survivalist-g-car",															"g")
	aadd("rg-vehicles-4",					"n-s-survivalist-r-car",															"h")
	aadd("rg-vehicles-5",					"n-p-survivalist-car",																"i")
	aadd("rg-vehicles-5",					"n-p-survivalist-c-car",															"j")
	aadd("rg-vehicles-5",					"n-p-survivalist-g-car",															"k")
	aadd("rg-vehicles-5",					"n-p-survivalist-r-car",															"l")
	aadd("rg-vehicles-6",					"n-trash-car",																				"a")
end
do	--[[alien]]--
end
do  --[[atomic]]--
	if i_exist("n-power") then
	aadd("rg-atomic-3",						"n-power",																						"a")
	aadd("rg-atomic-3",						"n-chem-fuel-empty",																	"b")
	aadd("rg-atomic-3",						"n-chem-fuel-1",																			"c")
	aadd("rg-atomic-3",						"n-chem-fuel-2",																			"d")
	aadd("rg-atomic-3",						"n-chem-fuel-3",																			"e")
	aadd("rg-atomic-3",						"n-chem-fuel-4",																			"f")
	aadd("rg-atomic-3",						"n-chem-inf-fuel-1",																	"g")
	aadd("rg-atomic-3",						"n-chem-inf-fuel-2",																	"h")
	aadd("rg-atomic-3",						"n-chem-inf-fuel-3",																	"i")
	aadd("rg-atomic-3",						"n-chem-inf-fuel-4",																	"j")
	
	aadd("rg-atomic-4",						"n-enr-alienol",																			"a")
	aadd("rg-atomic-4",						"n-enr-heavy",																				"b")
	aadd("rg-atomic-4",						"n-enr-light",																				"c")
	aadd("rg-atomic-4",						"n-enr-petroleum",																		"d")
	
	aadd("rg-atomic-5",						"n-heat-pipe",																				"a")
	aadd("rg-atomic-5",						"n-adv-heat-pipe",																		"b")
	
	aadd("rg-atomic-6",						"n-heat-gen",																					"a")
	aadd("rg-atomic-6",						"n-chem-heat-gen",																		"b")
	
	aadd("rg-atomic-7",						"n-heat-boi",																					"a")
	aadd("rg-atomic-7",						"n-chem-heat-boi",																		"b")
	
	aadd("rg-atomic-8",						"n-watts-eater",																			"a")
	end
end
do --[[barreling]]--
end
do --[[other]]--
end