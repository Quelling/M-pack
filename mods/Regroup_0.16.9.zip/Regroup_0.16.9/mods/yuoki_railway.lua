local allow_changes = regroup.settings.yuoki_rail

function i_exist(item)
	for _,v in pairs(rg.name_list) do
		if tostring(v) == item then return true end
	end
	return false
end

do	--[[transport]]--
	aadd("rg-transport-10",					"y_loco_access-pipe-in",															"e")
	aadd("rg-transport-10",					"y_loco_access-pipe-out",															"f")
end
do	--[[liquids]]--
	if regroup.settings.liquid_move then
	aadd("rg-chemistry-10",				"yir_fuel_fluid_u1",																	"e")
	aadd("rg-chemistry-10",				"yir_fuel_fluid_u2",																	"f")
	aadd("rg-chemistry-19",				"yir_fuel_fluid_u3",																	"g")
	else
	aadd("rg-liquids-7",						"yir_fuel_fluid_u1",																	"a")
	aadd("rg-liquids-7",						"yir_fuel_fluid_u2",																	"b")
	aadd("rg-liquids-7",						"yir_fuel_fluid_u3",																	"c")
	end
end
do	--[[resources]]--
	aadd("rg-resources-1",					"yir_fuel_energy",																		"j")
	aadd("rg-resources-1",					"yir_fuel_energy_u1",																	"k")
	aadd("rg-resources-1",					"yir_fuel_coks",																			"l")
	aadd("rg-resources-1",					"yir_fuel_diesel",																		"m")
	
	--ahide("yir_fuel_coks")
	--ahide("yir_fuel_diesel")
end
do	--[[energy]]--
end
do	--[[trains-vehicles]]--
	aadd("rg-trains-8",						"yir_cw_trans_4a",																		"a")
	aadd("rg-trains-8",						"yir_cw_empty_4a",																		"b")
	aadd("rg-trains-8",						"yir_cw_uran_4a",																			"c")
	aadd("rg-trains-8",						"yir_cw_flourit_4a",																	"d")
	aadd("rg-trains-8",						"yir_es44cr",																					"e")
	aadd("rg-trains-8",						"yir_wagon_cabose_cr",																"f")
	aadd("rg-trains-8",						"yir_4a_conatiner_cr",																"g")
	aadd("rg-trains-8",						"yir_4a_clean_cr",																		"h")
	
	-- production
	aadd("rg-trains-9",						"yir_emdf7a_cr",																			"a")
	aadd("rg-trains-9",						"yir_emdf7a_mn",																			"b")
	aadd("rg-trains-9",						"yir_emdf7b_cr",																			"c")
	aadd("rg-trains-9",						"yir_emdf7b_mn",																			"d")
	aadd("rg-trains-9",						"yir_factory_loco",																		"e")
	aadd("rg-trains-9",						"yir_factory_chemical",																"f")
	aadd("rg-trains-9",						"yir_factory_wagon",																	"g")
	aadd("rg-trains-9",						"yir_factory_material",																"h")
	aadd("rg-trains-9",						"yir_factory_tiles",																	"i")
	aadd("rg-trains-9",						"yir_factory_stuff",																	"j")
	
	aadd("rg-trains-20",						"yir_coin",																						"a")
	aadd("rg-trains-20",						"yir_diesel_coin",																		"b")
	aadd("rg-trains-20",						"yir_future_coin",																		"c")
	
	-- parts
	aadd("rg-trains-21",						"yir_frame_loco_steam",																"a")
	aadd("rg-trains-21",						"yir_frame_loco_diesel",															"b")
	aadd("rg-trains-21",						"yir_frame_loco_future",															"c")
	aadd("rg-trains-21",						"yir_frame_waggon",																		"d")
	aadd("rg-trains-21",						"yir_radsatz_locos",																	"e")
	aadd("rg-trains-21",						"yir_radsatz_waggon",																	"f")
	
	-- colors
	aadd("rg-trains-22",						"z_yira_4a_cw_yiblue",																"a")
	aadd("rg-trains-22",						"z_yira_4a_cw_yigreen",																"b")
	aadd("rg-trains-22",						"z_yira_4a_yiblue",																		"c")
	aadd("rg-trains-22",						"z_yira_4a_yigreen",																	"d")
	aadd("rg-trains-22",						"yir_color_white",																		"e")
	aadd("rg-trains-22",						"yir_color_black",																		"f")
	aadd("rg-trains-22",						"yir_color_red",																			"g")
	aadd("rg-trains-22",						"yir_color_green",																		"h")
	aadd("rg-trains-22",						"yir_color_blue",																			"i")
	aadd("rg-trains-22",						"yir_kr_green",																				"j")
	
	-- loco 1
	aadd("rg-trains-23",						"y_loco_diesel_620",																	"a")
	aadd("rg-trains-23",						"z_yira_4a_cw_energy",																"b")
	aadd("rg-trains-23",						"z_yira_4a_cw_eb1",																		"c")
	aadd("rg-trains-23",						"z_yira_4a_cw_gears",																	"d")
	aadd("rg-trains-23",						"z_yira_4a_cw_kiste1",																"e")
	aadd("rg-trains-23",						"z_yira_4a_cw_ziegelgrau",														"f")
	aadd("rg-trains-23",						"z_yira_4a_cw_ziegelrot",															"g")
	
	-- loco 1
	aadd("rg-trains-24",						"y_loco_ses_std",																			"a")
	aadd("rg-trains-24",						"y_loco_ses_red",																			"b")
	aadd("rg-trains-24",						"yir_loco_fut_red",																		"c")
	aadd("rg-trains-24",						"yir_loco_sel_blue",																	"d")
	aadd("rg-trains-24",						"y_loco_fs_steam_green",															"e")
	aadd("rg-trains-24",						"y_loco_steam_wt450",																	"f")
	aadd("rg-trains-24",						"yir_loco_steam_wt580of",															"g")
	aadd("rg-trains-24",						"y_wagon_tender_black",																"h")
	aadd("rg-trains-24",						"y_wagon_tender_green",																"i")
	aadd("rg-trains-24",						"yir_loco_del_mk1400",																"j")
	aadd("rg-trains-24",						"y_loco_emd3000_white",																"k")
	aadd("rg-trains-24",						"yir_loco_del_bluegray",															"l")
	aadd("rg-trains-24",						"yir_loco_de_bluegray_recipe",												"m")
	aadd("rg-trains-24",						"yir_loco_del_KR",																		"n")
	aadd("rg-trains-24",						"y_loco_diesel_620",																	"o")
	
	-- loco 2 Amer
	aadd("rg-trains-25",						"y_loco_emd1500black",																"a")
	aadd("rg-trains-25",						"y_loco_emd1500black_v2",															"b")
	aadd("rg-trains-25",						"y_loco_emd1500blue",																	"c")
	aadd("rg-trains-25",						"y_loco_emd1500blue_v2",															"d")
	aadd("rg-trains-25",						"yir_loco_fesw_op",																		"e")
	aadd("rg-trains-25",						"y_loco_desw",																				"f")
	aadd("rg-trains-25",						"y_loco_desw_orange",																	"g")
	aadd("rg-trains-25",						"y_loco_desw_blue",																		"h")
	aadd("rg-trains-25",						"yir_es44cr",																					"i")
	
	-- loco 3 UP&Industries&Amer
	aadd("rg-trains-26",						"y_3acw_T10K",																				"a")
	aadd("rg-trains-26",						"yir_mre044",																					"b")
	aadd("rg-trains-26",						"yir_lsw_840green",																		"c")
	aadd("rg-trains-26",						"yir_lsw_r790orange",																	"d")
	aadd("rg-trains-26",						"yir_lsw_r790red",																		"e")
	aadd("rg-trains-26",						"yir_emdf7a_cr",																			"f")
	aadd("rg-trains-26",						"yir_emdf7a_mn",																			"g")
	aadd("rg-trains-26",						"yir_atom_header",																		"h")
	aadd("rg-trains-26",						"yir_atom_mitte",																			"i")
	
	-- wagon 5 UP&Amer
	aadd("rg-trains-27",						"z_yira_4a_cw_yiblue",																"a")
	aadd("rg-trains-27",						"z_yira_4a_cw_yigreen",																"b")
	aadd("rg-trains-27",						"yir_cw_cargo_blue",																	"c")
	aadd("rg-trains-27",						"yir_cw_cargo_green",																	"d")
	aadd("rg-trains-27",						"z_yira_4a_cw_steel",																	"e")
	aadd("rg-trains-27",						"z_yira_6a_maai1",																		"f")
	aadd("rg-trains-27",						"yir_wagon_caboose_cr_crrecipe",											"g")
	aadd("rg-trains-27",						"yir_wagon_caboose_cr",																"h")
	aadd("rg-trains-27",						"yir_4a_container_crrecipe",													"i")
	aadd("rg-trains-27",						"yir_4a_container_cr",																"j")
	aadd("rg-trains-27",						"yir_4a_clean_cr",																		"k")
	
	-- wagon 1 Amer
	aadd("rg-trains-28",						"yir_2acw_wood",																			"a") 
	aadd("rg-trains-28",						"y_wagon_coal",																				"b")
	aadd("rg-trains-28",						"y_wagon_stone",																			"c")
	aadd("rg-trains-28",						"y_wagon_copper",																			"d")
	aadd("rg-trains-28",						"y_wagon_iron",																				"e")
	aadd("rg-trains-28",						"yir_emdf7b_cr",																			"f")
	aadd("rg-trains-28",						"yir_emdf7b_mn",																			"g")
			
	-- wagon 2
	aadd("rg-trains-29",						"y_wagon_closed",																			"a")
	aadd("rg-trains-29",						"yir_wagon2a_closed_recipe",													"b")
	aadd("rg-trains-29",						"y_wagon_trans",																			"c")
	aadd("rg-trains-29",						"yir_2acw_3blocks",																		"d")
	aadd("rg-trains-29",						"y_wagon_corn_green",																	"e")
	aadd("rg-trains-29",						"y_wagon_corn_blue",																	"f")
	aadd("rg-trains-29",						"y_wagon_hopper_yellow",															"g")
	
	-- wagon 3
	aadd("rg-trains-40",						"yir_4acw_grey",																			"a")
	aadd("rg-trains-40",						"yir_4acw_oceanblue",																	"b")
	aadd("rg-trains-40",						"yir_4acw_purple",																		"c")
	aadd("rg-trains-40",						"y_wagon_zement_gray",																"d")
	aadd("rg-trains-40",						"y_wagon_zement_white",																"e")
	
	-- wagon 4
	aadd("rg-trains-41",						"y_wagon_tank_fm1",																		"a")
	aadd("rg-trains-41",						"y_wagon_tank_fm2",																		"b")
	aadd("rg-trains-41",						"y_wagon_tank_blue",																	"c")
	aadd("rg-trains-41",						"yir_wagon2a_tank_blue_recipe",												"d")
	aadd("rg-trains-41",						"y_wagon_tank_orange",																"e")
	aadd("rg-trains-41",						"yir_wagon2a_tank_orange_recipe",											"f")
	
	-- wagon 5
	aadd("rg-trains-42",						"z_yira_4a_cw_kisten",																"a") 
	aadd("rg-trains-42",						"z_yira_4a_cw_stuff1",																"b") 
	aadd("rg-trains-42",						"yir_4acw_wood",																			"c")
	aadd("rg-trains-42",						"yir_4acw_coal",																			"d")
	aadd("rg-trains-42",						"yir_4acw_copper",																		"e")
	aadd("rg-trains-42",						"yir_4acw_iron",																			"f")
	aadd("rg-trains-42",						"yir_4acw_stone",																			"g")
	
	-- wagon 6
	aadd("rg-trains-43",						"yir_4acw_closed",																		"a")
	aadd("rg-trains-43",						"yir_4acw_gold",																			"b")
	aadd("rg-trains-43",						"yir_4acw_mun",																				"c")
	aadd("rg-trains-43",						"yir_4acw_tf",																				"d")
	aadd("rg-trains-43",						"yir_4acw_vc",																				"e")
	aadd("rg-trains-43",						"yir_fw4_vc",																					"f")
	aadd("rg-trains-43",						"yir_fw4a_tank_oil",																	"g")
	
	-- wagon 7 Industries
	aadd("rg-trains-44",						"yir_cw_flourit",																			"a")
	aadd("rg-trains-44",						"yir_cw_flourit_4a",																	"b")
	aadd("rg-trains-44",						"yir_cw_uranite",																			"c")
	aadd("rg-trains-44",						"yir_cw_uran_4a",																			"d")
	aadd("rg-trains-44",						"yir_cw_4a_urana",																		"e")
	aadd("rg-trains-44",						"yir_cw_upempty",																			"f")
	aadd("rg-trains-44",						"yir_cw_empty_4a",																		"g")
	aadd("rg-trains-44",						"yir_cw_upclosed",																		"h")
	aadd("rg-trains-44",						"yir_cw_trans_4a",																		"i")
	aadd("rg-trains-44",						"yir_cw_4a_cellsu",																		"j")
end
do	--[[decorative]]--	
	aadd("rg-decorative-4",				"yir_lamp_modern",																		"m")
	aadd("rg-decorative-4",				"yir_lamp_old1",																			"n")
	aadd("rg-decorative-4",				"yir_lamp_clock",																			"o")
	
	aadd("rg-decorative-5",				"y_path_slag",																				"a")
	aadd("rg-decorative-5",				"yir_copper_tile",																		"b")
	aadd("rg-decorative-5",				"yir_iron_tile",																			"c")
	aadd("rg-decorative-5",				"y_path_labor",																				"d")
	aadd("rg-decorative-5",				"y_path_checker",																			"e")
	aadd("rg-decorative-5",				"yir_stony_tile",																			"f")
	aadd("rg-decorative-5",				"yir_grating_tile",																		"g")
	aadd("rg-decorative-5",				"y_path_science",																			"h")
	aadd("rg-decorative-5",				"y_tgb",																							"i")
	aadd("rg-decorative-5",				"y_tring",																						"j")
	
	aadd("rg-decorative-6",				"yir_wood1_tile",																			"a")
	aadd("rg-decorative-6",				"yir_wood2_tile",																			"b")
	aadd("rg-decorative-6",				"yir_wood3_tile",																			"c")
	aadd("rg-decorative-6",				"yir_ground1_tile",																		"d")
	aadd("rg-decorative-6",				"yir_plates2_tile",																		"f")
	aadd("rg-decorative-6",				"yir_muster1_tile",																		"g")
	aadd("rg-decorative-6",				"yir_brick2_tile",																		"i")
	aadd("rg-decorative-6",				"yir_brick1_tile",																		"j")
	
	aadd("rg-decorative-7",				"yir_metal1_tile",																		"a")
	aadd("rg-decorative-7",				"yir_metal2_tile",																		"b")
	aadd("rg-decorative-7",				"yir_metal3_tile",																		"c")
	aadd("rg-decorative-7",				"yir_metal4_tile",																		"d")
	aadd("rg-decorative-7",				"yir_metal5_tile",																		"e")
	aadd("rg-decorative-7",				"yir_tile3_tile",																			"f")
	aadd("rg-decorative-7",				"yir_tile2_tile",																			"g")
	aadd("rg-decorative-7",				"yir_tile1_tile",																			"h")
	aadd("rg-decorative-7",				"yir_blue_tile",																			"i")
	
	aadd("rg-decorative-8",				"yir_diesel_monument",																"k")
	aadd("rg-decorative-8",				"yir_future_monument",																"l")
	
	ahide("y_tile_slagfilled")
	ahide("yir_wood4_tile")
	
	rg.t_remove_recipe_unlock("yuoki_industries", "y_tile_slagfilled_recipe")
	rg.t_remove_recipe_unlock("yuoki_industries-2", "y_tile_slagpattern_recipe")
	rg.t_remove_recipe_unlock("yuoki_industries-3", "y_tile_slagbricks_recipe")
	
	if i_exist("yir_blue_tile") and data.raw.recipe["y_tile_slagpattern_recipe"] and data.raw.recipe["y_tile_slagbricks_recipe"]then
		data.raw.recipe["y_tile_slagpattern_recipe"].category= "yir_rc_tiles"
		data.raw.recipe["y_tile_slagbricks_recipe"].category = "yir_rc_tiles"
	end
end
do	--[[TECH]]--
	if regroup.settings.yuoki_tech and i_exist("yir_factory_loco") and data.raw.technology["yi-basic-mechanical-force"] == nil then
		if not i_exist("y-unicomp-raw") then
		data:extend({
			{
				type = "technology",
				name = "yuoki_railway",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[f]"
			},
			{
				type = "technology",
				name = "yuoki_railway-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {"yuoki_railway"},
				effects = {},
				unit = {
					count = 25,
					time = 45,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-2[f]"
			},
			{
				type = "technology",
				name = "yuoki_railway-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {"yuoki_railway-2"},
				effects = {},
				unit = {
					count = 50,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[f]"
			}
		})
		else
		data:extend({
			{
				type = "technology",
				name = "yuoki_railway",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {"yuoki_technology"},
				effects = {},
				unit = {
					count = 25,
					time = 30,
					ingredients = {
						{"science-pack-1",2},
						{"science-pack-2",1}
					}
				},
				order = "y-1[f]"
			},
			{
				type = "technology",
				name = "yuoki_railway-2",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {"yuoki_railway","yuoki_industries"},
				effects = {},
				unit = {
					count = 25,
					time = 45,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-2[f]"
			},
			{
				type = "technology",
				name = "yuoki_railway-3",
				icon = "__Regroup__/graphics/icons/tech/yuoki_railway.png",
				icon_size = 64,
				prerequisites = {"yuoki_railway-2","yuoki_industries-2"},
				effects = {},
				unit = {
					count = 50,
					time = 60,
					ingredients = {
						{"science-pack-1",3},
						{"science-pack-2",2},
						{"science-pack-3",1}
					}
				},
				enabled = false,
				order = "y-3[f]"
			}
		})
		end
		
		
		-- yuoki_railway-3

		do --# transport
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_access-pipe-in")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_access-pipe-out")
		end
		do	--# energy
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_fuel_energy_recipe")
		end
		do	--# trains-vehicles
			rg.add_recipe_to_tech("yuoki_railway",				"yir_factory_loco_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_factory_chemical_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_factory_material_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_factory_tiles_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_factory_stuff_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_coins_gen1_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_diesel_coin_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_future_coin_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_frame_loco_steam_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_frame_waggon_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_radsatz_locos_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_color_white_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_color_black_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_color_red_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_color_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_color_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_loco_diesel_620")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_energy")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_eb1")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_gears")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_kiste1")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_ziegelgrau")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_ziegelrot")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_kr_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_loco_ses_std_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_loco_ses_red_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_loco_fut_red_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_loco_sel_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_loco_fs_steam_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_loco_steam_wt450_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_loco_steam_wt580of_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_loco_del_KR_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_3acw_T10K_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_mre044_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_yiblue_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_yigreen_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_yiblue")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_yigreen")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_cargo_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_cargo_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_steel_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_steel")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_6a_maai1_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_6a_maai1")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_flourit_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_uranite_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_flourit_4a_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_uran_4a_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_kisten") 
			rg.add_recipe_to_tech("yuoki_railway",				"z_yira_4a_cw_stuff1")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_wood")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_coal")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_copper")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_iron")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_stone")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_closed")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_gold")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_mun")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_tf")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_4acw_vc")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_fw4_vc")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_fw4a_tank_oil")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_4a_urana")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_cw_4a_cellsu")
			
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_frame_loco_diesel_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_radsatz_waggon_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_ses_red_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_tender_black_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_tender_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_emd1500black_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_emd1500blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_desw_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_desw_orange_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_desw_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_factory_wagon_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_2acw_wood_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_coal_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_stone_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_copper_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_iron_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_wagon2a_closed_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_trans_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_tank_fm1_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_wagon_tank_fm2_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_atom_header_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_atom_mitte_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_lsw_840green_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_lsw_r790orange_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_lsw_r790red_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_cw_upempty_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_cw_upclosed_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_cw_empty_4a_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_loco_diesel_620_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_cw_trans_4a_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_es44cr_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_emdf7a_cr_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_emdf7a_mn_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_emdf7b_cr_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_emdf7b_mn_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_wagon_caboose_cr_crrecipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_4a_container_crrecipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_4a_clean_cr_recipe")
			
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_frame_loco_future_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_loco_fesw_op_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_loco_emd1500black_v2_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_loco_emd1500blue_v2")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_loco_del_mk1400")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_loco_emd3000_white_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_loco_de_bluegray_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_2acw_3blocks_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_wagon_corn_green_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_wagon_corn_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_wagon_hopper_yellow_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_4acw_grey_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_4acw_oceanblue_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_4acw_purple_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_wagon_zement_gray_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"y_wagon_zement_white_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_wagon2a_tank_blue_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_wagon2a_tank_orange_recipe")
		end
		do	--# decorative
			rg.add_recipe_to_tech("rg-decorative-4",				"yir_lamp_modern")
			rg.add_recipe_to_tech("rg-decorative-4",				"yir_lamp_old1")
			rg.add_recipe_to_tech("rg-decorative-4",				"yir_lamp_clock")
			rg.add_recipe_to_tech("yuoki_railway",				"y_path_slag_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_path_labor_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_path_checker_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_stony_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"yir_grating_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_path_science_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_tgb_recipe")
			rg.add_recipe_to_tech("yuoki_railway",				"y_tring_recipe")
			
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_wood1_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_wood3_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_ground1_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_plates2_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_tile_slagpattern_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_muster1_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"y_tile_slagbricks_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_brick2_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-2",				"yir_brick1_tile_recipe")
			
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_metal1_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_metal3_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_metal4_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_metal5_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_tile3_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_tile2_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_tile1_tile_recipe")
			rg.add_recipe_to_tech("yuoki_railway-3",				"yir_blue_tile_recipe")
		end
	end
end
