data:extend({
  {
    type = "recipe-category",
    name = "welding"
  },
})