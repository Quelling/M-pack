if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.smeltingtrain then angelsmods.addons.smeltingtrain = {} end

require("prototypes.entities.smelting-train")

require("prototypes.recipes.smelting-recipe")

require("prototypes.technology.smelting-technology")

