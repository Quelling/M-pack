data:extend(
{  
	-- items
	{
		type = "technology",
		name = "necro-tech-biter-steak",
		icon = "__necromant__/graphics/icons/biter-steak.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-biter-steak"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {{"science-pack-1", 1}},
			time = 10
		},
		order = "z-a"
	},
	{
		type = "technology",
		name = "necro-tech-bone-charcoal",
		icon = "__necromant__/graphics/icons/bone-charcoal.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-bone-charcoal"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {{"science-pack-1", 1}},
			time = 20
		},
		order = "z-a-a"
	},
	{
		type = "technology",
		name = "necro-tech-enriched-bones",
		icon = "__necromant__/graphics/icons/enriched-bones.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-enriched-bones"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-enriched-bones-from-fish"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-enriched-bones-charcoal"
			}
		},
		prerequisites = {"necro-tech-bone-charcoal"},
		unit =
		{
			count = 200,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1}
			},
			time = 20
		},
		order = "z-a-b"
	},
	{
		type = "technology",
		name = "necro-tech-chitin-processing",
		icon = "__necromant__/graphics/icons/chitin.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-chitin-processing"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse", },
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 20
		},
		order = "z-a"
	},
	{
		type = "technology",
		name = "necro-tech-chitin-to-bones",
		icon = "__necromant__/graphics/icons/bones.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-chitin-to-bones"
			}
		},
		prerequisites = {"necro-tech-chitin-processing"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1}
			},
			time = 25
		},
		order = "z-a"
	},
	{
		type = "technology",
		name = "necro-tech-chitin-to-worm-chitin",
		icon = "__necromant__/graphics/icons/worms/worm_chitin.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-chitin-to-worm-chitin"
			}
		},
		prerequisites = {"necro-tech-chitin-processing", "necro-tech-process-small-worm-corpse", "necro-tech-enriched-bones"},
		unit =
		{
			count = 300,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1}
			},
			time = 25
		},
		order = "z-a"
	},
	
	-- alien corpses =============
	-- small
	{
		type = "technology",
		name = "necro-tech-process-small-biter-corpse",
		icon = "__necromant__/graphics/icons/small-biter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-small-biter-corpse"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-alien-dna-from-brain"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-alien-dna-from-flesh"
			}
		},
		unit =
		{
			count = 20,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 10
		},
		order = "z-b-a"
	},
	{
		type = "technology",
		name = "necro-tech-process-small-spitter-corpse",
		icon = "__necromant__/graphics/icons/small-spitter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-small-spitter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse"},
		unit =
		{
			count = 20,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 10
		},
		order = "z-c-a"
	},
	
	-- medium
	{
		type = "technology",
		name = "necro-tech-process-medium-biter-corpse",
		icon = "__necromant__/graphics/icons/medium-biter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-medium-biter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 20
		},
		order = "z-b-b"
	},
	{
		type = "technology",
		name = "necro-tech-process-medium-spitter-corpse",
		icon = "__necromant__/graphics/icons/medium-spitter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-medium-spitter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-small-spitter-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 20
		},
		order = "z-c-b"
	},
	
	-- big
	{
		type = "technology",
		name = "necro-tech-process-big-biter-corpse",
		icon = "__necromant__/graphics/icons/big-biter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-big-biter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-medium-biter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1}
			},
			time = 20
		},
		order = "z-b-c"
	},
	{
		type = "technology",
		name = "necro-tech-process-big-spitter-corpse",
		icon = "__necromant__/graphics/icons/big-spitter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-big-spitter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-medium-spitter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1}
			},
			time = 20
		},
		order = "z-c-c"
	},
	
	-- behemoth
	{
		type = "technology",
		name = "necro-tech-process-behemoth-biter-corpse",
		icon = "__necromant__/graphics/icons/behemoth-biter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-behemoth-biter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-big-biter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 3},
				{"science-pack-2", 2},
				{"science-pack-3", 1}
			},
			time = 20
		},
		order = "z-b-d"
	},
	{
		type = "technology",
		name = "necro-tech-process-behemoth-spitter-corpse",
		icon = "__necromant__/graphics/icons/behemoth-spitter-processing.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-behemoth-spitter-corpse"
			}
		},
		prerequisites = {"necro-tech-process-big-spitter-corpse"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 3},
				{"science-pack-2", 2},
				{"science-pack-3", 1}
			},
			time = 20
		},
		order = "z-c-d"
	},
	
	-- alien fluids & results =============

	-- necro-tech-alien-chemicals moved to recipe-artifacts.lua
	
	{
		type = "technology",
		name = "necro-tech-alien-chemicals-results",
		icon = "__necromant__/graphics/icons/alien-chemicals-results.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-alien-chemicals-results"
			}
		},
		prerequisites = {"necro-tech-alien-chemicals"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1}
			},
			time = 20
		},
		order = "z-d-a"
	},
	{
		type = "technology",
		name = "necro-tech-alien-poison-from-protein",
		icon = "__necromant__/graphics/icons/alien-poison.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-alien-poison-from-protein"
			}
		},
		prerequisites = {"necro-tech-alien-chemicals-results"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 3},
				{"science-pack-2", 2},
				{"production-science-pack", 1},
			},
			time = 30
		},
		order = "z-d-c"
	},
	{
		type = "technology",
		name = "necro-tech-heal-potion",
		icon = "__necromant__/graphics/icons/heal-potion.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-recipe-heal-potion"
			}
		},
		prerequisites = {"necro-tech-alien-chemicals-results", "necro-tech-biter-steak"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1},
				{"production-science-pack", 1},
			},
			time = 20
		},
		order = "z-d-d"
	},
	{
		type = "technology",
		name = "necro-tech-poison-ammo",
		icon = "__necromant__/graphics/icons/poison-ammo.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-recipe-poison-ammo"
			}
		},
		prerequisites = {"necro-tech-alien-chemicals-results", "military-2"},
		unit =
		{
			count = 50,
			ingredients = {
				{"science-pack-1", 3},
				{"science-pack-2", 2},
				{"science-pack-3", 1},
				{"military-science-pack", 1},
			},
			time = 30
		},
		order = "z-d-f"
	},
})

if settings.startup["necro-setting-fireball-launcher-and-towers"].value == true then
data:extend(
{
	-- fireball ===============================
	{
		type = "technology",
		name = "necro-tech-fireball",
		icon = "__necromant__/graphics/icons/fireball.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-fireball-lauchner-recipe"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-fireball-powder-recipe"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-burning-substance-recipe-charcoal"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-burning-substance-recipe-coal"
			}
		},
		prerequisites = {"necro-tech-bone-charcoal", "necro-tech-alien-chemicals"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"military-science-pack", 1}
			},
			time = 20
		},
		order = "z-e-a"
	},
	
	-- fireball towers =============
	{
		type = "technology",
		name = "necro-tech-fireball-tower",
		icon = "__necromant__/graphics/icons/fireball-tower.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-fireball-tower-recipe"
			}
		},
		prerequisites = {"necro-tech-fireball", "necro-tech-worm-wall", "turrets"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 5},
				{"science-pack-2", 3},
				{"military-science-pack", 1}
			},
			time = 25
		},
		order = "z-e-b"
	},
	{
		type = "technology",
		name = "necro-tech-fireball-artillery",
		icon = "__necromant__/graphics/icons/fireball-artillery.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-fireball-artillery-recipe"
			}
		},
		prerequisites = {"necro-tech-fireball-tower", "military-3", "bi_tech_bio_cannon"},
		unit =
		{
			count = 500,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"military-science-pack", 1}
			},
			time = 30
		},
		order = "z-e-c"
	}
})
end

data:extend(
{
	-- worm & wall =================
	{
		type = "technology",
		name = "necro-tech-process-small-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_small.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-small-worm-corpse"
			}
		},
		prerequisites = {"necro-tech-process-small-biter-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1}
			},
			time = 10
		},
		order = "z-f-a"
	},
	{
		type = "technology",
		name = "necro-tech-process-medium-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_medium.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-medium-worm-corpse"
			}
		},
		prerequisites = {"necro-tech-process-small-worm-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1}
			},
			time = 15
		},
		order = "z-f-b"
	},
	{
		type = "technology",
		name = "necro-tech-process-big-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_big.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-process-big-worm-corpse"
			}
		},
		prerequisites = {"necro-tech-process-medium-worm-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"military-science-pack", 1}
			},
			time = 20
		},
		order = "z-f-c"
	},
	{
		type = "technology",
		name = "necro-tech-worm-wall",
		icon = "__necromant__/graphics/entity/walls/stone-worm-wall.png",
		icon_size = 32,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "necro-worm-stone-wall-recipe"
			},
			{
				type = "unlock-recipe",
				recipe = "necro-worm-gate-recipe"
			}
		},
		prerequisites = {"necro-tech-process-small-worm-corpse"},
		unit =
		{
			count = 100,
			ingredients = {
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"military-science-pack", 1}
			},
			time = 20
		},
		order = "z-f-d"
	}
}
)
