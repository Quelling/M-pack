if data.raw.technology["heavy-armor"] then
	table.insert(data.raw.technology["heavy-armor"].prerequisites, "necro-tech-chitin-processing")
end