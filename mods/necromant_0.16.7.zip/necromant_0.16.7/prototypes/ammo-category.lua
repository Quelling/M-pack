data:extend(
{
  {
    type = "ammo-category",
    name = "necro-staff"
  }
}
)
