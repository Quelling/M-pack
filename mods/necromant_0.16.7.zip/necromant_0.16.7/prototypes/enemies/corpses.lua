data:extend(
{
	-- biters =======================================
	{
		type = "item",
		name = "necro-small-biter-corpse",
		icon = "__necromant__/graphics/icons/corpses/small-biter-corpse.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "a",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-medium-biter-corpse",
		icon = "__necromant__/graphics/icons/corpses/medium-biter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "b",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-big-biter-corpse",
		icon = "__necromant__/graphics/icons/corpses/big-biter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "c",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-behemoth-biter-corpse",
		icon = "__necromant__/graphics/icons/corpses/behemoth-biter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "d",
		stack_size = 200,
		default_request_amount = 200
	},
	
	-- spitters =======================================
	{
		type = "item",
		name = "necro-small-spitter-corpse",
		icon = "__necromant__/graphics/icons/corpses/small-spitter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "e",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-medium-spitter-corpse",
		icon = "__necromant__/graphics/icons/corpses/medium-spitter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "f",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-big-spitter-corpse",
		icon = "__necromant__/graphics/icons/corpses/big-spitter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "g",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-behemoth-spitter-corpse",
		icon = "__necromant__/graphics/icons/corpses/behemoth-spitter.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "h",
		stack_size = 200,
		default_request_amount = 200
	},
	
	-- worms ==========================================
	{
		type = "item",
		name = "necro-small-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_small.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "i-a",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-medium-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_medium.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "i-b",
		stack_size = 200,
		default_request_amount = 200
	},
	{
		type = "item",
		name = "necro-big-worm-corpse",
		icon = "__necromant__/graphics/icons/worms/worm_corpse_big.png",
		icon_size = 32,
		flags = { "goes-to-main-inventory" },
		subgroup = "necromant-filter-processing",
		order = "i-c",
		stack_size = 200,
		default_request_amount = 200
	}
}
)
