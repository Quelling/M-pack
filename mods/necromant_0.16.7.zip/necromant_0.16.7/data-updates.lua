require("prototypes.updates")
require("prototypes.enemies.update-corpses")
require("prototypes.enemies.update-corpses_5dim")
require("prototypes.technology-updates")
