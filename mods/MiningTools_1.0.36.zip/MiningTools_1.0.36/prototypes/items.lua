data:extend(
	{
		----------------------------------------------------------------------------------
		{
			type = "item-group",
			name = "advanced-mining-group",
			icon = "__MiningTools__/graphics/advanced-mining-group.png",
			icon_size = 64,
			inventory_order = "m",
			order = "m"
		},
		{
			type = "item-subgroup",
			name = "advanced-mining-tools",
			group = "advanced-mining-group",
			order = "a"
		},
		{
			type = "item-subgroup",
			name = "advanced-mining-dynamites-1",
			group = "advanced-mining-group",
			order = "d"
		},
		{
			type = "item-subgroup",
			name = "advanced-mining-dynamites-2",
			group = "advanced-mining-group",
			order = "e"
		},
		{
			type = "item-subgroup",
			name = "advanced-mining-dynamites-3",
			group = "advanced-mining-group",
			order = "f"
		},
		{
			type = "item-subgroup",
			name = "advanced-mining-dynamites-4",
			group = "advanced-mining-group",
			order = "g"
		},
		
		----------------------------------------------------------------------------------
		{
			type = "item",
			name = "water-injector",
			icon = "__MiningTools__/graphics/water-injector-icon.png",
			icon_size = 32,
			flags = {"goes-to-quickbar"},
			subgroup = "advanced-mining-tools",
			order = "e",
			place_result = "water-injector",
			stack_size = 20
		},

		-- {
			-- type = "item",
			-- name = "water-injector-mono",
			-- icon = "__MiningTools__/graphics/water-injector-mono-icon.png",
			-- flags = {"goes-to-quickbar"},
			-- subgroup = "advanced-mining-tools",
			-- order = "e",
			-- place_result = "water-injector-mono",
			-- stack_size = 20
		-- },

		{
			type = "item",
			name = "water-injection",
			icon = "__MiningTools__/graphics/water-injection.png",
			icon_size = 32,
			flags = {"goes-to-quickbar","hidden"},
			subgroup = "intermediate-product",
			order = "e",
			stack_size = 200
		},

		----------------------------------------------------------------------------------
		{
			type = "mining-tool",
			name = "pneumatic-drill",
			icon = "__MiningTools__/graphics/pneumatic-drill.png",
			icon_size = 32,
			flags = {"goes-to-quickbar"},
			action =
			{
				type="direct",
				action_delivery =
				{
					type = "instant",
					target_effects =
					{
						type = "damage",
						damage = { amount = 15 , type = "physical"}
					}
				}
			},
			durability = 250000,
			subgroup = "advanced-mining-tools",
			order = "b",
			speed = 20,
			stack_size = 20
		},
		
		{
			type = "mining-tool",
			name = "electric-pneumatic-drill",
			icon = "__MiningTools__/graphics/electric-pneumatic-drill.png",
			icon_size = 32,
			flags = {"goes-to-quickbar"},
			action =
			{
				type="direct",
				action_delivery =
				{
					type = "instant",
					target_effects =
					{
						type = "damage",
						damage = { amount = 30 , type = "physical"}
					}
				}
			},
			durability = 500000,
			subgroup = "advanced-mining-tools",
			order = "a[mining]-e[electric-pneumatic-drill]",
			speed = 40,
			stack_size = 20
		},

		----------------------------------------------------------------------------------
		{
			type = "item",
			name = "fast-mining-drill",
			icon = "__MiningTools__/graphics/fast-mining-drill-icon.png",
			icon_size = 32,
			flags = {"goes-to-quickbar"},
			subgroup = "advanced-mining-tools",
			order = "d",
			place_result = "fast-mining-drill",
			stack_size = 50
		},
	}
)

