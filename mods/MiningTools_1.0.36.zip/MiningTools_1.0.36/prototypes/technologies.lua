data:extend(
	{
		---------------------------------------------------------------------------------
		{
			type = "technology",
			name = "advanced-mining-1",
			icon = "__MiningTools__/graphics/advanced-mining.png",
			icon_size = 128,
			upgrade = true,
			effects =
			{
				{
					type = "unlock-recipe",
					recipe = "water-injector"
				},
				{
					type = "unlock-recipe",
					recipe = "pneumatic-drill"
				},
				{
					type = "unlock-recipe",
					recipe = "electric-pneumatic-drill"
				},
				{
					type = "unlock-recipe",
					recipe = "fast-mining-drill"
				},
			},
			unit =
			{
				count = 50,
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1}
				},
				time = 30
			},
			order = "c-k-m"
		},
		---------------------------------------------------------------------------------
		{
			type = "technology",
			name = "advanced-mining-2",
			icon = "__MiningTools__/graphics/advanced-mining.png",
			icon_size = 128,
			prerequisites = {"advanced-mining-1"},
			upgrade = true,
			effects =
			{
			},
			unit =
			{
				count = 100,
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1}
				},
				time = 40
			},
			order = "c-k-m"
		},
		---------------------------------------------------------------------------------
		{
			type = "technology",
			name = "advanced-mining-3",
			icon = "__MiningTools__/graphics/advanced-mining.png",
			icon_size = 128,
			prerequisites = {"advanced-mining-2"},
			upgrade = true,
			effects =
			{
			},
			unit =
			{
				count = 150,
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1},
					{"science-pack-3", 1}
				},
				time = 50
			},
			order = "c-k-m"
		},
		---------------------------------------------------------------------------------
		{
			type = "technology",
			name = "advanced-mining-4",
			icon = "__MiningTools__/graphics/advanced-mining.png",
			icon_size = 128,
			prerequisites = {"advanced-mining-3"},
			upgrade = true,
			effects =
			{
				-- {
					-- type = "unlock-recipe",
					-- recipe = "water-injector-mono"
				-- },
			},
			unit =
			{
				count = 200,
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1},
					{"science-pack-3", 1}
				},
				time = 60
			},
			order = "c-k-m"
		},
	}
)

