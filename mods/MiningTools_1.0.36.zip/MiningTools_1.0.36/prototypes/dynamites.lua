local n_order = 0

function add_dynamite_level( ore, level, pic_undefined, is_fluid, true_item )
	local techno_name, subgroup_name, localised_name_item, localised_name_entity, localised_name_recipe
	
	local dyna_name = "dynamite-".. level .. "-" .. ore
	local dyna_name_nolvl = "dynamite-" .. ore
	
	if level == 0 then
		techno_name = "advanced-mining-1"
		subgroup_name = "advanced-mining-tools"
		localised_name_item = {"item-name." .. dyna_name_nolvl}
		localised_name_entity = {"entity-name." .. dyna_name_nolvl}
		localised_name_recipe = {"recipe-name." .. dyna_name_nolvl}
	else
		techno_name = "advanced-mining-" .. level
		subgroup_name = "advanced-mining-dynamites-" .. level
		localised_name_item = {"item-name.dynamite-level", {"item-name." .. dyna_name_nolvl},level}
		localised_name_entity = {"entity-name.dynamite-level", {"entity-name." .. dyna_name_nolvl},level}
		localised_name_recipe = {"recipe-name.dynamite-level", {"recipe-name." .. dyna_name_nolvl},level}
	end
	
	local dyna_ingredients
	-- if ore == "crude-oil" then
	if is_fluid == true then
		dyna_ingredients = {{"explosives",4*level},{"sulfur",4*dynamite_ore_investment*level}}
	elseif ore == "monazite-ore" then
		dyna_ingredients = {{"explosives",1*level},{"monazite-ore-base",dynamite_ore_investment*level}}
	elseif ore == "gem-ore" then
		dyna_ingredients = {{"explosives",1*level},{"ruby-ore",2*level},{"sapphire-ore",2*level},{"emerald-ore",2*level},{"amethyst-ore",2*level},{"topaz-ore",2*level},{"diamond-ore",2*level}}
	elseif ore == "wipe" then
		dyna_ingredients = {{"explosives",1},{"sulfur",1}}
	else
		if true_item ~= nil then
			dyna_ingredients = {{"explosives",1*level},{true_item,dynamite_ore_investment*level}}
		else
			dyna_ingredients = {{"explosives",1*level},{ore,dynamite_ore_investment*level}}
		end
	end
	
	if level == 0 then
		dyna_icon = "__MiningTools__/graphics/dynamite-wipe.png"
	else
		if pic_undefined then
			dyna_icon = "__MiningTools__/graphics/level" .. level .. "/dynamite-" .. level .. "-undefined.png"
		else
			dyna_icon = "__MiningTools__/graphics/level" .. level .. "/" .. dyna_name .. ".png"
		end
	end
	
	data:extend(
		{
			----------------------------------------------------------------------------------
			{
				type = "container",
				name = dyna_name,
				localised_name = localised_name_entity,
				icon = dyna_icon,
				icon_size = 32,
				-- tint = colors.blue,
				flags = {"placeable-neutral", "player-creation"},
				minable = {mining_time = 1, result = dyna_name},
				max_health = 100,
				corpse = "big-remnants",
				dying_explosion = "big-explosion",
				resistances ={{type = "fire",percent = 80}},
				collision_box = {{-0.35, -0.35}, {0.35, 0.35}},
				--collision_mask = {"object-layer"},
				selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
				inventory_size = 1,
				picture =
				{
					filename = dyna_icon,
					-- tint = colors.blue,
					priority = "extra-high",
					width = 32,
					height = 32,
					shift = {0.0, 0.0}
				}
			},
			----------------------------------------------------------------------------------
			{
				type = "recipe",
				name = dyna_name,
				localised_name = localised_name_recipe,
				ingredients = dyna_ingredients,
				result = dyna_name,
				result_count = 1,
				enabled = "false"
			},
			----------------------------------------------------------------------------------
			{
				type = "item",
				name = dyna_name,
				localised_name = localised_name_item,
				icon = dyna_icon,
				icon_size = 32,
				-- tint = colors.blue,
				flags = {"goes-to-quickbar"},
				subgroup = subgroup_name,
				
				place_result = dyna_name,
				stack_size = 100
			},
		}
	)
	table.insert( data.raw["technology"][techno_name].effects,
		{
			type = "unlock-recipe",
			recipe = dyna_name,
		}
	)
	n_order = n_order + 1
	
	return( true )
end

function add_dynamite( ore, pic_undefined, is_fluid, true_item )
	if data.raw["resource"][ore] == nil then return( false ) end
	
	 add_dynamite_level( ore, 1, pic_undefined, is_fluid, true_item )
	 add_dynamite_level( ore, 2, pic_undefined, is_fluid, true_item )
	 add_dynamite_level( ore, 3, pic_undefined, is_fluid, true_item )
	 add_dynamite_level( ore, 4, pic_undefined, is_fluid, true_item )
end

-- wipe
add_dynamite_level( "wipe", 0, false )

-- mod base
add_dynamite( "coal", false )
add_dynamite( "stone", false )
add_dynamite( "iron-ore", false )
add_dynamite( "copper-ore", false )
add_dynamite( "crude-oil", false, true )

-- mod dark matter
add_dynamite( "tenemut", false )	

-- mod nucular
add_dynamite( "uranium-ore", false )	

-- mod thorium
add_dynamite( "monazite-ore", false )	

-- mod anonymods
add_dynamite( "mercury-ore", true, false, "cinnabar" )
add_dynamite( "cobalt-ore", true, false, "cobaltite" )
add_dynamite( "gold-ore", true, false, "gold-oxide" )
add_dynamite( "aluminum-ore", true, false, "bauxite" )
add_dynamite( "lead-ore", true, false, "galena" )
add_dynamite( "nickel-ore", true, false, "pentlandite" )
add_dynamite( "phosphorus-ore", true, false, "apatite" )
add_dynamite( "quartz-ore", true, false, "quartz" )
add_dynamite( "silver-ore", true, false, "argentite" )
add_dynamite( "tin-ore", true, false, "cassiterite" )
add_dynamite( "titanium-ore", true, false, "rutile" )
add_dynamite( "tungsten-ote", true, false, "wolframite" )
add_dynamite( "zinc-ore", true, false, "sphalerite" )
add_dynamite( "limestone-ore", true, false, "limestone" )
add_dynamite( "sulfur-ore", true, false, "sulfur" )
add_dynamite( "natural-gas", true, true )
add_dynamite( "thermal-water", true, true )

-- mod bobores + 5dim
add_dynamite( "sulfur", false )	
add_dynamite( "bauxite-ore", false )	
add_dynamite( "cobalt-ore", false )	
add_dynamite( "gem-ore", false )	
add_dynamite( "gold-ore", false )	
add_dynamite( "lead-ore", false )	
add_dynamite( "nickel-ore", false )	
add_dynamite( "quartz", false )	
add_dynamite( "rutile-ore", false )	
add_dynamite( "silver-ore", false )	
add_dynamite( "tin-ore", false )	
add_dynamite( "tungsten-ore", false )	
-- add_dynamite( "uranium-ore", false )	-- already in nucular
add_dynamite( "zinc-ore", false )	
add_dynamite( "lithia-water", false, true )	
add_dynamite( "ground-water", false, true )	

-- mod crafted artifacts
add_dynamite( "rare-earth", false )	

-- mod reactor
add_dynamite( "nuclear-ores", false )	
add_dynamite( "Nature-Gas", false, true )	

-- mod angel refining

add_dynamite( "angels-ore1", false)
add_dynamite( "angels-ore2", false)
add_dynamite( "angels-ore3", false)
add_dynamite( "angels-ore4", false)
add_dynamite( "angels-ore5", false)
add_dynamite( "angels-ore6", false)
add_dynamite( "angels-natural-gas", false, true )
add_dynamite( "angels-fissure", false, true )

-- mod yuoki
add_dynamite( "y-res1", false )	
add_dynamite( "y-res2", false )	

-- mod liquid-naphtha
add_dynamite( "liquid-naphtha", false, true )

-- mod water-purified
add_dynamite( "water-purified", false, true )

-- mod spring-water
add_dynamite( "spring-water", false, true )

-- mod gas-sulfur-dioxide
add_dynamite( "gas-sulfur-dioxide", false, true )

-- mod gas-polyethylene
add_dynamite( "gas-polyethylene", false, true )

-- mod gas-oxygen
add_dynamite( "gas-oxygen", false, true )

-- mod gas-hydrogen
add_dynamite( "gas-hydrogen", false, true )

-- mod gas-chlorine
add_dynamite( "gas-chlorine", false, true )

-- mod gas-hydrogen
add_dynamite( "gas-carbon-dioxide", false, true )

-- mod fusion-heat-fluid
add_dynamite( "fusion-heat-fluid", false, true )

-- mod fusion-advanced-heat-fluid
add_dynamite( "fusion-advanced-heat-fluid", false, true )

-- mod gas-methane
add_dynamite( "gas-methane", false, true )
