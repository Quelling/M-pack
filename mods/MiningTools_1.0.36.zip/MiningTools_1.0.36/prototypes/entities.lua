local fast_mining_drill = dupli_proto("mining-drill","electric-mining-drill","fast-mining-drill")
fast_mining_drill.icon = "__MiningTools__/graphics/fast-mining-drill-icon.png"
fast_mining_drill.max_health = 600 -- from 300
for _ , anim in pairs(fast_mining_drill.animations) do
	anim.animation_speed = 0.5
end
fast_mining_drill.mining_speed = 1.5 -- from 0.5
fast_mining_drill.energy_usage = "180kW" -- from 90
fast_mining_drill.mining_power = 3 -- from 3

data:extend(
	{
		fast_mining_drill,
		
		----------------------------------------------------------------------------------
		{
			type = "assembling-machine",
			name = "water-injector",
			icon = "__MiningTools__/graphics/water-injector-icon.png",
			icon_size = 32,
			flags = {"placeable-neutral", "placeable-player", "player-creation"},
			minable = {hardness = 0.2, mining_time = 0.5, result = "water-injector"},
			max_health = 250,
			corpse = "big-remnants",
			dying_explosion = "medium-explosion",
			resistances =
			{
				{
					type = "fire",
					percent = 70
				}
			},
			fluid_boxes =
			{
				{
					production_type = "input",
					pipe_picture = assembler2pipepictures(),
					pipe_covers = pipecoverspictures(),
					base_area = 10,
					base_level = -1,
					pipe_connections = {{ type="input", position = {0, -2} }}
				},
				off_when_no_fluid_recipe = true
			},
			collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
			selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
			animation =
			{
				filename = "__MiningTools__/graphics/water-injector-anim.png",
				priority = "high",
				width = 113,
				height = 99,
				frame_count = 32,
				line_length = 8,
				shift = {0.4, -0.06}
			},
			open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
			close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
			vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
			working_sound =
			{
				sound = 
				{
					{
						filename = "__base__/sound/assembling-machine-t2-1.ogg",
						volume = 0.8
					},
					{
						filename = "__base__/sound/assembling-machine-t2-2.ogg",
						volume = 0.8
					},
				},
				idle_sound = 
				{
					filename = "__base__/sound/idle1.ogg", volume = 0.6 
				},
				apparent_volume = 1.5,
			},
			crafting_categories = {"water-injection"},
			crafting_speed = 1.0,
			energy_source =
			{
				type = "electric",
				usage_priority = "secondary-input",
				emissions = injector_polution,
				drain = "100kW",
			},
			energy_usage = injector_consumption .. "MW",
			ingredient_count = 2,
			module_specification =
			{
				module_slots = 2
			},
			fixed_recipe = "water-injection",
			allowed_effects = {"consumption", "speed", "productivity", "pollution"},
		},
	}
)

-- local injector_mono = dupli_proto("assembling-machine","water-injector","water-injector-mono")
-- injector_mono.animation.filename = "__MiningTools__/graphics/water-injector-mono-anim.png"
-- injector_mono.icon = "__MiningTools__/graphics/water-injector-mono-icon.png"
-- injector_mono.ingredient_count = 4
-- injector_mono.inventory_size = 3

-- data:extend(
	-- {
		-- injector_mono,
	-- }
-- )
