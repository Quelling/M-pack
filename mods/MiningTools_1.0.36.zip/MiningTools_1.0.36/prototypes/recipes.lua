data:extend(
	{
		---------------------------------------------------------------------------------
		{
			type = "recipe-category",
			name = "water-injection"
		},
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "water-injector",
			enabled = false,
			energy_required = 10,
			ingredients =
			{
				{"iron-plate", 10},
				{"steel-plate", 10},
			},
			result = "water-injector"
		},
		
		-- {
			-- type = "recipe",
			-- name = "water-injector-mono",
			-- enabled = false,
			-- energy_required = 15,
			-- ingredients =
			-- {
				-- {"iron-plate", 20},
				-- {"steel-plate", 20},
			-- },
			-- result = "water-injector-mono"
		-- },
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "water-injection",
			enabled = true,
			hidden = true,
			energy_required = 2, 
			category = "water-injection",
			ingredients =
			{
			  {type="fluid", name="water", amount=100}, 
			  {type="item", name="sulfur", amount=1}, 
			},
			result = "water-injection"
		},
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "pneumatic-drill",
			enabled = false,
			energy_required = 5,
			ingredients =
			{
				{"iron-plate", 6},
				{"steel-plate", 6},
				{"iron-stick", 3},
				{"engine-unit", 1},
			},
			result = "pneumatic-drill"
		},
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "electric-pneumatic-drill",
			enabled = false,
			energy_required = 5,
			ingredients =
			{
				{"iron-plate", 10},
				{"steel-plate", 10},
				{"iron-stick", 5},
				{"battery", 5},
				{"electric-engine-unit", 1},
			},
			result = "electric-pneumatic-drill"
		},
		
		---------------------------------------------------------------------------------
		{
			type = "recipe",
			name = "fast-mining-drill",
			enabled = false,
			energy_required = 2,
			ingredients =
			{
				{"electronic-circuit", 6},
				{"iron-gear-wheel", 10},
				{"iron-plate", 20}
			},
			result = "fast-mining-drill"
		},
		
	}
)

