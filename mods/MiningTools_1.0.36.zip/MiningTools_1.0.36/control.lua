-- debug_status = 1
debug_mod_name = "MiningTools"
debug_file = debug_mod_name .. "-debug.txt"
require("utils")
require("config")

-- status of water injector
local injector_status = { 
	checking = -1,  -- checking if zone already exploited
	preparing = 0,  -- preparing injections
	injecting = 1,  -- injecting and revealing ores
	finished = 2,   -- process finished
}

--------------------------------------------------------------------------------------
local function is_fluid( name )
	for _, fluid in pairs(global.fluids) do
		if fluid == name then return true end
	end
	return false
end

--------------------------------------------------------------------------------------
local function check_zone_used( inj, pos )
	local x_grid = math.floor( pos.x ) + 0.5
	local y_grid = math.floor( pos.y ) + 0.5
	
	-- test if zone already used
	
	local zoneok = true
	
	for _, zone in pairs( global.zones_used ) do
		local dx = zone.x - x_grid
		local dy = zone.y - y_grid
		local dist = math.sqrt(dx*dx+dy*dy)
		if dist < injector_zone_radius * 1.5 then 
			zoneok = false
			break
		end
	end
	
	return zoneok
end

--------------------------------------------------------------------------------------
local function add_ore(name, proba)
	if game.entity_prototypes[name] then  
		debug_print( "update ore ", name )
		table.insert( global.ores, {name=name, proba=proba} )
		
		for level = 1,4 do
			local dyna_name = "dynamite-" .. level .. "-" .. name
			local techno_name = "advanced-mining-" .. level 
			
			for _,force in pairs(game.forces) do
				if game.entity_prototypes[dyna_name] then  
					force.recipes[dyna_name].enabled = force.technologies[techno_name].researched
					debug_print( "dyna recipe updated " .. dyna_name )
				else
					debug_print( "dyna recipe not found " .. dyna_name )
				end
			end
		end
	end
end
	
--------------------------------------------------------------------------------------
local function add_fluid(name, proba)
	if game.entity_prototypes[name] then  
		debug_print( "update fluid ", name )
		table.insert( global.fluids, name )

		for level = 1,4 do
			local dyna_name = "dynamite-" .. level .. "-" .. name
			local techno_name = "advanced-mining-" .. level 

			for _,force in pairs(game.forces) do
				if game.entity_prototypes[dyna_name] then  
					force.recipes[dyna_name].enabled = force.technologies[techno_name].researched
					debug_print( "dyna recipe updated " .. dyna_name )
				else
					debug_print( "dyna recipe not found " .. dyna_name )
				end
			end
		end
	end
end
	
--------------------------------------------------------------------------------------
local function update_ores_fluids()
	-- update global tables & recipes for ores and fluids
	debug_print( "update ores" )

	global.ores = {}
	global.fluids = {}

	for _,force in pairs(game.forces) do
		force.reset_technologies()
		force.reset_recipes()
	end

	-- mod base
	add_ore("coal", 0.7)
	add_ore("stone", 0.6 )
	add_ore("iron-ore", 1.0)
	add_ore("copper-ore", 1.1)
	add_fluid("crude-oil")
	
	-- mod dark matter
	add_ore("tenemut", 0.5)
	
	-- mod nucular
	add_ore("uranium-ore", 0.6)
	
	-- mod thorium
	add_ore("monazite-ore", 0.6)
	
	-- mod anonymods
	
	add_ore( "cinnabar", 0.5 )
	add_ore( "bauxite", 0.7 )
	add_ore( "cobaltite", 0.5 )
	add_ore( "gold-oxide", 0.7 )
	add_ore( "galena", 0.7 )
	add_ore( "pentlandite", 0.7 )
	add_ore( "apatite", 0.5 )
	add_ore( "quartz", 0.7 )
	add_ore( "argentite", 0.7 )
	add_ore( "cassiterite", 0.5 )
	add_ore( "rutile", 0.4 )
	add_ore( "wolframite", 0.5 )
	add_ore( "sphalerite", 0.5 )
	add_ore( "limestone", 0.7 )
	add_ore( "sulfur", 0.7 )
	
	-- mod crafted artifacts
	add_ore("rare-earth", 0.6)
	
	-- mod reactor
	add_ore("nuclear-ores", 0.6)
	add_fluid("Nature-Gas")
	
	-- mod angel refining
	
    add_ore("angels-ore1", 1.0)
    add_ore("angels-ore2", 0.7)
    add_ore("angels-ore3", 1.1)
    add_ore("angels-ore4", 0.6)
    add_ore("angels-ore5", 0.6)
    add_ore("angels-ore6", 0.6)
	add_fluid("angels-natural-gas")
	add_fluid("angels-fissure")
	
		-- mod bobores / 5dim
	add_ore("sulfur", 0.5)
	add_ore("bauxite-ore", 0.7)
	add_ore("cobalt-ore", 0.5)
	add_ore("gem-ore", 0.4)
	add_ore("gold-ore", 0.3)
	add_ore("lead-ore", 0.7)
	add_ore("nickel-ore", 0.7)
	add_ore("quartz", 0.5)
	add_ore("rutile-ore", 0.7)
	add_ore("silver-ore", 0.4)
	add_ore("tungsten-ore", 0.5)
	add_ore("tin-ore", 0.7)
	add_ore("zinc-ore", 0.7)
	add_fluid("lithia-water")
	add_fluid("ground-water")
	
	-- mod yuoki
	add_ore("y-res1", 0.6)
	add_ore("y-res2", 0.6)
	
		-- mod liquid-naphtha
		add_fluid("liquid-naphtha")
					
-- mod water-purified
add_fluid( "water-purified", false, true )

-- mod spring-water
add_fluid( "spring-water", false, true )

-- mod gas-sulfur-dioxide
add_fluid( "gas-sulfur-dioxide", false, true )

-- mod gas-polyethylene
add_fluid( "gas-polyethylene", false, true )

-- mod gas-oxygen
add_fluid( "gas-oxygen", false, true )

-- mod gas-hydrogen
add_fluid( "gas-hydrogen", false, true )

-- mod gas-chlorine
add_fluid( "gas-chlorine", false, true )

-- mod gas-hydrogen
add_fluid( "gas-carbon-dioxide", false, true )

-- mod fusion-heat-fluid
add_fluid( "fusion-heat-fluid", false, true )

-- mod fusion-advanced-heat-fluid
add_fluid( "fusion-advanced-heat-fluid", false, true )
					
	
	if debug_status then
		debug_print( "ores=",#global.ores )
		for _, ore in pairs(global.ores) do
			debug_print( ore.name .. "(" .. ore.proba .. ")" )
		end
		debug_print( "fluids=",#global.fluids )
		for _, fluid in pairs(global.fluids) do
			debug_print( fluid )
		end
	end
end

--------------------------------------------------------------------------------------
local function scramble_ores()
	local ores2 = {}
	local n = #global.ores
	local m
	
	while n > 0 do
		m = math.random(1,#global.ores)
		table.insert( ores2, global.ores[m] )
		table.remove( global.ores, m )
		n=n-1
	end
	
	global.ores = ores2
end

--------------------------------------------------------------------------------------
local function initiate_resources_zones( inj, pos )
	-- initialize ores zones (centers and zones)
	local x_grid = math.floor( pos.x ) + 0.5
	local y_grid = math.floor( pos.y ) + 0.5
	local angle = math.pi*2*math.random()
	local dist
	local add_zones = 0
	local larg = 0
	
	if inj.type == 0 then
		for _, ore in pairs(global.ores) do
			larg = larg + ore.proba
		end
	else
		larg = 2
	end
	
	larg = math.floor(injector_zone_radius * (9.5+math.random())/10 * (6+larg)/(6+3.1))
	
	scramble_ores()
	
	if debug_status then
		local s = "ores: "
		for _, ore in pairs(global.ores) do
			s = s .. ore.name .. "(" .. ore.proba .. "),"
		end
		debug_print( s )
	end
		
	for n = 1, #global.ores+injector_add_zones do
		local n2
		if n <= #global.ores then
			n2 = n
		else
			add_zones = 1
			n2 = math.random(1,#global.ores)
		end
		
		dist = math.random(larg*(0.2+0.2*add_zones),larg*(0.63-0.6/#global.ores))
		angle = angle + math.pi * 2 / #global.ores * (4.5+math.random())/5
		
		table.insert(inj.centers ,
			{
				x = x_grid + dist * math.cos(angle),
				y = y_grid + dist * math.sin(angle),
				larg = math.min(larg*0.7, larg-dist) * (3+math.random())/4 * global.ores[n2].proba / (1+add_zones),
				invweight = 0.75+0.25*math.random()*(1-add_zones),
				ore = global.ores[n2].name,
			}
		)
	end
	
	debug_print( "centers=" .. #inj.centers )
	for n, center in pairs(inj.centers) do
		debug_print( "center" .. n .. "=" .. center.x .. "," .. center.y .. " " .. center.ore )
	end
	
	for y=y_grid-larg,y_grid+larg do
		for x=x_grid-larg,x_grid+larg do
			dist_min = 5 * larg
			n_min = -1
		
			for n, center in pairs(inj.centers) do
				dx = x - center.x
				dy = y - center.y
				dist = math.sqrt(dx*dx+dy*dy)
				
				if dist <= center.larg then
					if dist * center.invweight * (0.85+0.3*math.random()) < dist_min then
						dist_min = dist
						n_min = n
					end
				end
			end
			
			if n_min ~= -1 then
				center = inj.centers[n_min]
				
				table.insert(inj.zones, 
					{
						position = { x = x, y = y },
						ore = center.ore,
						amount_target = math.floor(math.random( injector_ore_min_amount, injector_ore_max_amount ) ),
						amount_divisor = 128,
						revealed = false,
						entity = nil,
					}
				)
			end
		end
	end
end

--------------------------------------------------------------------------------------
local function reveal_resources_progressive( inj )
	local n_update = 0
	local surf = inj.entity.surface
	
	-- increase already placed resources, and generate random explosions
	
	for _, zone in pairs(inj.zones) do
		if (not zone.revealed ) and zone.entity and zone.entity.valid then
			zone.entity.amount = math.max( 1, zone.amount_target / zone.amount_divisor )
			
			if zone.amount_divisor <= 1 then
				zone.revealed = true
			else
				zone.amount_divisor = zone.amount_divisor / 2
				n_update = n_update + 1
			end
			
			inj.n_boom = inj.n_boom - 1
			
			if inj.n_boom < 0 then
				surf.create_entity({name= "explosion", position=zone.position})
				inj.n_boom = math.random( 80 , 120 )
			end
		end
	end
	
	-- place all oils at the first call (not top interfere with further ores placements)
	local n_try = 100
	
	if inj.max_oils ~= 0 then
		debug_print( "max oils " .. inj.max_oils )
		while (inj.max_oils > 0) and (n_try > 0) do
			local n = math.random(1, #(inj.zones) )
			
			local pos = inj.zones[n].position
			local ents = surf.find_entities_filtered({area = square_area(pos,1.4), type = "resource"})

			if ents[1] == nil then				
				local am = 75 * math.random( injector_oil_min_yield, injector_oil_max_yield )
				local fluid = global.fluids[1+(inj.max_oils%(#global.fluids))]
				surf.create_entity({name=fluid, amount=am, position=pos})
				inj.max_oils = inj.max_oils - 1 
			end
				
			n_try = n_try - 1
		end
		
		inj.max_oils = 0
	end
	
	-- place some ores
	
	n_try = inj.nb_try_ores
	
	while n_try > 0  do
		-- choose a random zone
		n0 = math.random(1, #inj.zones )
		n = n0
		
		-- find next unrevealed zone
		while (inj.zones[n].entity ~= nil) or inj.zones[n].revealed do
			n = n + 1
			if n > #inj.zones then 
				n = 1 
			end
			
			if n == n0 then
				n = -1 
				break
			end
		end
		
		if n > 0 then
			zone = inj.zones[n]
			
			local pos = zone.position
			local ents = surf.find_entities_filtered({area = square_area(pos,0.4), type = "resource"})
			local tile = surf.get_tile(pos.x, pos.y)
			
			if ents[1] == nil and (tile.name ~= "water") and (tile.name ~= "deepwater") then
				zone.entity = surf.create_entity( {name=zone.ore, amount=1, position=pos} )
				n_update = n_update + 1
			else
				zone.revealed = true
			end			
		else
			inj.nb_try_ores = 0
			break
		end
		
		n_try = n_try - 1
	end

	if n_update == 0 then
		-- no more zones updated : end of process
		inj.status = injector_status.finished
	end
end

--------------------------------------------------------------------------------------
local function reveal_resources_once( inj )
	local surf = inj.entity.surface
	
	for n, zone in pairs(inj.zones) do
		zone.entity = surf.create_entity({name=zone.ore, amount=zone.amount_target, position=zone.position})
	end
end

--------------------------------------------------------------------------------------
local function refresh_resources_once()
	debug_print( "refresh_resources_once" )
	message_all( "refresh resources" )
	
	for _, surf in pairs(game.surfaces) do
		for chunk in surf.get_chunks() do
			local a = {{chunk.x * 32, chunk.y * 32}, {chunk.x * 32 + 32, chunk.y * 32 + 32}}
			local ores = surf.find_entities_filtered({area = a, type="resource"})
			
			for _, ore in pairs(ores) do
				if is_fluid(ore.name) then
					ore.amount = 75 * math.random(injector_oil_min_yield,injector_oil_max_yield)
				else
					ore.amount = math.random(injector_ore_min_amount,injector_ore_max_amount)
				end
			end	
		end
	end
end

--------------------------------------------------------------------------------------
local function refresh_resources_chunk()
	-- debug_print( "refresh_resources_chunk" )
	
	local surf = game.surfaces.nauvis
	
	if global.refresh_chunk == nil then
		global.refresh_chunks = {}
		local n = 0
		for chunk in surf.get_chunks() do
			table.insert(global.refresh_chunks, chunk)
			n = n+1
		end

		message_all( "refresh resources init" )
		-- debug_print( "refresh resources init #chunks=", n )

		global.refresh_chunk_k, global.refresh_chunk = next(global.refresh_chunks,nil)
	else
		global.refresh_chunk_k, global.refresh_chunk = next(global.refresh_chunks,global.refresh_chunk_k)
	end
	
	if global.refresh_chunk ~= nil then
		local chunk = global.refresh_chunk
		local a = {{chunk.x * 32, chunk.y * 32}, {chunk.x * 32 + 32, chunk.y * 32 + 32}}
		-- debug_print( "refresh resources chunks=", chunk.x, ",", chunk.y )
		local ores = surf.find_entities_filtered({area = a, type="resource"})
		
		for _, ore in pairs(ores) do
			if is_fluid(ore.name) then
				ore.amount = 75 * math.random(injector_oil_min_yield,injector_oil_max_yield)
			else
				ore.amount = math.random(injector_ore_min_amount,injector_ore_max_amount)
			end
		end	
	end
end

--------------------------------------------------------------------------------------
local function init_globals()
	-- initialize or update general globals of the mod
	debug_print( "init_globals " )
	
	global.ticks = global.ticks or 0
	global.dynamites = global.dynamites or {}
	global.injectors = global.injectors or {}
	global.zones_used = global.zones_used or {}
	global.ores = global.ores or {}
	global.fluids = global.fluids or {}
	
	if global.refresh == nil then global.refresh = false end -- automatic refresh of resources
	global.refresh_chunks = nil
	global.refresh_chunk = nil
	global.refresh_chunk_k = 1
end

--------------------------------------------------------------------------------------
local function on_init() 
	-- called once, the first time the mod is loaded on a game (new or existing game)
	debug_print( "on_init" )
	init_globals()
	update_ores_fluids()
end

script.on_init(on_init)

--------------------------------------------------------------------------------------
local function on_resource_depleted( event )
	local ore = event.entity
	
	debug_print( "depleted ", ore.name, ":", ore.position.x, ",", ore.position.y )

	if is_fluid(ore.name) then
		ore.amount = 75 * math.random(injector_oil_min_yield,injector_oil_max_yield)
	else
		ore.amount = math.random(injector_ore_min_amount,injector_ore_max_amount)
	end
end

-- script.on_event(defines.events.on_resource_depleted, on_resource_depleted )
script.on_event(defines.events.on_resource_depleted, nil )

--------------------------------------------------------------------------------------
local function on_configuration_changed(data)
	-- detect any mod or game version change
	if data.mod_changes ~= nil then
		local changes = data.mod_changes[debug_mod_name]
		if changes ~= nil then
			debug_print( "update mod: ", debug_mod_name, " ", tostring(changes.old_version), " to ", tostring(changes.new_version) )
			
			init_globals()
			
			if changes.old_version and older_version(changes.old_version, "1.0.16") then
				global.refresh = false
			end
			
			if changes.old_version and older_version(changes.old_version, "1.0.31") then
				if global.refresh == true then
					script.on_event(defines.events.on_resource_depleted, on_resource_depleted )
					global.refresh = false
				end
			end
		end
		
		-- update any other mod could result in a newx ores/fluids list...
		update_ores_fluids()
	end
end

script.on_configuration_changed(on_configuration_changed)

--------------------------------------------------------------------------------------
local function on_creation( event )
	local ent = event.created_entity
	
	if ent.name == "water-injector" or ent.name == "water-injector-mono" then
		debug_print( "injector created" )

		local inj = 			
		{
			entity = ent, 
			type = 0, -- 0 multi, 1 mono resource
			status=injector_status.checking_, 
			max_oils = math.floor(#global.fluids * injector_max_oils * (2+math.random())/3 ),
			cycles = injector_cycles,
			nb_try_ores = 0,
			n_boom = 0,
			centers={},
			zones={}, 
			elements={},
		}
		
		if ent.name == "water-injector-mono" then
			inj.type = 1
			inj.cycles = injector_cycles_mono
			inj.max_oils = 0
			ent.active = false
		end

		table.insert( global.injectors, inj	)
		
		if check_zone_used( inj, ent.position ) then
			inj.status = injector_status.preparing
		else
			if event.player_index then -- test if player or robot
				game.players[event.player_index].print( {"already-injected"} )
			end
			inj.status = injector_status.finished
			ent.active = false
			ent.operable = false
		end
		
		debug_print( "injectors=" .. #global.injectors )
		
	elseif string.sub(ent.name,1,9) == "dynamite-" then
		--local pos = event.created_entity.position
		local dyna = ent.name
		local level = tonumber(string.sub(dyna,10,10))
		local ore = string.sub(ent.name,12)
		ent.operable = false
		
		table.insert( global.dynamites,
			{
				entity = ent,
				--position = pos,
				ore = ore,
				level = level,
				countdown = dynamite_countdown,
			}
		)
		
		debug_print( "dynamites=" .. #global.dynamites )
	end
end

script.on_event(defines.events.on_built_entity, on_creation )
script.on_event(defines.events.on_robot_built_entity, on_creation )

--------------------------------------------------------------------------------------
local function on_destruction( event )
	local ent = event.entity
	
	if ent.name == "water-injector" or ent.name == "water-injector-mono" then
		debug_print( "injector destroyed" )
		
		for i, inj in pairs(global.injectors) do
			if inj.entity == ent then
				table.remove( global.injectors, i )
				break
			end
		end
		
		debug_print( "injectors=" .. #global.injectors )
		
	elseif string.sub(ent.name,1,9) == "dynamite-" then
		debug_print( "dynamite destroyed" )
		
		for i, dyna in pairs(global.dynamites) do
			if dyna.entity == ent then
				table.remove( global.dynamites, i )
				break
			end
		end
		
		debug_print( "dynamites=" .. #global.dynamites )
	end
end

script.on_event(defines.events.on_entity_died, on_destruction )
script.on_event(defines.events.on_robot_pre_mined, on_destruction )
script.on_event(defines.events.on_pre_player_mined_item, on_destruction )

--------------------------------------------------------------------------------------
local function on_tick(event)
	if global.ticks == 0 then
		global.ticks = math.floor(injector_ticks * (10+math.random(-3,3))/10)
		local i=1
		local inj
		
		-- manage injectors
		
		while i <= #global.injectors do
			inj = global.injectors[i]
			local ent = inj.entity

			if ent and ent.valid then
				if inj.status == injector_status.preparing then
					-- prepare injections
					local inv = ent.get_output_inventory()
					
					if inv then
						local nb_inj = inv.get_item_count("water-injection")
						
						if nb_inj >= injector_injections_threshold then
							debug_print( "inj=" .. nb_inj )
							inv.remove( {name="water-injection", count=injector_injections_threshold} )
							inj.status = injector_status.injecting
							ent.active = false
							initiate_resources_zones( inj, ent.position )
							inj.nb_try_ores = math.floor( 2 + #inj.zones / inj.cycles )
							debug_print( "nb try ores=" .. inj.nb_try_ores)
							table.insert( global.zones_used, ent.position )
						end
					end
				elseif inj.status == injector_status.injecting then
					-- injecting and revealing						
					reveal_resources_progressive( inj )
				end
			else
				table.remove(global.injectors, i)
				i=i-1
			end
			i=i+1
		end
	else
		global.ticks = global.ticks - 1
	end
	
	if #global.dynamites > 0 then
		-- manage dynamite explosions
		local  i=1
		local dyna
		while i <= #global.dynamites do
			dyna = global.dynamites[i]
			if dyna.countdown <= 0 then
				local ent = dyna.entity
				local surf = ent.surface
				local pos = ent.position
				local level = dyna.level
				local res_mult = (level*2)-1
				local ore = dyna.ore
				local cancel_dynamite = false
				
				local ents = surf.find_entities_filtered({area = square_area(pos,0.4), type = "resource"})
				for _, ent2 in pairs(ents) do
					if is_fluid(ent2.name) and ore ~= "wipe" then
						-- do not overwrite fluid resource with another dynamite, unless it is a "wipe" one
						cancel_dynamite = true
					else
						ent2.destroy()
					end
				end
				
				if ore == "wipe" and #ents == 0 then
					-- do not wipe if no resource here
					cancel_dynamite = true
				end

				if not cancel_dynamite then
					ent = dyna.entity
					
					if ent and ent.valid then
						ent.destroy()
					end

					surf.create_entity({name= "explosion", position=pos})

					if ore ~= "wipe" then				
						if is_fluid(ore) then
							-- debug_print("fluid ", res_mult)
							surf.create_entity({name=ore, amount=res_mult * 75 * math.random(dynamite_oil_min_yield,dynamite_oil_max_yield) , position=pos})
						else
							-- debug_print("solid ", res_mult)
							surf.create_entity({name=ore, amount=res_mult * math.random(dynamite_ore_min_amount,dynamite_ore_max_amount), position=pos})
						end
					end
				end
				
				table.remove( global.dynamites, i )
				i=i-1
			else
				dyna.countdown = dyna.countdown - 1
			end
			i=i+1
		end
	end
	
	-- if global.refresh == true and game.tick%71989 == 0 then -- every 20 mins, optional refresh for debug purpose
		-- refresh_resources_once()
	-- end
	
	if global.refresh == true and game.tick%73 == 0 then 
		refresh_resources_chunk()
	end
end

script.on_event(defines.events.on_tick, on_tick)

--------------------------------------------------------------------------------------

local interface = {}

function interface.reset()
	debug_print( "reset" )
	
	global.refresh = false
	
	update_ores_fluids()
	
	for _, player in pairs(game.players) do
		if player.gui.top.mntl_frame then
			player.gui.top.mntl_frame.destroy()
		end
	end
end

function interface.refresh()
	debug_print( "refresh" )
	
	refresh_resources_once()
	
	global.refresh_chunk = nil
end

function interface.refon()
	debug_print( "refon" )
	-- global.refresh = true
	-- global.refresh_chunk = nil
	script.on_event(defines.events.on_resource_depleted, on_resource_depleted )
end

function interface.refoff()
	debug_print( "refoff" )
	-- global.refresh = false
	-- global.refresh_chunk = nil
	-- global.refresh_chunks = {}
	script.on_event(defines.events.on_resource_depleted, nil )
end

function interface.zap()
	debug_print( "zap" )
	
	local pos = game.player.position
	local surf = game.player.surface
	local forc = game.player.force
	pos.x = pos.x + 3
	local ent = surf.create_entity({name="water-injector", amount=1, position=pos, force = forc})
	
	local inj = {
		entity = ent, 
		status = injector_status.finished, 
		max_oils = math.floor(#global.fluids * injector_max_oils * (2+math.random())/3 ),
		cycles = 1,
		nb_try_ores = 0,
		centers={},
		zones={}, 
		elements={},
	}
	
	initiate_resources_zones( inj, ent.position )
	reveal_resources_once( inj )
	ent.active = false
end

remote.add_interface( "miningtools", interface )

-- /c remote.call( "miningtools", "refon" )
-- /c remote.call( "miningtools", "refoff" )
-- /c remote.call( "miningtools", "zap" )
-- /c remote.call( "miningtools", "refresh" )
-- /c remote.call( "miningtools", "reset" )