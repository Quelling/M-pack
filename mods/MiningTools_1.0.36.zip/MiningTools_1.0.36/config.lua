injector_consumption = 20 -- energy consumption in MW
injector_polution = 0.05 -- polution ratio
injector_injections_threshold = 100 -- number of injections before resources appear on the surface

injector_zone_radius = 36 -- average radius of the injector zone
injector_add_zones = 3 -- number of additional subzones created after the default ones (by default: 1 subzone for each ore type).
injector_max_oils = 4 -- max number of oil to be created
injector_cycles = 100 -- nb of cycles to grow an injection zone
-- injector_cycles_mono = 150 -- nb of cycles to grow an injection zone (mono resource)
injector_ticks = 30 -- average duration of one growth cycle (in gameticks)

injector_ore_min_amount = 2000
injector_ore_max_amount = 4000
injector_oil_min_yield = 250
injector_oil_max_yield = 500

dynamite_countdown = 300 -- dynamite explosion countdown
dynamite_ore_min_amount = 400 -- minimum ore revealed by a dynamite
dynamite_ore_max_amount = 800 -- maximum ore revealed by a dynamite
dynamite_oil_min_yield = 125 -- minimum oil revealed by a dynamite
dynamite_oil_max_yield = 250 -- maximum oil revealed by a dynamite

dynamite_ore_investment = 10 -- nb of ore to use to create a resource dynamite

