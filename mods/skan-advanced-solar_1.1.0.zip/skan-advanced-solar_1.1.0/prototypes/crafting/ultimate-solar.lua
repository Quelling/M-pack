data:extend(
{
  {
    type = "recipe",
    name = "ultimate-solar",
    energy_required = 10,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 25},
      {"processing-unit", 5},
      {"elite-solar", 10}
    },
    result = "ultimate-solar"
  }
}
)
