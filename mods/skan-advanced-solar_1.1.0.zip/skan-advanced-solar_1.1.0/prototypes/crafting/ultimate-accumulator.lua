data:extend(
{
  {
    type = "recipe",
    name = "ultimate-accumulator",
    energy_required = 25,
    enabled = "false",
    ingredients =
    {
      {"elite-accumulator", 10},
      {"steel-plate", 45},
      {"battery", 45}
    },
    result = "ultimate-accumulator"
  }
}
)
