data:extend(
{
  {
    type = "item",
    name = "elite-accumulator",
    icon = "__skan-advanced-solar__/graphics/elite-accumulator/elite-accumulator-icon.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "e-b",
    place_result = "elite-accumulator",
    stack_size = 50
  }
}
)
