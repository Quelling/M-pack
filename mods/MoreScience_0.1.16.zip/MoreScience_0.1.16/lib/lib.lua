if not MoreScience then MoreScience = {} end
if not MoreScience.lib then MoreScience.lib = {} end

require("lib.utilities.log")
require("lib.utilities.util")

require("lib.prototyping.recipe")
require("lib.prototyping.technology")
