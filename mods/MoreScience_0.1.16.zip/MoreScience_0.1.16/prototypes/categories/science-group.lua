
data:extend({
  {
    type = "item-group",
    name = "ms-science",
    order = "e",
    icon = "__MoreScience__/graphics/item-group/science-bottles.png",
    icon_size = 512,
  },
})
