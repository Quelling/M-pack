
--------------------------------------------------------------------------------
----- Rocket-silo                                                          -----
--------------------------------------------------------------------------------
data.raw["item"]["rocket-silo"].subgroup = "rocket-assembly"



--------------------------------------------------------------------------------
----- Rocket-MK1                                                           -----
--------------------------------------------------------------------------------

data.raw["item"]["rocket-part"].icon = "__MoreScience__/graphics/technology/rocket-tech.png"
data.raw["item"]["rocket-part"].icon_size = 250
data.raw["item"]["rocket-part"].subgroup = data.raw["item"]["rocket-silo"].subgroup
