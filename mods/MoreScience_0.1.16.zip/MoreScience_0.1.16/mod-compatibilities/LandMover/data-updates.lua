
if mods["LandMover"] then

  MoreScience.lib.technology.addIngredient("landfill-2", 1, "basic-automation-science-pack")
  MoreScience.lib.technology.addPrerequisite("landfill-2", "advanced-science-research-1")

end
