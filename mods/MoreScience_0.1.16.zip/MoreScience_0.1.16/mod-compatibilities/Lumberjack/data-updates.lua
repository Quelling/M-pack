
if mods["Lumberjack"] then

  MoreScience.lib.technology.removeIngredient("sawmill", "science-pack-2")
  MoreScience.lib.technology.addPrerequisite("sawmill", "basic-automation")

end
