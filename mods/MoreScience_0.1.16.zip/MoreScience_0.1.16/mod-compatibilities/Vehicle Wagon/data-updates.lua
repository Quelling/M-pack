if mods["Vehicle Wagon"] then

  MoreScience.lib.technology.addIngredient("vehicle-wagons", 1, "basic-automation-science-pack")

end
