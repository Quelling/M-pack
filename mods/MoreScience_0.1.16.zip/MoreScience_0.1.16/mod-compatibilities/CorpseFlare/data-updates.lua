if mods["CorpseFlare"] then

  MoreScience.lib.technology.movePrerequisite("corpse-flare", "military-2", "basic-military-science-research")

end
