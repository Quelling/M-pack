# factorio-mod-wreckage-pollution
A mod for the game Factorio, adding chemical spills and pollution from destroyed entities.
