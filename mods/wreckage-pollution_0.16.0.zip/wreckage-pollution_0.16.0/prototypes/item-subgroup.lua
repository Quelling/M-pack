data:extend(
  {
    {
      type = "item-subgroup",
      name = "chemical-spill",
      group = "environment",
      order = "d",
    },
  }
)
