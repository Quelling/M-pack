data:extend(
{
	{
		type = "recipe",
		name = "thorium-nuclear-fuel-reprocessing",
		energy_required = 50,
		enabled = false,
		category = "centrifuging",
		ingredients = {{"used-up-thorium-fuel-cell", 5}},
		icon = "__Clowns-Nuclear__/graphics/icons/thorium-nuclear-fuel-reprocessing.png",
		icon_size = 32,
		subgroup = "clowns-nuclear-cells",
		order = "c-a-b",
		results =
		{
			{type="item", name="thorium-232", amount=3},
			{type="item", name="plutonium-239", amount=1}
		},
	},
	
	{
		type = "recipe",
		name = "advanced-nuclear-fuel-reprocessing",
		energy_required = 50,
		enabled = false,
		category = "chemistry",
		ingredients =
		{
			{type="item", name="used-up-uranium-fuel-cell", amount=5},
			{type="fluid", name="liquid-nitric-acid", amount=20}
		},
		icon = "__Clowns-Nuclear__/graphics/icons/nuclear-fuel-reprocessing.png",
		icon_size = 32,
		subgroup = "clowns-nuclear-cells",
		order = "c-b-a",
		results =
		{
			{type="item", name="uranium-238", amount="3"},
			{type="item", name="plutonium-239", amount="2"},
			{type="item", name="strontium-90", amount="1"},
			{type="item", name="caesium-137", amount="1"},
			{type="fluid", name="water-radioactive-waste", amount="100"}
		},
	},
	
	{
		type = "recipe",
		name = "advanced-thorium-nuclear-fuel-reprocessing",
		energy_required = 50,
		enabled = false,
		category = "chemistry",
		ingredients =
		{
			{type="item", name="used-up-thorium-fuel-cell", amount=1},
			{type="fluid", name="liquid-nitric-acid", amount=20}
		},
		icon = "__Clowns-Nuclear__/graphics/icons/thorium-nuclear-fuel-reprocessing.png",
		icon_size = 32,
		subgroup = "clowns-nuclear-cells",
		order = "c-b-b",
		results =
		{
			{type="item", name="thorium-232", amount="3"},
			{type="item", name="plutonium-239", amount="1"},
			{type="item", name="protactinium-231", amount="1"},
			{type="fluid", name="water-radioactive-waste", amount="20"}
		},
	},
}
)