data:extend(
{
	{
		type = "recipe",
		name = "hypernuclear-fuel",
		energy_required = 60,
		enabled = false,
		category = "centrifuging",
		ingredients =
		{
			{type="item", name="strontium-90", amount=1},
			{type="item", name="nuclear-fuel", amount=1}
		},
		icon_size = 32,
		results = {{type="item", name="hypernuclear-fuel", amount=1}}
	},
	{
		type = "recipe",
		name = "turbonuclear-fuel",
		energy_required = 60,
		enabled = false,
		category = "centrifuging",
		ingredients =
		{
			{type="item", name="protactinium-231", amount=1},
			{type="item", name="hypernuclear-fuel", amount=1}
		},
		icon_size = 32,
		results = {{type="item", name="turbonuclear-fuel", amount=1}}
	},
	
	{
		type = "recipe",
		name = "radiothermal-fuel",
		energy_required = 60,
		enabled = false,
		category = "centrifuging",
		ingredients =
		{
			{type="item", name="lead-plate", amount=10},
			{type="item", name="plutonium-239", amount=1}
			
		},
		icon_size = 32,
		results = {{type="item", name="radiothermal-fuel", amount=1}}
	},
	{
		type = "recipe",
		name = "superradiothermal-fuel",
		energy_required = 60,
		enabled = false,
		category = "centrifuging",
		ingredients =
		{
			{type="item", name="polonium-210", amount=1},
			{type="item", name="radiothermal-fuel", amount=1}
		},
		icon_size = 32,
		results = {{type="item", name="superradiothermal-fuel", amount=1}}
	},
	{
		type = "recipe",
		name = "ultraradiothermal-fuel",
		energy_required = 60,
		enabled = false,
		category = "centrifuging",
		ingredients =
		{
			{type="item", name="caesium-137", amount=1},
			{type="item", name="superradiothermal-fuel", amount=1}
		},
		icon_size = 32,
		results = {{type="item", name="ultraradiothermal-fuel", amount=1}}
	},
}
)