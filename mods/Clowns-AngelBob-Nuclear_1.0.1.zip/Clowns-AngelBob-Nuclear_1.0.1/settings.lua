data:extend(
{
	{
		type = "bool-setting",
		name = "thorium-processing",
		setting_type = "startup",
		default_value = true,
	},
	{
		type = "bool-setting",
		name = "artillery-shells",
		setting_type = "startup",
		default_value = false,
	},
	{
		type = "bool-setting",
		name = "clowns-centrifuging",
		setting_type = "startup",
		default_value = true,
	},
 }
 )