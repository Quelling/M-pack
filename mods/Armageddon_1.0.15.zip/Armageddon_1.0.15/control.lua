-- debug_status = 1
require("util")
debug_mod_name = "Armageddon"
debug_file = debug_mod_name .. "-debug.txt"
require("utils")
require("config")

--------------------------------------------------------------------------------------
local function init_chunks()
	-- scan the map for constructed chunks (zones)
	
	local force_enemy = game.forces.enemy
	local force_neutral = game.forces.neutral
	
	global.n_chunks_constructed = 0
	
	for chunk in global.surface.get_chunks() do
		local a = {{chunk.x * 32, chunk.y * 32}, {chunk.x * 32 + 32, chunk.y * 32 + 32}}
		local ents = global.surface.find_entities(a)
		if ents ~= nil then
			for _, ent in pairs(ents) do
				local force = ent.force
				if force ~= force_enemy and force ~= force_neutral then
					-- table.insert(global.chunks_constructed, chunk)
					local tag = tostring(chunk.x) .. "," .. tostring(chunk.y)
					-- debug_print( tag )
					if global.chunks_constructed[tag] == nil then
						global.chunks_constructed[tag] = { x = chunk.x, y = chunk.y }
						global.n_chunks_constructed = global.n_chunks_constructed + 1
					end
					break
				end
			end	
		end
	end
	
	debug_print( "n_chunks_constructed=", global.n_chunks_constructed )
	
	return( nil )
end

--------------------------------------------------------------------------------------
local function find_random_position()
	-- find a random position in constructed areas
	
	local n = global.n_chunks_constructed
	debug_print( "constructed=", n, "/", global.n_chunks_constructed )
	
	if n > 0 then
		n = math.random( 1, n )
		local i = 0
		
		for _, chunk in pairs(global.chunks_constructed) do
			i = i + 1
			if i == n then
				local pos = {x = chunk.x * 32 + math.random(8,24), y = chunk.y * 32 + math.random(8,24)}
				return( pos )
			end
		end
	end
	
	return( nil )
end

--------------------------------------------------------------------------------------
local function create_invasion()
	local target = find_random_position()
	
	if target ~= nil then
		local ratio 
		
		if game.forces.enemy.evolution_factor > disasters.invasion.minimal_evolution then 
			ratio = (game.forces.enemy.evolution_factor-disasters.invasion.minimal_evolution)/(1-disasters.invasion.minimal_evolution)
		else
			ratio = 0
		end

		local nb_nests = math.floor(0.4+disasters.invasion.nb_nests_min + (disasters.invasion.nb_nests_max-disasters.invasion.nb_nests_min)*ratio)

		debug_print("invasion target=", target.x, ",", target.y, " nests=", nb_nests )

		local invasion = {
			position = target,
			nests = {},
			nb_nests = nb_nests,
		}
		
		table.insert(global.invasions, invasion )
		
		if armageddon_verbose then
			message_all({"arma-gui-warning-invasion"})
		end
	else
		debug_print("target=nil" )
	end
end

--------------------------------------------------------------------------------------
local function create_biterzilla()
	local target = find_random_position()
	
	if target ~= nil then
		debug_print("biterzilla target=", target.x, ",", target.y )

		local position = global.surface.find_non_colliding_position("biterzilla", target, 0, 1)
		if position ~= nil then
			local zilla = global.surface.create_entity{name="biterzilla", position=position, force = game.forces.enemy}
			zilla.active = false
			table.insert(global.biterzillas, { entity = zilla, countdown = disasters.biterzilla.activation_delay } )
		end
		
		if armageddon_verbose then
			message_all({"arma-gui-warning-biterzilla"})
		end
	else
		debug_print("target=nil" )
	end
end

--------------------------------------------------------------------------------------
local function create_frenzy()
	local target = find_random_position()
	
	if target ~= nil then
		local ratio 
		-- local nb_aliens = math.random(disasters.frenzy.nb_aliens_min,disasters.frenzy.nb_aliens_max) 
		if game.forces.enemy.evolution_factor > disasters.frenzy.minimal_evolution then 
			ratio = (game.forces.enemy.evolution_factor-disasters.frenzy.minimal_evolution)/(1-disasters.frenzy.minimal_evolution)
		else
			ratio = 0
		end

		local nb_aliens = math.floor((disasters.frenzy.nb_aliens_min + ratio *(disasters.frenzy.nb_aliens_max-disasters.frenzy.nb_aliens_min)) * (0.8+0.4*math.random()))
		
		debug_print("frenzy target=", target.x, ",", target.y, " aliens=", nb_aliens )
		
		local sent = global.surface.set_multi_command({
			command = {type=defines.command.attack_area, destination=target, radius=disasters.frenzy.radius_target, distraction = defines.distraction.by_anything },
			unit_count = nb_aliens,
			force = game.forces.enemy,
			unit_search_distance = disasters.frenzy.radius_call,
		})

		debug_print("frenzy sent aliens=", sent )

		if armageddon_verbose then
			message_all({"arma-gui-warning-frenzy"})
		end
	else
		debug_print("target=nil" )
	end
end

--------------------------------------------------------------------------------------
function init_globals()
	-- initialize or update general globals of the mod
	debug_print( "init_globals " )

	global.enabled = armageddon_enabled
	global.surface = game.surfaces.nauvis
	global.ticks = global.ticks or 0
	global.disaster_average_days = global.disaster_average_days or disaster_average_days
	
	global.invasions = global.invasions or {} -- invasions
	global.biterzillas = global.biterzillas or {} -- biterzillas
	
	global.n_chunks_constructed = global.n_chunks_constructed or 0
	if global.chunks_constructed == nil then -- chunks populated/constructed by players (where to pop disasters)
		global.chunks_constructed = {}
		init_chunks()
	end
end

--------------------------------------------------------------------------------------
local function on_init() 
	-- called once, the first time the mod is loaded on a game (new or existing game)
	debug_print( "on_init" )
	init_globals()
end

script.on_init(on_init)

--------------------------------------------------------------------------------------
local function on_configuration_changed(data)
	-- detect any mod or game version change
	if data.mod_changes ~= nil then
		local changes = data.mod_changes[debug_mod_name]
		if changes ~= nil then
			debug_print( "update mod: ", debug_mod_name, " ", tostring(changes.old_version), " to ", tostring(changes.new_version) )
		
			init_globals()
		end
	end
end

script.on_configuration_changed(on_configuration_changed)

--------------------------------------------------------------------------------------
local function on_creation( event )
	local ent = event.created_entity
	local force = ent.force
	
	if force ~= game.forces.enemy and force ~= game.forces.neutral then
		-- debug_print( "construction ", ent.name )
		
		-- update constructed chunks
		
		local xc = math.floor(ent.position.x / 32)
		local yc = math.floor(ent.position.y / 32)
		local tag = tostring(xc) .. "," .. tostring(yc)
		if global.chunks_constructed[tag] == nil then
			global.chunks_constructed[tag] = { x = xc, y = yc }
			global.n_chunks_constructed = global.n_chunks_constructed + 1
			debug_print( "n_chunks_constructed=", global.n_chunks_constructed )
		end
	end
end

script.on_event(defines.events.on_built_entity, on_creation )
script.on_event(defines.events.on_robot_built_entity, on_creation )

--------------------------------------------------------------------------------------
local function on_tick(event)
	if not global.enabled then return end
	
	if global.ticks <= 0 then
		-- new disaster
		local type = nil
		
		for name, disaster in pairs(disasters) do
			local dice = math.random()
			debug_print( "disaster=", name, " dice=", string.format("%3f",dice), " evol=", string.format("%3f",game.forces.enemy.evolution_factor))
			if game.forces.enemy.evolution_factor > disaster.minimal_evolution then
				if dice <= disaster.proba then
					type = name
					break
				end
			end
		end
		
		if type ~= nil then
			debug_print( "type=", type)
			
			if type == "invasion" then
				create_invasion()
				
			elseif type == "biterzilla" then
				create_biterzilla()

			elseif type == "frenzy" then
				create_frenzy()
			end
			
			-- next event :
			local dura_next = global.disaster_average_days * 25000 * 2 / (1+game.forces.enemy.evolution_factor) -- 25000 ticks is 1 game-day
			dura_next = math.floor(dura_next * (0.8+0.7*math.random())) -- adds a little random
			-- if debug_status == 1 then dura_next = math.floor(25000 / 12) end
			debug_print( "dura_next=", dura_next)
		
			global.ticks = dura_next
		else
			global.ticks = 600
		end
	end
		
	if global.ticks %159 == 0 then
		-- manage invasion apparition
		
		for i, invasion in pairs(global.invasions) do
			if invasion.nb_nests > 0 then
				local position = global.surface.find_non_colliding_position("arma-spawner", invasion.position, 0, 1)
				if position ~= nil then
					local nest = global.surface.create_entity{name="arma-spawner", position=position, force = game.forces.enemy}
					table.insert( invasion.nests, nest )
				end
		
				invasion.nb_nests = invasion.nb_nests - 1
			else
				if #invasion.nests == 0 then
					table.remove(global.invasions,i)
					break
				else
					for k, nest in pairs(invasion.nests) do
						if not nest.valid then
							table.remove(invasion.nests, k)
							break
						end
					end
				end
			end
		end
	end
		
	if global.ticks %57 == 0 then
		-- manage biterzillas area damages and apparition countdown
		
		for k, zilla in pairs(global.biterzillas) do
			if zilla.entity.valid then
				if zilla.countdown == -1 then
					-- damage objects around.
					local a = square_area(zilla.entity.position,5)
					local ents = global.surface.find_entities(a)
					for _, ent in pairs(ents) do
						if ent.valid and ent.health ~= nil then
							ent.damage(disasters.biterzilla.area_damage,game.forces.enemy,"physical")
						end
					end
				elseif zilla.countdown > 0 then
					zilla.countdown = zilla.countdown - 1
				elseif zilla.countdown == 0 then
					zilla.entity.active = true
					zilla.countdown = -1
				end
			else
				table.remove(global.biterzillas,k)
				break
			end
		end
	end
	
	global.ticks = global.ticks - 1
end

script.on_event(defines.events.on_tick, on_tick )

--------------------------------------------------------------------------------------

local interface = {}

function interface.reset()
	debug_print( "reset" )
	global.enabled = true
	global.ticks = 0
	for _, invasion in pairs(global.invasions) do
		for _, nest in pairs(invasion.nests) do
			if nest.valid then
				nest.die()
			end
		end
	end
	global.invasions = {}
	
	for _, zilla in pairs(global.biterzillas) do
		if zilla.entity.valid then
			zilla.entity.die()
		end
	end
	global.biterzillas = {}
	
	message_all( "chunks = " .. global.n_chunks_constructed )
end

function interface.on()
	debug_print( "on" )
	global.enabled = true
end

function interface.off()
	debug_print( "off" )
	global.enabled = false
end

function interface.invasion()
	debug_print( "manual invasion" )
	
	if global.enabled then
		create_invasion()
	end
end

function interface.biterzilla()
	debug_print( "manual biterzilla" )
	
	if global.enabled then
		create_biterzilla()
	end
end

function interface.frenzy()
	debug_print( "manual frenzy" )
	
	if global.enabled then
		create_frenzy()
	end
end

function interface.days( d )
	debug_print( "days" )
	
	d = tonumber(d)
	
	if d ~= nil then
		global.disaster_average_days = math.floor(math.max(1,d))
	end
end

remote.add_interface( "armageddon", interface )

-- /c remote.call( "armageddon", "reset" )
-- /c remote.call( "armageddon", "on" )
-- /c remote.call( "armageddon", "off" )
-- /c remote.call( "armageddon", "invasion" )
-- /c remote.call( "armageddon", "frenzy" )
-- /c remote.call( "armageddon", "biterzilla" )
-- /c remote.call( "armageddon", "days", 8 )
