require("config")

arma_spawner_tint = {r=0.09, g=0.99, b=0.09, a=1}

--------------------------------------------------------------------------------------
local corpse = dupli_proto( "corpse", "biter-spawner-corpse", "arma-spawner-corpse" )
corpse.animation =
{
	{
		layers =
		{
			{
				width = 148,
				height = 148,
				frame_count = 1,
				direction_count = 1,
				shift = {0,0},
				stripes =
				{
					{
						filename = "__Armageddon__/graphics/tunnel-dead.png",
						width_in_frames = 1,
						height_in_frames = 1,
						y = 0
					},
				}
			},
		}
	}
}
corpse.time_before_removed = 5 * 60 * 60


--------------------------------------------------------------------------------------
local spawner = dupli_proto( "unit-spawner", "biter-spawner", "arma-spawner" )
spawner.corpse = "arma-spawner-corpse"
spawner.animations =
{
	{
		layers =
		{
			{
				filename = "__Armageddon__/graphics/tunnel.png",
				line_length = 1,
				width = 148,
				height = 148,
				frame_count = 1,
				animation_speed = 0.18,
				direction_count = 1,
				run_mode = "forward-then-backward",
				shift = {0,0},
			},
		}
	}
}
-- spawner.loot =
-- {
	-- {
		-- count_max = 30,
		-- count_min = 20,
		-- item = "alien-artifact",
		-- probability = 1
	-- }
-- }
spawner.max_count_of_owned_units = 7
spawner.max_friends_around_to_spawn = 16
spawner.spawning_cooldown = {60*5, 60*2}
spawner.result_units = (function()
	local res = {}
	res[1] = {"small-biter", {{0.0, 0.3}, {0.7, 0.0}}}
	res[2] = {"medium-biter", {{0.3, 0.0}, {0.6, 0.3}, {0.8, 0.1}}}
	res[3] = {"big-biter", {{0.6, 0.0}, {1.0, 0.4}}}
	res[4] = {"behemoth-biter", {{0.99, 0.0}, {1.0, 0.3}}}
	res[5] = {"small-spitter", {{0.25, 0.0}, {0.5, 0.3}, {0.7, 0.0}}}
	res[6] = {"medium-spitter", {{0.5, 0.0}, {0.7, 0.3}, {0.9, 0.1}}}
	res[7] = {"big-spitter", {{0.6, 0.0}, {1.0, 0.4}}}
	res[8] = {"behemoth-spitter", {{0.99, 0.0}, {1.0, 0.3}}}
	return res
end)()

--------------------------------------------------------------------------------------
local biterzilla_scale = 5
local biterzilla_tint1 = {r=0.9, g=0.3, b=0.3, a=0.75}
local biterzilla_tint2 = {r=0.88, g=0.24, b=0.24, a=0.9}

data:extend(
	{
		corpse,
		spawner,
		
		{
			type = "unit",
			name = "biterzilla",
			order="b-b-d",
			icon = "__base__/graphics/icons/behemoth-biter.png",
			icon_size = 32,
			flags = {"placeable-player", "placeable-enemy", "placeable-off-grid", "breaths-air", "not-repairable"},
			max_health = disasters.biterzilla.max_health,
			subgroup="enemies",
			resistances =
			{
				{
					type = "physical",
					decrease = 8,
					percent = 40
				},
				{
					type = "explosion",
					decrease = 10,
					percent = 40
				}
			},
			spawning_time_modifier = 8,
			healing_per_tick = 0.1,
			collision_box = {{-0.1, -0.1}, {0.1, 0.1}},
			selection_box = {{-3.4, -3.4}, {3.4, 3.4}},
			distraction_cooldown = 300, -- 300,
			attack_parameters =
			{
				type = "projectile",
				range = 10,
				cooldown = 20,
				ammo_category = "melee",
				ammo_type = make_unit_melee_ammo_type(disasters.biterzilla.attack_damage),
				sound =  make_biter_roars(0.8),
				animation = biterattackanimation(biterzilla_scale, biterzilla_tint1, biterzilla_tint2)
			},
			vision_distance = 45, -- 30
			movement_speed = 0.03,
			distance_per_frame = 0.3,
			-- in pu
			pollution_to_join_attack = 1, -- 20000
			corpse = "biterzilla-corpse",
			dying_explosion = "blood-explosion-big",
			working_sound = make_biter_calls(1.5),
			dying_sound = make_biter_dying_sounds(1.5),
			run_animation = biterrunanimation(biterzilla_scale, biterzilla_tint1, biterzilla_tint2)
		},

		{
			type = "corpse",
			name = "biterzilla-corpse",
			icon = "__base__/graphics/icons/big-biter-corpse.png",
			icon_size = 32,
			selectable_in_game = false,
			selection_box = {{-3, -3}, {3, 3}},
			subgroup="corpses",
			order = "c[corpse]-a[biter]-c[big]",
			flags = {"placeable-neutral", "placeable-off-grid", "building-direction-8-way", "not-on-map"},
			dying_speed = 0.1,
			time_before_removed = 15 * 60 * 60,
			final_render_layer = "corpse",
			animation = biterdieanimation(biterzilla_scale, biterzilla_tint1, biterzilla_tint2)
		},
  
	}
)