armageddon_enabled = true -- to disable the mod without losing all its inner data (initial scan)

armageddon_verbose = true -- to enable a warning message when a disaster happens.

disaster_average_days = 4 -- in game days (when evolution is maximal), 1 game day = 7 real mins.

disasters = { -- list must be in minimal_evolution descending order... last will be default disaster if no other found.
	biterzilla = { proba = 0.2, minimal_evolution = 0.9, max_health = 200000, attack_damage = 400, area_damage = 50, activation_delay = 5 }, -- gigantic bitter 
	invasion = { proba = 0.35, minimal_evolution = 0.5, nb_nests_min = 1, nb_nests_max = 8}, -- alien underground invasion 
	frenzy = { proba = 1, minimal_evolution = 0.2, nb_aliens_min = 20, nb_aliens_max = 500, radius_target=150, radius_call=2000}, -- alien frenzy attack 
}


