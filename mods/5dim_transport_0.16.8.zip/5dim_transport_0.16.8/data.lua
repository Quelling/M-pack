require("config")
--Changes
require("prototypes.changes")
--Chest
require("prototypes.chest-2")
require("prototypes.chest-3")
require("prototypes.chest-4")
require("prototypes.chest-5")
--Pipe
require("prototypes.pipe-2")
require("prototypes.pipe-3")
--Pipe Ground
require("prototypes.pipe-ground-2")
require("prototypes.pipe-ground-3")
--Pipe Ground 30
require("prototypes.pipe-ground-1-30")
require("prototypes.pipe-ground-2-30")
require("prototypes.pipe-ground-3-30")
--Pipe Ground 50
require("prototypes.pipe-ground-1-50")
require("prototypes.pipe-ground-2-50")
require("prototypes.pipe-ground-3-50")
--Splitter
require("prototypes.splitter-4")
require("prototypes.splitter-5")
--Tank Ground
require("prototypes.tank-ground")
--Tansport Belt
require("prototypes.transport-belt-4")
require("prototypes.transport-belt-5")
--Tansport Belt Ground
require("prototypes.transport-belt-ground-4")
require("prototypes.transport-belt-ground-5")
--Tansport Belt Ground 30
require("prototypes.transport-belt-ground-1-30")
require("prototypes.transport-belt-ground-2-30")
require("prototypes.transport-belt-ground-3-30")
require("prototypes.transport-belt-ground-4-30")
require("prototypes.transport-belt-ground-5-30")
--Tansport Belt Ground 50
require("prototypes.transport-belt-ground-1-50")
require("prototypes.transport-belt-ground-2-50")
require("prototypes.transport-belt-ground-3-50")
require("prototypes.transport-belt-ground-4-50")
require("prototypes.transport-belt-ground-5-50")
--Tech
require("prototypes.tech")