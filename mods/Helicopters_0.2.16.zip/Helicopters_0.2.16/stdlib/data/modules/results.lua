--luacheck: ignore

local Results = {
    _class = 'Results'
}

return Results
