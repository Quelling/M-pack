data:extend({
 {
    type = "item",
    name = "reinforced-wall",
    icon = "__Reinforced-Walls-016__/graphics/icons/reinforced-wall.png",
      icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "a[stone-wall]-b[reinforced-wall]",
    place_result = "reinforced-wall",
    stack_size = 100
  },
  {
     type = "item",
    name = "acid-resist-wall",
    icon = "__Reinforced-Walls-016__/graphics/icons/acid-resist-wall.png",
      icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "a[stone-wall]-c[acid-resist-wall]",
    place_result = "acid-resist-wall",
    stack_size = 100
  },
  {
     type = "item",
    name = "damage-reflect-wall",
    icon = "__Reinforced-Walls-016__/graphics/icons/damage-reflect-wall.png",
      icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
    order = "a[stone-wall]-c[damage-reflect-wall]",
    place_result = "damage-reflect-wall",
    stack_size = 100
  }
  
})
