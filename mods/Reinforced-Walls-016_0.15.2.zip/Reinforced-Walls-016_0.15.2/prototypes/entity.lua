local w = util.table.deepcopy(data.raw["wall"]["stone-wall"])
w.name = "reinforced-wall"
w.icon = "__Reinforced-Walls-016__/graphics/icons/reinforced-wall.png"
w.minable.result = "reinforced-wall"
w.max_health = 700
w.resistances = {
      {
        type = "physical",
        decrease = 3,
        percent = 40
      },
      {
        type = "impact",
        decrease = 45,
        percent = 60
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 30
      },
      {
        type = "fire",
        percent = 100
      },
      {
        type = "laser",
        percent = 70
      }
    }

data:extend { w	}


local w = util.table.deepcopy(data.raw["wall"]["stone-wall"])
w.name = "acid-resist-wall"
w.icon = "__Reinforced-Walls-016__/graphics/icons/acid-resist-wall.png"
w.minable.result = "acid-resist-wall"
w.max_health = 700
w.resistances =
    {
      {
        type = "physical",
        decrease = 3,
        percent = 50
      },
      {
        type = "impact",
        decrease = 45,
        percent = 60
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 30
      },
      {
        type = "fire",
        percent = 100
      },
      {
        type = "acid",
        decrease = 4,
        percent = 60
      },	  
      {
        type = "laser",
        percent = 70
      }
    }

data:extend { w	}



local w = util.table.deepcopy(data.raw["wall"]["stone-wall"])
w.name = "damage-reflect-wall"
w.icon = "__Reinforced-Walls-016__/graphics/icons/damage-reflect-wall.png"
w.minable.result = "damage-reflect-wall"
w.max_health = 700
w.resistances =
    {
      {
        type = "physical",
        decrease = 3,
        percent = 50
      },
      {
        type = "impact",
        decrease = 45,
        percent = 60
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 30
      },
      {
        type = "fire",
        percent = 100
      },
	  {
        type = "acid",
        decrease = 4,
        percent = 60
      },	
      {
        type = "laser",
        percent = 70
      }
    }


    -- this kind of code can be used for having walls mirror the effect
    -- there can be multiple reaction items

w.attack_reaction =
    {
        {
        ---- how far the mirroring works
        range = 2,
        ---- what kind of damage triggers the mirroring
        ---- if not present then anything triggers the mirroring
        --damage_type = "laser",
        ---- caused damage will be multiplied by this and added to the subsequent damages
        reaction_modifier = 0.1,
        action =
             {
              type = "direct",
             action_delivery =
                {
                type = "instant",
                target_effects =
                  {
                  type = "damage",
                  ---- always use at least 0.1 damage
                  damage = {amount = 0.5, type = "laser"}
                  }
               }
             },
       }
    }
data:extend { w	}

