--plates
if not mods["angelssmelting"] then
	--plates
	if data.raw["item"]["tin-plate"] then data.raw["item"]["tin-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/tin-plate.png" end
	if data.raw["item"]["tin-plate"] then data.raw["item"]["tin-plate"].icon_size = 32 end

	if data.raw["item"]["silver-plate"] then data.raw["item"]["silver-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silver-plate.png" end
	if data.raw["item"]["silver-plate"] then data.raw["item"]["silver-plate"].icon_size = 32 end

	if data.raw["item"]["lead-plate"] then data.raw["item"]["lead-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lead-plate.png" end
	if data.raw["item"]["lead-plate"] then data.raw["item"]["lead-plate"].icon_size = 32 end

	if data.raw["item"]["gold-plate"] then data.raw["item"]["gold-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/gold-plate.png" end
	if data.raw["item"]["gold-plate"] then data.raw["item"]["gold-plate"].icon_size = 32 end

	if data.raw["item"]["nickel-plate"] then data.raw["item"]["nickel-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/nickel-plate.png" end
	if data.raw["item"]["nickel-plate"] then data.raw["item"]["nickel-plate"].icon_size = 32 end

	if data.raw["item"]["zinc-plate"] then data.raw["item"]["zinc-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/zinc-plate.png" end
	if data.raw["item"]["zinc-plate"] then data.raw["item"]["zinc-plate"].icon_size = 32 end

	if data.raw["item"]["aluminium-plate"] then data.raw["item"]["aluminium-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/aluminium-plate.png" end
	if data.raw["item"]["aluminium-plate"] then data.raw["item"]["aluminium-plate"].icon_size = 32 end

	if data.raw["item"]["titanium-plate"] then data.raw["item"]["titanium-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/titanium-plate.png" end
	if data.raw["item"]["titanium-plate"] then data.raw["item"]["titanium-plate"].icon_size = 32 end

	if data.raw["item"]["tungsten-plate"] then data.raw["item"]["tungsten-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/tungsten-plate.png" end
	if data.raw["item"]["tungsten-plate"] then data.raw["item"]["tungsten-plate"].icon_size = 32 end

	if data.raw["item"]["silicon"] then data.raw["item"]["silicon"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silicon-plate.png" end
	if data.raw["item"]["silicon"] then data.raw["item"]["silicon"].icon_size = 32 end

	if data.raw["item"]["cobalt-plate"] then data.raw["item"]["cobalt-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/cobalt-plate.png" end
	if data.raw["item"]["cobalt-plate"] then data.raw["item"]["cobalt-plate"].icon_size = 32 end

	--alloys
	if data.raw["item"]["bronze-alloy"] then data.raw["item"]["bronze-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/bronze-plate.png" end
	if data.raw["item"]["bronze-alloy"] then data.raw["item"]["bronze-alloy"].icon_size = 32 end

	if data.raw["item"]["brass-alloy"] then data.raw["item"]["brass-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/brass-plate.png" end
	if data.raw["item"]["brass-alloy"] then data.raw["item"]["brass-alloy"].icon_size = 32 end

	if data.raw["item"]["electrum-alloy"] then data.raw["item"]["electrum-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/electrum-plate.png" end
	if data.raw["item"]["electrum-alloy"] then data.raw["item"]["electrum-alloy"].icon_size = 32 end

	if data.raw["item"]["gunmetal-alloy"] then data.raw["item"]["gunmetal-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/gunmetal-plate.png" end
	if data.raw["item"]["gunmetal-alloy"] then data.raw["item"]["gunmetal-alloy"].icon_size = 32 end

	if data.raw["item"]["invar-alloy"] then data.raw["item"]["invar-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/invar-plate.png" end
	if data.raw["item"]["invar-alloy"] then data.raw["item"]["invar-alloy"].icon_size = 32 end

	if data.raw["item"]["nitinol-alloy"] then data.raw["item"]["nitinol-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/nitinol-plate.png" end
	if data.raw["item"]["nitinol-alloy"] then data.raw["item"]["nitinol-alloy"].icon_size = 32 end

	if data.raw["item"]["cobalt-steel-alloy"] then data.raw["item"]["cobalt-steel-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/cobalt-steel-plate.png" end
	if data.raw["item"]["cobalt-steel-alloy"] then data.raw["item"]["cobalt-steel-alloy"].icon_size = 32 end

	if data.raw["item"]["glass"] then data.raw["item"]["glass"].icon = "__morebobs__/graphics/moreshiny/icons/plates/glass.png" end
	if data.raw["item"]["glass"] then data.raw["item"]["glass"].icon_size = 32 end

	--other
	if data.raw["item"]["alumina"] then data.raw["item"]["alumina"].icon = "__morebobs__/graphics/moreshiny/icons/plates/corundum.png" end
	if data.raw["item"]["alumina"] then data.raw["item"]["alumina"].icon_size = 32 end

	if data.raw["item"]["cobalt-oxide"] then data.raw["item"]["cobalt-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/cobalt-oxide.png" end
	if data.raw["item"]["cobalt-oxide"] then data.raw["item"]["cobalt-oxide"].icon_size = 32 end

	if data.raw["item"]["lead-oxide"] then data.raw["item"]["lead-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lead-oxide.png" end
	if data.raw["item"]["lead-oxide"] then data.raw["item"]["lead-oxide"].icon_size = 32 end

	if data.raw["item"]["silver-nitrate"] then data.raw["item"]["silver-nitrate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silver-nitrate.png" end
	if data.raw["item"]["silver-nitrate"] then data.raw["item"]["silver-nitrate"].icon_size = 32 end

	if data.raw["item"]["powdered-tungsten"] then data.raw["item"]["powdered-tungsten"].icon = "__morebobs__/graphics/moreshiny/icons/plates/powdered-tungsten.png" end
	if data.raw["item"]["powdered-tungsten"] then data.raw["item"]["powdered-tungsten"].icon_size = 32 end

	if data.raw["item"]["tungsten-oxide"] then data.raw["item"]["tungsten-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/tungsten-oxide.png" end
	if data.raw["item"]["tungsten-oxide"] then data.raw["item"]["tungsten-oxide"].icon_size = 32 end
end

--plates
if data.raw["item"]["lithium"] then data.raw["item"]["lithium"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lithium-plate.png" end
if data.raw["item"]["lithium"] then data.raw["item"]["lithium"].icon_size = 32 end

--alloys
if data.raw["item"]["alien-blue-alloy"] then data.raw["item"]["alien-blue-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/alien-blue-alloy.png" end
if data.raw["item"]["alien-blue-alloy"] then data.raw["item"]["alien-blue-alloy"].icon_size = 32 end

if data.raw["item"]["alien-orange-alloy"] then data.raw["item"]["alien-orange-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/alien-orange-alloy.png" end
if data.raw["item"]["alien-orange-alloy"] then data.raw["item"]["alien-orange-alloy"].icon_size = 32 end

if data.raw["item"]["copper-tungsten-alloy"] then data.raw["item"]["copper-tungsten-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/copper-tungsten-plate.png" end
if data.raw["item"]["copper-tungsten-alloy"] then data.raw["item"]["copper-tungsten-alloy"].icon_size = 32 end

if data.raw["item"]["tungsten-carbide"] then data.raw["item"]["tungsten-carbide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/tungsten-carbide-plate.png" end
if data.raw["item"]["tungsten-carbide"] then data.raw["item"]["tungsten-carbide"].icon_size = 32 end

if data.raw["item"]["solder-alloy"] then data.raw["item"]["solder-alloy"].icon = "__morebobs__/graphics/moreshiny/icons/plates/solder-plate.png" end
if data.raw["item"]["solder-alloy"] then data.raw["item"]["solder-alloy"].icon_size = 32 end

--other
if data.raw["item"]["calcium-chloride"] then data.raw["item"]["calcium-chloride"].icon = "__morebobs__/graphics/moreshiny/icons/plates/calcium-chloride.png" end
if data.raw["item"]["calcium-chloride"] then data.raw["item"]["calcium-chloride"].icon_size = 32 end

if data.raw["item"]["carbon"] then data.raw["item"]["carbon"].icon = "__morebobs__/graphics/moreshiny/icons/plates/carbon.png" end
if data.raw["item"]["carbon"] then data.raw["item"]["carbon"].icon_size = 32 end

if data.raw["item"]["gun-cotton"] then data.raw["item"]["gun-cotton"].icon = "__morebobs__/graphics/moreshiny/icons/plates/gun-cotton.png" end
if data.raw["item"]["gun-cotton"] then data.raw["item"]["gun-cotton"].icon_size = 32 end

if data.raw["item"]["heat-shield-tile"] then data.raw["item"]["heat-shield-tile"].icon = "__morebobs__/graphics/moreshiny/icons/plates/heat-shield-tile.png" end
if data.raw["item"]["heat-shield-tile"] then data.raw["item"]["heat-shield-tile"].icon_size = 32 end

if data.raw["item"]["lithium-chloride"] then data.raw["item"]["lithium-chloride"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lithium-chloride.png" end
if data.raw["item"]["lithium-chloride"] then data.raw["item"]["lithium-chloride"].icon_size = 32 end

if data.raw["item"]["lithium-cobalt-oxide"] then data.raw["item"]["lithium-cobalt-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lithium-cobalt-oxide.png" end
if data.raw["item"]["lithium-cobalt-oxide"] then data.raw["item"]["lithium-cobalt-oxide"].icon_size = 32 end

if data.raw["item"]["lithium-perchlorate"] then data.raw["item"]["lithium-perchlorate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lithium-perchlorate.png" end
if data.raw["item"]["lithium-perchlorate"] then data.raw["item"]["lithium-perchlorate"].icon_size = 32 end

if data.raw["item"]["petroleum-jelly"] then data.raw["item"]["petroleum-jelly"].icon = "__morebobs__/graphics/moreshiny/icons/plates/petroleum-jelly.png" end
if data.raw["item"]["petroleum-jelly"] then data.raw["item"]["petroleum-jelly"].icon_size = 32 end

if data.raw["item"]["silicon-powder"] then data.raw["item"]["silicon-powder"].icon = "__morebobs__/graphics/moreshiny/icons/plates/powdered-silicon.png" end
if data.raw["item"]["silicon-powder"] then data.raw["item"]["silicon-powder"].icon_size = 32 end

if data.raw["item"]["rubber"] then data.raw["item"]["rubber"].icon = "__morebobs__/graphics/moreshiny/icons/plates/rubber.png" end
if data.raw["item"]["rubber"] then data.raw["item"]["rubber"].icon_size = 32 end

if data.raw["item"]["salt"] then data.raw["item"]["salt"].icon = "__morebobs__/graphics/moreshiny/icons/plates/salt.png" end
if data.raw["item"]["salt"] then data.raw["item"]["salt"].icon_size = 32 end

if data.raw["item"]["silicon-carbide"] then data.raw["item"]["silicon-carbide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silicon-carbide.png" end
if data.raw["item"]["silicon-carbide"] then data.raw["item"]["silicon-carbide"].icon_size = 32 end

if data.raw["item"]["silicon-nitride"] then data.raw["item"]["silicon-nitride"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silicon-nitride.png" end
if data.raw["item"]["silicon-nitride"] then data.raw["item"]["silicon-nitride"].icon_size = 32 end

if data.raw["item"]["silicon-wafer"] then data.raw["item"]["silicon-wafer"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silicon-wafer.png" end
if data.raw["item"]["silicon-wafer"] then data.raw["item"]["silicon-wafer"].icon_size = 32 end

if data.raw["item"]["silver-oxide"] then data.raw["item"]["silver-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/silver-oxide.png" end
if data.raw["item"]["silver-oxide"] then data.raw["item"]["silver-oxide"].icon_size = 32 end

if data.raw["item"]["sodium-hydroxide"] then data.raw["item"]["sodium-hydroxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/sodium-hydroxide.png" end
if data.raw["item"]["sodium-hydroxide"] then data.raw["item"]["sodium-hydroxide"].icon_size = 32 end

--Origin
if data.raw["item"]["raw-wood"] then data.raw["item"]["raw-wood"].icon = "__morebobs__/graphics/moreshiny/icons/plates/raw-wood.png" end
if data.raw["item"]["raw-wood"] then data.raw["item"]["raw-wood"].icon_size = 32 end

if data.raw["item"]["wood"] then data.raw["item"]["wood"].icon = "__morebobs__/graphics/moreshiny/icons/plates/wood.png" end
if data.raw["item"]["wood"] then data.raw["item"]["wood"].icon_size = 32 end

if data.raw["item"]["stone-brick"] then data.raw["item"]["stone-brick"].icon = "__morebobs__/graphics/moreshiny/icons/plates/stone-brick.png" end
if data.raw["item"]["stone-brick"] then data.raw["item"]["stone-brick"].icon_size = 32 end

if data.raw["item"]["concrete"] then data.raw["item"]["concrete"].icon = "__morebobs__/graphics/moreshiny/icons/plates/concrete.png" end
if data.raw["item"]["concrete"] then data.raw["item"]["concrete"].icon_size = 32 end

if data.raw["item"]["hazard-concrete"] then data.raw["item"]["hazard-concrete"].icon = "__morebobs__/graphics/moreshiny/icons/plates/hazard-concrete.png" end
if data.raw["item"]["hazard-concrete"] then data.raw["item"]["hazard-concrete"].icon_size = 32 end

if data.raw["item"]["plastic-bar"] then data.raw["item"]["plastic-bar"].icon = "__morebobs__/graphics/moreshiny/icons/plates/plastic-bar.png" end
if data.raw["item"]["plastic-bar"] then data.raw["item"]["plastic-bar"].icon_size = 32 end

--recipes
if data.raw["recipe"]["synthetic-wood"] then data.raw["recipe"]["synthetic-wood"].icon = "__morebobs__/graphics/moreshiny/icons/plates/synthetic-wood.png" end
if data.raw["recipe"]["synthetic-wood"] then data.raw["recipe"]["synthetic-wood"].icon_size = 32 end

if data.raw["recipe"]["cobalt-oxide-from-copper"] then data.raw["recipe"]["cobalt-oxide-from-copper"].icon = "__morebobs__/graphics/moreshiny/icons/plates/copper-cobalt-oxide.png" end
if data.raw["recipe"]["cobalt-oxide-from-copper"] then data.raw["recipe"]["cobalt-oxide-from-copper"].icon_size = 32 end

if data.raw["recipe"]["silver-from-lead"] then data.raw["recipe"]["silver-from-lead"].icon = "__morebobs__/graphics/moreshiny/icons/plates/lead-silver.png" end
if data.raw["recipe"]["silver-from-lead"] then data.raw["recipe"]["silver-from-lead"].icon_size = 32 end

if data.raw["recipe"]["bob-nickel-plate"] then data.raw["recipe"]["bob-nickel-plate"].icon = "__morebobs__/graphics/moreshiny/icons/plates/nickel-sulfur-dioxide-recipe.png" end
if data.raw["recipe"]["bob-nickel-plate"] then data.raw["recipe"]["bob-nickel-plate"].icon_size = 32 end

if data.raw["recipe"]["lead-oxide"] then data.raw["recipe"]["lead-oxide"].icon = "__morebobs__/graphics/moreshiny/icons/plates/sulfur-lead-oxide-recipe.png" end
if data.raw["recipe"]["lead-oxide"] then data.raw["recipe"]["lead-oxide"].icon_size = 32 end