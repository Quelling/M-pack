--item-group
if data.raw["item-group"]["bob-logistics"] then data.raw["item-group"]["bob-logistics"].icon = "__morebobs__/graphics/moreshiny/cat/electronics-machine-chip.png" end
if data.raw["item-group"]["bob-logistics"] then data.raw["item-group"]["bob-logistics"].icon_size = 128 end
if data.raw["item-group"]["bob-gems"] then data.raw["item-group"]["bob-gems"].icon = "__morebobs__/graphics/moreshiny/cat/gem.png" end
if data.raw["item-group"]["bob-gems"] then data.raw["item-group"]["bob-gems"].icon_size = 128 end
if data.raw["item-group"]["bob-resource-products"] then data.raw["item-group"]["bob-resource-products"].icon = "__base__/graphics/technology/advanced-material-processing.png" end
if data.raw["item-group"]["bob-resource-products"] then data.raw["item-group"]["bob-resource-products"].icon_size = 128 end
if data.raw["item-group"]["bob-fluid-products"] then data.raw["item-group"]["bob-fluid-products"].icon = "__base__/graphics/technology/advanced-chemistry.png" end
if data.raw["item-group"]["bob-fluid-products"] then data.raw["item-group"]["bob-fluid-products"].icon_size = 128 end
if data.raw["item-group"]["bob-intermediate-products"] then data.raw["item-group"]["bob-intermediate-products"].icon = "__morebobs__/graphics/moreshiny/cat/advanced-electronics_old.png" end
if data.raw["item-group"]["bob-intermediate-products"] then data.raw["item-group"]["bob-intermediate-products"].icon_size = 128 end
if data.raw["item-group"]["bobmodules"] then data.raw["item-group"]["bobmodules"].icon = "__morebobs__/graphics/moreshiny/cat/modules.png" end
if data.raw["item-group"]["bobmodules"] then data.raw["item-group"]["bobmodules"].icon_size = 64 end
if data.raw["item-group"]["void"] then data.raw["item-group"]["void"].icon = "__morebobs__/graphics/moreshiny/cat/void.png" end
if data.raw["item-group"]["void"] then data.raw["item-group"]["void"].icon_size = 128 end
if data.raw["item-group"]["generated"] then data.raw["item-group"]["generated"].icon_size = 64 end