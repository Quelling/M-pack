if mods["bobmodules"] then
	--module-case
	if data.raw["tool"]["module-case"] then data.raw["tool"]["module-case"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-case.png" end
	if data.raw["tool"]["module-case"] then data.raw["tool"]["module-case"].icon_size = 32 end
	--module-contact
	if data.raw["item"]["module-case"] then data.raw["item"]["module-case"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-contact.png" end
	if data.raw["item"]["module-case"] then data.raw["item"]["module-case"].icon_size = 32 end
	--module-contact
	if data.raw["tool"]["module-circuit-board"] then data.raw["tool"]["module-circuit-board"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-circuit-board.png" end
	if data.raw["tool"]["module-circuit-board"] then data.raw["tool"]["module-circuit-board"].icon_size = 32 end

	--module-processor-board
	if data.raw["item"]["module-processor-board"] then data.raw["item"]["module-processor-board"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-processor-board.png" end
	if data.raw["item"]["module-processor-board"] then data.raw["item"]["module-processor-board"].icon_size = 32 end
	--module-processor-board-2
	if data.raw["item"]["module-processor-board-2"] then data.raw["item"]["module-processor-board-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-processor-board-2.png" end
	if data.raw["item"]["module-processor-board-2"] then data.raw["item"]["module-processor-board-2"].icon_size = 32 end
	--module-processor-board-3
	if data.raw["item"]["module-processor-board-3"] then data.raw["item"]["module-processor-board-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/module-processor-board-3.png" end
	if data.raw["item"]["module-processor-board-3"] then data.raw["item"]["module-processor-board-3"].icon_size = 32 end

	--speed-processor
	if data.raw["tool"]["speed-processor"] then data.raw["tool"]["speed-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor.png" end
	if data.raw["tool"]["speed-processor"] then data.raw["tool"]["speed-processor"].icon_size = 32 end
	--speed-processor-2
	if data.raw["item"]["speed-processor-2"] then data.raw["item"]["speed-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor-2.png" end
	if data.raw["item"]["speed-processor-2"] then data.raw["item"]["speed-processor-2"].icon_size = 32 end
	--speed-processor-3
	if data.raw["item"]["speed-processor-3"] then data.raw["item"]["speed-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor-3.png" end
	if data.raw["item"]["speed-processor-3"] then data.raw["item"]["speed-processor-3"].icon_size = 32 end

	--speed-processor
	if data.raw["tool"]["speed-processor"] then data.raw["tool"]["speed-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor.png" end
	if data.raw["tool"]["speed-processor"] then data.raw["tool"]["speed-processor"].icon_size = 32 end
	--speed-processor-2
	if data.raw["item"]["speed-processor-2"] then data.raw["item"]["speed-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor-2.png" end
	if data.raw["item"]["speed-processor-2"] then data.raw["item"]["speed-processor-2"].icon_size = 32 end
	--speed-processor-3
	if data.raw["item"]["speed-processor-3"] then data.raw["item"]["speed-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-processor-3.png" end
	if data.raw["item"]["speed-processor-3"] then data.raw["item"]["speed-processor-3"].icon_size = 32 end

	--effectivity-processor
	if data.raw["tool"]["effectivity-processor"] then data.raw["tool"]["effectivity-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-processor.png" end
	if data.raw["tool"]["effectivity-processor"] then data.raw["tool"]["effectivity-processor"].icon_size = 32 end
	--effectivity-processor-2
	if data.raw["item"]["effectivity-processor-2"] then data.raw["item"]["effectivity-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-processor-2.png" end
	if data.raw["item"]["effectivity-processor-2"] then data.raw["item"]["effectivity-processor-2"].icon_size = 32 end
	--effectivity-processor-3
	if data.raw["item"]["effectivity-processor-3"] then data.raw["item"]["effectivity-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-processor-3.png" end
	if data.raw["item"]["effectivity-processor-3"] then data.raw["item"]["effectivity-processor-3"].icon_size = 32 end

	--productivity-processor
	if data.raw["tool"]["productivity-processor"] then data.raw["tool"]["productivity-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-processor.png" end
	if data.raw["tool"]["productivity-processor"] then data.raw["tool"]["productivity-processor"].icon_size = 32 end
	--productivity-processor-2
	if data.raw["item"]["productivity-processor-2"] then data.raw["item"]["productivity-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-processor-2.png" end
	if data.raw["item"]["productivity-processor-2"] then data.raw["item"]["productivity-processor-2"].icon_size = 32 end
	--productivity-processor-3
	if data.raw["item"]["productivity-processor-3"] then data.raw["item"]["productivity-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-processor-3.png" end
	if data.raw["item"]["productivity-processor-3"] then data.raw["item"]["productivity-processor-3"].icon_size = 32 end

	--pollution-clean-processor
	if data.raw["tool"]["pollution-clean-processor"] then data.raw["tool"]["pollution-clean-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-processor.png" end
	if data.raw["tool"]["pollution-clean-processor"] then data.raw["tool"]["pollution-clean-processor"].icon_size = 32 end
	--pollution-clean-processor-2
	if data.raw["item"]["pollution-clean-processor-2"] then data.raw["item"]["pollution-clean-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-processor-2.png" end
	if data.raw["item"]["pollution-clean-processor-2"] then data.raw["item"]["pollution-clean-processor-2"].icon_size = 32 end
	--pollution-clean-processor-3
	if data.raw["item"]["pollution-clean-processor-3"] then data.raw["item"]["pollution-clean-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-processor-3.png" end
	if data.raw["item"]["pollution-clean-processor-3"] then data.raw["item"]["pollution-clean-processor-3"].icon_size = 32 end

	--pollution-create-processor
	if data.raw["tool"]["pollution-create-processor"] then data.raw["tool"]["pollution-create-processor"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-processor.png" end
	if data.raw["tool"]["pollution-create-processor"] then data.raw["tool"]["pollution-create-processor"].icon_size = 32 end
	--pollution-create-processor-2
	if data.raw["item"]["pollution-create-processor-2"] then data.raw["item"]["pollution-create-processor-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-processor-2.png" end
	if data.raw["item"]["pollution-create-processor-2"] then data.raw["item"]["pollution-create-processor-2"].icon_size = 32 end
	--pollution-create-processor-3
	if data.raw["item"]["pollution-create-processor-3"] then data.raw["item"]["pollution-create-processor-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-processor-3.png" end
	if data.raw["item"]["pollution-create-processor-3"] then data.raw["item"]["pollution-create-processor-3"].icon_size = 32 end

	--speed-module
	if data.raw["module"]["speed-module"] then data.raw["module"]["speed-module"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-1.png" end
	if data.raw["module"]["speed-module"] then data.raw["module"]["speed-module"].icon_size = 32 end
	--speed-module-2
	if data.raw["module"]["speed-module-2"] then data.raw["module"]["speed-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-2.png" end
	if data.raw["module"]["speed-module-2"] then data.raw["module"]["speed-module-2"].icon_size = 32 end
	--speed-module-3
	if data.raw["module"]["speed-module-3"] then data.raw["module"]["speed-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-3.png" end
	if data.raw["module"]["speed-module-3"] then data.raw["module"]["speed-module-3"].icon_size = 32 end
	--speed-module-4
	if data.raw["module"]["speed-module-4"] then data.raw["module"]["speed-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-4.png" end
	if data.raw["module"]["speed-module-4"] then data.raw["module"]["speed-module-4"].icon_size = 32 end
	--speed-module-5
	if data.raw["module"]["speed-module-5"] then data.raw["module"]["speed-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-5.png" end
	if data.raw["module"]["speed-module-5"] then data.raw["module"]["speed-module-5"].icon_size = 32 end
	--speed-module-6
	if data.raw["module"]["speed-module-6"] then data.raw["module"]["speed-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-6.png" end
	if data.raw["module"]["speed-module-6"] then data.raw["module"]["speed-module-6"].icon_size = 32 end
	--speed-module-7
	if data.raw["module"]["speed-module-7"] then data.raw["module"]["speed-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-7.png" end
	if data.raw["module"]["speed-module-7"] then data.raw["module"]["speed-module-7"].icon_size = 32 end
	--speed-module-8
	if data.raw["module"]["speed-module-8"] then data.raw["module"]["speed-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/speed-module-8.png" end
	if data.raw["module"]["speed-module-8"] then data.raw["module"]["speed-module-8"].icon_size = 32 end

	--effectivity-module
	if data.raw["module"]["effectivity-module"] then data.raw["module"]["effectivity-module"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-1.png" end
	if data.raw["module"]["effectivity-module"] then data.raw["module"]["effectivity-module"].icon_size = 32 end
	--effectivity-module-2
	if data.raw["module"]["effectivity-module-2"] then data.raw["module"]["effectivity-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-2.png" end
	if data.raw["module"]["effectivity-module-2"] then data.raw["module"]["effectivity-module-2"].icon_size = 32 end
	--effectivity-module-3
	if data.raw["module"]["effectivity-module-3"] then data.raw["module"]["effectivity-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-3.png" end
	if data.raw["module"]["effectivity-module-3"] then data.raw["module"]["effectivity-module-3"].icon_size = 32 end
	--effectivity-module-4
	if data.raw["module"]["effectivity-module-4"] then data.raw["module"]["effectivity-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-4.png" end
	if data.raw["module"]["effectivity-module-4"] then data.raw["module"]["effectivity-module-4"].icon_size = 32 end
	--effectivity-module-5
	if data.raw["module"]["effectivity-module-5"] then data.raw["module"]["effectivity-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-5.png" end
	if data.raw["module"]["effectivity-module-5"] then data.raw["module"]["effectivity-module-5"].icon_size = 32 end
	--effectivity-module-6
	if data.raw["module"]["effectivity-module-6"] then data.raw["module"]["effectivity-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-6.png" end
	if data.raw["module"]["effectivity-module-6"] then data.raw["module"]["effectivity-module-6"].icon_size = 32 end
	--effectivity-module-7
	if data.raw["module"]["effectivity-module-7"] then data.raw["module"]["effectivity-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-7.png" end
	if data.raw["module"]["effectivity-module-7"] then data.raw["module"]["effectivity-module-7"].icon_size = 32 end
	--effectivity-module-8
	if data.raw["module"]["effectivity-module-8"] then data.raw["module"]["effectivity-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/effectivity-module-8.png" end
	if data.raw["module"]["effectivity-module-8"] then data.raw["module"]["effectivity-module-8"].icon_size = 32 end

	--productivity-module
	if data.raw["module"]["productivity-module"] then data.raw["module"]["productivity-module"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-1.png" end
	if data.raw["module"]["productivity-module"] then data.raw["module"]["productivity-module"].icon_size = 32 end
	--productivity-module-2
	if data.raw["module"]["productivity-module-2"] then data.raw["module"]["productivity-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-2.png" end
	if data.raw["module"]["productivity-module-2"] then data.raw["module"]["productivity-module-2"].icon_size = 32 end
	--productivity-module-3
	if data.raw["module"]["productivity-module-3"] then data.raw["module"]["productivity-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-3.png" end
	if data.raw["module"]["productivity-module-3"] then data.raw["module"]["productivity-module-3"].icon_size = 32 end
	--productivity-module-4
	if data.raw["module"]["productivity-module-4"] then data.raw["module"]["productivity-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-4.png" end
	if data.raw["module"]["productivity-module-4"] then data.raw["module"]["productivity-module-4"].icon_size = 32 end
	--productivity-module-5
	if data.raw["module"]["productivity-module-5"] then data.raw["module"]["productivity-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-5.png" end
	if data.raw["module"]["productivity-module-5"] then data.raw["module"]["productivity-module-5"].icon_size = 32 end
	--productivity-module-6
	if data.raw["module"]["productivity-module-6"] then data.raw["module"]["productivity-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-6.png" end
	if data.raw["module"]["productivity-module-6"] then data.raw["module"]["productivity-module-6"].icon_size = 32 end
	--productivity-module-7
	if data.raw["module"]["productivity-module-7"] then data.raw["module"]["productivity-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-7.png" end
	if data.raw["module"]["productivity-module-7"] then data.raw["module"]["productivity-module-7"].icon_size = 32 end
	--productivity-module-8
	if data.raw["module"]["productivity-module-8"] then data.raw["module"]["productivity-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/productivity-module-8.png" end
	if data.raw["module"]["productivity-module-8"] then data.raw["module"]["productivity-module-8"].icon_size = 32 end

	--pollution-create-module
	if data.raw["module"]["pollution-create-module-1"] then data.raw["module"]["pollution-create-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-1.png" end
	if data.raw["module"]["pollution-create-module-1"] then data.raw["module"]["pollution-create-module-1"].icon_size = 32 end
	--pollution-create-module-2
	if data.raw["module"]["pollution-create-module-2"] then data.raw["module"]["pollution-create-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-2.png" end
	if data.raw["module"]["pollution-create-module-2"] then data.raw["module"]["pollution-create-module-2"].icon_size = 32 end
	--pollution-create-module-3
	if data.raw["module"]["pollution-create-module-3"] then data.raw["module"]["pollution-create-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-3.png" end
	if data.raw["module"]["pollution-create-module-3"] then data.raw["module"]["pollution-create-module-3"].icon_size = 32 end
	--pollution-create-module-4
	if data.raw["module"]["pollution-create-module-4"] then data.raw["module"]["pollution-create-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-4.png" end
	if data.raw["module"]["pollution-create-module-4"] then data.raw["module"]["pollution-create-module-4"].icon_size = 32 end
	--pollution-create-module-5
	if data.raw["module"]["pollution-create-module-5"] then data.raw["module"]["pollution-create-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-5.png" end
	if data.raw["module"]["pollution-create-module-5"] then data.raw["module"]["pollution-create-module-5"].icon_size = 32 end
	--pollution-create-module-6
	if data.raw["module"]["pollution-create-module-6"] then data.raw["module"]["pollution-create-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-6.png" end
	if data.raw["module"]["pollution-create-module-6"] then data.raw["module"]["pollution-create-module-6"].icon_size = 32 end
	--pollution-create-module-7
	if data.raw["module"]["pollution-create-module-7"] then data.raw["module"]["pollution-create-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-7.png" end
	if data.raw["module"]["pollution-create-module-7"] then data.raw["module"]["pollution-create-module-7"].icon_size = 32 end
	--pollution-create-module-8
	if data.raw["module"]["pollution-create-module-8"] then data.raw["module"]["pollution-create-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-create-module-8.png" end
	if data.raw["module"]["pollution-create-module-8"] then data.raw["module"]["pollution-create-module-8"].icon_size = 32 end

	--pollution-clean-module
	if data.raw["module"]["pollution-clean-module-1"] then data.raw["module"]["pollution-clean-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-1.png" end
	if data.raw["module"]["pollution-clean-module-1"] then data.raw["module"]["pollution-clean-module-1"].icon_size = 32 end
	--pollution-clean-module-2
	if data.raw["module"]["pollution-clean-module-2"] then data.raw["module"]["pollution-clean-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-2.png" end
	if data.raw["module"]["pollution-clean-module-2"] then data.raw["module"]["pollution-clean-module-2"].icon_size = 32 end
	--pollution-clean-module-3
	if data.raw["module"]["pollution-clean-module-3"] then data.raw["module"]["pollution-clean-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-3.png" end
	if data.raw["module"]["pollution-clean-module-3"] then data.raw["module"]["pollution-clean-module-3"].icon_size = 32 end
	--pollution-clean-module-4
	if data.raw["module"]["pollution-clean-module-4"] then data.raw["module"]["pollution-clean-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-4.png" end
	if data.raw["module"]["pollution-clean-module-4"] then data.raw["module"]["pollution-clean-module-4"].icon_size = 32 end
	--pollution-clean-module-5
	if data.raw["module"]["pollution-clean-module-5"] then data.raw["module"]["pollution-clean-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-5.png" end
	if data.raw["module"]["pollution-clean-module-5"] then data.raw["module"]["pollution-clean-module-5"].icon_size = 32 end
	--pollution-clean-module-6
	if data.raw["module"]["pollution-clean-module-6"] then data.raw["module"]["pollution-clean-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-6.png" end
	if data.raw["module"]["pollution-clean-module-6"] then data.raw["module"]["pollution-clean-module-6"].icon_size = 32 end
	--pollution-clean-module-7
	if data.raw["module"]["pollution-clean-module-7"] then data.raw["module"]["pollution-clean-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-7.png" end
	if data.raw["module"]["pollution-clean-module-7"] then data.raw["module"]["pollution-clean-module-7"].icon_size = 32 end
	--pollution-clean-module-8
	if data.raw["module"]["pollution-clean-module-8"] then data.raw["module"]["pollution-clean-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/pollution-clean-module-8.png" end
	if data.raw["module"]["pollution-clean-module-8"] then data.raw["module"]["pollution-clean-module-8"].icon_size = 32 end

	--raw-speed-module
	if data.raw["module"]["raw-speed-module-1"] then data.raw["module"]["raw-speed-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-1.png" end
	if data.raw["module"]["raw-speed-module-1"] then data.raw["module"]["raw-speed-module-1"].icon_size = 32 end
	--raw-speed-module-2
	if data.raw["module"]["raw-speed-module-2"] then data.raw["module"]["raw-speed-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-2.png" end
	if data.raw["module"]["raw-speed-module-2"] then data.raw["module"]["raw-speed-module-2"].icon_size = 32 end
	--raw-speed-module-3
	if data.raw["module"]["raw-speed-module-3"] then data.raw["module"]["raw-speed-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-3.png" end
	if data.raw["module"]["raw-speed-module-3"] then data.raw["module"]["raw-speed-module-3"].icon_size = 32 end
	--raw-speed-module-4
	if data.raw["module"]["raw-speed-module-4"] then data.raw["module"]["raw-speed-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-4.png" end
	if data.raw["module"]["raw-speed-module-4"] then data.raw["module"]["raw-speed-module-4"].icon_size = 32 end
	--raw-speed-module-5
	if data.raw["module"]["raw-speed-module-5"] then data.raw["module"]["raw-speed-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-5.png" end
	if data.raw["module"]["raw-speed-module-5"] then data.raw["module"]["raw-speed-module-5"].icon_size = 32 end
	--raw-speed-module-6
	if data.raw["module"]["raw-speed-module-6"] then data.raw["module"]["raw-speed-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-6.png" end
	if data.raw["module"]["raw-speed-module-6"] then data.raw["module"]["raw-speed-module-6"].icon_size = 32 end
	--raw-speed-module-7
	if data.raw["module"]["raw-speed-module-7"] then data.raw["module"]["raw-speed-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-7.png" end
	if data.raw["module"]["raw-speed-module-7"] then data.raw["module"]["raw-speed-module-7"].icon_size = 32 end
	--raw-speed-module-8
	if data.raw["module"]["raw-speed-module-8"] then data.raw["module"]["raw-speed-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/cyan-module-8.png" end
	if data.raw["module"]["raw-speed-module-8"] then data.raw["module"]["raw-speed-module-8"].icon_size = 32 end

	--green-module
	if data.raw["module"]["green-module-1"] then data.raw["module"]["green-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-1.png" end
	if data.raw["module"]["green-module-1"] then data.raw["module"]["green-module-1"].icon_size = 32 end
	--green-module-2
	if data.raw["module"]["green-module-2"] then data.raw["module"]["green-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-2.png" end
	if data.raw["module"]["green-module-2"] then data.raw["module"]["green-module-2"].icon_size = 32 end
	--green-module-3
	if data.raw["module"]["green-module-3"] then data.raw["module"]["green-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-3.png" end
	if data.raw["module"]["green-module-3"] then data.raw["module"]["green-module-3"].icon_size = 32 end
	--green-module-4
	if data.raw["module"]["green-module-4"] then data.raw["module"]["green-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-4.png" end
	if data.raw["module"]["green-module-4"] then data.raw["module"]["green-module-4"].icon_size = 32 end
	--green-module-5
	if data.raw["module"]["green-module-5"] then data.raw["module"]["green-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-5.png" end
	if data.raw["module"]["green-module-5"] then data.raw["module"]["green-module-5"].icon_size = 32 end
	--green-module-6
	if data.raw["module"]["green-module-6"] then data.raw["module"]["green-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-6.png" end
	if data.raw["module"]["green-module-6"] then data.raw["module"]["green-module-6"].icon_size = 32 end
	--green-module-7
	if data.raw["module"]["green-module-7"] then data.raw["module"]["green-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-7.png" end
	if data.raw["module"]["green-module-7"] then data.raw["module"]["green-module-7"].icon_size = 32 end
	--green-module-8
	if data.raw["module"]["green-module-8"] then data.raw["module"]["green-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/yellow-module-8.png" end
	if data.raw["module"]["green-module-8"] then data.raw["module"]["green-module-8"].icon_size = 32 end

	--raw-productivity-module
	if data.raw["module"]["raw-productivity-module-1"] then data.raw["module"]["raw-productivity-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-1.png" end
	if data.raw["module"]["raw-productivity-module-1"] then data.raw["module"]["raw-productivity-module-1"].icon_size = 32 end
	--raw-productivity-module-2
	if data.raw["module"]["raw-productivity-module-2"] then data.raw["module"]["raw-productivity-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-2.png" end
	if data.raw["module"]["raw-productivity-module-2"] then data.raw["module"]["raw-productivity-module-2"].icon_size = 32 end
	--raw-productivity-module-3
	if data.raw["module"]["raw-productivity-module-3"] then data.raw["module"]["raw-productivity-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-3.png" end
	if data.raw["module"]["raw-productivity-module-3"] then data.raw["module"]["raw-productivity-module-3"].icon_size = 32 end
	--raw-productivity-module-4
	if data.raw["module"]["raw-productivity-module-4"] then data.raw["module"]["raw-productivity-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-4.png" end
	if data.raw["module"]["raw-productivity-module-4"] then data.raw["module"]["raw-productivity-module-4"].icon_size = 32 end
	--raw-productivity-module-5
	if data.raw["module"]["raw-productivity-module-5"] then data.raw["module"]["raw-productivity-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-5.png" end
	if data.raw["module"]["raw-productivity-module-5"] then data.raw["module"]["raw-productivity-module-5"].icon_size = 32 end
	--raw-productivity-module-6
	if data.raw["module"]["raw-productivity-module-6"] then data.raw["module"]["raw-productivity-module-6"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-6.png" end
	if data.raw["module"]["raw-productivity-module-6"] then data.raw["module"]["raw-productivity-module-6"].icon_size = 32 end
	--raw-productivity-module-7
	if data.raw["module"]["raw-productivity-module-7"] then data.raw["module"]["raw-productivity-module-7"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-7.png" end
	if data.raw["module"]["raw-productivity-module-7"] then data.raw["module"]["raw-productivity-module-7"].icon_size = 32 end
	--raw-productivity-module-8
	if data.raw["module"]["raw-productivity-module-8"] then data.raw["module"]["raw-productivity-module-8"].icon = "__morebobs__/graphics/moreshiny/icons/modules/red-module-8.png" end
	if data.raw["module"]["raw-productivity-module-8"] then data.raw["module"]["raw-productivity-module-8"].icon_size = 32 end

	--god-module
	if data.raw["module"]["god-module-1"] then data.raw["module"]["god-module-1"].icon = "__morebobs__/graphics/moreshiny/icons/modules/god-module-1.png" end
	if data.raw["module"]["god-module-1"] then data.raw["module"]["god-module-1"].icon_size = 32 end
	--god-module-2
	if data.raw["module"]["god-module-2"] then data.raw["module"]["god-module-2"].icon = "__morebobs__/graphics/moreshiny/icons/modules/god-module-2.png" end
	if data.raw["module"]["god-module-2"] then data.raw["module"]["god-module-2"].icon_size = 32 end
	--god-module-3
	if data.raw["module"]["god-module-3"] then data.raw["module"]["god-module-3"].icon = "__morebobs__/graphics/moreshiny/icons/modules/god-module-3.png" end
	if data.raw["module"]["god-module-3"] then data.raw["module"]["god-module-3"].icon_size = 32 end
	--god-module-4
	if data.raw["module"]["god-module-4"] then data.raw["module"]["god-module-4"].icon = "__morebobs__/graphics/moreshiny/icons/modules/god-module-4.png" end
	if data.raw["module"]["god-module-4"] then data.raw["module"]["god-module-4"].icon_size = 32 end
	--god-module-5
	if data.raw["module"]["god-module-5"] then data.raw["module"]["god-module-5"].icon = "__morebobs__/graphics/moreshiny/icons/modules/god-module-5.png" end
	if data.raw["module"]["god-module-5"] then data.raw["module"]["god-module-5"].icon_size = 32 end
end