--chests-icons
--wooden-chest
if data.raw["item"]["wooden-chest"] then data.raw["item"]["wooden-chest"].icon = "__morebobs__/graphics/moreshiny/icons/chests/wooden-chest.png" end
if data.raw["item"]["wooden-chest"] then data.raw["item"]["wooden-chest"].icon_size = 32 end

--iron-chest
if data.raw["item"]["iron-chest"] then data.raw["item"]["iron-chest"].icon = "__morebobs__/graphics/moreshiny/icons/chests/iron-chest.png" end
if data.raw["item"]["iron-chest"] then data.raw["item"]["iron-chest"].icon_size = 32 end

--steel-chest
if data.raw["item"]["steel-chest"] then data.raw["item"]["steel-chest"].icon = "__morebobs__/graphics/moreshiny/icons/chests/steel-chest.png" end
if data.raw["item"]["steel-chest"] then data.raw["item"]["steel-chest"].icon_size = 32 end

--brass-chest
if data.raw["item"]["brass-chest"] then data.raw["item"]["brass-chest"].icon = "__morebobs__/graphics/moreshiny/icons/chests/brass-chest.png" end
if data.raw["item"]["brass-chest"] then data.raw["item"]["brass-chest"].icon_size = 32 end

--titanium-chest
if data.raw["item"]["titanium-chest"] then data.raw["item"]["titanium-chest"].icon = "__morebobs__/graphics/moreshiny/icons/chests/titanium-chest.png" end
if data.raw["item"]["titanium-chest"] then data.raw["item"]["titanium-chest"].icon_size = 32 end

--logistic-chest-passive-provider
if data.raw["item"]["logistic-chest-passive-provider"] then data.raw["item"]["logistic-chest-passive-provider"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-passive-provider.png" end
if data.raw["item"]["logistic-chest-passive-provider"] then data.raw["item"]["logistic-chest-passive-provider"].icon_size = 32 end
if data.raw["item"]["logistic-chest-passive-provider-2"] then data.raw["item"]["logistic-chest-passive-provider-2"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-passive-provider-2.png" end
if data.raw["item"]["logistic-chest-passive-provider-2"] then data.raw["item"]["logistic-chest-passive-provider-2"].icon_size = 32 end
if data.raw["item"]["logistic-chest-passive-provider-3"] then data.raw["item"]["logistic-chest-passive-provider-3"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-passive-provider-3.png" end
if data.raw["item"]["logistic-chest-passive-provider-3"] then data.raw["item"]["logistic-chest-passive-provider-3"].icon_size = 32 end

--logistic-chest-active-provider
if data.raw["item"]["logistic-chest-active-provider"] then data.raw["item"]["logistic-chest-active-provider"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-active-provider.png" end
if data.raw["item"]["logistic-chest-active-provider"] then data.raw["item"]["logistic-chest-active-provider"].icon_size = 32 end
if data.raw["item"]["logistic-chest-active-provider-2"] then data.raw["item"]["logistic-chest-active-provider-2"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-active-provider-2.png" end
if data.raw["item"]["logistic-chest-active-provider-2"] then data.raw["item"]["logistic-chest-active-provider-2"].icon_size = 32 end
if data.raw["item"]["logistic-chest-active-provider-3"] then data.raw["item"]["logistic-chest-active-provider-3"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-active-provider-3.png" end
if data.raw["item"]["logistic-chest-active-provider-3"] then data.raw["item"]["logistic-chest-active-provider-3"].icon_size = 32 end

--logistic-chest-storage
if data.raw["item"]["logistic-chest-storage"] then data.raw["item"]["logistic-chest-storage"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-storage.png" end
if data.raw["item"]["logistic-chest-storage"] then data.raw["item"]["logistic-chest-storage"].icon_size = 32 end
if data.raw["item"]["logistic-chest-storage-2"] then data.raw["item"]["logistic-chest-storage-2"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-storage-2.png" end
if data.raw["item"]["logistic-chest-storage-2"] then data.raw["item"]["logistic-chest-storage-2"].icon_size = 32 end
if data.raw["item"]["logistic-chest-storage-3"] then data.raw["item"]["logistic-chest-storage-3"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-storage-3.png" end
if data.raw["item"]["logistic-chest-storage-3"] then data.raw["item"]["logistic-chest-storage-3"].icon_size = 32 end

--logistic-chest-requester
if data.raw["item"]["logistic-chest-requester"] then data.raw["item"]["logistic-chest-requester"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-requester.png" end
if data.raw["item"]["logistic-chest-requester"] then data.raw["item"]["logistic-chest-requester"].icon_size = 32 end
if data.raw["item"]["logistic-chest-requester-2"] then data.raw["item"]["logistic-chest-requester-2"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-requester-2.png" end
if data.raw["item"]["logistic-chest-requester-2"] then data.raw["item"]["logistic-chest-requester-2"].icon_size = 32 end
if data.raw["item"]["logistic-chest-requester-3"] then data.raw["item"]["logistic-chest-requester-3"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-requester-3.png" end
if data.raw["item"]["logistic-chest-requester-3"] then data.raw["item"]["logistic-chest-requester-3"].icon_size = 32 end

--logistic-chest-buffer
if data.raw["item"]["logistic-chest-buffer"] then data.raw["item"]["logistic-chest-buffer"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-buffer.png" end
if data.raw["item"]["logistic-chest-buffer"] then data.raw["item"]["logistic-chest-buffer"].icon_size = 32 end
if data.raw["item"]["logistic-chest-buffer-2"] then data.raw["item"]["logistic-chest-buffer-2"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-buffer-2.png" end
if data.raw["item"]["logistic-chest-buffer-2"] then data.raw["item"]["logistic-chest-buffer-2"].icon_size = 32 end
if data.raw["item"]["logistic-chest-buffer-3"] then data.raw["item"]["logistic-chest-buffer-3"].icon = "__morebobs__/graphics/moreshiny/icons/logisticchests/logistic-chest-buffer-3.png" end
if data.raw["item"]["logistic-chest-buffer-3"] then data.raw["item"]["logistic-chest-buffer-3"].icon_size = 32 end

--chests-entities
--chest
if data.raw["container"]["brass-chest"] then
	data.raw["container"]["brass-chest"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/brass-chest.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["container"]["titanium-chest"] then
	data.raw["container"]["titanium-chest"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/titanium-chest.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
--logistic-chest
if data.raw["logistic-container"]["logistic-chest-passive-provider-2"] then
	data.raw["logistic-container"]["logistic-chest-passive-provider-2"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-passive-provider-2.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-passive-provider-3"] then
	data.raw["logistic-container"]["logistic-chest-passive-provider-3"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-passive-provider-3.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-active-provider-2"] then
	data.raw["logistic-container"]["logistic-chest-active-provider-2"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-active-provider-2.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-active-provider-3"] then
	data.raw["logistic-container"]["logistic-chest-active-provider-3"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-active-provider-3.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-storage-2"] then
	data.raw["logistic-container"]["logistic-chest-storage-2"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-storage-2.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-storage-3"] then
	data.raw["logistic-container"]["logistic-chest-storage-3"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-storage-3.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-requester-2"] then
	data.raw["logistic-container"]["logistic-chest-requester-2"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-requester-2.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-requester-3"] then
	data.raw["logistic-container"]["logistic-chest-requester-3"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-requester-3.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-buffer-2"] then
	data.raw["logistic-container"]["logistic-chest-buffer-2"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-buffer-2.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end
if data.raw["logistic-container"]["logistic-chest-buffer-3"] then
	data.raw["logistic-container"]["logistic-chest-buffer-3"].picture =
	{
	  filename = "__morebobs__/graphics/moreshiny/entity/chests/logistic-chest-buffer-3.png",
	  priority = "extra-high",
	  width = 48,
	  height = 34,
	  shift = {0.1875, 0}
	}
end