--intermediates
--empty-barrel
if data.raw["item"]["empty-barrel"] then data.raw["item"]["empty-barrel"].icon = "__morebobs__/graphics/moreshiny/icons/intermediates/empty-barrel.png" end
if data.raw["item"]["empty-barrel"] then data.raw["item"]["empty-barrel"].icon_size = 32 end
--empty-canister
if data.raw["item"]["empty-canister"] then data.raw["item"]["empty-canister"].icon = "__morebobs__/graphics/moreshiny/icons/intermediates/empty-canister.png" end
if data.raw["item"]["empty-canister"] then data.raw["item"]["empty-canister"].icon_size = 32 end
--gas-canister
if data.raw["item"]["gas-canister"] then data.raw["item"]["gas-canister"].icon = "__morebobs__/graphics/moreshiny/icons/intermediates/gas-canister.png" end
if data.raw["item"]["gas-canister"] then data.raw["item"]["gas-canister"].icon_size = 32 end
--solid-fuel
if data.raw["item"]["solid-fuel"] then data.raw["item"]["solid-fuel"].icon = "__morebobs__/graphics/moreshiny/icons/intermediates/solid-fuel.png" end
if data.raw["item"]["solid-fuel"] then data.raw["item"]["solid-fuel"].icon_size = 32 end
--enriched-fuel
if data.raw["item"]["enriched-fuel"] then data.raw["item"]["enriched-fuel"].icon = "__morebobs__/graphics/moreshiny/icons/intermediates/enriched-fuel.png" end
if data.raw["item"]["enriched-fuel"] then data.raw["item"]["enriched-fuel"].icon_size = 32 end

--gearbearing
if data.raw["item"]["iron-gear-wheel"] then data.raw["item"]["iron-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/iron-gear-wheel.png" end
if data.raw["item"]["iron-gear-wheel"] then data.raw["item"]["iron-gear-wheel"].icon_size = 32 end

if data.raw["item"]["brass-gear-wheel"] then data.raw["item"]["brass-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/brass-gear-wheel.png" end
if data.raw["item"]["brass-gear-wheel"] then data.raw["item"]["brass-gear-wheel"].icon_size = 32 end

if data.raw["item"]["cobalt-steel-gear-wheel"] then data.raw["item"]["cobalt-steel-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/cobalt-steel-gear-wheel.png" end
if data.raw["item"]["cobalt-steel-gear-wheel"] then data.raw["item"]["cobalt-steel-gear-wheel"].icon_size = 32 end

if data.raw["item"]["nitinol-gear-wheel"] then data.raw["item"]["nitinol-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/nitinol-gear-wheel.png" end
if data.raw["item"]["nitinol-gear-wheel"] then data.raw["item"]["nitinol-gear-wheel"].icon_size = 32 end

if data.raw["item"]["steel-gear-wheel"] then data.raw["item"]["steel-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/steel-gear-wheel.png" end
if data.raw["item"]["steel-gear-wheel"] then data.raw["item"]["steel-gear-wheel"].icon_size = 32 end

if data.raw["item"]["titanium-gear-wheel"] then data.raw["item"]["titanium-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/titanium-gear-wheel.png" end
if data.raw["item"]["titanium-gear-wheel"] then data.raw["item"]["titanium-gear-wheel"].icon_size = 32 end

if data.raw["item"]["tungsten-gear-wheel"] then data.raw["item"]["tungsten-gear-wheel"].icon = "__morebobs__/graphics/moreshiny/icons/gearbearing/tungsten-gear-wheel.png" end
if data.raw["item"]["tungsten-gear-wheel"] then data.raw["item"]["tungsten-gear-wheel"].icon_size = 32 end

--electronics
--battery
if data.raw["item"]["battery"] then data.raw["item"]["battery"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/battery.png" end
if data.raw["item"]["battery"] then data.raw["item"]["battery"].icon_size = 32 end

if data.raw["item"]["lithium-ion-battery"] then data.raw["item"]["lithium-ion-battery"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/lithium-ion-battery.png" end
if data.raw["item"]["lithium-ion-battery"] then data.raw["item"]["lithium-ion-battery"].icon_size = 32 end

if data.raw["item"]["silver-zinc-battery"] then data.raw["item"]["silver-zinc-battery"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/silver-zinc-battery.png" end
if data.raw["item"]["silver-zinc-battery"] then data.raw["item"]["silver-zinc-battery"].icon_size = 32 end
--electronic-component
if data.raw["item"]["electronic-components"] then data.raw["item"]["electronic-components"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/electronic-components.png" end
if data.raw["item"]["electronic-components"] then data.raw["item"]["electronic-components"].icon_size = 32 end

if data.raw["item"]["intergrated-electronics"] then data.raw["item"]["intergrated-electronics"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/integrated-electronics.png" end
if data.raw["item"]["intergrated-electronics"] then data.raw["item"]["intergrated-electronics"].icon_size = 32 end

if data.raw["item"]["processing-electronics"] then data.raw["item"]["processing-electronics"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/cpu.png" end
if data.raw["item"]["processing-electronics"] then data.raw["item"]["processing-electronics"].icon_size = 32 end
--wire
if data.raw["item"]["copper-cable"] then data.raw["item"]["copper-cable"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/copper-cable.png" end
if data.raw["item"]["copper-cable"] then data.raw["item"]["copper-cable"].icon_size = 32 end

if data.raw["item"]["tinned-copper-cable"] then data.raw["item"]["tinned-copper-cable"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/tinned-copper-cable.png" end
if data.raw["item"]["tinned-copper-cable"] then data.raw["item"]["tinned-copper-cable"].icon_size = 32 end

if data.raw["item"]["insulated-cable"] then data.raw["item"]["insulated-cable"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/insulated-cable.png" end
if data.raw["item"]["insulated-cable"] then data.raw["item"]["insulated-cable"].icon_size = 32 end

if data.raw["item"]["gilded-copper-cable"] then data.raw["item"]["gilded-copper-cable"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/gilded-copper-cable.png" end
if data.raw["item"]["gilded-copper-cable"] then data.raw["item"]["gilded-copper-cable"].icon_size = 32 end

if data.raw["item"]["solder"] then data.raw["item"]["solder"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/solder_org.png" end
if data.raw["item"]["solder"] then data.raw["item"]["solder"].icon_size = 32 end

if data.raw["item"]["red-wire"] then data.raw["item"]["red-wire"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/red-wire.png" end
if data.raw["item"]["red-wire"] then data.raw["item"]["red-wire"].icon_size = 32 end

if data.raw["item"]["green-wire"] then data.raw["item"]["green-wire"].icon = "__morebobs__/graphics/moreshiny/icons/electronics/green-wire.png" end
if data.raw["item"]["green-wire"] then data.raw["item"]["green-wire"].icon_size = 32 end