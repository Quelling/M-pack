if mods["bobwarfare"] then
--turrets
	--gun-turrets
	if data.raw["technology"]["turrets"] then
		data.raw["technology"]["turrets"].icon = "__morebobs__/graphics/moreshiny/technologies/turrets.png"
		data.raw["technology"]["turrets"].icon_size = 128
	end
	if data.raw["technology"]["bob-turrets-2"] then
		data.raw["technology"]["bob-turrets-2"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turrets.png"
		data.raw["technology"]["bob-turrets-2"].icon_size = 128
	end
	if data.raw["technology"]["bob-turrets-3"] then
		data.raw["technology"]["bob-turrets-3"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turrets.png"
		data.raw["technology"]["bob-turrets-3"].icon_size = 128
	end
	if data.raw["technology"]["bob-turrets-4"] then
		data.raw["technology"]["bob-turrets-4"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turrets.png"
		data.raw["technology"]["bob-turrets-4"].icon_size = 128
	end
	if data.raw["technology"]["bob-turrets-5"] then
		data.raw["technology"]["bob-turrets-5"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turrets.png"
		data.raw["technology"]["bob-turrets-5"].icon_size = 128
	end
	
	if data.raw["technology"]["gun-turret-damage-1"] then
		data.raw["technology"]["gun-turret-damage-1"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-1"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-2"] then
		data.raw["technology"]["gun-turret-damage-2"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-2"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-3"] then
		data.raw["technology"]["gun-turret-damage-3"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-3"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-4"] then
		data.raw["technology"]["gun-turret-damage-4"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-4"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-5"] then
		data.raw["technology"]["gun-turret-damage-5"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-5"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-6"] then
		data.raw["technology"]["gun-turret-damage-6"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-6"].icon_size = 128
	end
	if data.raw["technology"]["gun-turret-damage-7"] then
		data.raw["technology"]["gun-turret-damage-7"].icon = "__morebobs__/graphics/moreshiny/technologies/gun-turret-damage.png"
		data.raw["technology"]["gun-turret-damage-7"].icon_size = 128
	end
	
	--sniper-turrets
	if data.raw["technology"]["bob-sniper-turrets-1"] then
		data.raw["technology"]["bob-sniper-turrets-1"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets.png"
		data.raw["technology"]["bob-sniper-turrets-1"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turrets-2"] then
		data.raw["technology"]["bob-sniper-turrets-2"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets.png"
		data.raw["technology"]["bob-sniper-turrets-2"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turrets-3"] then
		data.raw["technology"]["bob-sniper-turrets-3"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets.png"
		data.raw["technology"]["bob-sniper-turrets-3"].icon_size = 128
	end
	
	if data.raw["technology"]["bob-sniper-turret-damage-1"] then
		data.raw["technology"]["bob-sniper-turret-damage-1"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-1"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-2"] then
		data.raw["technology"]["bob-sniper-turret-damage-2"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-2"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-3"] then
		data.raw["technology"]["bob-sniper-turret-damage-3"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-3"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-4"] then
		data.raw["technology"]["bob-sniper-turret-damage-4"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-4"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-5"] then
		data.raw["technology"]["bob-sniper-turret-damage-5"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-5"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-6"] then
		data.raw["technology"]["bob-sniper-turret-damage-6"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-6"].icon_size = 128
	end
	if data.raw["technology"]["bob-sniper-turret-damage-7"] then
		data.raw["technology"]["bob-sniper-turret-damage-7"].icon = "__morebobs__/graphics/moreshiny/technologies/sniper-turrets-damage.png"
		data.raw["technology"]["bob-sniper-turret-damage-7"].icon_size = 128
	end
	
	--laser-turrets
	if data.raw["technology"]["laser-turrets"] then
		data.raw["technology"]["laser-turrets"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turrets.png"
		data.raw["technology"]["laser-turrets"].icon_size = 128
	end
	if data.raw["technology"]["bob-laser-turrets-2"] then
		data.raw["technology"]["bob-laser-turrets-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turrets.png"
		data.raw["technology"]["bob-laser-turrets-2"].icon_size = 128
	end
	if data.raw["technology"]["bob-laser-turrets-3"] then
		data.raw["technology"]["bob-laser-turrets-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turrets.png"
		data.raw["technology"]["bob-laser-turrets-3"].icon_size = 128
	end
	if data.raw["technology"]["bob-laser-turrets-4"] then
		data.raw["technology"]["bob-laser-turrets-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turrets.png"
		data.raw["technology"]["bob-laser-turrets-4"].icon_size = 128
	end
	if data.raw["technology"]["bob-laser-turrets-5"] then
		data.raw["technology"]["bob-laser-turrets-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turrets.png"
		data.raw["technology"]["bob-laser-turrets-5"].icon_size = 128
	end
	
	if data.raw["technology"]["laser-turret-damage-1"] then
		data.raw["technology"]["laser-turret-damage-1"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-1"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-2"] then
		data.raw["technology"]["laser-turret-damage-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-2"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-3"] then
		data.raw["technology"]["laser-turret-damage-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-3"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-4"] then
		data.raw["technology"]["laser-turret-damage-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-4"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-5"] then
		data.raw["technology"]["laser-turret-damage-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-5"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-6"] then
		data.raw["technology"]["laser-turret-damage-6"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-6"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-7"] then
		data.raw["technology"]["laser-turret-damage-7"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-7"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-damage-8"] then
		data.raw["technology"]["laser-turret-damage-8"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-damage.png"
		data.raw["technology"]["laser-turret-damage-8"].icon_size = 128
	end
	
	if data.raw["technology"]["laser-turret-speed-1"] then
		data.raw["technology"]["laser-turret-speed-1"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-1"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-2"] then
		data.raw["technology"]["laser-turret-speed-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-2"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-3"] then
		data.raw["technology"]["laser-turret-speed-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-3"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-4"] then
		data.raw["technology"]["laser-turret-speed-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-4"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-5"] then
		data.raw["technology"]["laser-turret-speed-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-5"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-6"] then
		data.raw["technology"]["laser-turret-speed-6"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-6"].icon_size = 128
	end
	if data.raw["technology"]["laser-turret-speed-7"] then
		data.raw["technology"]["laser-turret-speed-7"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-turret-speed.png"
		data.raw["technology"]["laser-turret-speed-7"].icon_size = 128
	end
end

--laser-rifle
	--laser-rifle
if data.raw["technology"]["bob-laser-rifle"] then
	data.raw["technology"]["bob-laser-rifle"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle.png"
	data.raw["technology"]["bob-laser-rifle"].icon_size = 64
end
	--laser-rifle-ammo
if data.raw["technology"]["bob-laser-rifle-ammo-1"] then
	data.raw["technology"]["bob-laser-rifle-ammo-1"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-1.png"
	data.raw["technology"]["bob-laser-rifle-ammo-1"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-ammo-2"] then
	data.raw["technology"]["bob-laser-rifle-ammo-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-2.png"
	data.raw["technology"]["bob-laser-rifle-ammo-2"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-ammo-3"] then
	data.raw["technology"]["bob-laser-rifle-ammo-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-3.png"
	data.raw["technology"]["bob-laser-rifle-ammo-3"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-ammo-4"] then
	data.raw["technology"]["bob-laser-rifle-ammo-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-4.png"
	data.raw["technology"]["bob-laser-rifle-ammo-4"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-ammo-5"] then
	data.raw["technology"]["bob-laser-rifle-ammo-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-5.png"
	data.raw["technology"]["bob-laser-rifle-ammo-5"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-ammo-6"] then
	data.raw["technology"]["bob-laser-rifle-ammo-6"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-ammo-6.png"
	data.raw["technology"]["bob-laser-rifle-ammo-6"].icon_size = 64
end
	--laser-rifle-damage
if data.raw["technology"]["bob-laser-rifle-damage-1"] then
	data.raw["technology"]["bob-laser-rifle-damage-1"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-1"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-2"] then
	data.raw["technology"]["bob-laser-rifle-damage-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-2"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-3"] then
	data.raw["technology"]["bob-laser-rifle-damage-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-3"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-4"] then
	data.raw["technology"]["bob-laser-rifle-damage-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-4"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-5"] then
	data.raw["technology"]["bob-laser-rifle-damage-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-5"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-6"] then
	data.raw["technology"]["bob-laser-rifle-damage-6"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-6"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-damage-7"] then
	data.raw["technology"]["bob-laser-rifle-damage-7"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-damage.png"
	data.raw["technology"]["bob-laser-rifle-damage-7"].icon_size = 64
end
	--laser-rifle-speed
if data.raw["technology"]["bob-laser-rifle-speed-1"] then
	data.raw["technology"]["bob-laser-rifle-speed-1"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-1"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-speed-2"] then
	data.raw["technology"]["bob-laser-rifle-speed-2"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-2"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-speed-3"] then
	data.raw["technology"]["bob-laser-rifle-speed-3"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-3"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-speed-4"] then
	data.raw["technology"]["bob-laser-rifle-speed-4"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-4"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-speed-5"] then
	data.raw["technology"]["bob-laser-rifle-speed-5"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-5"].icon_size = 64
end
if data.raw["technology"]["bob-laser-rifle-speed-6"] then
	data.raw["technology"]["bob-laser-rifle-speed-6"].icon = "__morebobs__/graphics/moreshiny/technologies/laser-rifle-speed.png"
	data.raw["technology"]["bob-laser-rifle-speed-6"].icon_size = 64
end

--reinforced-wall
if data.raw["technology"]["reinforced-wall"] then
	data.raw["technology"]["reinforced-wall"].icon = "__morebobs__/graphics/moreshiny/technologies/reinforced-wall.png"
	data.raw["technology"]["reinforced-wall"].icon_size = 128
end

--artillery
if data.raw["technology"]["bob-artillery-wagon-2"] then
	data.raw["technology"]["bob-artillery-wagon-2"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-wagon-re.png"
	data.raw["technology"]["bob-artillery-wagon-2"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-wagon-3"] then
	data.raw["technology"]["bob-artillery-wagon-3"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-wagon-re.png"
	data.raw["technology"]["bob-artillery-wagon-3"].icon_size = 128
end

if data.raw["technology"]["bob-artillery-damage-1"] then
	data.raw["technology"]["bob-artillery-damage-1"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-1"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-damage-2"] then
	data.raw["technology"]["bob-artillery-damage-2"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-2"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-damage-3"] then
	data.raw["technology"]["bob-artillery-damage-3"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-3"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-damage-4"] then
	data.raw["technology"]["bob-artillery-damage-4"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-4"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-damage-5"] then
	data.raw["technology"]["bob-artillery-damage-5"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-5"].icon_size = 128
end
if data.raw["technology"]["bob-artillery-damage-6"] then
	data.raw["technology"]["bob-artillery-damage-6"].icon = "__morebobs__/graphics/moreshiny/technologies/artillery-damage.png"
	data.raw["technology"]["bob-artillery-damage-6"].icon_size = 128
end

--mine
if data.raw["technology"]["land-mine"] then
	data.raw["technology"]["land-mine"].icon = "__morebobs__/graphics/moreshiny/technologies/land-mine.png"
	data.raw["technology"]["land-mine"].icon_size = 128
end
if data.raw["technology"]["distractor-mine"] then
	data.raw["technology"]["distractor-mine"].icon = "__morebobs__/graphics/moreshiny/technologies/land-mine-distractor.png"
	data.raw["technology"]["distractor-mine"].icon_size = 128
end
if data.raw["technology"]["poison-mine"] then
	data.raw["technology"]["poison-mine"].icon = "__morebobs__/graphics/moreshiny/technologies/land-mine-poison.png"
	data.raw["technology"]["poison-mine"].icon_size = 128
end
if data.raw["technology"]["slowdown-mine"] then
	data.raw["technology"]["slowdown-mine"].icon = "__morebobs__/graphics/moreshiny/technologies/land-mine-slowdown.png"
	data.raw["technology"]["slowdown-mine"].icon_size = 128
end