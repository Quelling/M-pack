--mining-drill
if data.raw["technology"]["bob-drills-1"] then
	data.raw["technology"]["bob-drills-1"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-drill-0.png"
	data.raw["technology"]["bob-drills-1"].icon_size = 128
end
if data.raw["technology"]["bob-drills-2"] then
	data.raw["technology"]["bob-drills-2"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-drill-0.png"
	data.raw["technology"]["bob-drills-2"].icon_size = 128
end
if data.raw["technology"]["bob-drills-3"] then
	data.raw["technology"]["bob-drills-3"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-drill-0.png"
	data.raw["technology"]["bob-drills-3"].icon_size = 128
end
if data.raw["technology"]["bob-drills-4"] then
	data.raw["technology"]["bob-drills-4"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-drill-0.png"
	data.raw["technology"]["bob-drills-4"].icon_size = 128
end

--large-mining-drill
if data.raw["technology"]["bob-area-drills-1"] then
	data.raw["technology"]["bob-area-drills-1"].icon = "__morebobs__/graphics/moreshiny/technologies/large-mining-drill.png"
	data.raw["technology"]["bob-area-drills-1"].icon_size = 128
end
if data.raw["technology"]["bob-area-drills-2"] then
	data.raw["technology"]["bob-area-drills-2"].icon = "__morebobs__/graphics/moreshiny/technologies/large-mining-drill.png"
	data.raw["technology"]["bob-area-drills-2"].icon_size = 128
end
if data.raw["technology"]["bob-area-drills-3"] then
	data.raw["technology"]["bob-area-drills-3"].icon = "__morebobs__/graphics/moreshiny/technologies/large-mining-drill.png"
	data.raw["technology"]["bob-area-drills-3"].icon_size = 128
end
if data.raw["technology"]["bob-area-drills-4"] then
	data.raw["technology"]["bob-area-drills-4"].icon = "__morebobs__/graphics/moreshiny/technologies/large-mining-drill.png"
	data.raw["technology"]["bob-area-drills-4"].icon_size = 128
end

	--water-miner
if data.raw["technology"]["water-miner-1"] then
	data.raw["technology"]["water-miner-1"].icon = "__morebobs__/graphics/moreshiny/technologies/water-gathering.png"
	data.raw["technology"]["water-miner-1"].icon_size = 128
end
if data.raw["technology"]["water-miner-2"] then
	data.raw["technology"]["water-miner-2"].icon = "__morebobs__/graphics/moreshiny/technologies/water-gathering.png"
	data.raw["technology"]["water-miner-2"].icon_size = 128
end
if data.raw["technology"]["water-miner-3"] then
	data.raw["technology"]["water-miner-3"].icon = "__morebobs__/graphics/moreshiny/technologies/water-gathering.png"
	data.raw["technology"]["water-miner-3"].icon_size = 128
end
if data.raw["technology"]["water-miner-4"] then
	data.raw["technology"]["water-miner-4"].icon = "__morebobs__/graphics/moreshiny/technologies/water-gathering.png"
	data.raw["technology"]["water-miner-4"].icon_size = 128
end
if data.raw["technology"]["water-miner-5"] then
	data.raw["technology"]["water-miner-5"].icon = "__morebobs__/graphics/moreshiny/technologies/water-gathering.png"
	data.raw["technology"]["water-miner-5"].icon_size = 128
end

--mining-productivity
if data.raw["technology"]["mining-productivity-1"] then
	data.raw["technology"]["mining-productivity-1"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-productivity.png"
	data.raw["technology"]["mining-productivity-1"].icon_size = 128
end
if data.raw["technology"]["mining-productivity-4"] then
	data.raw["technology"]["mining-productivity-4"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-productivity.png"
	data.raw["technology"]["mining-productivity-4"].icon_size = 128
end
if data.raw["technology"]["mining-productivity-8"] then
	data.raw["technology"]["mining-productivity-8"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-productivity.png"
	data.raw["technology"]["mining-productivity-8"].icon_size = 128
end
if data.raw["technology"]["mining-productivity-12"] then
	data.raw["technology"]["mining-productivity-12"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-productivity.png"
	data.raw["technology"]["mining-productivity-12"].icon_size = 128
end
if data.raw["technology"]["mining-productivity-16"] then
	data.raw["technology"]["mining-productivity-16"].icon = "__morebobs__/graphics/moreshiny/technologies/mining-productivity.png"
	data.raw["technology"]["mining-productivity-16"].icon_size = 128
end