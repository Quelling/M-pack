--chemical-processing
	--air-compressor
if data.raw["technology"]["air-compressor-1"] then
	data.raw["technology"]["air-compressor-1"].icon = "__morebobs__/graphics/moreshiny/technologies/air-compressor.png"
	data.raw["technology"]["air-compressor-1"].icon_size = 128
end
if data.raw["technology"]["air-compressor-2"] then
	data.raw["technology"]["air-compressor-2"].icon = "__morebobs__/graphics/moreshiny/technologies/air-compressor.png"
	data.raw["technology"]["air-compressor-2"].icon_size = 128
end
if data.raw["technology"]["air-compressor-3"] then
	data.raw["technology"]["air-compressor-3"].icon = "__morebobs__/graphics/moreshiny/technologies/air-compressor.png"
	data.raw["technology"]["air-compressor-3"].icon_size = 128
end
if data.raw["technology"]["air-compressor-4"] then
	data.raw["technology"]["air-compressor-4"].icon = "__morebobs__/graphics/moreshiny/technologies/air-compressor.png"
	data.raw["technology"]["air-compressor-4"].icon_size = 128
end

	--water-bore
if data.raw["technology"]["water-bore-1"] then
	data.raw["technology"]["water-bore-1"].icon = "__morebobs__/graphics/moreshiny/technologies/water-bore.png"
	data.raw["technology"]["water-bore-1"].icon_size = 128
end
if data.raw["technology"]["water-bore-2"] then
	data.raw["technology"]["water-bore-2"].icon = "__morebobs__/graphics/moreshiny/technologies/water-bore.png"
	data.raw["technology"]["water-bore-2"].icon_size = 128
end
if data.raw["technology"]["water-bore-3"] then
	data.raw["technology"]["water-bore-3"].icon = "__morebobs__/graphics/moreshiny/technologies/water-bore.png"
	data.raw["technology"]["water-bore-3"].icon_size = 128
end
if data.raw["technology"]["water-bore-4"] then
	data.raw["technology"]["water-bore-4"].icon = "__morebobs__/graphics/moreshiny/technologies/water-bore.png"
	data.raw["technology"]["water-bore-4"].icon_size = 128
end

	--gas
if data.raw["technology"]["gas-canisters"] then
	data.raw["technology"]["gas-canisters"].icon = "__morebobs__/graphics/moreshiny/technologies/gas-canister-re.png"
	data.raw["technology"]["gas-canisters"].icon_size = 128
end
if data.raw["technology"]["nitrogen-processing"] then
	data.raw["technology"]["nitrogen-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/nitrogen-processing.png"
	data.raw["technology"]["nitrogen-processing"].icon_size = 64
end
if data.raw["technology"]["nitroglycerin-processing"] then
	data.raw["technology"]["nitroglycerin-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/nitroglycerin-processing.png"
	data.raw["technology"]["nitroglycerin-processing"].icon_size = 64
end
if data.raw["technology"]["hydrazine"] then
	data.raw["technology"]["hydrazine"].icon = "__morebobs__/graphics/moreshiny/technologies/hydrazine.png"
	data.raw["technology"]["hydrazine"].icon_size = 128
end
if data.raw["technology"]["void-fluid"] then
	data.raw["technology"]["void-fluid"].icon = "__morebobs__/graphics/moreshiny/technologies/void.png"
	data.raw["technology"]["void-fluid"].icon_size = 128
end

	--chemical-processing
if data.raw["technology"]["chemical-processing-1"] then
	data.raw["technology"]["chemical-processing-1"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-processing.png"
	data.raw["technology"]["chemical-processing-1"].icon_size = 128
end
if data.raw["technology"]["chemical-processing-2"] then
	data.raw["technology"]["chemical-processing-2"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-processing.png"
	data.raw["technology"]["chemical-processing-2"].icon_size = 128
end
if data.raw["technology"]["chemical-processing-3"] then
	data.raw["technology"]["chemical-processing-3"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-processing.png"
	data.raw["technology"]["chemical-processing-3"].icon_size = 128
end

	--oil-processing
if data.raw["technology"]["advanced-oil-processing"] then
	data.raw["technology"]["advanced-oil-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-oil-processing.png"
	data.raw["technology"]["advanced-oil-processing"].icon_size = 128
end
if data.raw["technology"]["coal-liquefaction"] then
	data.raw["technology"]["coal-liquefaction"].icon = "__morebobs__/graphics/moreshiny/technologies/coal-liquefaction.png"
	data.raw["technology"]["coal-liquefaction"].icon_size = 128
end

	--electrolysis
if data.raw["technology"]["electrolysis-1"] then
	data.raw["technology"]["electrolysis-1"].icon = "__morebobs__/graphics/moreshiny/technologies/electrolysis-1.png"
	data.raw["technology"]["electrolysis-1"].icon_size = 128
end
if data.raw["technology"]["electrolysis-2"] then
	data.raw["technology"]["electrolysis-2"].icon = "__morebobs__/graphics/moreshiny/technologies/electrolysis-2.png"
	data.raw["technology"]["electrolysis-2"].icon_size = 128
end

	--chemical-plant
if data.raw["technology"]["chemical-plant"] then
	data.raw["technology"]["chemical-plant"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-plant-1.png"
	data.raw["technology"]["chemical-plant"].icon_size = 128
end
if data.raw["technology"]["chemical-plant-2"] then
	data.raw["technology"]["chemical-plant-2"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-plant-1.png"
	data.raw["technology"]["chemical-plant-2"].icon_size = 128
end
if data.raw["technology"]["chemical-plant-3"] then
	data.raw["technology"]["chemical-plant-3"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-plant-1.png"
	data.raw["technology"]["chemical-plant-3"].icon_size = 128
end
if data.raw["technology"]["chemical-plant-4"] then
	data.raw["technology"]["chemical-plant-4"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-plant-1.png"
	data.raw["technology"]["chemical-plant-4"].icon_size = 128
end
if data.raw["technology"]["chemical-plant-5"] then
	data.raw["technology"]["chemical-plant-5"].icon = "__morebobs__/graphics/moreshiny/technologies/chemical-plant-1.png"
	data.raw["technology"]["chemical-plant-5"].icon_size = 128
end