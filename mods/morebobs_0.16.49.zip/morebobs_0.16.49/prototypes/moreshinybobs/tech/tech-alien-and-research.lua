--advanced-research
if data.raw["technology"]["advanced-research"] then
	data.raw["technology"]["advanced-research"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-research.png"
	data.raw["technology"]["advanced-research"].icon_size = 128
end
--greenhouse
if data.raw["technology"]["bob-greenhouse"] then
	data.raw["technology"]["bob-greenhouse"].icon = "__morebobs__/graphics/moreshiny/technologies/greenhouse.png"
	data.raw["technology"]["bob-greenhouse"].icon_size = 128
end
--roket
if data.raw["technology"]["low-density-structure"] then
	data.raw["technology"]["low-density-structure"].icon = "__morebobs__/graphics/moreshiny/technologies/low-density-structure.png"
	data.raw["technology"]["low-density-structure"].icon_size = 128
end
if data.raw["technology"]["rocket-fuel"] then
	data.raw["technology"]["rocket-fuel"].icon = "__morebobs__/graphics/moreshiny/technologies/rocket-fuel.png"
	data.raw["technology"]["rocket-fuel"].icon_size = 128
end
--alien
if data.raw["technology"]["alien-research"] then
	data.raw["technology"]["alien-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-research.png"
	data.raw["technology"]["alien-research"].icon_size = 128
end
if data.raw["technology"]["alien-blue-research"] then
	data.raw["technology"]["alien-blue-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-blue-research.png"
	data.raw["technology"]["alien-blue-research"].icon_size = 128
end
if data.raw["technology"]["alien-orange-research"] then
	data.raw["technology"]["alien-orange-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-orange-research.png"
	data.raw["technology"]["alien-orange-research"].icon_size = 128
end
if data.raw["technology"]["alien-green-research"] then
	data.raw["technology"]["alien-green-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-green-research.png"
	data.raw["technology"]["alien-green-research"].icon_size = 128
end
if data.raw["technology"]["alien-purple-research"] then
	data.raw["technology"]["alien-purple-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-purple-research.png"
	data.raw["technology"]["alien-purple-research"].icon_size = 128
end
if data.raw["technology"]["alien-red-research"] then
	data.raw["technology"]["alien-red-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-red-research.png"
	data.raw["technology"]["alien-red-research"].icon_size = 128
end
if data.raw["technology"]["alien-yellow-research"] then
	data.raw["technology"]["alien-yellow-research"].icon = "__morebobs__/graphics/moreshiny/technologies/alien-yellow-research.png"
	data.raw["technology"]["alien-yellow-research"].icon_size = 128
end