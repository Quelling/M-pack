--material-processing
	--advanced-material-processing
if data.raw["technology"]["advanced-material-processing"] then
	data.raw["technology"]["advanced-material-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-material-processing.png"
	data.raw["technology"]["advanced-material-processing"].icon_size = 128
end
if data.raw["technology"]["advanced-material-processing-2"] then
	data.raw["technology"]["advanced-material-processing-2"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-material-processing-re.png"
	data.raw["technology"]["advanced-material-processing-2"].icon_size = 128
end
if data.raw["technology"]["advanced-material-processing-3"] then
	data.raw["technology"]["advanced-material-processing-3"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-material-processing-re.png"
	data.raw["technology"]["advanced-material-processing-3"].icon_size = 128
end
if data.raw["technology"]["advanced-material-processing-4"] then
	data.raw["technology"]["advanced-material-processing-4"].icon = "__morebobs__/graphics/moreshiny/technologies/advanced-material-processing-re.png"
	data.raw["technology"]["advanced-material-processing-4"].icon_size = 128
end

	--alloy-processing
if data.raw["technology"]["alloy-processing-1"] then
	data.raw["technology"]["alloy-processing-1"].icon = "__morebobs__/graphics/moreshiny/technologies/alloy-processing-1.png"
	data.raw["technology"]["alloy-processing-1"].icon_size = 128
end
if data.raw["technology"]["alloy-processing-2"] then
	data.raw["technology"]["alloy-processing-2"].icon = "__morebobs__/graphics/moreshiny/technologies/alloy-processing-2.png"
	data.raw["technology"]["alloy-processing-2"].icon_size = 128
end

	--mixing-steel-furnace
if data.raw["technology"]["mixing-steel-furnace"] then
	data.raw["technology"]["mixing-steel-furnace"].icon = "__morebobs__/graphics/moreshiny/technologies/mixing-steel-furnace.png"
	data.raw["technology"]["mixing-steel-furnace"].icon_size = 128
end

	--multi-purpose-furnace
if data.raw["technology"]["multi-purpose-furnace-1"] then
	data.raw["technology"]["multi-purpose-furnace-1"].icon = "__morebobs__/graphics/moreshiny/technologies/multi-purpose-furnace.png"
	data.raw["technology"]["multi-purpose-furnace-1"].icon_size = 128
end
if data.raw["technology"]["multi-purpose-furnace-2"] then
	data.raw["technology"]["multi-purpose-furnace-2"].icon = "__morebobs__/graphics/moreshiny/technologies/multi-purpose-furnace.png"
	data.raw["technology"]["multi-purpose-furnace-2"].icon_size = 128
end

	--plates_processing
if data.raw["technology"]["cobalt-processing"] then
	data.raw["technology"]["cobalt-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/cobalt-processing.png"
	data.raw["technology"]["cobalt-processing"].icon_size = 128
end
if data.raw["technology"]["aluminium-processing"] then
	data.raw["technology"]["aluminium-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/aluminium-processing.png"
	data.raw["technology"]["aluminium-processing"].icon_size = 128
end
if data.raw["technology"]["ceramics"] then
	data.raw["technology"]["ceramics"].icon = "__morebobs__/graphics/moreshiny/technologies/ceramics.png"
	data.raw["technology"]["ceramics"].icon_size = 128
end
if data.raw["technology"]["electrum-processing"] then
	data.raw["technology"]["electrum-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/electrum-processing.png"
	data.raw["technology"]["electrum-processing"].icon_size = 128
end
if data.raw["technology"]["gold-processing"] then
	data.raw["technology"]["gold-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/gold-processing.png"
	data.raw["technology"]["gold-processing"].icon_size = 128
end
if data.raw["technology"]["heat-shield"] then
	data.raw["technology"]["heat-shield"].icon = "__morebobs__/graphics/moreshiny/technologies/heat-shield.png"
	data.raw["technology"]["heat-shield"].icon_size = 128
end
if data.raw["technology"]["invar-processing"] then
	data.raw["technology"]["invar-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/invar-processing.png"
	data.raw["technology"]["invar-processing"].icon_size = 128
end
if data.raw["technology"]["lead-processing"] then
	data.raw["technology"]["lead-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/lead-processing.png"
	data.raw["technology"]["lead-processing"].icon_size = 128
end
if data.raw["technology"]["lithium-processing"] then
	data.raw["technology"]["lithium-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/lithium-processing.png"
	data.raw["technology"]["lithium-processing"].icon_size = 128
end
if data.raw["technology"]["zinc-processing"] then
	data.raw["technology"]["zinc-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/zinc-processing.png"
	data.raw["technology"]["zinc-processing"].icon_size = 128
end
if data.raw["technology"]["nickel-processing"] then
	data.raw["technology"]["nickel-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/nickel-processing.png"
	data.raw["technology"]["nickel-processing"].icon_size = 128
end
if data.raw["technology"]["nitinol-processing"] then
	data.raw["technology"]["nitinol-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/nitinol-processing.png"
	data.raw["technology"]["nitinol-processing"].icon_size = 128
end
if data.raw["technology"]["steel-processing"] then
	data.raw["technology"]["steel-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/steel-processing.png"
	data.raw["technology"]["steel-processing"].icon_size = 128
end
if data.raw["technology"]["sulfur-processing"] then
	data.raw["technology"]["sulfur-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/sulfur-processing.png"
	data.raw["technology"]["sulfur-processing"].icon_size = 128
end
if data.raw["technology"]["titanium-processing"] then
	data.raw["technology"]["titanium-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/titanium-processing.png"
	data.raw["technology"]["titanium-processing"].icon_size = 128
end
if data.raw["technology"]["tungsten-alloy-processing"] then
	data.raw["technology"]["tungsten-alloy-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/tungsten-alloy-processing.png"
	data.raw["technology"]["tungsten-alloy-processing"].icon_size = 128
end
if data.raw["technology"]["tungsten-processing"] then
	data.raw["technology"]["tungsten-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/tungsten-processing.png"
	data.raw["technology"]["tungsten-processing"].icon_size = 128
end
if data.raw["technology"]["silicon-processing"] then
	data.raw["technology"]["silicon-processing"].icon = "__morebobs__/graphics/moreshiny/technologies/silicon-processing.png"
	data.raw["technology"]["silicon-processing"].icon_size = 128
end
if data.raw["technology"]["solid-fuel"] then
	data.raw["technology"]["solid-fuel"].icon = "__morebobs__/graphics/moreshiny/technologies/solid-fuel.png"
	data.raw["technology"]["solid-fuel"].icon_size = 128
end

	--gems
if data.raw["technology"]["gem-processing-1"] then
	data.raw["technology"]["gem-processing-1"].icon = "__morebobs__/graphics/moreshiny/technologies/gem-processing-1.png"
	data.raw["technology"]["gem-processing-1"].icon_size = 128
end
if data.raw["technology"]["gem-processing-2"] then
	data.raw["technology"]["gem-processing-2"].icon = "__morebobs__/graphics/moreshiny/technologies/gem-processing-2.png"
	data.raw["technology"]["gem-processing-2"].icon_size = 128
end
if data.raw["technology"]["grinding"] then
	data.raw["technology"]["grinding"].icon = "__morebobs__/graphics/moreshiny/technologies/grinding.png"
	data.raw["technology"]["grinding"].icon_size = 64
end
if data.raw["technology"]["polishing"] then
	data.raw["technology"]["polishing"].icon = "__morebobs__/graphics/moreshiny/technologies/polishing.png"
	data.raw["technology"]["polishing"].icon_size = 64
end