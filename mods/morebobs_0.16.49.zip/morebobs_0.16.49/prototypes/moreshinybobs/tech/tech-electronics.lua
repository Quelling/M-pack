--electronics-machine
if data.raw["technology"]["electronics-machine-1"] then
	data.raw["technology"]["electronics-machine-1"].icon = "__morebobs__/graphics/moreshiny/technologies/electronics-machine-1.png"
	data.raw["technology"]["electronics-machine-1"].icon_size = 128
end
if data.raw["technology"]["electronics-machine-2"] then
	data.raw["technology"]["electronics-machine-2"].icon = "__morebobs__/graphics/moreshiny/technologies/electronics-machine-2.png"
	data.raw["technology"]["electronics-machine-2"].icon_size = 128
end
if data.raw["technology"]["electronics-machine-3"] then
	data.raw["technology"]["electronics-machine-3"].icon = "__morebobs__/graphics/moreshiny/technologies/electronics-machine-3.png"
	data.raw["technology"]["electronics-machine-3"].icon_size = 128
end