data:extend({
  {
    type = "recipe-category",
    name = "tank-crafting"
  },
  {
    type = "recipe-category",
    name = "tank-ammo-component"
  },
})