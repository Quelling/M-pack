data:extend({
	{
		type = "ammo-category",
		name = "auto-cannon-ammo"
	},
	{
			type = "ammo-category",
			name = "tank-spray-ammo"
	},
	{
		type = "ammo-category",
		name = "tank-spray-ammo-2"
	},
	{
		type = "ammo-category",
		name = "tank-nade-ammo"
	},
	{
		type = "ammo-category",
		name = "tank-mine-ammo"
	},
	{
		type = "ammo-category",
		name = "tank-rocket-ammo"
	},
	{
		type = "ammo-category",
		name = "tank-wmd-ammo"
	},
})