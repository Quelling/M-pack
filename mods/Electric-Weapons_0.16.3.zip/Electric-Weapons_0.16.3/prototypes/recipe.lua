data:extend(
{
  {
    type = "recipe",
    name = "sw-electric-gun",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"steel-plate", 5},
	  {"plastic-bar", 4},
      {"advanced-circuit", 5},
	  {"battery", 6}
    },
    result = "sw-electric-gun"
  },

  
   {
    type = "recipe",
    name = "sw-electric-rifle",
    enabled = false,
    energy_required = 30,
    ingredients =
    {
      {"steel-plate", 10},
	  {"plastic-bar", 10},
      {"speed-module", 5},
	  {"battery", 10}
    },
    result = "sw-electric-rifle"
  },
  
   {
    type = "recipe",
    name = "sw-electric-bomber",
    enabled = false,
    energy_required = 40,
    ingredients =
    {
      {"steel-plate", 40},
	  {"effectivity-module", 5},
      {"processing-unit", 20},
	  {"battery", 10}
    },
    result = "sw-electric-bomber"
  },
  
  {
    type = "recipe",
    name = "sw-electric-gun-cell",
    enabled = false,
    energy_required = 6,
    ingredients =
    {
      {"steel-plate", 2},
      {"advanced-circuit", 1},
	  {"plastic-bar", 1},
	  {"battery", 2}
    },
    result = "sw-electric-gun-cell"
  },

  {
    type = "recipe",
    name = "sw-electric-gun-cell-wsticker",
    enabled = false,
    energy_required = 7,
    ingredients =
    {
	  {"sw-electric-gun-cell", 2},
      {"advanced-circuit", 1},
	  {"battery", 3}
    },
    result = "sw-electric-gun-cell-wsticker"
  },
  
  {
    type = "recipe",
    name = "sw-shock-bomb-ammo-1",
    enabled = false,
    energy_required = 7,
    ingredients =
    {
	  {"sw-electric-gun-cell", 2},
      {"explosives", 2},
      {"processing-unit", 1},
	  {"battery", 2}
    },
    result = "sw-shock-bomb-ammo-1"
  },
  
  
   {
    type = "recipe",
    name = "sw-shock-bomb-ammo-2",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
	  {"sw-electric-gun-cell", 1},
	  {"sw-shock-bomb-ammo-1", 1},
      {"explosives", 3},
      {"processing-unit", 1},
	  {"battery", 3}
    },
    result = "sw-shock-bomb-ammo-2"
  }, 
  
    
   {
    type = "recipe",
    name = "sw-shock-bomb-ammo-3",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
	  {"sw-electric-gun-cell", 1},
	  {"sw-shock-bomb-ammo-2", 1},
      {"explosives", 4},
      {"processing-unit", 1},
	  {"solid-fuel", 2}
    },
    result = "sw-shock-bomb-ammo-3"
  }, 
   

   {
    type = "recipe",
    name = "sw-electric-rounds-magazine",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
   	  {"piercing-rounds-magazine", 1},
	  {"battery", 2},
    },
    result = "sw-electric-rounds-magazine"
  }, 
   




  {
    type = "recipe",
    name = "sw-electric-turret-1",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"laser-turret", 1},
      {"steel-plate", 20},
      {"battery", 10}
    },
    result = "sw-electric-turret-1"
  },
  {
    type = "recipe",
    name = "sw-electric-turret-2",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"sw-electric-turret-1", 1},
      {"steel-plate", 20},
      {"battery", 12},
	  {"advanced-circuit",10}
    },
    result = "sw-electric-turret-2"
  },
  {
    type = "recipe",
    name = "sw-electric-turret-3",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"sw-electric-turret-2", 1},
      {"steel-plate", 20},
      {"processing-unit", 20},
      {"battery", 12},
    },
    result = "sw-electric-turret-3"
  },


   


  {
    type = "recipe",
    name = "sw-electric-stick-turret-1",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"sw-electric-turret-1", 1},
	  {"sw-electric-gun-cell-wsticker", 5},
      {"battery", 10}
    },
    result = "sw-electric-stick-turret-1"
  },
  {
    type = "recipe",
    name = "sw-electric-stick-turret-2",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"sw-electric-stick-turret-2", 1},
      {"sw-electric-gun-cell-wsticker", 10},
      {"battery", 12},
	  {"advanced-circuit",10}
    },
    result = "sw-electric-stick-turret-2"
  },
  {
    type = "recipe",
    name = "sw-electric-stick-turret-3",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
      {"sw-electric-stick-turret-2", 1},
      {"sw-electric-gun-cell-wsticker", 15},
      {"processing-unit", 20},
      {"battery", 12},
    },
    result = "sw-electric-stick-turret-3"
  },
  
})