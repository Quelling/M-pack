data:extend(
{
  {
    type = "damage-type",
    name = "electric"
  },
})