data:extend(
  {
  {
    type = "technology",
    name = "sw-tech-electric-gun",
    icon = "__Electric-Weapons__/graphics/electric_gun.png",
    icon_size = 512,
    prerequisites=
		{
		"laser-turrets",
		"military-3"
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-gun"
      },
      {
        type = "unlock-recipe",
        recipe = "sw-electric-gun-cell"
	  },
      {
        type = "unlock-recipe",
        recipe = "sw-electric-rounds-magazine"
	  }
	  
    },
    unit =
    {
      count = 200,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"military-science-pack", 1},
		{"science-pack-3", 1}
		
      },
	  time = 15
    },
    order = "c-a"
   },
   
   
   {
    type = "technology",
    name = "sw-tech-electric-rifle",
    icon = "__Electric-Weapons__/graphics/electric_rifle.png",
    icon_size = 512,
    prerequisites=
		{
		"sw-tech-electric-gun",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-rifle"
      },
    },
    unit =
    {
      count = 400,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
	--	{"production-science-pack", 1},
    --    {"high-tech-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 15
    },
    order = "c-a"
   },
   

   
   {
    type = "technology",
    name = "sw-tech-gun-cell-wsticker",
    icon = "__Electric-Weapons__/graphics/tech_electric_ammo_sticker.png",
    icon_size = 512,
    prerequisites=
		{
		"sw-tech-electric-gun",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-gun-cell-wsticker"
      },
    },
    unit =
    {
      count = 400,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
        {"high-tech-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 15
    },
    order = "c-a"
   },
     
   
   
    {
    type = "technology",
    name = "sw-tech-electric-bomber",
    icon = "__Electric-Weapons__/graphics/electric_bomber.png",
    icon_size = 512,
    prerequisites=
		{
		"sw-tech-electric-rifle",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-bomber"
      },
      {
        type = "unlock-recipe",
        recipe = "sw-shock-bomb-ammo-1"
      },	  
    },
    unit =
    {
      count = 800,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
        {"high-tech-science-pack", 1},
	--	{"production-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 20
    },
    order = "c-a"
   },
     
   
    {
    type = "technology",
    name = "sw-tech-shock-bomb-ammo2",
    icon = "__Electric-Weapons__/graphics/tech_shock_bomb_ammo.png",
    icon_size = 512,
    prerequisites=
		{
		"sw-tech-electric-bomber",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-shock-bomb-ammo-2"
      },	  
    },
    unit =
    {
      count = 1200,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
        {"high-tech-science-pack", 1},
	--	{"production-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 20
    },
    order = "c-a"
   },
        
  
   
    {
    type = "technology",
    name = "sw-tech-shock-bomb-ammo3",
    icon = "__Electric-Weapons__/graphics/tech_shock_bomb_ammo.png",
    icon_size = 512,
    prerequisites=
		{
		"sw-tech-shock-bomb-ammo2",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-shock-bomb-ammo-3"
      },	  
    },
    unit =
    {
      count = 1500,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
        {"high-tech-science-pack", 1},
	--	{"production-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 20
    },
    order = "c-a"
   },
        
 








  {
    type = "technology",
    name = "sw-electric-gun-cell-damage-1",
    icon = "__Electric-Weapons__/graphics/tech_electric_ammo_damage.png",
    icon_size = 512,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "electric-gun-ammo",
        modifier = 0.2
      }
    },
    prerequisites = {"sw-tech-electric-gun"},
    unit =
    {
      count = 400,
      ingredients =
      {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "e-n-a"
  },

  {
    type = "technology",
    name = "sw-electric-gun-cell-damage-2",
    icon = "__Electric-Weapons__/graphics/tech_electric_ammo_damage.png",
    icon_size = 512,
    effects =
    {
      {
        type = "ammo-damage",
        ammo_category = "electric-gun-ammo",
        modifier = 0.2
      }
    },
    prerequisites = {"sw-electric-gun-cell-damage-1"},
    unit =
    {
      count = 700,
      ingredients =
      {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "e-n-a"
  },

  
  
  
  
  {
    type = "technology",
    name = "sw-tech-electric-turrets",
    icon = "__Electric-Weapons__/graphics/electric-turrets.png",
    icon_size = 128,
    prerequisites=
		{
		"sw-tech-electric-gun",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-turret-1"
      },
      {
        type = "unlock-recipe",
        recipe = "sw-electric-stick-turret-1"
      },	  
    },
    unit =
    {
      count = 400,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
	--	{"production-science-pack", 1},
    --    {"high-tech-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 20
    },
    order = "c-a"
   },


  {
    type = "technology",
    name = "sw-tech-electric-turrets-2",
    icon = "__Electric-Weapons__/graphics/electric-turrets.png",
    icon_size = 128,
    prerequisites=
		{
		"sw-tech-electric-turrets",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-turret-2"
      },
      {
        type = "unlock-recipe",
        recipe = "sw-electric-stick-turret-2"
      },		  
    },
    unit =
    {
      count = 600,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
	--	{"production-science-pack", 1},
    --    {"high-tech-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 25
    },
    order = "c-a"
   },

  {
    type = "technology",
    name = "sw-tech-electric-turrets-3",
    icon = "__Electric-Weapons__/graphics/electric-turrets.png",
    icon_size = 128,
    prerequisites=
		{
		"sw-tech-electric-turrets-2",
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "sw-electric-turret-3"
      },
      {
        type = "unlock-recipe",
        recipe = "sw-electric-stick-turret-3"
      },		  
    },
    unit =
    {
      count = 800,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 1},
		{"science-pack-3", 1},
        {"military-science-pack", 1},
	--	{"production-science-pack", 1},
        {"high-tech-science-pack", 1},
--		{"space-science-pack", 1}
      },
	  time = 30
    },
    order = "c-a"
   },



 
   
  }
)