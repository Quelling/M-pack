data:extend(
{
  {
    type = "ammo-category",
    name = "electric-gun-ammo"
  },
  {
    type = "ammo-category",
    name = "shockwave-ammo"
  }

})