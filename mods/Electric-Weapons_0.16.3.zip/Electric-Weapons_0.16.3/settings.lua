data:extend({
{
	type = "double-setting",
	name = "sw-damage-multiplier",
	setting_type = "startup",
	default_value = 1,
	minimum_value = 0.1,
	maximum_value = 3,
	order = "ca"
},

})