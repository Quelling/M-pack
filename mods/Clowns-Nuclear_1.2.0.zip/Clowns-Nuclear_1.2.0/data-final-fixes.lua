data.raw["technology"]["kovarex-enrichment-process"].effects=
{
	{type = "unlock-recipe", recipe = "depleted-uranium-reprocessing"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-80%"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-75%"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-70%"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-65%"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-55%"},
	{type = "unlock-recipe", recipe = "clowns-centrifuging-45%"}
}