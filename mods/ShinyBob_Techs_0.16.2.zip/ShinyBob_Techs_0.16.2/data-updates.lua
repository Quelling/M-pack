ShinyBob_path = "__ShinyBob_Techs__"


require('prototypes/functions/shinyfunc')

require('prototypes/all_icons')
