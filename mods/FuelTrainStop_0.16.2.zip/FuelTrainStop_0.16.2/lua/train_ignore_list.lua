TrainIgnoreList = 
	{
		"electric-locomotive",
		"electric-locomotive-mk1",
		"electric-locomotive-mk2",
		"electric-locomotive-mk3",
		"fusion-locomotive-mk1",
		"fusion-locomotive-mk2",
		"fusion-locomotive-mk3",
		"hybrid-train",
		"electric-vehicles-electric-locomotive",
		"Senpais-Electric-Train",
		"Senpais-Electric-Train-2"
	}