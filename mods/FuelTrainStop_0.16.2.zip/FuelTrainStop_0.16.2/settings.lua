data:extend({
	{
		type = "int-setting",
		name = "min-fuel-amount",
		setting_type = "runtime-global",
		default_value = 20,
		minimum_value = 10
	}
})
