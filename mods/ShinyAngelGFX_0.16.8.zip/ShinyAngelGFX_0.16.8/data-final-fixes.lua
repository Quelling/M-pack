if data.raw["assembling-machine"]["oil-refinery-2"] then 
	iconset("oil-refinery","","-1")
end

if data.raw["assembling-machine"]["chemical-plant-2"] then 
	iconset("chemical-plant","","-1")
end