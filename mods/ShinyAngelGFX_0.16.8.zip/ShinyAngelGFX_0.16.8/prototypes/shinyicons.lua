function iconset(name,suf,tier)

if settings.startup["usecoloricons"].value == true then
	if settings.startup["usecolorbars"].value == true then
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- },
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	else
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	end
else
if settings.startup["usecolorbars"].value == true then
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..".png",
		-- },
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
else

end
end	
end

function iconsetspec(name,suf,tier)

if settings.startup["usecoloricons"].value == true then
	if settings.startup["usecolorbars"].value == true then
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- },
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	else
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	end
else
if settings.startup["usecolorbars"].value == true then
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- },
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		},
		{
			icon = "__ShinyAngelGFX__/graphics/icons/num"..tier..".png",
		}
	}
	else
	data.raw["item"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	-- data.raw["recipe"][name..suf].icons = {
		-- {
			-- icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		-- }
	-- }
	data.raw["assembling-machine"][name..suf].icons = {
		{
			icon = "__ShinyAngelGFX__/graphics/icons/"..name..tier..".png",
		}
	}
	end

end
end	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	