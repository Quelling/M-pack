function is_value_in_list (value, list)
  for i, v in pairs (list) do
    if v == value then return true end
  end
  return false
end

script.on_event(defines.events.on_built_entity, function(event)
  local entity = event.created_entity
  if entity.type == 'pipe' then
    local neighbours = entity.neighbours
    local fluid_list = {}
    if neighbours then
      for i, neighbours_2 in pairs (neighbours) do
        for j, neighbour in pairs (neighbours_2) do
          -- printAll(i..' '..j..' '..neighbour.type)
          -- if neighbour.type == 'pipe' or 'pipe-to-ground' then
            if neighbour.fluidbox[1] and not is_value_in_list (neighbour.fluidbox[1].name, fluid_list) then
              table.insert (fluid_list, neighbour.fluidbox[1].name)
            end
          -- end
        end
      end
    end
    if #fluid_list > 1 then
      printAll('[PipesFix] '..'fluids: '..serpent.line(fluid_list))
      entity.destroy()
    end
  end
end)



function printAll(text)
  for i in pairs (game.players) do
    game.players[i].print(text)
  end
end