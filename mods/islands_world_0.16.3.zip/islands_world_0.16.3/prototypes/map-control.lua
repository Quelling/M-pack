-- replace elevation noise layer

local noise = require("noise")
local tne = noise.to_noise_expression

local function make_multioctave_noise_function(seed0,seed1,octaves,octave_output_scale_multiplier,octave_input_scale_multiplier,output_scale0,input_scale0)
  octave_output_scale_multiplier = octave_output_scale_multiplier or 2
  octave_input_scale_multiplier = octave_input_scale_multiplier or 1 / octave_output_scale_multiplier
  return function(x,y,inscale,outscale)
	return tne{
	  type = "function-application",
	  function_name = "factorio-multioctave-noise",
	  arguments = {
		x = tne(x),
		y = tne(y),
		seed0 = tne(seed0),
		seed1 = tne(seed1),
		input_scale = tne((inscale or 1) * (input_scale0 or 1)),
		output_scale = tne((outscale or 1) * (output_scale0 or 1)),
		octaves = tne(octaves),
		octave_output_scale_multiplier = tne(octave_output_scale_multiplier),
		octave_input_scale_multiplier = tne(octave_input_scale_multiplier),
	  }
	}
  end
end

-- Inputs to multi-octave noise to replicate 0.15 terrain
-- (ignoring that it won't match due to shifting having changed)
-- Roughness scale=0.125000, seed=9, amplitude=0.325000
-- Elevation scale=0.500000, seed=8, amplitude=6000.000000

-- TODO: Use actual noise layer indexes for seeds instead of hard-coding

data.raw["noise-expression"]["default-elevation"].expression = noise.define_noise_function( function(x,y,tile,map)
	  x = x * map.segmentation_multiplier + 10000 -- Move the point where 'fractal similarity' is obvious off into the boonies
	  y = y * map.segmentation_multiplier

--	  local high_freq_noise = make_multioctave_noise_function(map.seed, 11, 6, 2, 1/3, 1/8, 1/4)
	  local low_freq_noise = make_multioctave_noise_function(map.seed, 8, 8, 1.5, 1/2, 2/3, 1/4)

	  local basis =low_freq_noise(x,y) - 15 * noise.clamp(tile.tier, 0, 1)
	  return basis
	end)


-- increse stone patch size in start area
data.raw["resource"]["stone"]["autoplace"]["starting_area_size"] = 5500 * (0.005 / 3)


-- register dummy hidden terchnology that show warning message when disabled
local warning_item = {
	{
		type = "technology",
		name = "***_warning_***_islands_world_was_enabled_in_this_game_data_",
		icon_size = 128,
		icon = "__base__/graphics/technology/steel-processing.png",
		enabled = false,
		effects = {},
		unit =
		{
			count = 1,
			ingredients = {{"science-pack-1", 1}},
			time = 5
		},
		order = "z-z"
	}
}


data:extend(warning_item)

