if mods["bobwarfare"] then
	data.raw["artillery-turret"]["bob-artillery-turret-2"].localised_name = {"override-item-name.bob-artillery-turret-2"}
	data.raw["artillery-turret"]["bob-artillery-turret-3"].localised_name = {"override-item-name.bob-artillery-turret-3"}
	data.raw.item["bob-artillery-turret-2"].localised_name = {"override-item-name.bob-artillery-turret-2"}
	data.raw.item["bob-artillery-turret-3"].localised_name = {"override-item-name.bob-artillery-turret-3"}

	data.raw["item-with-entity-data"]["bob-artillery-wagon-2"].localised_name = {"override-item-name.bob-artillery-wagon-2"}
	data.raw["item-with-entity-data"]["bob-artillery-wagon-3"].localised_name = {"override-item-name.bob-artillery-wagon-3"}
	data.raw["artillery-wagon"]["bob-artillery-wagon-2"].localised_name = {"override-item-name.bob-artillery-wagon-2"}
	data.raw["artillery-wagon"]["bob-artillery-wagon-3"].localised_name = {"override-item-name.bob-artillery-wagon-3"}
end