return {
    infinite_research_enabled = 'qol-infinite-research-enabled',
    enabled = 'qol-%s-enabled',
    research_enabled = 'qol-%s-research-enabled',
    research_config = 'qol-%s-research-config',
    flat_bonus = 'qol-%s-flat-bonus',
    multiplier = 'qol-%s-multiplier',
    field_toggle = 'qol-%s-field-%%s'
}