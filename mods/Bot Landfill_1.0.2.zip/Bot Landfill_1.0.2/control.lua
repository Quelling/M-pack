-- LANDFILL_RESULT = "dirt-4"
LANDFILL_RESULT = "grass-1"
WATERFILL_RESULT = "water"

function placedTiles(entity, tiles, item)
  if  item.name == "landfill" then
    local surface = entity.surface
    for i,tile in pairs(tiles) do
      surface.set_tiles({{name=LANDFILL_RESULT, position=tile.position}})
    end
  elseif item.name == "blasting-charge" then
    local surface = entity.surface
    for i,tile in pairs(tiles) do
      surface.set_tiles({{name=WATERFILL_RESULT, position=tile.position}})
    end
  end
end

script.on_event(defines.events.on_player_built_tile, function(event)
  placedTiles(game.players[event.player_index], event.tiles, event.item)
end)

script.on_event(defines.events.on_robot_built_tile, function(event)
  placedTiles(event.robot, event.tiles, event.item)
end)