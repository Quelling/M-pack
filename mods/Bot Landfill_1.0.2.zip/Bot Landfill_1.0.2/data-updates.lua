-- LANDFILL_RESULT = "dirt-4"
LANDFILL_RESULT = "grass-1"
WATERFILL_RESULT = "water"

landfill_tile = util.table.deepcopy(data.raw["tile"][LANDFILL_RESULT])
landfill_tile.name = "landfill"
landfill_tile.autoplace = nil
landfill_tile.can_be_part_of_blueprint = nil

data:extend(
{
  landfill_tile
})

data.raw["item"]["landfill"].place_as_tile.result = "landfill"

if data.raw["item"]["blasting-charge"] then
  waterfill_tile = util.table.deepcopy(data.raw["tile"][WATERFILL_RESULT])
  waterfill_tile.name = "waterfill"
  waterfill_tile.autoplace = nil
  waterfill_tile.can_be_part_of_blueprint = nil
  
  data:extend(
  {
    waterfill_tile
  })

  data.raw["item"]["blasting-charge"].place_as_tile.result = "waterfill"
end