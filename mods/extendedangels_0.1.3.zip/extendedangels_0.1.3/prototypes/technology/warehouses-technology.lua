if angelsmods.addons.warehouses then
data:extend(
{

  {
    type = "technology",
    name = "warehouses-2",
    icon = "__angelsaddons-warehouses__/graphics/technology/warehouses.png",
  icon_size = 128,
  prerequisites =
    {
  "angels-warehouses",
  "zinc-processing",
  "angels-invar-smelting-1",
    },
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "warehouse-mk2"
      },
    },
    unit =
    {
      count = 125,
      ingredients = {
    {"science-pack-1", 1},
    {"science-pack-2", 1},
    },
      time = 20
    },
    order = "c-a"
    },  

    {
      type = "technology",
      name = "warehouses-3",
      icon = "__angelsaddons-warehouses__/graphics/technology/warehouses.png",
    icon_size = 128,
    prerequisites =
      {
    "warehouses-2",
    "angels-titanium-smelting-1",
    "ceramics",
      },
      effects =
      {
        {
          type = "unlock-recipe",
          recipe = "warehouse-mk3"
        },
      },
      unit =
      {
        count = 200,
        ingredients = {
      {"science-pack-1", 1},
      {"science-pack-2", 1},
      {"science-pack-3", 1},
      },
        time = 20
      },
      order = "c-a"
      },  
  
      {
        type = "technology",
        name = "warehouses-4",
        icon = "__angelsaddons-warehouses__/graphics/technology/warehouses.png",
      icon_size = 128,
      prerequisites =
        {
          "warehouses-3",
          "angels-tungsten-smelting-1",         
          "nitinol-processing",
        },
        effects =
        {
          {
            type = "unlock-recipe",
            recipe = "warehouse-mk4"
          },
        },
        unit =
        {
          count = 200,
          ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        },
          time = 20
        },
        order = "c-a"
        },  
    
      
	{
    type = "technology",
    name = "logistic-warehouses-2",
    icon = "__angelsaddons-warehouses__/graphics/technology/warehouses-logistics.png",
	icon_size = 128,
	prerequisites =
    {
  "angels-logistic-warehouses",
  "warehouses-2",
  "zinc-processing",
  "angels-invar-smelting-1",  
    },
    effects =
    {
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-passive-provider-mk2"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-active-provider-mk2"
      },
	  {
        type = "unlock-recipe",
        recipe = "warehouse-storage-mk2"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-requester-mk2"
      },
    },
    unit =
    {
      count = 125,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  },
      time = 20
    },
    order = "c-a"
    },
 
	{
    type = "technology",
    name = "logistic-warehouses-3",
    icon = "__angelsaddons-warehouses__/graphics/technology/warehouses-logistics.png",
	icon_size = 128,
	prerequisites =
    {
  "logistic-warehouses-2",
  "warehouses-3",
  "angels-titanium-smelting-1",
  "ceramics",
  "advanced-electronics-2",
    },
    effects =
    {
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-passive-provider-mk3"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-active-provider-mk3"
      },
	  {
        type = "unlock-recipe",
        recipe = "warehouse-storage-mk3"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-requester-mk3"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack", 1},
	  },
      time = 25
    },
    order = "c-a"
    },
	
	{
    type = "technology",
    name = "logistic-warehouses-4",
    icon = "__angelsaddons-warehouses__/graphics/technology/warehouses-logistics.png",
	icon_size = 128,
	prerequisites =
    {
  "logistic-warehouses-3",
  "warehouses-4",
  "angels-tungsten-smelting-1",         
  "nitinol-processing",
  "advanced-electronics-3",
    },
    effects =
    {
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-passive-provider-mk4"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-active-provider-mk4"
      },
	  {
        type = "unlock-recipe",
        recipe = "warehouse-storage-mk4"
      },
  	  {
        type = "unlock-recipe",
        recipe = "warehouse-requester-mk4"
      },
    },
    unit =
    {
      count = 300,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
    {"production-science-pack", 1},
    {"high-tech-science-pack", 1},
	  },
      time = 30
    },
    order = "c-a"
    }

})

end

