require("prototypes.subgroups")

-- For Angel's Petrochem
require("prototypes.items.petrochem")

-- For Angel's Smelting
require("prototypes.items.smelting")
require("prototypes.recipes.smelting")
require("prototypes.technology.smelting-technology")