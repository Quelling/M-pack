--Define if battlefield is installed
equipment = true --Default: True