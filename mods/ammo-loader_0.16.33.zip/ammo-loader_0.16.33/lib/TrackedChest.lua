--[[--
TrackedChest: Class representing a single loader chest.
@classmod TC
@alias TrackedChest
]]
local TC = {}
-- local SL = require "lib/TrackedSlot"
-- local TrackedChest = TC
TC.className = "TrackedChest"
TC.dbName = TC.className
DB.register(TC.dbName)
TC.rangeIndicator = "ammo-loader-range-indicator"
--[[--
Metatable
@table objMT
]]
TC.objMT = {
    __index = TC
}

function TC._init()
    util.destroyAll({name = TC.rangeIndicator})
    -- util.destroyAll(TC.indicators.infinite)

    -- DB.new(TC.dbName)
    global["TC"] = {}
    global["TC"]["chestNames"] = TC.findChestNames()
    global["TC"]["indicators"] = {count = 0, queue = Q.new()}
end
Init.registerFunc(TC._init)
function TC._onLoad()
    for id, obj in pairs(DB.getAll(TC.dbName)) do
        setmetatable(obj, TC.objMT)
        -- setmetatable(obj.slotQ, idQ.objMT)
        -- if (obj.slotIter) then
        -- setmetatable(obj.slotIter, util.iterator.objMT)
        -- end
        -- if (obj.slotIter) then
        --     setmetatable(obj.slotIter.slotQ, idQ.objMT)
        -- end
        -- setmetatable(obj.movingInRangeQ, idQ.objMT)
        -- for item, cons in pairs(obj._cache) do
        --     setmetatable(cons.searchQ, idQ.objMT)
        -- end
        -- for item, q in pairs(obj._removalQueues) do
        --     setmetatable(q, idQ.objMT)
        -- end
    end
end
Init.registerOnLoadFunc(TC._onLoad)

function TC.dbInsert(chest)
    return DB.insert(TC.dbName, chest)
end

function TC.master()
    return global["TC"]
end
function TC.chestNames(listType)
    if not listType then
        return TC.master()["chestNames"]
    end
    return TC.master()["chestNames"][listType]
end
function TC.chestDB()
    return DB.getAll(TC.dbName)
end

function TC.indicators()
    return global["TC"]["indicators"]
end

--- Create new TrackedChest object
-- @param ent Entity to use to create new chest.
-- @return Tracked Chest object
function TC.new(ent)
    if (not TC.isChest(ent)) then
        return nil
    end

    local obj = {}
    setmetatable(obj, TC.objMT)
    obj.entName = ent.name
    obj.ent = ent
    obj.inv = ent.get_inventory(defines.inventory.chest)
    if not isValid(obj.inv) then
        return nil
    end
    obj.forceName = ent.force.name
    obj.surfaceName = ent.surface.name
    local pos = ent.position
    if (obj.surfaceName ~= "nauvis") then
        local player = ent.last_user
        if not player then
            return nil
        end
        pos = trackedPos(player.index)
        if not pos then
            return nil
        end
    end
    obj._posX = pos.x
    obj._posY = pos.y
    -- obj.type = TC.getType(ent)
    -- if obj.type == nil then return nil end
    obj.id = TC.dbInsert(obj)

    local rad = gSets.chestRadius()
    local force = obj:force()
    if (rad > 0) then
        obj.area = Position.expand_to_area(obj:position(), rad)
        obj.consumersInRange = {}
        force.slots:forEach(
            function(slot)
                if (not slot.canMove) and (Area.inside(obj.area, slot:position())) then
                    obj.consumersInRange[slot.id] = true
                end
            end,
            nil,
            true
        )
    end
    -- obj.provItem = nil
    if (ent.name == protoNames.chests.storage) then
        obj.isStorage = true
    end
    -- obj._cacheLastTick = 0
    obj._invCache = {}
    obj._removalCache = {}
    -- obj.slotsToAdd = {}
    -- obj.slotQ = idQ.new(SL)
    obj._indicators = {count = 0, ents = {}}
    force:addChest(obj)
    -- obj:tick()
    if (TC.indicators().toggled) then
        obj:drawRange()
    end
    return obj
end

TC.position = function(self)
    return {x = self._posX, y = self._posY}
end

TC.surface = function(self)
    return self.ent.surface
end

function TC.destroy(self)
    self:clearIndicators()
    local force = self:force()
    -- local cats = force.provCats
    -- for catName, cat in pairs(cats) do

    -- end
    force:purgeProv(self.id)
    -- if (self.provItem) then
    -- self.provItem = nil
    -- self.slotIter = nil
    -- local force = self:force()
    -- Array.removeValue(force:provItem(self.provItem).providers, self.id)
    -- for slot in self:iterCons() do
    --     -- local ins = slot:inserter()
    --     -- if (ins.sourceID) and (ins.sourceID == self.id) then
    --     --     slot:setProvider()
    --     --     slot:checkAllProviders()
    --     -- end
    --     slot:removeProvider(self)
    -- end
    -- self.provItem = nil
    -- self.slotIter = nil
    -- end
    DB.deleteID(TC.dbName, self.id)
end

function TC.isValid(self)
    if not self then
        return false
    end
    return isValid(self.inv)
end

function TC.newIndicator(self, position)
    local new = self:surface().create_entity {name = TC.rangeIndicator, position = position}
    new.minable = false
    new.destructible = false
    new.active = false
    local inds = self._indicators

    inds.count = inds.count + 1
    inds.ents[inds.count] = new
    return new
end

function TC.clearIndicators(self)
    local inds = self._indicators
    local ents = inds.ents
    local allInds = TC.indicators()
    allInds.count = allInds.count - inds.count
    for i = 1, inds.count do
        local ent = ents[i]
        if (ent) then
            ent.destroy()
        end
    end
    self._indicators = {count = 0, ents = {}}
end

function TC.clearAllIndicators(forceName)
    if (forceName) then
        -- error(forceName)
        local chests = Force.get(forceName).chests
        chests:forEach(TC.clearIndicators, nil, true)
    else
        for chest in TC.chests():iter() do
            chest:clearIndicators()
        end
    end
    local allInds = TC.indicators()
    allInds.queue = Q.new()
    allInds.count = 0

    -- for id, chest in pairs(DB.getAll(TC.dbName)) do
    --     chest:clearIndicators()
    -- end
    -- local inds = TC.indicators()
    -- local ents = inds.ents
    -- for i = 1, #ents do
    --     local ent = ents[i]
    --     if (ent) then
    --         ent.destroy()
    --     end
    -- end
    -- inds.ents = {}
    -- inds.count = 0
    -- inds.queue = Q.new()
end

-- function TC.destroyAllIndicators()
--     local found = util.allfind({name=TC.indicators.range})
--     local found2 = util.allfind({name=TC.indicators})
-- end

-- function TC.drawRange(self)
--     self:clearIndicators()
--     local area = self.area
--     if (not area) then
--         local pos = self:position()
--         pos.x = pos.x + 1
--         self:newIndicator(TC.indicators.infinite, pos)
--     else
--         local rangeInd = TC.indicators.range
--         for x, y in Area.iterate(area) do
--             self:newIndicator(rangeInd, {x = x, y = y})
--         end
--     end
-- end

function TC.tickIndicators()
    local inds = TC.indicators()
    local q = inds.queue
    local size = Q.size(q)
    if (size <= 0) then
        return nil
    end
    local max = gSets.maxIndicatorsPerTick()
    if (size < max) then
        max = size
    end
    for i = 1, max do
        local info = Q.pop(q)
        local chest = TC.getObj(info.parentID)
        if (chest) then
            local newInd = chest:newIndicator(info.position)
        -- chest._indicators.count = chest._indicators.count + 1
        -- chest._indicators.ents[chest._indicators.count] = newInd
        -- inds.count = inds.count + 1
        end
    end
end

function TC.queueAllIndicators(forceName)
    if (forceName) then
        local chests = Force.get(forceName).chests
        local function qChest(chest)
            return chest:drawRange()
        end
        chests:forEach(qChest, nil, true)
    else
        for chest in TC.chests():iter() do
            chest:drawRange()
        end
    end
end

function TC.drawRange(self)
    if (gSets.rangeIsInfinite()) then
        return nil
    end
    -- TC.queueIndicators(self.surfaceName, self.area, self.id)
    -- local surfName = ent.surface.name
    local area = self.area
    local inds = TC.indicators()
    local count = inds.count
    local q = inds.queue
    local per, amt = util.perimeter(area)
    local maxInds = gSets.maxIndicators()
    -- for x, y in Area.iterate(area) do
    for i = 1, amt do
        if (count + Q.size(q) >= maxInds) then
            break
        end
        local pos = per[i]
        Q.push(q, {surface = self.surfaceName, position = pos, parentID = self.id})
    end
end

function TC.entDrawRange(ent)
    local chest = TC.getObjFromEnt(ent)
    if not chest then
        return nil
    end
    chest:drawRange()
end

function TC.force(self)
    return Force.get(self.forceName)
end

function TC.filterItem(self)
    return self.provItem
end

function TC.itemInfo(self)
    local name = self.provItem
    if not name then
        return nil
    end
    return ItemDB.item.get(name)
end
TC.filterInfo = TC.itemInfo

function TC.category(self)
    local inf = self:itemInfo()
    if (not inf) then
        return nil
    end
    return inf.category
end

function TC.itemAmt(self, item, new)
    if (new) then
        self._invCache[item] = new
        return new
    end
    local amt = self._invCache[item] or 0
    return amt
end
function TC.distributeItems(self, contents)
    for item, amt in pairs(contents) do
        local curStack = {name = item, count = amt}
        local chests = FRC.get(self.force).chests
        for i = 1, chests:size() do
            local curChest = chests:cycle()
            if not curChest then
                break
            end
            local inserted = TC.insert(curChest, curStack)
            curStack.count = curStack.count - inserted
            if curStack.count <= 0 then
                break
            end
        end
        if curStack.count > 0 then
            local dropPos = {x = 0, y = 0}
            local owner = nil
            if self.ownerInd ~= nil then
                owner = game.players[self.ownerInd]
            end
            if isValid(owner) then
                local dropPos = owner.position
                local given = owner.insert(curStack)
                curStack.count = curStack.count - given
            end
            if curStack.count > 0 then
                game.surfaces.nauvis.spill_item_stack(dropPos, curStack, true, self.force)
            end
        end
    end
end

function TC.isInRange(self, pos)
    if (not self.area) then
        return true
    end
    return Area.inside(self.area, pos)
end

-- function TC.slotInRange(s)

function TC.canProvide(self, slotObj)
    if (not self.area) then
        return true
    end
    if (slotObj.canMove) then
        return self:isInRange(slotObj:position())
    end
    if (self.consumersInRange[slotObj.id]) then
        return true
    end
    return false
end

function TC.allChests()
    local q = idQ.new(TC.dbName)
    for id, chest in pairs(DB.getEntries(TC.dbName)) do
        idQ.push(q, chest)
    end
    return q
end
function TC.findChestNames()
    local result = {list = {}, hash = {}}
    local hash = result.hash
    local list = result.list
    for key, name in pairs(protoNames.chests) do
        hash[name] = true
        list[#list + 1] = name
    end
    return result
end

function TC.isChest(ent)
    -- inform("checking chest in entity named "..ent.name)
    if (not isValid(ent)) or (ent.surface.name ~= "nauvis") then
        return false
    elseif (TC.chestNames("hash")[ent.name]) then
        return true
    end
    return false
end

function TC.getObj(id)
    return DB.getObj(TC.dbName, id)
end

function TC.highestID()
    return DB.get(TC.dbName).nextID - 1
end

function TC.getObjFromEnt(ent)
    for id, obj in pairs(DB.getAll(TC.dbName)) do
        if (obj.ent == ent) then
            if (obj:isValid()) then
                return obj
            else
                obj:destroy()
                return nil
            end
        end
    end
end

function TC.insert(self, stack)
    if (not stack) or (stack.count <= 0) then
        return 0
    end
    local amtInserted = self.inv.insert(stack)
    local cache = self._invCache
    local item = stack.name
    if (amtInserted > 0) then
        if not cache[item] then
            cache[item] = amtInserted
        else
            cache[item] = cache[item] + amtInserted
        end
    end
    return amtInserted
end

function TC.remove(self, stack)
    local cache = self._invCache
    if (not stack) or (stack.count <= 0) then --or (not cache[stack.name]) or (cache[stack.name] <= 0) then
        return 0
    end
    local amtRemoved = self.inv.remove(stack)
    local item = stack.name

    if (cache[item]) then
        -- if (cache[item] <= 0) then
        --     cache[item] = nil
        -- end
        cache[item] = cache[item] - amtRemoved
    end
    return amtRemoved
end

function TC.pushSlot(self, slotObj, front)
    -- if (not self.provItem) then
    --     return false
    -- elseif (self.slotIter) and (table.containsValue(self.slotIter.list, slotObj.id)) then
    --     return false
    -- end
    if (front) then
        self.slotQ:pushleft(slotObj)
    else
        self.slotQ:push(slotObj)
    end
end

function TC.setProvItem(self, itemName)
    local itemInf = ItemDB.item.get(itemName)
    if not itemInf then
        return nil
    end
    local oldInf = self:filterInfo()
    local force = self:force()
    if (oldInf) then
        Array.removeValue(force:provItem(oldInf.name).providers, self.id)
    -- for slot in self:iterCons() do
    --     slot:removeProvider(self)
    -- end
    end
    -- self.provItem = nil
    -- self.slotIter = nil
    -- self.slotQ = nil
    Array.insert(force:provItem(itemName).providers, self.id)
    self.provItem = itemName
    -- self.slotIter = self:iterConsObj(true)
    -- self.slotQ = idQ.new(SL)
end

function TC.findValidItemInfo(inv)
    for item, count in pairs(inv) do
        local inf = ItemDB.item.get(item)
        if (inf ~= nil) then
            return inf
        end
    end
    return nil
end

function TC.updateCache(self)
    local gTick = gSets.tick()
    -- local ticksPerCache = gSets.ticksBetweenChestCache()
    -- if (self._cacheLastTick + ticksPerCache > gTick) then
    --     return
    -- end
    inform("updating chest cache")
    -- self._cacheLastTick = gTick
    local newCache = self.inv.get_contents()
    local oldCache = self._invCache
    self._invCache = newCache
    local force = self:force()
    local cats = force.provCats
    -- local didRemove = false
    -- for item, count in pairs(force) do
    --     local inf = ItemDB.item.get(item)
    --     if (inf) and (not newCache[item]) then
    --         inform("removing provider")
    --         force:removeProv(self.id, item)
    --     end
    -- end
    local ignoreReturn = {}
    local rmCache = self._removalCache
    for item, count in pairs(newCache) do
        local inf = ItemDB.item.get(item)
        rmCache[item] = nil
        if (inf) and (not oldCache[item]) then
            inform("adding provider")
            force:addProv(self.id, item)
            -- if (isCatBest) then
            -- inform("cat is best")
            -- local catBest = force:provCat(inf.category)
            local limit = math.floor(count / inf.fillLimit)
            local added = 0
            local consCat = force:consCat(inf.category)
            local consItems = consCat.items
            for i = 1, #consItems do
                local itemObj = consItems[i]
                inform("checking item: " .. itemObj.name)
                if (inf.score > itemObj.score) then
                    -- inform("score is greater")
                    local cons = itemObj.consumers
                    -- local toAdd = self.slotsToAdd[item]
                    -- if not toAdd then
                    --     toAdd = {}
                    --     self.slotsToAdd[item] = toAdd
                    -- end
                    for id, t in pairs(cons) do
                        inform("checking id: " .. tostring(id))
                        if (added >= limit) then
                            goto addFin
                        end
                        local slot = SL.getObj(id)
                        if (slot) and (slot:provID() ~= self.id) and (self:canProvide(slot)) then
                            -- toAdd[id] = true
                            inform("setting slot provider to self")
                            slot:setProvider(self, item)
                            added = added + 1
                        end
                    end
                end
            end
            ::addFin::
            if (added >= limit) then
                newCache[item] = nil
                ignoreReturn[item] = true
            end
        -- end
        end
    end
    -- for itemName, slots in pairs(self.slotsToAdd) do
    --     local inf = ItemDB.item.get(itemName)
    --     local limit = math.floor(self:itemAmt(itemName) / inf.fillLimit)
    --     local added = 0
    --     for id, t in pairs(slots) do
    --         inform("checking id: " .. tostring(id))
    --         local slot = SL.getObj(id)
    --         slots[id] = nil
    --         added = added + 1
    --         if (slot) and (slot:filterScore() < inf.score) then
    --             slot:setProvider(self, itemName)
    --         end
    --         if (added >= limit) then
    --             newCache[itemName] = nil
    --             -- ignoreReturn[itemName] = true
    --             break
    --         end
    --     end
    --     if (added < limit) then
    --         self.slotsToAdd[itemName] = nil
    --     end
    -- end
    local ticksToWait = gSets.ticksBeforeCacheRemoval()
    for catName, cat in pairs(cats) do
        local items = cat.items
        for i = 1, #items do
            local itemObj = items[i]
            if (itemObj.providers[self.id]) then
                if (not ignoreReturn[itemObj.name]) and (not newCache[itemObj.name]) and (not rmCache[itemObj.name]) then
                    rmCache[itemObj.name] = gTick + ticksToWait
                -- didRemove = true
                end
            end
        end
    end
    for item, tick in pairs(rmCache) do
        if (gTick >= tick) then
            inform("TC: removeProv")
            force:removeProv(self.id, item)
            rmCache[item] = nil
        -- self.slotsToAdd[item] = nil
        end
    end
    -- if (not self.isStorage) then
    --     self:updateProvItem()
    -- end
    -- self:updateProvItem()
end

function TC.tick(self)
    inform("TC Tick")
    if (self.isStorage) then
        -- inform("exit 1")
        return
    end
    self:updateCache()
    -- if (not self.provItem) then
    --     -- inform("exit 2")
    --     return
    -- end
    -- local iter = self.slotIter
    -- local slotQ = self.slotQ
    -- local list = slotQ
    -- local nextSlot = idQ.pop
    -- local size = slotQ:size()
    -- if (size <= 0) then
    --     if (iter) then
    --         list = iter
    --         nextSlot = TC.nextCon
    --         size = iter.size - iter.ind + 1
    --         if (size <= 0) then
    --             self.slotIter = nil
    --             return
    --         end
    --     else
    --         return
    --     end
    -- end
    -- inform("For chest with item: " .. self.provItem .. ", total slots queued: " .. tostring(size))
    -- -- local start = slotQSize
    -- -- local remain = start
    -- local remain = size
    -- local itemInf = self:itemInfo()
    -- local itemAmt = self:itemAmt()
    -- local max = math.floor(itemAmt / itemInf.fillLimit)
    -- local amtAdded = 0
    -- -- local itemsUsed = itemInf.fillLimit
    -- while (remain > 0) and (amtAdded < max) do
    --     local slot = nextSlot(list)
    --     if not slot then
    --         inform("wierd...")
    --         self.iterSlot = nil
    --         break
    --     end
    --     remain = remain - 1
    --     -- inform("add provider")
    --     local added = slot:addProvider(self)
    --     if added then
    --         amtAdded = amtAdded + 1
    --         itemAmt = itemAmt - itemInf.fillLimit
    --     -- if (slot:getItemStack().count <= 0) then
    --     -- itemsUsed = itemsUsed + itemInf.fillLimit
    --     -- end
    --     end
    -- end
    -- self:itemAmt(itemAmt)
    -- self:itemAmt(itemAmt - (itemsUsed - itemInf.fillLimit))
    -- inform("TC itemUpdate, count: " .. tostring(size - remain) .. ", added: " .. tostring(amtAdded))
end

function TC.updateProvItem(self)
    local cache = self._invCache
    local newItemInfo = TC.findValidItemInfo(cache)
    if not newItemInfo then
        -- inform("no best item for chest...")
        return nil
    end
    local curItem = self.provItem
    if (curItem) and (cache[curItem]) then
        return nil
    end
    inform("setProv " .. newItemInfo.name)
    self:setProvItem(newItemInfo.name)
end

-- function TC.tickStorage(self)
-- end

function TC.iterator(self, sec)
    return util.iterator.new(TC, self, sec)
end
TC.chests = TC.iterator
function TC.slots(self, sec)
    return util.iterator.new(SL, self, sec)
end

function TC.iterCons(self, onlyWorse)
    local list, size = self:releventCons(onlyWorse, true)
    local ind = 1
    local function nextSlot()
        if (ind > size) then
            return nil
        end
        local chest = list[ind]
        ind = ind + 1
        return chest
    end
    return nextSlot, nil
end

function TC.iterConsObj(self, onlyWorse)
    local obj = {}
    local l, s = self:releventCons(onlyWorse)
    obj.list = l
    obj.size = s
    obj.ind = 1
    return obj
end

function TC.nextCon(iter)
    -- if (not iter) then return nil
    while (iter.size >= iter.ind) do
        local slot = SL.getObj(iter.list[iter.ind])
        iter.ind = iter.ind + 1
        if (slot) then
            return slot
        end
    end
    return nil
end

function TC.releventCons(self, onlyWorse, getObjects)
    -- local pos = self:position()
    -- local filterInf = self:filterInfo()
    -- local curScore = 0
    -- if (onlyBetter) and (filterInf) then
    -- curScore = filterInf.score
    -- end
    local force = self:force()
    local cats = self:force().provCats
    local res = {}
    local n = 0
    local relItems = {}
    local relItemAmt = 0
    for catName, cat in pairs(cats) do
        local items = cat.items
        for i = 1, #items do
            local itemObj = items[i]
            if (itemObj.providers[self.id]) then
                -- local consCat
                local consCat = force:consCat(itemObj.category)
                for conRank, consItem in pairs(consCat.items) do
                    if (not onlyWorse) or (consItem.score < itemObj.score) then
                        for id, t in pairs(consItem.consumers) do
                            local slot = SL.getObj(id)
                            if (slot) and (self:isInRange(slot:position())) then
                                n = n + 1
                                if (getObjects) then
                                    res[n] = slot
                                else
                                    res[n] = id
                                end
                            end
                        end
                    end
                end
                break
            end
        end
    end
    return res, n
end

return TC
