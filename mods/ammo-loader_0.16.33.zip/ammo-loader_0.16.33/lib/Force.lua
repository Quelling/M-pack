--[[--
Class representing a LuaForce.
@classmod Force
@alias FRC
]]
local Force = {}
local FRC = Force
Force.objMT = {
    __index = Force
}

Force._init = function()
    global["Force"] = {}
    global["Force"]["forces"] = {}
    for name, frc in pairs(game.forces) do
        global["Force"]["forces"][name] = Force.new(name)
    end
    -- Force._globs()
end
Init.registerFunc(Force._init)

Force._onLoad = function()
    -- Force._globs()
    for name, frc in pairs(Force.forces()) do
        setmetatable(frc, Force.objMT)
        setmetatable(frc.chests, idQ.objMT)
        setmetatable(frc.slots, idQ.objMT)
        setmetatable(frc.providedSlots, idQ.objMT)
        setmetatable(frc.slotsToCheck, idQ.objMT)
        setmetatable(frc.slotsNeedReturn, idQ.objMT)
        setmetatable(frc.storageChests, idQ.objMT)
    end
end
Init.registerOnLoadFunc(Force._onLoad)

function Force.new(name)
    local obj = {}
    setmetatable(obj, Force.objMT)
    obj.name = name
    obj.chests = idQ.new(TC)
    obj.provCats = {}
    obj.storageChests = idQ.new(TC)
    obj.slots = idQ.new(SL)
    obj.consumerCats = {}
    obj.providedSlots = idQ.new(SL)
    obj.slotsToCheck = idQ.new(SL)
    obj.slotsNeedReturn = idQ.new(SL)
    obj.techs = {}
    obj:getTechs()
    return obj
end

function Force.getTechs(self)
    local force = game.forces[self.name]
    local forceTechs = force.technologies
    local recipes = force.recipes
    local useTech = gSets.useTech()
    for key, name in pairs(protoNames.tech) do
        local tech = forceTechs[name]
        if not tech then
            return
        end
        if (useTech) then
            tech.enabled = true
        else
            tech.enabled = false
        end
        if (not tech.enabled) or (tech.researched) then
            if (tech.name == protoNames.tech.loader) then
                recipes[protoNames.loaderChest].enabled = true
            elseif (tech.name == protoNames.tech.requester) then
                recipes[protoNames.requesterChest].enabled = true
            elseif (tech.name == protoNames.tech.upgrade) then
                recipes[protoNames.storageChest].enabled = true
            end
            self.techs[name] = true
        end
    end
end

function Force.doUpgrade(self)
    if (not gSets.doUpgrade()) then
        return false
    end
    if (self.techs[protoNames.tech.upgrade]) then
        return true
    end
    return false
end
function Force.doVehicles(self)
    if (self.techs[protoNames.tech.vehicles]) then
        return true
    end
    return false
end
function Force.doArtillery(self)
    if (not gSets.doArtillery()) then
        return false
    end
    if (self.techs[protoNames.tech.artillery]) then
        return true
    end
    return false
end
function Force.doBurners(self)
    if (not gSets.doBurners()) then
        return false
    end
    if (self.techs[protoNames.tech.burners]) then
        return true
    end
    return false
end
function Force.doReturn(self)
    if (not gSets.doReturn()) then
        return false
    end
    if (self.techs[protoNames.tech.returnItems]) then
        return true
    end
    return false
end

function Force.provCat(self, catName)
    local res = self.provCats[catName]
    if not res then
        res = {items = {}}
        self.provCats[catName] = res
    end
    return res
end

function Force.provItem(self, itemName)
    local inf = ItemDB.item.get(itemName)
    if not inf then
        return nil
    end
    local cat = self:provCat(inf.category)
    local items = cat.items
    local rank = #items + 1
    for i = 1, rank - 1 do
        local item = items[i]
        if item.name == itemName then
            return item
        end
        if (item.score < inf.score) then
            rank = i
            break
        end
    end
    local item = {name = itemName, score = inf.score, category = inf.category, providers = {}}
    Array.insert(items, item, rank)
    return item
end

function Force.addProv(self, chestID, item)
    inform("adding provider...")
    local inf = ItemDB.item.get(item)
    local provItem = self:provItem(item)
    local chest = TC.getObj(chestID)
    if not chest then
        return
    end
    if (not provItem.providers[chestID]) then
        provItem.providers[chestID] = true
    -- if (chest.area) then
    --     self.slots:forEach(
    --         function(slot)
    --             if (slot.consumerCat == inf.category) and (not slot.canMove) and (Area.inside(chest.area, slot:position())) then
    --                 chest.consumersInRange[slot.id] = true
    --             end
    --         end,
    --         nil,
    --         true
    --     )
    -- end
    end
end

function Force.removeProv(self, chestID, item)
    local inf = ItemDB.item.get(item)
    inform("removing provider...")
    local provItem = self:provItem(item)
    local provs = provItem.providers
    if (provs[chestID]) then
        provs[chestID] = nil
        local consItem = self:consItem(item)
        local cons = consItem.consumers
        for slotID, t in pairs(cons) do
            local slot = SL.getObj(slotID)
            if (slot) then
                local ins = slot:inserter()
                if (ins.sourceID) and (ins.sourceID == chestID) then
                    slot:setBestProvider()
                end
            end
        end
    -- local chest = TC.getObj(chestID)
    -- if (not chest) or (not chest.area) then
    --     return
    -- end
    -- local hasCat = false
    -- local provCat = self:provCat(inf.category)
    -- for rank, provItem in pairs(provCat.items) do
    --     if (provItem.providers[chestID]) then
    --         hasCat = true
    --         break
    --     end
    -- end
    -- if (not hasCat) then
    --     local inRange = chest.consumersInRange
    --     for slotID, t in pairs(inRange) do
    --         local slot = SL.getObj(slotID)
    --         if (not slot) or (slot.consumerCat == inf.category) then
    --             inRange[slotID] = nil
    --         end
    --     end
    -- end
    end
    -- Array.removeValue(provItem.providers, chestID)
    -- provItem.providers[chestID] = nil
end

function Force.purgeProv(self, chestID)
    inform("purging provider...")
    local cats = self.provCats
    -- local chestID = chest.id
    for catName, cat in pairs(cats) do
        for rank, item in pairs(cat.items) do
            -- Array.removeValue(item.providers, chestID)
            self:removeProv(chestID, item.name)
        end
    end
end

function Force.consumerCat(self, catName)
    local res = self.consumerCats[catName]
    if not res then
        res = {slots = {}, items = {{name = "_noItem", score = 0, category = catName, consumers = {}}}}
        res._noItem = res.items[1]
        self.consumerCats[catName] = res
    end
    return res
end
Force.consCat = Force.consumerCat

function Force.consumerItem(self, itemName)
    local inf = ItemDB.item.get(itemName)
    if not inf then
        return nil
    end
    local cat = self:consumerCat(inf.category).items
    local rank = #cat + 1
    for i = 1, rank - 1 do
        local item = cat[i]
        if item.name == itemName then
            return cat[i]
        end
        if (item.score < inf.score) then
            rank = i
            break
        end
    end
    local item = {name = itemName, score = inf.score, category = inf.category, consumers = {}}
    Array.insert(cat, item, rank)
    return item
end
Force.consItem = Force.consumerItem

function Force.addConsumerToCategory(self, slotID, catName)
    local cat = self:consCat(catName)
    cat.slots[slotID] = true
end

function Force.addConsumer(self, slotID, item)
    inform("addCons")
    local slot = SL.getObj(slotID)
    if not slot then
        return
    end
    local consItem = self:consItem(item)
    if not item then
        local consCat = self:consCat(slot.consumerCat)
        consItem = consCat._noItem
    end
    consItem.consumers[slotID] = true
end
Force.addCons = Force.addConsumer

function Force.removeConsumer(self, slotID, item)
    inform("removeCons")
    local slot = SL.getObj(slotID)
    if not slot then
        return
    end
    local consItem = self:consItem(item)
    if not item then
        local consCat = self:consCat(slot.consumerCat)
        consItem = consCat._noItem
    end
    consItem.consumers[slotID] = nil
end
Force.removeCons = Force.removeConsumer

function Force.purgeConsumer(self, slotID)
    local cats = self.consumerCats
    -- local chestID = chest.id
    for catName, cat in pairs(cats) do
        cat.slots[slotID] = nil
        for rank, item in pairs(cat.items) do
            item.consumers[slotID] = nil
        end
    end
end

function Force.forces()
    return global["Force"]["forces"]
end

function Force.get(name)
    local forces = Force.forces()
    local frc = forces[name]
    if not frc then
        frc = Force.new(name)
        forces[name] = frc
    end
    return frc
end

function FRC.tickAll()
    for name, frc in pairs(Force.forces()) do
        frc:tick()
    end
end

function FRC.tick(self)
    local chests = self.chests
    local slots = self.slots
    local chestsNum = chests:size()
    local slotsNum = slots:size()

    -- inform("Force " .. self.name .. " has " .. tostring(chestsNum) .. " chests and " .. tostring(slotsNum) .. " slots.")
    if (chestsNum == 0) or (slotsNum == 0) then
        return nil
    end

    local slotsPer = gSets.slotsPerCycle()
    local chestsPer = gSets.chestsPerCycle()

    self.chests:forEach(TC.tick, chestsPer, true)
    -- self.slots:forEach(SL.setBestProvider, slotsPer, true)
    if (self:doUpgrade()) and (self.storageChests:size() > 0) then
        self.slotsNeedReturn:forEach(
            function(slot)
                local remain = slot:returnItems(true)
                if remain then
                    self.slotsNeedReturn:push(slot)
                end
            end,
            slotsPer,
            false
        )
    end
    -- self.slotsToCheck:forEach(SL.checkAllProviders, slotsPer, false)
    self.providedSlots:forEach(SL.doProvide, slotsPer, true)
end

function FRC.addChest(self, chestObj)
    if (chestObj.isStorage) then
        self.storageChests:push(chestObj)
    else
        self.chests:push(chestObj)
    end
end
function FRC.addSlot(self, slotObj)
    local cat = self:consumerCat(slotObj.consumerCat)
    cat[slotObj.id] = true
    if (slotObj.isProvided) then
        self.providedSlots:pushleft(slotObj)
    end
    self.slots:push(slotObj)
end

function FRC.isValid(self)
    if game.forces[self.name] ~= nil then
        return true
    end
    return false
end

return Force
