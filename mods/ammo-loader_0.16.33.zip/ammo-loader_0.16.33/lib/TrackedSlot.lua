--[[--
TrackedSlot: Class representing a single tracked slot.
@classmod SL
]]
local SL = {}
SL.className = "TrackedSlot"
SL.dbName = SL.className
DB.register(SL.dbName)

--[[-- Metatable for all instances to use.
@table objMT
]]
SL.objMT = {
    __index = SL
}
-- local TS = SL

function SL._onLoad()
    for id, obj in pairs(DB.getAll(SL.dbName)) do
        setmetatable(obj, SL.objMT)
    end
end
Init.registerOnLoadFunc(SL._onLoad)

function SL._init()
    -- HI.destroyAll()
    -- DB.new(SL.dbName)
    global["trackedEntNames"] = {}
end
Init.registerFunc(SL._init)

function SL.highestID()
    return DB.highest(SL.dbName)
end

function SL.emptyStack()
    return {name = nil, count = 0}
end

SL.trackable = {}

SL.trackable.all = function()
    return global["trackedEntNames"]
end
SL.trackedEnts = SL.trackable.all

function SL.trackable.getOrAddEnt(ent)
    local tracked = SL.trackable.all()
    local tEnt = tracked[ent.name]
    if not tEnt then
        tEnt = {}
        tracked[ent.name] = tEnt
    end
    return tEnt
end
SL.trackable.addEnt = SL.trackable.getOrAddEnt

function SL.trackable.getOrAddInv(ent, ind)
    local invs = SL.trackable.getOrAddEnt(ent)
    local inv = invs[ind]
    if not inv then
        inv = {}
        invs[ind] = inv
    end
    return inv
end
SL.trackable.addInv = SL.trackable.getOrAddInv

function SL.trackable.getOrAddSlot(ent, invInd, slotInd)
    local slots = SL.trackable.getOrAddInv(ent, invInd)
    local slot = slots[slotInd]
    if not slot then
        slot = true
        slots[slotInd] = slot
    end
    return slot
end

function SL.isTrackable(ent)
    if (not SL.trackedEnts()[ent.name]) then
        return false
    end
    return true
end

function SL.allSlots()
    return DB.getAll(SL.dbName)
end

function SL.clearAllSlots(forceName)
    -- local slots = SL.allSlots()
    -- for id, slotObj in pairs(slots) do
    --     slotObj:slot().clear()
    -- end
    local slots = Force.get(forceName).slots
    slots:forEach(SL.returnItems, nil, true)
end

function SL.returnAll(forceEmpty)
    local forces = {}
    local slots = SL.allSlots()
    for id, slotObj in pairs(slots) do
        local spillStack = slotObj:returnItems(forceEmpty, false)
        if (spillStack ~= nil) and (spillStack.count > 0) then
            local force = forces[slotObj.forceName]
            if not force then
                force = {}
                forces[slotObj.forceName] = force
            end
            local spill = force
            local amt = spill[spillStack.name]
            if (not amt) then
                amt = 0
                spill[spillStack.name] = amt
            end
            spill[spillStack.name] = amt + spillStack.count
        end
    end
    for forceName, inv in pairs(forces) do
        for item, amt in pairs(inv) do
            local stack = {name = item, count = amt}
            game.surfaces.nauvis.spill_item_stack({x = 0, y = 0}, stack, true, forceName)
        end
    end
end

function SL.getSlotsWithEnt(ent)
    local q = idQ.new(SL)
    local slots = SL.allSlots()
    for id, obj in pairs(slots) do
        if (obj.ent == ent) then
            q:push(obj)
        end
    end
    return q
end

function SL.prepareForRemoval(self)
    local inserter = self:inserter()
    inserter:destroy()
    self:returnItems()
end

function SL.new(ent, inv, index)
    if (not isValid(ent)) or (ent.type == "boiler") then
        -- inform("???????????????????")
        return nil
    end
    local ind = index or 1
    if not SL.isValidSlot(inv, ind) then
        -- inform("not a valid slot for " .. ent.name)
        return nil
    end
    local slot = inv[ind]
    local slotCat = SL.getSlotCat(slot)
    if not slotCat then
        -- inform("no category for " .. ent.name)
        return nil
    end

    local obj = {}
    setmetatable(obj, SL.objMT)
    obj.ent = ent
    -- obj.entName = ent.name
    obj.invInd = SL.getInvInd(ent, inv)
    if (not obj.invInd) then
        obj._inv = inv
    end
    obj.slotInd = ind
    obj.forceName = ent.force.name
    local force = Force.get(obj.forceName)
    if (not gSets.doTrains()) and (ent.type == "locomotive") then
        return nil
    end
    -- obj.type = slotType
    -- obj.category = slotCat
    obj.consumerCat = slotCat

    local ammoEntTypes = {
        "artillery-turret",
        "ammo-turret",
        "artillery-wagon",
        "car"
    }
    if (obj.consumerCat ~= "fuel") and (not Map.containsValue(ammoEntTypes, ent.type)) then
        return
    end

    if (obj.consumerCat == "artillery-shell") and (not force:doArtillery()) then
        return nil
    end
    local pos = ent.position
    if (SL.entCanMove(ent)) then
        if (not force:doVehicles()) then
            return nil
        end
        obj.isProvided = true
        obj.canMove = true
        pos = nil
    elseif (obj.consumerCat == "fuel") and (not force:doBurners()) then
        return nil
    end
    if (ent.surface.name ~= "nauvis") then
        if (obj.canMove) then
            return nil
        end
        obj.isProvided = true
        local player = ent.last_user
        if not player then
            return nil
        end
        pos = trackedPos(player.index)
        if not pos then
            -- inform("no pos...")
            return nil
        end
    end
    if (pos) then
        obj._posX = pos.x
        obj._posY = pos.y
    end
    -- obj._stackCache = {lastTick = 0, stack = SL.emptyStack()}
    obj.id = SL.dbInsert(obj)
    if obj.isProvided then
        obj._inserter = {lastTick = 0}
        obj._slot = inv[index]
    else
        obj.inserterID = SL.newInserter(obj).id
    end
    local force = obj:force()
    force:addSlot(obj)
    force:consCat(obj.consumerCat)._noItem.consumers[obj.id] = true
    if (not gSets.rangeIsInfinite()) and (not obj.canMove) then
        local tempPos = obj:position()
        force.chests:forEach(
            function(chest)
                if (Area.inside(chest.area, tempPos)) then
                    chest.consumersInRange[obj.id] = true
                end
            end,
            nil,
            true
        )
    end
    -- for chest in obj:iterProvs() do
    -- end
    -- obj:checkAllProviders(true)
    obj:setBestProvider()
    SL.trackable.getOrAddSlot(ent, obj.invInd, obj.slotInd)
    return obj
end

SL.category = function(self)
    -- local inf = self:filterInfo()
    -- if (not inf) then
    --     return nil
    -- end
    -- return inf.category
    return self.consumerCat
end

SL.getArea = function(self)
    local rad = gSets.chestRadius()
    if rad > 0 then
        return Position.expand_to_area(self:position(), rad)
    end
    return nil
end

SL.surface = function(self)
    return self.ent.surface
end

SL.inv = function(self)
    if (not self.invInd) then
        return self._inv
    end
    return self.ent.get_inventory(self.invInd)
end
SL.slot = function(self)
    if (not self._slot) then
        return self:inv()[self.slotInd]
    end
    return self._slot
end

function SL.inserter(self)
    if (self.isProvided) then
        return self._inserter
    end
    return HI.getObj(self.inserterID)
end

function SL.destroy(self)
    -- local obj = self
    -- obj:prepareForRemoval()
    local force = self:force()
    -- force:consumerCat(self.consumerCat)[self.id] = nil
    force:purgeConsumer(self.id)
    local ins = self:inserter()
    if (ins) and (not self.isProvided) then
        ins:destroy()
    end
    DB.deleteID(SL.dbName, self.id)
end

function SL.getPosition(self)
    if (self._posX) then
        return {x = self._posX, y = self._posY}
    end
    return self.ent.position
end
SL.position = SL.getPosition

function SL.getForce(self)
    return FRC.get(self.forceName)
end
SL.force = SL.getForce

function SL.getItemInfo(self)
    local stack = self:getItemStack()
    if stack.count > 0 then
        return ItemDB.item.get(stack.name)
    end
    return nil
end
SL.itemInfo = SL.getItemInfo
SL.getCurItemInfo = SL.getItemInfo
SL.stackItemInfo = SL.getItemInfo

--- Return Hidden Inserter's current pickup target.
-- @param self
-- @return Provider
function SL.getCurProvider(self)
    return TC.getObj(self:inserter().sourceID)
end
SL.curProvider = SL.getCurProvider
SL.provider = SL.getCurProvider

function SL.getSourceID(self)
    local ins = self:inserter()
    return ins.sourceID
end
SL.sourceID = SL.getSourceID

function SL.getBestItemInfo(self)
    return ItemDB.item.get(self:filterItem())
end
SL.filterInfo = SL.getBestItemInfo
SL.bestItemInfo = SL.getBestItemInfo
SL.provItemInfo = SL.getBestItemInfo

function SL.getFilterScore(self)
    local inf = self:filterInfo()
    if not inf then
        return 0
    end
    return inf.score
end
SL.filterScore = SL.getFilterScore

function SL.getFilterItem(self)
    return self:inserter().filterName
end
SL.filterItem = SL.getFilterItem
SL.filterName = SL.getFilterItem
SL.provItem = SL.getFilterItem

-- function SL.updateProvider(self)
--     local ins = self:inserter()
--     local sourceID = ins.sourceID
--     local filterItem = ins.filterName
--     local chest = TC.getObj(sourceID)
--     if (not chest) or (not chest.provItem) or (chest.provItem ~= filterItem) or ((chest.area) and (not Area.inside(chest.area, self:position()))) then
--         self:force().slotsToCheck:push(self)
--     end
-- end

function SL.doProvide(self)
    inform("doProvide")
    if (self.canMove) then
        inform("provide: canMove")
        self:setBestProvider()
    end
    local ins = self:inserter()
    local sourceID = ins.sourceID
    if (not sourceID) then
        return false
    end
    local filterItem = ins.filterName
    local filterItemInf = ItemDB.item.get(filterItem)
    local slotStack = self:getItemStack()
    if (slotStack.count > 0) and (slotStack.name ~= filterItem) then
        return
    end
    local amtToFull = filterItemInf.fillLimit * 2 - slotStack.count
    if (amtToFull > filterItemInf.fillLimit) then
        inform("need to fill")
        local fillStack = {name = filterItem, count = amtToFull}
        local chest = TC.getObj(sourceID)
        if (chest) then
            local amtRemoved = chest:remove(fillStack)
            if (amtRemoved > 0) then
                inform("provide: set_stack")
                fillStack.count = slotStack.count + amtRemoved
                self:slot().set_stack(fillStack)
            -- if (amtIns < amtRemoved) then
            --     chest:insert({name = fillStack.name, count = amtRemoved - amtIns})
            -- end
            -- fillStack.count = slotStack.count + amtRemoved
            -- self:setItemStack(fillStack)
            -- inform("set stack: " .. filterItem .. ", " .. tostring(fillStack.count))
            end
        end
    end
end

function SL.setItemStack(self, stack)
    local slot = self:slot()
    -- local cache = self._stackCache
    -- cache.lastTick = gSets.tick()
    if (not stack) or (stack.count <= 0) then
        -- cache.stack = SL.emptyStack()
        slot.clear()
    else
        -- cache.stack = stack
        slot.set_stack(stack)
    end
end

function SL.addProvider(self, chestObj)
    if (not chestObj) or (not chestObj.provItem) then
        -- inform("exit1")
        return false
    end
    local force = self:force()
    local function returnIfNeeded(newInf)
        if (not force:doUpgrade()) then
            return false
        end
        local stack = self:getItemStack()
        if (stack.count <= 0) then
            return true
        end
        local curInf = ItemDB.item.get(stack.name)
        if (curInf) and (curInf.score < newInf.score) then
            force.slotsNeedReturn:push(self)
        end
        return true
    end
    local ins = self:inserter()
    local sourceID = ins.sourceID
    local oldInf = self:filterInfo()
    local newInf = chestObj:filterInfo()
    if (sourceID) then
        if (sourceID == chestObj.id) then
            return false
        else
            if (oldInf.score >= newInf.score) then
                return false
            else
                returnIfNeeded(newInf)
                self:setProvider(chestObj)
                return true
            end
        end
    else
        returnIfNeeded(newInf)
        self:setProvider(chestObj)
        return true
    end
    -- return false
end

function SL.removeProvider(self, chestObj)
    local ins = self:inserter()
    local sourceID = ins.sourceID
    -- local curItem = ins.filterName

    if (not sourceID) or (sourceID ~= chestObj.id) then
        return nil
    end
    self:setProvider()
    -- if (not self.isProvided) then
    -- self:force().slotsToCheck:push(self)
    self:checkAllProviders()
    -- end
end

function SL.provID(self)
    local ins = self:inserter()
    if (not ins.sourceID) then
        return 0
    end
    return ins.sourceID
end

function SL.setBestProvider(self)
    -- local curBest = nil
    -- local pos = self:position()
    local cat = self:force():provCat(self.consumerCat)
    local catItems = cat.items
    -- local best = {}
    for i = 1, #catItems do
        local item = catItems[i]
        local provs = item.providers
        for id, t in pairs(provs) do
            local chest = TC.getObj(id)
            if (chest) and (chest._invCache[item.name]) and (chest:canProvide(self)) then
                inform("setting provider...")
                self:setProvider(chest, item.name)
                return chest, item.name
            end
        end
    end
    inform("setting nil provider...")
    self:setProvider()
    -- local curScore = self:filterScore()
    -- if (ins.sourceID) and (Array.indexOf(force:provItem(ins.filterName).providers, ins.sourceID)) then
    --     curScore = ItemDB.item.get(ins.filterName).score
    -- end
    -- local provCat = force:provCat(self.consumerCat)
    -- for i = 1, #provCat do
    --     local provItem = provCat[i]
    --     if (provItem.score > curScore) then
    --         local provs = provItem.providers
    --         for id, t in pairs(provs) do
    --             local chest = TC.getObj(id)
    --             if (chest) then
    --                 -- end
    --                 -- if (chest:itemAmt() > 0) then
    --                 self:setProvider(chest, provItem.name)
    --                 return chest, provItem.name
    --             else
    --                 provs[id] = nil
    --             end
    --         end
    --     end
    -- for id, t in pairs(provItem.providers) do
    -- local chest = TC.getObj(id)
    -- if (chest) then
    -- end
    -- if (chest:itemAmt() > 0) then
    -- self:setProvider(chest)
    -- return chest
    -- else
    -- provItem[id] = nil
    -- end
    -- end
    -- end
    -- if (provItem)
    -- for chest in self:iterProviders() do
    --     local inf = chest:filterInfo()
    --     local amt = chest:itemAmt()
    --     if (inf) and (amt > 0) and ((not curBest) or (inf.score > curInf.score)) then
    --         curBest = chest
    --         curInf = inf
    --     end
    -- end
    -- self:setProvider(curBest)
    -- return curBest
end

function SL.checkAllProviders(self, pushToFront)
    for chest in self:iterProviders(true) do
        chest:pushSlot(self, pushToFront)
    end
end

function SL.setProvider(self, chestObj, itemName)
    local chest = nil
    local item = nil
    local id = nil
    local ins = self:inserter()
    local curProvID = self:provID()
    local force = self:force()
    if (chestObj) and (itemName) then
        chest = chestObj
        item = itemName
        id = chestObj.id
        if (curProvID == id) and (ins.filterName == item) then
            return
        end
        -- local amt = chestObj:itemAmt()
        local inf = ItemDB.item.get(item)
        -- chestObj:itemAmt(amt - inf.fillLimit)
        if (force:doUpgrade()) then
            local stackInf = self:stackItemInfo()
            if (stackInf) and (stackInf.score < inf.score) then
                -- force.slotsNeedReturn:push(self)
                local remain = self:returnItems()
                if remain then
                    force.slotsNeedReturn:push(self)
                end
            end
        end
    end
    if (not id) and (not ins.sourceID) then
        return
    end
    force:removeCons(self.id, ins.filterName)
    force:addCons(self.id, item)
    if (self.isProvided) then
        ins.sourceID = id
        ins.filterName = item
    else
        ins:setSourceAndItem(chest, item)
    end
end

function SL.newInserter(self)
    local newIns = HI.new(self)
    return newIns
end

function SL.isValid(self)
    if not self then
        return false
    end
    return isValid(self.ent)
end

function SL.insert(self, stack)
    local curStack = self:stackCache()
    local newAmt = stack.count
    if (curStack.count > 0) then
        if (curStack.name ~= stack.name) then
            return 0
        end
        newAmt = stack.count + curStack.count
    end
    local itemInf = ItemDB.item.get(stack.name)
    local stackSize = itemInf.stackSize
    if (stackSize < newAmt) then
        newAmt = stackSize
    end
    if (newAmt > curStack.count) then
        self:setItemStack({name = stack.name, count = newAmt})
        return newAmt - curStack.count
    else
        return 0
    end
end

function SL.remove(self, stack)
    local curStack = self:stackCache()
    local newAmt = stack.count
    if (curStack.count <= 0) or (curStack.name ~= stack.name) then
        return 0
    end
    newAmt = stack.count - curStack.count
    -- local itemInf = ItemDB.item.get(stack.name)
    -- local stackSize = itemInf.stackSize
    if (newAmt <= 0) then
        newAmt = 0
    end
    if (newAmt < curStack.count) then
        self:setItemStack({name = stack.name, count = newAmt})
        return curStack.count - newAmt
    end
    return 0
end

function SL.transferTo(self, target, stack)
    if (not stack) or (stack.count <= 0) then
        return 0
    end
    local amtRem = self:remove(stack)
    if (amtRem <= 0) then
        return 0
    end
    local amtIns = target:insert({name = stack.name, count = amtRem})
    if (amtIns < amtRem) then
        local newAmt = amtRem - amtIns
        self:insert({name = stack.name, count = newAmt})
        return newAmt
    end
    return amtIns
end

function SL.returnItems(self, matchFilter)
    local force = self:force()
    if (force.storageChests:size() <= 0) then
        return
    end
    local curStack = self:itemStack()
    if (curStack.count <= 0) then
        return
    end
    local filterName = self:filterItem()
    if (matchFilter) and (curStack.name == filterName) then
        return
    end
    local slot = self:slot()
    -- local doSpill = spill or true
    for chest in self:iterStorage() do
        local inserted = chest:insert(curStack)
        curStack.count = curStack.count - inserted
        if curStack.count <= 0 then
            slot.clear()
            return true
        end
    end
    slot.set_stack(curStack)
    return curStack
    -- if (not forceEmpty) then
    -- force.slotsNeedReturn:push(self)
    -- return false
    -- end
    -- local dropPos = {x = 0, y = 0}
    -- local owner = self.ent.last_user
    -- if isValid(owner) then
    --     dropPos = owner.position
    --     local given = owner.insert(curStack)
    --     curStack.count = curStack.count - given
    --     self:setItemStack(curStack)
    --     if (curStack.count <= 0) then
    --         return curStack
    --     end
    -- end
    -- if (doSpill) then
    --     self:surface().spill_item_stack(dropPos, curStack, true, self.forceName)
    --     self:setItemStack()
    -- else
    --     return curStack
    -- end
end

function SL.returnEntItems(ent)
    for id, slotObj in pairs(SL.allSlots()) do
        if (slotObj.ent == ent) then
            slotObj:returnItems()
        end
    end
end

function SL.getSlotItemStack(slot)
    local stack = {name = nil, count = 0}
    if (not isValid(slot)) or (not slot.valid_for_read) then
        return stack
    end
    stack.name = slot.name
    stack.count = slot.count
    return stack
end

function SL.isValidSlot(inv, ind)
    if not isValid(inv) then
        return false
    end
    local maxSlot = #inv
    if (maxSlot < ind) then
        return false
    end
    local slot = inv[ind]
    if not isValid(slot) then
        return false
    end
    return true
end

function SL.isBurner(ent, inv)
    if (not ent.burner) or (not ent.burner.inventory) then
        return false
    end
    if (ent.burner.inventory == inv) then
        return true
    end
    return false
end

function SL.getInvInd(ent, inv)
    for name, ind in pairs(defines.inventory) do
        local newInv = ent.get_inventory(ind)
        if (newInv == inv) then
            return ind
        end
    end
    return nil
end

function SL.getPossibleInventories(ent)
    -- local allResults = {}
    -- local burner = ent.burner
    -- local ents = {}
    -- ents[#ents+1] = ent
    -- ents[#ents+1] = burner
    -- for entInd, ent in pairs(ents) do
    local entResults = {}
    for name, invInd in pairs(defines.inventory) do
        if not entResults[invInd] then
            local newInv = ent.get_inventory(invInd)
            if (newInv ~= nil) and (#newInv > 0) then
                local newSlot = newInv[1]
                if (newSlot ~= nil) and (SL.getSlotCat(newSlot) ~= nil) then
                    entResults[invInd] = newInv
                end
            end
        end
    end
    if (ent.burner ~= nil) then
        -- inform("slotCreate adding burner inventory")
        local burnerInv = ent.burner.inventory
        local skip = false
        for ind, inv in pairs(entResults) do
            if (inv == burnerInv) then
                skip = true
                break
            end
        end
        if not skip then
            entResults[defines.inventory.fuel] = ent.burner.inventory
        end
    end
    -- allResults = table.combineValues({allResults, entResults})
    -- end
    return entResults
end

SL.invTypes = {
    defines.inventory.turret_ammo,
    defines.inventory.car_ammo,
    defines.inventory.fuel,
    defines.inventory.item_main
}

function SL.trackAllSlots(ent)
    if not isValid(ent) then
        return nil
    end
    -- if (string.find(ent.name, "heli-")) then
    --     createdQ.futureQ():push({tick = gSets.tick() + 5, options = {name = gSets.heliEntName()}})
    -- end
    -- local doInform = false
    -- if (ent.name == "artillery-turret") then
    --     doInform = true
    -- end
    local invTypes = SL.invTypes
    local invs = {}
    -- local main = ent.get_main_inventory()
    -- if (isValid(main)) then
    --     invs[#invs + 1] = main
    -- end
    for ind, invType in pairs(invTypes) do
        local newInv = ent.get_inventory(invType)
        if (isValid(newInv)) and (#newInv > 0) and (not Array.contains(invs, newInv)) then
            invs[#invs + 1] = newInv
        end
    end
    if (ent.burner) and (#ent.burner.inventory > 0) and (not Array.contains(invs, ent.burner.inventory)) then
        invs[#invs + 1] = ent.burner.inventory
    end

    -- local frc = FRC.get(ent.force.name)
    -- local invs = SL.getPossibleInventories(ent)
    -- if #invs <= 0 then return nil end
    -- local chestsInRange = FRC.getChestsInRange(ent.force.name, ent.position)
    local _i = 0
    local _s = 0
    for ind, inv in pairs(invs) do
        _i = _i + 1
        local slotsToCreate = 1
        if (ent.prototype.guns ~= nil) and (SL.getType(inv[1]) == "ammo") then
            slotsToCreate = #inv
        end
        for i = 1, slotsToCreate do
            _s = _s + 1
            local newSlot = SL.new(ent, inv, i)
        end
    end
    -- if (doInform) then
    -- inform("tested " .. tostring(_i) .. " inventories, attempted " .. tostring(_s) .. " new slots.")
    -- end
end

function SL.dbInsert(slotObj)
    return DB.insert(SL.dbName, slotObj)
end

function SL.getType(slot)
    local cat = SL.getSlotCat(slot)
    if not cat then
        return nil
    end
    if (cat == "fuel") then
        return cat
    end
    return "ammo"
end

function SL.entCanMove(ent)
    if (ent.speed ~= nil) then
        -- (ent.type == "car") or
        -- (ent.type == "locomotive") or
        -- (string.contains(ent.type, "wagon"))
        return true
    end
    return false
end

-- function SL.isInRange(self, pos)
--     local range = TC.chestRadius()
--     if range == 0 then
--         return true
--     end
--     local slotPos = SL.position(self)
--     local area = Position.expand_to_area(slotPos, range)
--     if (Area.inside(area, pos)) then
--         return true
--     end
--     return false
-- end

-- function SL.isInArea(self, area)
--     return Area.inside(area, self:position())
-- end

function SL.getObj(id)
    return DB.getObj(SL.dbName, id)
end

function SL.getSlotsByEnt(ent)
    local slots = DB.getEntries(SL.dbName)
    local result = {}
    for id, slotObj in pairs(slots) do
        if (slotObj.ent == ent) then
            result[#result + 1] = slotObj
        end
    end
    return result
end

-- function SL.getItemStack(self, returnRef)
--     local cache = self._stackCache
--     local interval = gSets.slotProvideInterval()
--     local gTick = gSets.tick()
--     if (cache.lastTick + interval > gTick) then
--         if (returnRef) then
--             return cache.stack
--         else
--             local cStack = cache.stack
--             if (cStack.count <= 0) then
--                 return SL.emptyStack()
--             end
--             return {name = cStack.name, count = cStack.count}
--         end
--     end
--     cache.lastTick = gTick
--     local slot = self:slot()
--     -- if (self.slot ~= nil) then slot = self.slot end
--     -- local emptyStack = {name = nil, count = 0}
--     if (not slot.valid_for_read) then
--         cache.stack = SL.emptyStack()
--     else
--         cache.stack = {name = slot.name, count = slot.count}
--     end
--     if (returnRef) then
--         return cache.stack
--     end
--     return {name = cache.stack.name, count = cache.stack.count}
-- end
function SL.getItemStack(self, returnRef)
    local slot = self:slot()
    -- if (self.slot ~= nil) then slot = self.slot end
    -- local emptyStack = {name = nil, count = 0}
    if (not slot.valid_for_read) then
        return SL.emptyStack()
    else
        return {name = slot.name, count = slot.count}
    end
end
SL.itemStack = SL.getItemStack
SL.stackCache = SL.getItemStack

function SL.getSlotCat(slot)
    local canInsert = slot.can_set_stack
    if (canInsert({name = "iron-plate", count = 1})) then
        return nil
    end
    for name, info in pairs(ItemDB.items()) do
        if (canInsert({name = name, count = 1})) then
            return info.category
        end
    end
    return nil
end

function SL.iterator(self, sec)
    return util.iterator.new(SL, self, sec)
end
SL.slots = SL.iterator

function SL.chests(self, sec)
    return util.iterator.new(TC, self, sec)
end

function SL.iterProviders(self, onlyBetter)
    local list, size = self:releventProvs(onlyBetter, true)
    local ind = 1
    local function nextChest()
        if (ind > size) then
            return nil
        end
        local chest = list[ind]
        ind = ind + 1
        return chest
    end
    return nextChest, nil
end
SL.iterProvs = SL.iterProviders

function SL.iterStorage(self)
    local chests = self:force().storageChests
    local size = chests:size()
    local i = 0
    local pos = self:position()
    local function nextChest()
        if (i >= size) then
            return nil
        end
        i = i + 1
        local chest = chests:cycle()
        if not chest then
            return nil
        end
        if (chest:isInRange(pos)) then
            return chest
        end
    end
    return nextChest, nil
end

function SL.releventProvs(self, onlyBetter, getObjects)
    -- local testBetter = onlyBetter
    local pos = self:position()
    local filterInf = self:filterInfo()
    local curScore = 0
    if (onlyBetter) and (filterInf) then
        curScore = filterInf.score
    end
    local cat = self:force():provCat(self.consumerCat)
    local catItems = cat.items
    local res = {}
    local n = 0
    for i = 1, #catItems do
        local item = catItems[i]
        if (item.score > curScore) then
            local provs = item.providers
            for id, t in pairs(provs) do
                local chest = TC.getObj(id)
                if (chest) and (chest:canProvide(pos)) then
                    n = n + 1
                    if (getObjects) then
                        res[n] = chest
                    else
                        res[n] = id
                    end
                end
            end
        end
        -- local doItem = (not onlyBetter)
        -- if (onlyBetter) then
        -- local inf = ItemDB.item.get(item)
        -- if (curScore < inf.score) then
        --     for id, t in pairs(provs) do
        --         local chest = TC.getObj(id)
        --         if (not chest) then
        --             provs[id] = nil
        --         elseif (chest:isInRange(pos)) then
        --             n = n + 1
        --             if (getObjects) then
        --                 res[n] = chest
        --             else
        --                 res[n] = id
        --             end
        --         end
        --     end
        -- end
    end
    return res, n
end

return SL
