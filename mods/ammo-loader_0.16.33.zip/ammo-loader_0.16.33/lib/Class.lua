--[[--
Module for creating classes.
@module Class
]]
local Class = {}
Class.createClass =
    function(name, newFunc)
    if not name then
        error("Ammo Loader: cannot create class without name.")
    end

    local obj = {}
    obj.class = name
    obj.className = obj.class
    obj.objMT = {
        __index = obj
    }
    obj.new = function(...)
        local newObj = newFunc(...)
        setmetatable(newObj, obj.objMT)
        return newObj
    end
    return obj
end

Class.createClassWithDB =
    function(name, newFunc)
    -- if (not name) or (not destF) or (not newF) or (not validF) then
    --     error("Ammo Loader: missing arguments for class with DB.")
    -- end

    local obj = {}
    obj.class = name
    obj.className = obj.class
    obj.dbName = obj.class
    obj.objMT = {
        __index = obj
    }
    obj.DB = function()
        return DB.getAll(obj.dbName)
    end
    obj.dbInsert = function(t)
        return DB.insert(obj.dbName, t)
    end
    obj.dbDelete = function(id)
        return DB.deleteID(obj.dbName, id)
    end
    obj.isValid = function(self)
        if (not self) then
            return false
        end
        return true
    end
    obj.getObj = function(id)
        local t = DB.getObj(obj.dbName, id)
        if not t then
            return nil
        end
        if not t:isValid() then
            t:destroy()
            obj.dbDelete(id)
            return nil
        end
        return t
    end
    obj._SETMETA = function()
        for id, t in pairs(obj.DB()) do
            setmetatable(t, obj.objMT)
        end
    end
    Init.registerOnLoadFunc(obj._SETMETA)
    obj.new = function(...)
        local newObj = newFunc(...)
        newObj.id = obj.dbInsert(newObj)
        setmetatable(newObj, obj.objMT)
        return newObj
    end
    obj.destroy = function(self)
        if not self then
            return nil
        end
        obj.dbDelete(self.id)
        return nil
    end
    return obj
end
return Class
