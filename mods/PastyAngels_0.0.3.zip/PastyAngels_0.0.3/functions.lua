--Util functions
function addUnique(where, what) 
	local doAdd = true
	for _,each in pairs(where) do
		--game.print("comparing "..each.." to "..what)
		if each==what then
			doAdd = false
		end
	end
	if doAdd then
		--game.print("adding: "..what)
		where[#where+1] = what
	end
end
function in_array(what, where)
	for each,_ in pairs(where) do
		if each==what then
			return true
		end
	end
	return false
	
end
function count(what)
	local count = 0
	for each, v in pairs(what) do
		count = count + 1
	end
	return count
end

function table.cstm_intersection (a,b)
  local res = {}
  for k,v in pairs(a) do
    res[k] = b[k]
  end
  return res
end

function debug.log(msg)
	if false then
		game.print(msg)
	elseif false then
		game.write_file("pasty.log", msg.."\n", true)
	end
end