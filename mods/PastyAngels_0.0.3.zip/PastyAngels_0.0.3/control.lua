require "functions"
script.on_init(function()
	setup()
end)

script.on_configuration_changed(function()
	setup()
end)

function setup()
	global.keywords = {
		angelsore1  = "angels_refining",
		angelsore2  = "angels_refining",
		angelsore3  = "angels_refining",
		angelsore4  = "angels_refining",
		angelsore5  = "angels_refining",
		angelsore6  = "angels_refining",
		["clowns-ore1"] = "angels_refining",
		["clowns-ore2"] = "angels_refining",
		["clowns-ore3"] = "angels_refining",
		["clowns-ore4"] = "angels_refining",
		["clowns-ore5"] = "angels_refining",
		["clowns-ore6"] = "angels_refining",
		["clowns-ore7"] = "angels_refining",
		copper = "angels_smelting",
		steel = "angels_smelting",
		aluminium = "angels_smelting",
		chrome = "angels_smelting",
		cobalt = "angels_smelting",
		iron = "angels_smelting",
		tin = "angels_smelting",
		lead = "angels_smelting",
		nickel = "angels_smelting",
		titanium = "angels_smelting",
		platinum = "angels_smelting",
		zinc = "angels_smelting",
		silicon = "angels_smelting",
		gold = "angels_smelting",
		silver = "angels_smelting",
		manganese = "angels_smelting",
	}
	global.catSets = {
		angels_refining = {["ore-sorting"]=true, ["ore-sorting-t1"]=true, ["ore-sorting-t2"]=true, ["ore-sorting-t3"]=true, ["ore-sorting-t4"]=true},
		angels_smelting = {["smelting"] = true, ["ore-processing"] = true, ["pellet-pressing"] = true, ["blast-smelting"] = true, ["chemical-smelting"] = true, ["induction-smelting"] = true, ["strand-casting"] = true, ["crusher"] = true, ["smelting"] = true }
	}
	global.last = {}
	global.last.action = ''
	global.last.matches = ''
	global.last.keyword = ''
	global.last.targ_cat = ''
end

--Core Functions
function get_valid_recipes_by_x(results, prod_ing, craft_cats, force_recipes, target_prod_ing)
	for _, each_recipe in pairs(force_recipes) do
		if not string.find(each_recipe.name, "GDIW")
		and not string.find(each_recipe.name, "pyvoid")
		and not string.find(each_recipe.name, "creative")
		and each_recipe.enabled and
		in_array(each_recipe.category, craft_cats) then
			for _, each_ing in pairs(each_recipe[target_prod_ing]) do
				if each_ing.name==prod_ing then
					addUnique(results, each_recipe.name)
				end
			end
		end
	end
	return results
end
function get_valid_recipes_by_product(results, product, craft_cats, force_recipes)
	for _, each_recipe in pairs(force_recipes) do
		if not string.find(each_recipe.name, "GDIW")
		and not string.find(each_recipe.name, "pyvoid")
		and not string.find(each_recipe.name, "creative")
		and each_recipe.enabled and
		in_array(each_recipe.category, craft_cats) then
			for _, each_prod in pairs(each_recipe.products) do
				if each_prod.name==product then
					addUnique(results, each_recipe.name)
				end
			end
		end
	end
	return results
end

---- SUPPORTING FUNCTIONS
function set_next_matches(event)
	local source_recipe = event.source.get_recipe()
	if source_recipe==nil or not event.destination.set_recipe then
		--game.print("no pastyAngels for you")
		return
	end
	
	local target_crafting_categories = game.entity_prototypes[event.destination.name].crafting_categories

	local tests = {}
	for _, result in pairs(source_recipe.products) do
		get_valid_recipes_by_x(tests, result.name, target_crafting_categories, game.players[event.player_index].force.recipes, "ingredient")
	end
	if count(tests) > 0 then
		global.lasts.by = "ing"
	end
	for _, result in pairs(source_recipe.ingredients) do
		get_valid_recipes_by_x(tests, result.name, target_crafting_categories, game.players[event.player_index].force.recipes, "product")
	end
	if count(tests) > 0 then
		global.lasts.by = "prod"
	end
	global.lasts.recipes = tests
end
function get_next_recipe()
	local i = 1
	local recipe
	for each,_ in pairs(global.lasts.recipes) do
		if i == global.lasts.pointer then
			recipe = each
		end
		i = i + 1
	end
		
	--local recipe = global.lasts.recipes[global.lasts.pointer]
	--game.print("pointer: "..global.lasts.pointer.." of "..count(global.lasts.recipes).." recipes")
	
	global.lasts.pointer = global.lasts.pointer + 1
	if global.lasts.pointer > count(global.lasts.recipes) then
		global.lasts.pointer = 1
	end
	--game.print("returning: "..recipe)
	return recipe
end

function get_recipes_matching(keyword, categories, recipes)
	local toRet = {}
	for name,recipe in pairs(recipes) do
		--if recipe.enabled then
			if string.find(name, keyword) then
				if in_array(recipe.category, categories) then
					toRet[#toRet+1] = name
				end
			end
		--end
	end
	return toRet
end

function get_next_from(list, pos)
	if pos==nil then
		return list[1]
	end
	for idx = 1, #list do
		if list[idx] == pos then
			if idx+1 > #list then
				debug.log("over list")
				return list[1]
			else
				return list[idx+1]
			end
		end
	end
end

---- BASE FUNCTIONS
function cycle_next_recipe(event)
	if global.last==nil then
		global.last = {}
		return false
	end
	debug.log("cycling")
	
	if     global.last.copy_unit_number == event.source.unit_number
	   and global.last.paste_unit_number == event.destination.unit_number
	   and global.last.copy_recipe == event.source.get_recipe()
	   then
	   		local recipe = get_next_from(global.last.recipes, global.last.recipe)
	   		event.destination.set_recipe(recipe)
	   		if event.destination.get_recipe() == nil  then
	   			debug.log("why didn't this work?!?")
	   		end
	   		global.last.recipe = recipe
	   		return true
	else
		global.last = {}
		return false
	end
end
function keyword_check(event)
	local source_recipe = event.source.get_recipe()
	local target_crafting_categories = game.entity_prototypes[event.destination.name].crafting_categories
	
	if source_recipe == nil or target_crafting_categories==nil or #target_crafting_categories==0 then
		return false
	end
	for keyword, catset in pairs(global.keywords) do
		if string.find(source_recipe.name, keyword) then
			debug.log("found: "..keyword)
			debug.log("targets: "..serpent.dump(target_crafting_categories))
			local intersect_cats = table.cstm_intersection(global.catSets[global.keywords[keyword]], target_crafting_categories)
			debug.log("tcc: "..serpent.dump(target_crafting_categories))
			debug.log("catSet: "..serpent.dump(global.catSets[global.keywords[keyword]]))
			debug.log("icats: "..serpent.dump(intersect_cats))
			if count(intersect_cats) > 0 then
				local matches = get_recipes_matching(keyword, intersect_cats, game.players[event.player_index].force.recipes)
				debug.log("found recipes: "..serpent.dump(matches))

				global.last.recipe = nil
				global.last.recipes = matches
				global.last.paste_unit_number = event.destination.unit_number
				global.last.copy_unit_number = event.source.unit_number
				global.last.copy_recipe = source_recipe
				cycle_next_recipe(event)
				return true
			else 
				debug.log("no intersect found: ")
			end
		else
			--keyword not found
		end
	end
	return false
end
function brute_check(event)
	debug.log("testing by brute force")
	local source_recipe = event.source.get_recipe()
	local target_crafting_categories = game.entity_prototypes[event.destination.name].crafting_categories
	
	local matches = {}
	for _, result in pairs(source_recipe.products) do
		get_valid_recipes_by_x(matches, result.name, target_crafting_categories, game.players[event.player_index].force.recipes, "ingredients")
	end
	if matches == nil or count(matches) == 0 then
		debug.log("testing by ingredients")
		for _, result in pairs(source_recipe.ingredients) do
			get_valid_recipes_by_x(matches, result.name, target_crafting_categories, game.players[event.player_index].force.recipes, "products")
		end
	end
	debug.log("found recipes: "..serpent.dump(matches))
	if count(matches) == 0 then
		debug.log("no recipes found")
		return false
	end
	debug.log("found "..serpent.dump(matches))
	global.last.recipe = nil
	global.last.recipes = matches
	global.last.paste_unit_number = event.destination.unit_number
	global.last.copy_unit_number = event.source.unit_number
	global.last.copy_recipe = source_recipe
	cycle_next_recipe(event)
end

script.on_event(defines.events.on_entity_settings_pasted, function (event) 
	if  event.source==nil
	or event.source.type~="assembling-machine"
	or event.destination.type~="assembling-machine"
	or event.source.name == event.destination.name then
		--**Allow built-in copy paste action
		global.last = {} -- and clear previous data
		return
	end

	debug.log("source: "..event.source.type)
	
	--local source_recipe = event.source.get_recipe() or
	--debug.log("source: "..source_recipe.name)
	--local target_crafting_categories = game.entity_prototypes[event.destination.name].crafting_categories
	--debug.log("cats: "..serpent.dump(target_crafting_categories))
	--debug.log("type: "..event.destination.type)

	
	if not cycle_next_recipe(event) then
		debug.log("can't cyle")
		if not keyword_check(event) then
			debug.log("no keyword match")
			if not brute_check(event) then
			end
		end
	end
end)

remote.add_interface("category_sets", {
	add_set = function(keywords, link_name, category_list)
		for keyword, _ in pairs(keywords) do
			if global.keywords[keyword] == nil then
				global.keywords[keyword] = link_name	
			else
				debug.log("Add Cat_set skipped keyword: "..keyword.." as it's already used.")
			end
		end
		if global.catSets[link_name] == nil then
			global.catSets[link_name] = {}
		end
		for each_cat,_ in category_list do 
			global.catSets[link_name][each_cat] = true
		end
	end,
	dump_sets = function(which)
		if which==nil then
			debug.log("dump: "..serpent.dump(global.keywords))
		else
			debug.log("dump: "..global.keywords[which])
		end
	end
})