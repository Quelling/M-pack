data:extend(
{
  {
    type = "recipe",
    name = "Pulse-Rifle",
    energy_required = 4,
    enabled = false,
    ingredients =
    {
      {"steel-plate", 60},
	  {"electronic-circuit",1},
      {"arithmetic-combinator", 1},
	  {"red-wire", 1},
	  {"green-wire", 1} 
    },
    result= "Pulse-Rifle"
  },
  {
    type = "recipe",
    name = "Pulse-Rifle-ammo",
    enabled = false,
    energy_required = 4,
    ingredients =
    {
      {"piercing-rounds-magazine", 3},
	  {"coal", 3}
    },
    result = "Pulse-Rifle-ammo"
  }
}
)