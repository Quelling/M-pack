
data:extend(
{
  {
    type = "recipe",
    name = "m40",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"steel-plate", 1},
      {"grenade", 2}, 
    },
    result = "m40"
  },
  {
    type = "recipe",
    name = "flare",
    enabled = true,
    energy_required = 8,
    ingredients =
    {
      {"coal", 4},
      {"stone", 4}, 
    },
    result = "flare"
  }
})
