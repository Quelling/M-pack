require ("prototypes.entity.nade")
data:extend(
{
  {
    type = "capsule",
    name = "m40",
    icon = "__PulseRifle__/graphics/m40-grenade.png",
    icon_size = 32,
	flags = {"goes-to-quickbar"},
    
	capsule_action =
    {
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "m40",
        cooldown = 130,
        projectile_creation_distance = 0.6,
        range = 30,
        sound = nade (),
		ammo_type =
        {
          category = "m40",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "m40",
              starting_speed = 0.9
            }
          }
        }
      }
    },
    subgroup = "capsule",
    order = "a[m40]-a[normal]",
	        
    stack_size = 100,
	},
    {
    type = "capsule",
    name = "flare",
    icon = "__PulseRifle__/graphics/flare.png",
    icon_size = 32,
	flags = {"goes-to-quickbar"},
    capsule_action =
    { 
      type = "throw",
      attack_parameters =
      {
        type = "projectile",
        ammo_category = "capsule",
        cooldown = 30,
        projectile_creation_distance = 0.6,
        range = 25,
		sound =
      {
        {
          filename = "__PulseRifle__/sound/flarebegin.ogg",
          volume = 0.5
        }
      },
		ammo_type =
        {
          category = "capsule",
          target_type = "position",
          action =
          {
            type = "direct",
            action_delivery =
            {
              type = "projectile",
              projectile = "flare",
              starting_speed = 0.1
            }
          }
        }
      }
    },
	subgroup = "capsule",
    order = "a[flare]-a[normal]",
	        
    stack_size = 100, 
  },	
})
