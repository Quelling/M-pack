

data:extend(
{
  {
    type = "gun",
    name = "Pulse-Rifle",
    icon = "__PulseRifle__/graphics/Pulse-Rifle.png",
    icon_size = 256,
    flags = {"goes-to-main-inventory"},
    subgroup = "gun",
    order = "b[Pulse-rifle]-a[military]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "Pulse-Rifle-ammo",
      explosion = "explosion-gunshot",
      cooldown = 6,
      movement_slow_down_factor = 0.456,
      damage_modifier = 1.678,
       shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.036,
        center = {0, 0.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1,
		projectile_creation_distance = 1.125
      },
	  projectile_creation_distance = 1.125,
      range = 22,
      cyclic_sound =
      {
        begin_sound =
        {
          {
		filename = "__PulseRifle__/sound/5.ogg",
        volume = 0.33,
		priority = "high" },
		  {
		filename = "__PulseRifle__/sound/6.ogg",
        volume = 0.33,
		priority = "medium" },
		  {
		filename = "__PulseRifle__/sound/4.ogg",
        volume = 0.33,
		priority = "medium" },
		  {
		filename = "__PulseRifle__/sound/9.ogg",
        volume = 0.33,
		priority = "very-low" },
		  {
		filename = "__PulseRifle__/sound/8.ogg",
        volume = 0.33,
		priority = "medium" 
          }
        },
        middle_sound =
        {
          {
            filename = "__PulseRifle__/sound/shitloop1.ogg",
            volume = 0.35
		  } 	
        },
        end_sound =
        {
          {
            filename = "__PulseRifle__/sound/shitloop1end.ogg",
            volume = 0.2 },
		  {	 
		    filename = "__PulseRifle__/sound/shitloopend2.ogg",
            volume = 0.2 },
		  { 
		    filename = "__PulseRifle__/sound/shitloopend3.ogg",
            volume = 0.2
		  }
		}  
      }
    },
    stack_size = 1
  },
  {
    type = "ammo",
    name = "Pulse-Rifle-ammo",
    icon = "__PulseRifle__/graphics/Pulse-Rifle-Ammo.png",
    icon_size = 256,
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "Pulse-Rifle-ammo",
      target_type = "direction",
      action =
      {
        {
          type = "direct",
          action_delivery = 
          {
            type = "instant",
            source_effects = 
            {
              {
                type = "create-explosion",
                entity_name = "explosion-gunshot"
              }
            }
          }
        },
        {
          type = "direct",
          repeat_count = 1,
          action_delivery =
          {
            type = "projectile",
            projectile = "Pulse-Rifle-Bullet",
            starting_speed = 1,
            direction_deviation = 0.12,
            range_deviation = 0.13,
            max_range = 22,
          }
        }
      }
    },
    magazine_size = 99,
    subgroup = "ammo",
    order = "b[shotgun]-b[piercing]",
    stack_size = 100
  }, 
 }
)