data:extend(
{
  {
    type = "ammo-category",
    name = "Pulse-Rifle-ammo"
  },
  {
    type = "ammo-category",
    name = "flare"
  },
  {
    type = "ammo-category",
    name = "capsule"
  },
  {
    type = "ammo-category",
	name = "m40"
  },
}
)
