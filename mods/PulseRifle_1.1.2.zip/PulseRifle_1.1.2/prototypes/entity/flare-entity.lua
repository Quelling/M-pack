data:extend(
{
    {
        type = "explosion",
        name = "flare-light",
        flags = {"not-on-map"},
        animations =
        {
          {
            filename = "__PulseRifle__/graphics/signal_red.png",
            priority = "extra-high",
            width = 1,
            height = 1,
            frame_count = 1,
            animation_speed = 1/60/26.5,
            shift = {0, 0}
          }
        },
        rotate = false,
        light = {intensity = 0.30, size = 40, color = { r = 120, g = 0.9, b = 0.8,a = 0.0 }},
		
		smoke = "smoke-fast",
        smoke_count = 1,
        smoke_slow_down_factor = 1

  
    },
    {
    type = "smoke-with-trigger",
    name = "flare-entity",
    flags = {"not-on-map"},
    show_when_smoke_off = true,
    cyclic = true,
    duration = 60 * 30,
    fade_away_duration = 2 * 60,
    spread_duration = 10,
	animation =
    {
      filename = "__PulseRifle__/graphics/flare.png",
	  frame_count = 1,
      priority = "extra-high",
      width = 32,
      height = 32,
      scale = .1,
	  color = { r = 60, g = 0.9, b = 0.2, a = 2 },
	 
    },
    slow_down_factor = 0,
    affected_by_wind = false,
    cyclic = true,
    duration = 60 * 19,
    fade_away_duration = 2 * 60,
    spread_duration = 10,
    color = { r = 120, g = 0.9, b = 0.2 },
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
          type = "create-explosion",
          entity_name = "flare-light"
        },
		{
          type = "create-explosion",
          entity_name = "explosion-flash"
        },
      }
    },
    action_frequency = 60
	},
	{
    type = "smoke-with-trigger",
    name = "cloud-cloud",
    flags = {"not-on-map"},
    show_when_smoke_off = true,
	animation =

    {
      filename = "__base__/graphics/entity/cloud/cloud-45-frames.png",
      flags = { "compressed" },
      priority = "extra-high",
      width = 256,
      height = 256,
      frame_count = 45,  
	  line_length = 7, 
	  animation_speed = 420/60/50,
      scale = 3,
    },
    slow_down_factor = 0,
    affected_by_wind = false,
    duration = 60 * 30,
	cyclic = true,
	fade_away_duration = 2 * 40,
    spread_duration = 10,
    color = { r = 130, g = 130, b = 130},
    
	action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        source_effects =
        {
          type = "create-explosion",
          entity_name = "explosion-flash"
        },
      }
    },
	action_frequency = 60
	},
    {
    type = "explosion",
    name = "explosion-flash",
    flags = {"not-on-map"},
	sound =
    {
      {
        filename = "__PulseRifle__/sound/flare4.ogg",
        volume = 0.4
      }
    },
	rotate = true,
	animations =
    {
      {
        filename = "__PulseRifle__/graphics/signal_red.png",
        priority = "extra-high",
        width = 1,
        height = 1,
		scale= 1,
        frame_count =1,
        animation_speed = 1/36/23,
        shift = {0, 0}
    
     
      }
    },
    spread_duration = 20,
	rotate = true,
    light = {intensity = 9, size = 5, color = { r = 120, g = .8, b =.8,a = 0.5 }},
	smoke = "smoke-fast",
    smoke_count = 100,
    smoke_slow_down_factor = 0,
    
 }
})