
data:extend({ 
 {
    type = "projectile",
    name = "Pulse-Rifle-Bullet",
    flags = {"not-on-map"},
    collision_box = {{-0.05, -0.25}, {0.05, 0.25}},
    acceleration = 0,
    direction_only = true,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        {
          type = "damage",
          damage = {amount = 15, type = "physical"}
        }
      }
    },
    animation =
    {
      filename = "__PulseRifle__/graphics/pulseriflebullet.png",
      frame_count = 1,
      width = 3,
      height = 50,
      priority = "high"  
    },
  },
 {
    type = "projectile",
    name = "m40",
    flags = {"not-on-map"},
    acceleration = 0.004,
    action =
    {
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
            type = "create-entity",
            entity_name = "medium-explosion"
            },
            {
            type = "create-entity",
            entity_name = "small-scorchmark",
            check_buildability = true
            }
          }
        }
      },
      {
        type = "area",
        radius = 4,
        action_delivery =
        {
          type = "instant",
          target_effects =
          {
            {
            type = "damage",
            damage = {amount = 50, type = "explosion"}
            },
            {
            type = "create-entity",
            entity_name = "explosion"
            },
          }
        }
      }
    },
    light = {intensity = 0.5, size = 2},
    animation =
    {
      filename = "__PulseRifle__/graphics/m40shot.png",
      frame_count = 1,
      width = 24,
      height = 24,
      priority = "high"
    },
    shadow =
    {
      filename = "__base__/graphics/entity/grenade/grenade-shadow.png",
      frame_count = 1,
      width = 5,
      height = 5,
      priority = "high"
    },
  },
 {
    type = "projectile",
    name = "flare",
    flags = {"not-on-map"},
    acceleration = 0.003,
    action =
    {
      type = "direct",
      action_delivery =
      {
        type = "instant",
        target_effects =
        { 
           {
		     type = "create-entity",
             entity_name = "flare-entity"
		   },
		  
		   {
		     type = "create-entity",
			 entity_name = "flare-light"
		   },
		   {
		     type = "create-entity",
			 entity_name = "explosion-flash"
		   },
		   
           {
		     type = "create-entity",
             entity_name = "cloud-cloud"
		   },
        }
      }
    },
    light = {intensity = 0.30, size = 40, color = { r = 120, g = 0.9, b = 0.8,a = 0.0 }},
    animation =
    {
      filename = "__PulseRifle__/graphics/flare.png",
      frame_count = 1,
      scale = .6,
	  width = 10,
      height = 10,
      priority = "high"
    },
	
         smoke = capsule_smoke,
  }
})