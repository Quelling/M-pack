
function nade(volume)
    return
    {
      {
        filename = "__PulseRifle__/sound/m40.ogg",
        volume = 0.45
      },
      {
        filename = "__PulseRifle__/sound/m401.ogg",
        volume = 0.45
      },
      {
        filename = "__PulseRifle__/sound/m402.ogg",
        volume = 0.45
      }
    }
end



