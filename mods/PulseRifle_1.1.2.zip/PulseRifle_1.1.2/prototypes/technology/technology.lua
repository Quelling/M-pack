data:extend(
{
  {
    type = "technology",
    name = "Weyland-Yutani-Armory",
    icon = "__PulseRifle__/graphics/Pulse-Rifle2.png",
    icon_size = 256,
    prerequisites=
		{
		"circuit-network",
		"military-2"
		},
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "Pulse-Rifle"
      },
      {
        type = "unlock-recipe",
        recipe = "flare"
	  },	
	  {
        type = "unlock-recipe",
        recipe = "Pulse-Rifle-ammo"
	  },	
      {	 
	    type = "unlock-recipe",
        recipe = "m40"
	  }	
    },
    unit =
    {
      count = 100,
      ingredients = 
	  {
	    {"science-pack-1", 1},
        {"science-pack-2", 2}
      },
	  time = 15
    },
    order = "c-a"
   },
  }
)