for i, force in pairs(game.forces) do 
 force.reset_recipes()
end

for i, force in pairs(game.forces) do 
 force.reset_technologies()
end

for i, force in pairs(game.forces) do 
 if force.technologies["circuit-network"].researched then 
   force.recipes["Weyland-Yutani-Armory"].enabled = true
 end
end