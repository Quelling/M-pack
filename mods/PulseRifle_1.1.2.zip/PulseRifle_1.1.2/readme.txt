Hello
***Meant to be played with enemy mods but not necessary (bobs enemies, scary nights, rampant)****
I wanted a weapon that could range attack enemy bases without completely getting swarmed and annihilated. The Gun will probably be super OP without those mods....For me super Op takes the fun out, for others super OP is fun so this could work out for both sides with the correct mods."))

Seems like the Pulse Rifle is Modded into every game at some point down the years. Im hoping I am the first for factorio but its doubtful. Anyways this is my first crack at creating a mod. It took longer than I expected. the most challenging part was trying to find sounds for the gun (I apologize if the sounds are not the greatest) Most came from movie rips and AVP games...thx for those FOX. I even tried creating my own with a machine gun a flanger and compressor but had no luck ( made some pretty cool sounds though)

I kinda really love the alien franchise and I feel that elements of factorio (and generally most sci-fi creations) are borrowed from this franchise. Lets face it Aliens is Badass. So that being said I want to create more movie props for the game. Items such as APC, Dropship, Power loader, Smart gun, mini sentrys, motion tracker and maybe even ALiens themselves ( I doubt I would be prepared to create something like that but if anyone wants to work together im down)..I do have a life cycle idea though.

Anyways I need feedback. First Mod so id like to what you think I should add or change... Some how and some time id like to make it fire its own grenade(like the movie) and maybe add tech to make the "WEAVER" Pulse rifle with flamethrower attached.

creds go to fox for sounds and franchise
pepedrage on https://sketchfab.com/models/70201c6c5c024b418110903c5bfa4046 for his beautiful pulse rifle model
Mod author-Smitherino --Firearmsplus modder---if it wernt for your script id have not been able to get started on this. You where my guide and you didn't even know it. I didn't borrow any assets or anything like that I needed a reference to get started.
Yuoki tani for his c4d tutorials on modeling 
And of course Factorio crew for factorio
