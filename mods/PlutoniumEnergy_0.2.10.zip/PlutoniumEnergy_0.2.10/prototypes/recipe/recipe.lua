data:extend({
	{
		type = "recipe",
		name = "pluto-centrifuge",
		energy_required = 4,
		enabled = false,
		ingredients =
		{
			{"concrete", 120},
			{"steel-plate", 70},
			{"advanced-circuit", 110},
			{"iron-gear-wheel", 110},
		},
		result = "pluto-centrifuge",
		requester_paste_multiplier= 2
	},
	
	{
		type = "recipe",
		name = "plutonium-fuel-reprocessing",
		energy_required = 50,
		enabled = false,
		category = "pluto-centrifuging",
		ingredients =
			{
				{"used-up-plutonium-fuel-cell", 5}
			},
		icon = "__PlutoniumEnergy__/graphics/icons/plutonium-fuel-reprocessing.png",
		icon_size = 32,
		subgroup = "intermediate-product",
		order = "r[plutonium-processing]-b[plutonium-fuel-reprocessing]",
		main_product = "",
		results =
			{
				{
					name = "plutonium-238",
					amount = 3
				}
			},
		allow_decomposition = false
	},
	
	{
		type = "recipe",
		name = "plutonium-fuel-cell",
		energy_required = 10,
		enabled = false,
		ingredients =
			{
				{"iron-plate", 10},
				{"plutonium-239", 1},
				{"plutonium-238", 19}
			},
		result = "plutonium-fuel-cell",
		result_count = 10
	},
	
	{
		type = "recipe",
		name = "JohnTheCF-enrichment-process",
		energy_required = 50,
		enabled = false,
		category = "pluto-centrifuging",
		ingredients = {{"plutonium-239", 40}, {"plutonium-238", 5}},
		icon = "__PlutoniumEnergy__/graphics/icons/JohnTheCF-enrichment-process.png",
		icon_size = 32,
		subgroup = "intermediate-product",
		order = "r[plutonium-processing]-c[JohnTheCF-enrichment-process]",
		main_product = "",
		results =
		{
				{
					name = "plutonium-239",
					amount = 41
				},
				{
					name = "plutonium-238",
					amount = 2
				}
		},
		allow_decomposition = false
	},
	
	{
    type = "recipe",
    name = "plutonium-processing",
    energy_required = 10,
    enabled = false,
    category = "pluto-centrifuging",
    ingredients = {{"raw-plutonium", 10}},
    icon = "__PlutoniumEnergy__/graphics/icons/plutonium-processing.png",
	icon_size = 32,
    subgroup = "raw-material",
    order = "h[plutonium-processing]",
    results =
    {
      {
        name = "plutonium-239",
        probability = 0.007,
        amount = 1
      },
      {
        name = "plutonium-238",
        probability = 0.993,
        amount = 1
      }
    }
  },
})