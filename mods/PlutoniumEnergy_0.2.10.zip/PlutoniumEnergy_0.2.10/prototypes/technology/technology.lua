data:extend({
	{
		type = "technology",
		name = "plutonium-nuclear-power",
		icon = "__PlutoniumEnergy__/graphics/technology/plutonium-nuclear-power.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "plutonium-fuel-cell"
			},
			{
				type = "unlock-recipe",
				recipe = "plutonium-processing"
			},
			{
				type = "unlock-recipe",
				recipe = "pluto-centrifuge"
			},
		},
		prerequisites = {"nuclear-power"},
		unit =
		{
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 25,
			count = 1200
		},
		order = "c-a"
	},
	
  {
    type = "technology",
    name = "JohnTheCF-enrichment-process",
    icon = "__PlutoniumEnergy__/graphics/technology/JohnTheCF-enrichment-process.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "JohnTheCF-enrichment-process"
      }
    },
    prerequisites = {"plutonium-nuclear-power", "kovarex-enrichment-process"},
    unit =
    {
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 2},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        {"high-tech-science-pack", 1}
      },
      time = 30,
      count = 1600
    },
    order = "e-p-b-c"
  },
  
  {
		type = "technology",
		name = "plutonium-fuel-reprocessing",
		icon = "__PlutoniumEnergy__/graphics/technology/plutonium-fuel-reprocessing.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "plutonium-fuel-reprocessing"
			},
		},
		prerequisites = {"plutonium-nuclear-power"},
		unit =
		{
			ingredients =
			{
				{"science-pack-1", 2},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 27,
			count = 1250
		},
		order = "c-a"
	},
})