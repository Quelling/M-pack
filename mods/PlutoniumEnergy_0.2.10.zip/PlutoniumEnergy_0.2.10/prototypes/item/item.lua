--integration
if not mods["Advanced-Atomics"] then
	data:extend({
	{
		type = "item",
		name = "plutonium-239",
		icon = "__PlutoniumEnergy__/graphics/icons/plutonium-239.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "g[plutonium-239]",
		stack_size = 100
	},
	})
end
data:extend({
	--machines
	{
		type = "item",
		name = "pluto-centrifuge",
		icon = "__PlutoniumEnergy__/graphics/icons/pluto-centrifuge.png",
		icon_size = 32,
		flags = {"goes-to-quickbar"},
		subgroup = "production-machine",
		order = "g[pluto-centrifuge]",
		place_result = "pluto-centrifuge",
		stack_size = 50
	},
	--resources
	{
		type = "item",
		name = "raw-plutonium",
		icon = "__PlutoniumEnergy__/graphics/icons/raw-plutonium.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "raw-resource",
		order = "g[raw-plutonium]",
		stack_size = 50
	},
	
	{
		type = "item",
		name = "plutonium-238",
		icon = "__PlutoniumEnergy__/graphics/icons/plutonium-238.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "g[plutonium-238]",
		stack_size = 100
	},
	--Cells
	{
		type = "item",
		name = "plutonium-fuel-cell",
		icon = "__PlutoniumEnergy__/graphics/icons/plutonium-fuel-cell.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "r[plutonium-processing]-a[plutonium-fuel-cell]",
		fuel_category = "nuclear",
		burnt_result = "used-up-plutonium-fuel-cell",
		fuel_value = "12GJ",
		stack_size = 50
	},
	
	{
		type = "item",
		name = "used-up-plutonium-fuel-cell",
		icon = "__PlutoniumEnergy__/graphics/icons/used-up-plutonium-fuel-cell.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		subgroup = "intermediate-product",
		order = "i[used-up-plutonium-fuel-cell]",
		stack_size = 50
	},
})