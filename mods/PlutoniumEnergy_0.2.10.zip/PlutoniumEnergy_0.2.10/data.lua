require("prototypes.category.recipe-category")
require("prototypes.item.item")
require("prototypes.recipe.recipe")
require("prototypes.technology.technology")
require("prototypes.entity.entity")

data.raw["recipe"]["nuclear-fuel-reprocessing"].results =
    {
      {
        name = "uranium-238",
        amount = 3
      },
	  {
		name = "raw-plutonium",
		amount = 1
	  }
    }