require "prototypes.entity.pump"
require "prototypes.entity.rail"
require "prototypes.entity.railloader"
require "prototypes.entity.railunloader"

require "prototypes.item.pump"
require "prototypes.item.railloader"
require "prototypes.item.railunloader"

require "prototypes.recipe.railloader"
require "prototypes.recipe.railunloader"

require "prototypes.technology.railloader"

require "prototypes.signal"