local loader_pump = util.table.deepcopy(data.raw.pump.pump)
loader_pump.name = "railpump-loader"
loader_pump.minable.result = "railpump-loader"
-- loader_pump.fluid_box.pipe_connections = {
  -- { position = {0, -1.5}, type="output" },
  -- { position = {-1, 0.5}, type="input" },
  -- { position = {1, 0.5}, type="input" },
-- }

local unloader_pump = util.table.deepcopy(data.raw.pump.pump)
unloader_pump.name = "railpump-unloader"
unloader_pump.minable.result = "railpump-unloader"
-- unloader_pump.collision_box = {{-0.29, -0.79}, {0.29, 0.79}}
-- unloader_pump.fluid_box.pipe_connections = {
  -- { position = {0, -1.5}, type="input" },
  -- { position = {-1, 0.5}, type="output" },
  -- { position = {1, 0.5}, type="output" },
-- }

data:extend{loader_pump, unloader_pump}