data:extend{

  {
    type = "item",
    name = "railpump-loader",
    icon = "__base__/graphics/icons/pump.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "b[pipe]-c[pump]",
    place_result = "railpump-loader",
    stack_size = 50
  },
  {
    type = "item",
    name = "railpump-unloader",
    icon = "__base__/graphics/icons/pump.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "b[pipe]-c[pump]",
    place_result = "railpump-unloader",
    stack_size = 50
  },
}