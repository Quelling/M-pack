data:extend({
	{
		type = "recipe",
		name = "scattergun-turret",
		enabled = false,
		energy_required = 20,
		ingredients = {{"stone-brick", 10},{"iron-plate", 10},{"bronze-alloy", 15},{"iron-gear-wheel", 10}},
    		results = {{type="item", name="scattergun-turret", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/scattergun-turret.png",
    		icon_size = 32,
	},

	{
		type = "recipe",
		name = "w93-modular-turret-base",
		enabled = false,
		energy_required = 10,
		ingredients = {{"stone-brick", 15},{"steel-plate", 8},{"engine-unit", 1}},
    		results = {{type="item", name="w93-modular-turret-base", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-turret-base.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-turret2-base",
		enabled = false,
		energy_required = 10,
		ingredients = {{"concrete", 25},{"plastic-bar", 20},{"electric-engine-unit", 1},{"processing-unit", 2}},
    		results = {{type="item", name="w93-modular-turret2-base", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-turret2-base.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-hmg",
		enabled = false,
		energy_required = 10,
		ingredients = {{"tin-plate", 6},{"electronic-circuit", 1},{"steel-gear-wheel", 2}},
    		results = {{type="item", name="w93-modular-gun-hmg", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-hmg.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-gatling",
		enabled = false,
		energy_required = 10,
		ingredients = {{"iron-stick", 12},{"bronze-alloy", 8},{"advanced-circuit", 2},{"electric-engine-unit", 1}},
    		results = {{type="item", name="w93-modular-gun-gatling", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-gatling.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-lcannon",
		enabled = false,
		energy_required = 10,
		ingredients = {{"bronze-alloy", 5},{"steel-plate", 4}, {"advanced-circuit", 1},
{"steel-gear-wheel", 4}},
    		results = {{type="item", name="w93-modular-gun-lcannon", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-lcannon.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-hcannon",
		category = "crafting-with-fluid",
		enabled = false,
		energy_required = 10,
		ingredients = {{"copper-tungsten-alloy", 10},{"tungsten-carbide", 12}, {"processing-unit", 1}, {type="fluid", name="lubricant", amount=50}
},
    		results = {{type="item", name="w93-modular-gun-hcannon", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-hcannon.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-rocket",
		enabled = false,
		energy_required = 10,
		ingredients = {{"titanium-plate", 5}, {"advanced-circuit", 2},{"rocket-launcher", 2}},
    		results = {{type="item", name="w93-modular-gun-rocket", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-rocket.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-tlaser",
		enabled = false,
		energy_required = 10,
		ingredients = {{"plastic-bar", 8},{"tungsten-carbide", 2}, {"processing-unit", 2},{"silver-zinc-battery", 10}},
    		results = {{type="item", name="w93-modular-gun-tlaser", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-tlaser.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-beam",
		enabled = false,
		energy_required = 10,
		ingredients = {{"uranium-fuel-cell", 1},{"small-lamp",1},{"low-density-structure", 1},{"poison-capsule", 1}, {"processing-unit", 2},{"silver-zinc-battery", 8}},
    		results = {{type="item", name="w93-modular-gun-beam", amount=1}},
		icon = "__scattergun_turret__/graphics/icons/modular-gun-beam.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-radar",

		enabled = false,
		energy_required = 10,
		ingredients =
 {{"copper-tungsten-alloy", 10},{"effectivity-module-2", 1},{"tungsten-gear-wheel", 10}},
		result = "w93-modular-gun-radar",
		icon = "__scattergun_turret__/graphics/icons/modular-gun-radar.png",
    		icon_size = 64,
	},
	{
		type = "recipe",
		name = "w93-modular-gun-radar2",

		enabled = false,
		energy_required = 10,
		ingredients =
 {{"copper-tungsten-alloy", 15},{"iron-stick", 10},{"speed-module-2", 1},{"tungsten-gear-wheel", 5}},
		result = "w93-modular-gun-radar2",
		icon = "__scattergun_turret__/graphics/icons/modular-gun-radar2.png",
    		icon_size = 64,
	},

	{
		type = "recipe",
		name = "w93-turret-light-cannon-shells",

		enabled = false,
		energy_required = 10,
		ingredients =
 {{"copper-plate", 10}, {"lead-plate", 10}},
		result = "w93-turret-light-cannon-shells",
		icon = "__scattergun_turret__/graphics/icons/turret-light-cannon-shells.png",
    		icon_size = 32,
	},
	{
		type = "recipe",
		name = "w93-turret-cannon-shells",

		normal =

		{
			enabled = false,
			energy_required = 10,
			ingredients =
 {{"tungsten-plate", 10}, {"plastic-bar", 10}, {"explosives", 20}},
			result = "w93-turret-cannon-shells",
		},
		expensive =

		{

			enabled = false,
			energy_required = 10,
			ingredients =
 {
{"tungsten-plate", 20},
 {"plastic-bar", 20},
 {"explosives", 40}
},
			result = "w93-turret-cannon-shells",
		},
		icon = "__scattergun_turret__/graphics/icons/turret-cannon-shells.png",
    		icon_size = 32,
	}
})