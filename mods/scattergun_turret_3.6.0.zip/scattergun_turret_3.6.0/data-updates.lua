if bobmods and bobmods.plates then
	require("prototypes.recipes.recipes-entity-bobs")
	require("prototypes.technology.technology-bobs")
end