--Define if logistic is installed
trains = true --Default: True