# Multi-Product Recipe Details
Mod for Factorio  
### Description
Displays the list of all product names in recipe description if there are more than one product in the recipe.  
Becomes quite useful when recipes get rather complex (like in Angel's PetroChemical or Py's CoalProcessing) so you don't have to guess recipe output only by product icons.  
