data:extend(
    {
        {
            type = "bool-setting",
            name = "mprd-vertical-display",
            setting_type = "startup",
            default_value = false,
        },
        {
            type = "bool-setting",
            name = "mprd-amount-display",
            setting_type = "startup",
            default_value = false,
        },
    }
)
