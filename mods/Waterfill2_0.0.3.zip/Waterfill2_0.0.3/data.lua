data:extend({
    {
        type = "item", 
        name = "waterfill", 
        icon = "__Waterfill2__/graphics/icons/waterfill.png", 
        icon_size = 32, 
        flags = {"goes-to-main-inventory"}, 
        subgroup = "terrain", 
        order = "c[landfill]-a[dirt]", 
        stack_size = 100, 
        
        place_as_tile = {
            result = "water", 
            condition_size = 1, 
            condition = {"water-tile"}
        }
        
    }, 
    {
        type = "recipe", 
        name = "waterfill", 
        energy_required = 0.5, 
        enabled = false, 
        category = "crafting", 
        ingredients = { {"iron-axe", 1} }, 
        result = "waterfill", 
        result_count = 25
    }, 
    {
        type = "technology", 
        name = "waterfill", 
        icon_size = 32, 
        icon = "__Waterfill2__/graphics/icons/water.png", 
        unit = {
            count = 25, 
            ingredients = {
                {"science-pack-1", 1}, {"science-pack-2", 1}
            }, 
            time = 30
        }, 
        effects = {
            { type = "unlock-recipe", recipe = "waterfill" }
        }, 
        order = "b-d"
    }
})