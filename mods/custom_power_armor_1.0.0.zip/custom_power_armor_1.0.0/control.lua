-- Based on ARMOR POCKETS script

-- Placed Equipment
script.on_event(defines.events.on_player_placed_equipment, function(event)

	local player = game.players[event.player_index]    
	local inventorySlots = player.character_inventory_slots_bonus
	local trashSlots = player.character_trash_slot_count_bonus
	local miningSpeed = player.character_mining_speed_modifier

	-- check if we are adding an armor pocket
    if event.equipment.name == "mk2-heavy-exoskeleton" then

		-- add the inventory bonus
		player.character_inventory_slots_bonus = inventorySlots + 50
		player.character_trash_slot_count_bonus = trashSlots + 3
    	player.character_mining_speed_modifier = miningSpeed + 1
		
    	-- log the inventory slot count to console
		--log_inventory_slot_count(player)
		--log_trash_slot_count(player)
		--log_mining_speed_modifier(player)

    end
end
)

-- Removed Equipment
script.on_event(defines.events.on_player_removed_equipment, function(event)
 
 	local player = game.players[event.player_index]
	local inventory_slots_bonus = player.character_inventory_slots_bonus
    local trash_slots_bonus = player.character_trash_slot_count_bonus
	local mining_speed_modifier = player.character_mining_speed_modifier

	-- check if we are removing an armor pocket
  	if event.equipment == "mk2-heavy-exoskeleton" then

  		if event.count >= 0 then

	  		local slotCount = inventory_slots_bonus - (50 * event.count)
			local trashCount = trash_slots_bonus - (3 * event.count)
			local msCount = mining_speed_modifier - (1 * event.count)
			
	  		if slotCount >= 0 then
		  		-- subtract the inventory bonus multiplied by the number of equipment items removed
				inventory_slots_bonus = slotCount

				-- set the player's inventory slot bonus count
				player.character_inventory_slots_bonus = inventory_slots_bonus
			end
			
			if trashCount >= 0 then
			trash_slots_bonus = trashCount
			player.character_trash_slot_count_bonus = trash_slots_bonus
			end
			
			if msCount >= 0 then
			mining_speed_modifier = msCount
			player.character_mining_speed_modifier = mining_speed_modifier
			
		end
    	-- log the inventory slot count to console
		--log_inventory_slot_count(player)
		--log_trash_slot_count(player)
		--log_mining_speed_modifier(player)
	end
end
end
)

-- Changed Armor
script.on_event(defines.events.on_player_armor_inventory_changed, function(event)
 
  	local player = game.players[event.player_index]
	local armor = player.get_inventory(defines.inventory.player_armor)
	
	-- check if an armor is equiped, before we do anything
	-- else we set the players inventory bonus count to zero
	if not armor.is_empty() then
		
		local total_slots = 0
		local total_trash = 0
		local total_ms = 0
				
		local grid =  armor[1].grid

		-- check if the armor has a grid
		if grid ~= nil then

			-- loop through the equipment in the grid
			for i = 1, #grid.equipment do
			
				-- if the equipment item at index is a pocket, we add bonus slots to the total
				if grid.equipment[i].name == "mk2-heavy-exoskeleton" then
					total_slots = total_slots + 50
					total_trash = total_trash + 3
					total_ms = total_ms + 1
				end

			end

			--set_inventory(player, total_slots, total_trash, total_ms)
			set_inventory1(player, total_slots)
            set_inventory2(player, total_trash)
			set_inventory3(player, total_ms)
		else
			clear_bonuses(player)			

		end	

	else
		clear_bonuses(player)
	end

	-- log the inventory slot count to console
	--log_inventory_slot_count(player)
	--log_trash_slot_count(player)
	--log_mining_speed_modifier(player)
end
)

function clear_bonuses(player)

	player.character_inventory_slots_bonus = 0
	player.character_trash_slot_count_bonus = 0
	player.character_mining_speed_modifier = 0

end

function set_inventory1(player, count)
	-- set the player's inventory slot bonus count to total_slots
	player.character_inventory_slots_bonus = count
end

function set_inventory2(player, count)
	player.character_trash_slot_count_bonus = count
	
end

function set_inventory3(player, count)
	player.character_mining_speed_modifier = count
	
end

function log_inventory_slot_count(player)
	player.print("Bonus inventory slots: +" .. player.character_inventory_slots_bonus)	
end

function log_trash_slot_count(player)
	player.print("Bonus logistic trash slots: +" .. player.character_trash_slot_count_bonus)	
end

function log_mining_speed_modifier(player)
	player.print("Bonus manual mining speed: +" .. player.character_mining_speed_modifier)	
end