require("prototypes.equipment")
require("prototypes.equipment-grid")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.laser-defense-upgradable")
require("prototypes.technology")


-- TEST AREA --
--[[

if Nohomoto_industries then custom_power_armor = {} end

-- Detectability and tables by Corvus Corax 
if not PaA then
  PaA={}
end

require("prototypes.equipment")
require("prototypes.equipment-grid")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.laser-defense-upgradable")
if PaA.Nohomoto_industries then
require("prototypes.technology1")
else
require("prototypes.technology")
end


--Hiding stuff if Nohomoto_industries is active. Code by Corvus Corax 
PaA.hider={}

if PaA.Nohomoto_industries then
	PaA.hider.equipment={"goes-to-main-inventory", "hidden"}
else
	PaA.hider.equipment={"goes-to-main-inventory"}
end

data.raw["armor"]["mk3-destroyer-power-armor"].flags=PaA.hider.equipment
data.raw["armor"]["mk4-exterminator-power-armor"].flags=PaA.hider.equipment
data.raw["armor"]["mk5-annihilator-power-armor"].flags=PaA.hider.equipment
data.raw["item"]["shield-mk3"].flags=PaA.hider.equipment
data.raw["item"]["shield-mk4"].flags=PaA.hider.equipment
data.raw["item"]["overhcarged-fusion-reactor"].flags=PaA.hider.equipment
data.raw["item"]["energy-cell"].flags=PaA.hider.equipment
data.raw["item"]["mk2-heavy-exoskeleton"].flags=PaA.hider.equipment
data.raw["item"]["mk2-fast-exoskeleton"].flags=PaA.hider.equipment
data.raw["item"]["personal-laser-minigun"].flags=PaA.hider.equipment
data.raw["item"]["personal-rocket-defence"].flags=PaA.hider.equipment
]]
