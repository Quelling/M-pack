data:extend({
	{
		type = "bool-setting",
		name = "custom-pld-upgrades",
		setting_type = "startup",
		default_value = false,
	},
})

