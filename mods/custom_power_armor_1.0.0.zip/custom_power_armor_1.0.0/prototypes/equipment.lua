data:extend({
	{
		type = "generator-equipment",
		name = "overhcarged-fusion-reactor",
		sprite =
	{
			filename = "__custom_power_armor__/graphics/equipment/overhcarged_fusion_reactor.png",
			width = 128,
			height = 128,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 4,
			height = 4,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "primary-output"
		},
		power = "1.5MW"
	},
    {
    type = "energy-shield-equipment",
    name = "shield-mk3",
    sprite =
    {
      filename = "__custom_power_armor__/graphics/equipment/shield_mk3.png",
			width = 64,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		max_shield_value = 300,
		energy_source =
		{
			type = "electric",
			buffer_capacity = "240kJ",
			input_flow_limit = "480kW",
			usage_priority = "primary-input"
		},
		energy_per_shield = "40kJ"
	},
    {
    type = "energy-shield-equipment",
    name = "shield-mk4",
    sprite =
    {
      filename = "__custom_power_armor__/graphics/equipment/shield_mk4.png",
			width = 64,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		max_shield_value = 500,
		energy_source =
		{
			type = "electric",
			buffer_capacity = "300kJ",
			input_flow_limit = "600kW",
			usage_priority = "primary-input"
		},
		energy_per_shield = "50kJ"
	},
	{
		type = "movement-bonus-equipment",
		name = "mk2-heavy-exoskeleton",
		sprite = 
		{
			filename = "__custom_power_armor__/graphics/equipment/mk2_heavy_exoskeleton.png",
			width = 64,
			height = 128,
			priority = "medium"
		},
		shape =
		{
			width = 2,
			height = 4,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_consumption = "375kW",
		movement_bonus = 0.4,
		categories = {"armor"}
	},
	{
		type = "movement-bonus-equipment",
		name = "mk2-fast-exoskeleton",
		sprite = 
		{
			filename = "__custom_power_armor__/graphics/equipment/mk2_fast_exoskeleton.png",
			width = 64,
			height = 128,
			priority = "medium"
		},
		shape =
		{
			width = 2,
			height = 4,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_consumption = "375kW",
		movement_bonus = 0.8,
		categories = {"armor"}
	},	
  {
    type = "battery-equipment",
    name = "energy-cell",
    sprite =
    {
      filename = "__custom_power_armor__/graphics/equipment/energy_cell.png",
      width = 64,
      height = 64,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
	categories = {"armor"},
    energy_source =
    {
      type = "electric",
      buffer_capacity = "1GJ",
      input_flow_limit = "10GW",
      output_flow_limit = "10GW",
      usage_priority = "terciary"
    },
   },
	{
		type = "active-defense-equipment",
		name = "personal-laser-minigun",
		sprite =
		{
			filename = "__custom_power_armor__/graphics/equipment/personal_laser_minigun.png",
			width = 64,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input",
			buffer_capacity = "200kJ"
		},
		attack_parameters =
		{
			type = "projectile",
			ammo_category = "electric",
			cooldown = 6.6,
			damage_modifier = 10,
			projectile_center = {0, 0},
			projectile_creation_distance = 0.6,
			range = 15,
			sound =
      {
        {
          filename = "__custom_power_armor__/sound/GatlingLaser_BurstShot_2.ogg",
          volume = 1.0
        }
      },
			ammo_type =
			{
				type = "projectile",
				category = "electric",
				energy_consumption = "100kJ",
				projectile = "laser",
				speed = 2,
				action =
				{
					{
						type = "direct",
						action_delivery =
						{
							{
								type = "projectile",
								projectile = "laser",
								starting_speed = 0.28
							}
						}
					}
				}
			}
		},
	automatic = true
	},
  {
    type = "active-defense-equipment",
    name = "personal-rocket-defence",
    sprite =
    {
      filename = "__custom_power_armor__/graphics/equipment/personal_rocket_defence.png",
      width = 96,
      height = 96,
      priority = "medium"
    },
    shape =
    {
      width = 3,
      height = 3,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      buffer_capacity = "330kJ"
    },
	
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "rocket",
      cooldown = 60,
	  movement_slow_down_factor = 0.8,
      damage_modifier = 1,
      projectile_center = {-0.17, 0},
      projectile_creation_distance = 0.6,
      range = 30,
      sound =
      {
        {
          filename = "__base__/sound/fight/rocket-launcher.ogg",
          volume = 0.7
        }
      },
	  ammo_type =
      {
        type = "projectile",
        category = "rocket",
        energy_consumption = "300kJ",
        projectile = "explosive-rocket",
        speed = 1,
        action =
        {
          {
            type = "direct",
            action_delivery =
            {
              {
                type = "projectile",
				--projectile = "rocket",
                projectile = "explosive-rocket",
                starting_speed = 0.28
              }
            }
          }
        }
      }
    },
	
    automatic = true,
    categories = {"armor"}
  }
}
)