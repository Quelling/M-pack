data:extend(
 {
  {
	type = "equipment-grid",
	name = "mk3-destroyer-grid",
	width = 12,
	height = 12,
	equipment_categories = {"armor"}
  },
  {
	type = "equipment-grid",
	name = "mk4-exterminator-grid",
	width = 14,
	height = 14,
	equipment_categories = {"armor"}
  },
  {
	type = "equipment-grid",
	name = "mk5-annihilator-grid",
	width = 16,
	height = 16,
	equipment_categories = {"armor"}
  }
 }
)