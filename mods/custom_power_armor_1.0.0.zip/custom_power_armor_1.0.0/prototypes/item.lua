--Fix for armor animations
for _, animation in ipairs(data.raw["player"]["player"]["animations"]) do
  if animation.armors then
    for _, armor in ipairs(animation.armors) do
      if armor == "power-armor-mk2" then
        animation.armors[#animation.armors + 1] = "mk3-destroyer-power-armor"
		animation.armors[#animation.armors + 1] = "mk4-exterminator-power-armor"
		animation.armors[#animation.armors + 1] = "mk5-annihilator-power-armor"
        break
      end
    end
  end
end

data:extend(
{
	{
		type = "armor",
		name = "mk3-destroyer-power-armor",
		icon = "__custom_power_armor__/graphics/icons/mk3_destroyer.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		resistances = 
		{
			{
				type = "physical",
				decrease = 10,
				percent = 50
			},
			{
				type = "acid",
				decrease = 10,
				percent = 50
			},
			{
				type = "explosion",
				decrease = 30,
				percent = 50
			},
			{
				type = "fire",
				decrease = 10,
				percent = 50
			}
		},
		durability = 30000,
		subgroup = "armor",
		order = "f[custom-power-armor-mk3]",
		stack_size = 1,
		equipment_grid = "mk3-destroyer-grid",
		inventory_size_bonus = 40
	},
	{
		type = "armor",
		name = "mk4-exterminator-power-armor",
		icon = "__custom_power_armor__/graphics/icons/mk4_exterminator.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		resistances = 
		{
			{
				type = "physical",
				decrease = 15,
				percent = 55
			},
			{
				type = "acid",
				decrease = 15,
				percent = 55
			},
			{
				type = "explosion",
				decrease = 40,
				percent = 55
			},
			{
				type = "fire",
				decrease = 10,
				percent = 80
			},
		},
		durability = 40000,
		subgroup = "armor",
		order = "f[custom-power-armor-mk3]",
		stack_size = 1,
		equipment_grid = "mk4-exterminator-grid",
		inventory_size_bonus = 40
	},
	{
		type = "armor",
		name = "mk5-annihilator-power-armor",
		icon = "__custom_power_armor__/graphics/icons/mk5_annihilator.png",
		icon_size = 32,
		flags = {"goes-to-main-inventory"},
		resistances = 
		{
			{
				type = "physical",
				decrease = 20,
				percent = 60
			},
			{
				type = "acid",
				decrease = 20,
				percent = 60
			},
			{
				type = "explosion",
				decrease = 50,
				percent = 60
			},
			{
				type = "fire",
				decrease = 10,
				percent = 95
			},
		},
		durability = 50000,
		subgroup = "armor",
		order = "f[custom-power-armor-mk3]",
		stack_size = 1,
		equipment_grid = "mk5-annihilator-grid",
		inventory_size_bonus = 40
	},
  {
    type = "item",
    name = "shield-mk3",
    icon = "__custom_power_armor__/graphics/icons/shield_mk3.png",
	icon_size = 32,
    placed_as_equipment_result = "shield-mk3",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "b[shield]-b[energy-shield-mk2-equipment]",
    stack_size = 50,
    default_request_amount = 10
  },
  {
    type = "item",
    name = "shield-mk4",
    icon = "__custom_power_armor__/graphics/icons/shield_mk4.png",
	icon_size = 32,
    placed_as_equipment_result = "shield-mk4",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "b[shield]-b[energy-shield-mk2-equipment]",
    stack_size = 50,
    default_request_amount = 10
  },
  {
		type = "item",
		name = "overhcarged-fusion-reactor",
		icon = "__custom_power_armor__/graphics/icons/overhcarged_fusion_reactor.png",
		icon_size = 32,
		placed_as_equipment_result = "overhcarged-fusion-reactor",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "a[energy-source]-b[fusion-reactor]",
		stack_size = 50,
		default_request_amount = 10
  },
  {
		type = "item",
		name = "energy-cell",
		icon = "__custom_power_armor__/graphics/icons/energy_cell.png",
		icon_size = 32,
		placed_as_equipment_result = "energy-cell",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "c[battery]-b[battery-mk2-equipment]",
		stack_size = 50,
		default_request_amount = 10
	},
		{
		type = "item",
		name = "mk2-heavy-exoskeleton",
		icon = "__custom_power_armor__/graphics/icons/mk2_heavy_exoskeleton.png",
		icon_size = 32,
		placed_as_equipment_result = "mk2-heavy-exoskeleton",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "e[exoskeleton]-a[exoskeleton-equipment]",
		stack_size = 50,
		default_request_amount = 10
	},
		{
		type = "item",
		name = "mk2-fast-exoskeleton",
		icon = "__custom_power_armor__/graphics/icons/mk2_fast_exoskeleton.png",
		icon_size = 32,
		placed_as_equipment_result = "mk2-fast-exoskeleton",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "e[exoskeleton]-a[exoskeleton-equipment]",
		stack_size = 50,
		default_request_amount = 10
	},
	{
		type = "item",
		name = "personal-laser-minigun",
		icon = "__custom_power_armor__/graphics/icons/personal_laser_minigun.png",
		icon_size = 32,
		placed_as_equipment_result = "personal-laser-minigun",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "d[active-defense]-a[personal-laser-defense-equipment]",
		stack_size = 50,
		default_request_amount = 10
	},
		{
		type = "item",
		name = "personal-rocket-defence",
		icon = "__custom_power_armor__/graphics/icons/personal_rocket_defence.png",
		icon_size = 32,
		placed_as_equipment_result = "personal-rocket-defence",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "d[active-defense]-b[personal-laser-minigun]",
		stack_size = 50,
		default_request_amount = 10
	}
}
)