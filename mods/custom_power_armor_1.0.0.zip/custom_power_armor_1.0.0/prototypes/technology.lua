data:extend(
{
	{
		type = "technology",
		name = "mk3-destroyer-power-armor",
		icon = "__custom_power_armor__/graphics/technology/mk3_destroyer.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "mk3-destroyer-power-armor"
         },
      },
	  prerequisites = {"power-armor-2", "productivity-module-3", "effectivity-module-3", "speed-module-3", "military-4"},
		unit =
		{
			count = 500,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-c",
	},
	{
		type = "technology",
		name = "mk4-exterminator-power-armor",
		icon = "__custom_power_armor__/graphics/technology/mk4_exterminator.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "mk4-exterminator-power-armor"
         },
      },
	  prerequisites = {"mk3-destroyer-power-armor"},
		unit =
		{
			count = 1000,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-d",
	},
	{
		type = "technology",
		name = "mk5-annihilator-power-armor",
		icon = "__custom_power_armor__/graphics/technology/mk5_annihilator.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "mk5-annihilator-power-armor"
         },
      },
	  prerequisites = {"mk4-exterminator-power-armor"},
		unit =
		{
			count = 2000,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-e",
	},	
	{
		type = "technology",
		name = "shield-mk3",
		icon = "__custom_power_armor__/graphics/technology/shield_mk3.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "shield-mk3"
         },
      },
	  prerequisites = {"mk4-exterminator-power-armor", "energy-shield-mk2-equipment"},
		unit =
		{
			count = 750,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-f",
	},	
	{
		type = "technology",
		name = "shield-mk4",
		icon = "__custom_power_armor__/graphics/technology/shield_mk4.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "shield-mk4"
         },
      },
	  prerequisites = {"mk5-annihilator-power-armor", "shield-mk3"},
		unit =
		{
			count = 1500,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-g",
	},	
	{
		type = "technology",
		name = "overhcarged-fusion-reactor",
		icon = "__custom_power_armor__/graphics/technology/overhcarged_fusion_reactor.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "overhcarged-fusion-reactor"
         },
      },
	  prerequisites = {"mk4-exterminator-power-armor", "fusion-reactor-equipment"},
		unit =
		{
			count = 1500,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-h",
	},	
	{
		type = "technology",
		name = "energy-cell",
		icon = "__custom_power_armor__/graphics/technology/energy_cell.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "energy-cell"
         },
      },
	  prerequisites = {"mk4-exterminator-power-armor", "battery-mk2-equipment"},
		unit =
		{
			count = 1000,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-i",
	},	
	{
		type = "technology",
		name = "mk2-heavy-fast-exoskeleton",
		icon = "__custom_power_armor__/graphics/technology/mk2_heavy_fast_exoskeleton.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "mk2-heavy-exoskeleton"
         },
         {
            type = "unlock-recipe",
            recipe = "mk2-fast-exoskeleton"
         },
      },
	  prerequisites = {"mk4-exterminator-power-armor", "exoskeleton-equipment"},
		unit =
		{
			count = 1250,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-j",
	},
	{
		type = "technology",
		name = "personal-laser-minigun",
		icon = "__custom_power_armor__/graphics/technology/personal_laser_minigun.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "personal-laser-minigun"
         },
      },
	  prerequisites = {"mk5-annihilator-power-armor", "personal-laser-defense-equipment"},
		unit =
		{
			count = 2000,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-k",
	},
	{
		type = "technology",
		name = "personal-rocket-defence",
		icon = "__custom_power_armor__/graphics/technology/personal_rocket_defence.png",
		icon_size = 128,
      effects = {
         {
            type = "unlock-recipe",
            recipe = "personal-rocket-defence"
         },
      },
	  prerequisites = {"mk5-annihilator-power-armor", "personal-laser-minigun"},
		unit =
		{
			count = 2500,
         ingredients = {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"military-science-pack", 1},
			{"production-science-pack", 1},
            {"high-tech-science-pack", 1}
         },
         time = 30
		},
		order = "g-c-l",
	},
}
)