data:extend(
{
	{
		type = "recipe",
		name = "mk3-destroyer-power-armor",
		enabled = "false",
		ingredients =
		{
			{"speed-module-3", 10},
		    {"effectivity-module-3", 20},
			{"electric-engine-unit", 32},
			{"processing-unit", 300},
			{"steel-plate", 100},
		},
		result = "mk3-destroyer-power-armor",
		--category = "crafting",
		energy_required = 30,
	},
	{
		type = "recipe",
		name = "mk4-exterminator-power-armor",
		enabled = "false",
		ingredients =
		{
			{"speed-module-3", 20},
		    {"effectivity-module-3", 40},
			{"electric-engine-unit", 64},
			{"processing-unit", 200},
			{"steel-plate", 200},
		},
		result = "mk4-exterminator-power-armor",
		--category = "crafting",
		energy_required = 35,
	},
	{
		type = "recipe",
		name = "mk5-annihilator-power-armor",
		enabled = "false",
		ingredients =
		{
			{"speed-module-3", 30},
		    {"effectivity-module-3", 60},
			{"electric-engine-unit", 128},
			{"processing-unit", 100},
			{"steel-plate", 300},
		},
		result = "mk5-annihilator-power-armor",
		--category = "crafting",
		energy_required = 40,
	},
	{
		type = "recipe",
		name = "shield-mk3",
		enabled = "false",
		ingredients =
		{
		    {"energy-shield-mk2-equipment", 5},
			{"processing-unit", 50},
		},
		result = "shield-mk3",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "shield-mk4",
		enabled = "false",
		ingredients =
		{
		    {"shield-mk3", 5},
			{"processing-unit", 50},
		},
		result = "shield-mk4",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "overhcarged-fusion-reactor",
		enabled = "false",
		ingredients =
		{
			{"fusion-reactor-equipment", 1},
			{"speed-module-3", 5},
		},
		result = "overhcarged-fusion-reactor",
		----category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "energy-cell",
		enabled = "false",
		ingredients =
		{
			{"fusion-reactor-equipment", 1},
			{"battery-mk2-equipment", 1},
			{"effectivity-module-3", 1},
		},
		result = "energy-cell",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "mk2-heavy-exoskeleton",
		enabled = "false",
		ingredients =
		{
			{"exoskeleton-equipment", 1},
			{"electric-engine-unit", 30},
			{"effectivity-module-3", 5},
			{"steel-chest", 2},
		},
		result = "mk2-heavy-exoskeleton",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "mk2-fast-exoskeleton",
		enabled = "false",
		ingredients =
		{
			{"exoskeleton-equipment", 1},
			{"electric-engine-unit", 30},
			{"speed-module-3", 5},
		},
		result = "mk2-fast-exoskeleton",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "personal-laser-minigun",
		enabled = "false",
		ingredients =
		{
			{"personal-laser-defense-equipment", 3},
			{"electric-engine-unit", 5},
			{"speed-module-3", 1},
			{"effectivity-module-3", 3},
		},
		result = "personal-laser-minigun",
		--category = "crafting",
		energy_required = 10,
	},
	{
		type = "recipe",
		name = "personal-rocket-defence",
		enabled = "false",
		ingredients =
		{
			{"rocket-launcher", 9},
			{"rocket", 200},			
			{"electric-engine-unit", 10},
			{"speed-module-3", 5},
			{"effectivity-module-3", 3},
			{"processing-unit", 50},
		},
		result = "personal-rocket-defence",
		--category = "crafting",
		energy_required = 10,
	},
}
)