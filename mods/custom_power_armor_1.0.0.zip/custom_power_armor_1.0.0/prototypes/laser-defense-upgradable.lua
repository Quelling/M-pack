if settings.startup["custom-pld-upgrades"].value then
	for key,pld in pairs(data.raw["active-defense-equipment"]) do
		if pld.automatic==true and pld.attack_parameters.ammo_type.category~="laser" then
			pld.attack_parameters.ammo_type.category="laser-turret"
		end
	end
end