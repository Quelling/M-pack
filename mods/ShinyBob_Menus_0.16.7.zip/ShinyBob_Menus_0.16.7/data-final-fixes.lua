ShinyBob_path = "__ShinyBob_Menus__"


require('prototypes/functions/shinyfunc')

require('prototypes/all_menus')
require('prototypes/all_icons')



