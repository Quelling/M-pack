require("prototypes.dependencies");
require("prototypes.tint");
require("prototypes.item");
require("prototypes.entity");
require("prototypes.recipe");
require("prototypes.technology");
