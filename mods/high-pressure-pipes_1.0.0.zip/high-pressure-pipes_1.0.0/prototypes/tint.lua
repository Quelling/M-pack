highPressureTint = {r = 0.6, g = 1, b = 0.8, a = 1};
