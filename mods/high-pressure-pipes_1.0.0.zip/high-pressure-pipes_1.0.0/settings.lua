data:extend(
{
	{
		type = "int-setting",
        name = "high-pressure-multiplier",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 5
	},
	{
		type = "int-setting",
        name = "high-pressure-pump-multiplier",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 1
	},
}
);