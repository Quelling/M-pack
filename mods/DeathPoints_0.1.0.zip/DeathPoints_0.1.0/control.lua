script.on_event({defines.events.on_player_died},
    function (e)
        local player = game.players[e.player_index]
        local time = (game.surfaces[1].daytime * 24 + 12) % 24
	    local h = math.floor(time)
        local m = math.floor((time - h) * 60)
        player.force.add_chart_tag(player.surface, {
            position = player.position,
            text = "[DeathPoint]: " .. player.name .. " died at " .. string.format("%02d:%02d", h, m)
        })
    end
)