
-- completely remove blood effects

data.raw['explosion']['blood-explosion-small'].created_effect = nil
data.raw['explosion']['blood-explosion-big'].created_effect = nil
data.raw['explosion']['blood-explosion-huge'].created_effect = nil
