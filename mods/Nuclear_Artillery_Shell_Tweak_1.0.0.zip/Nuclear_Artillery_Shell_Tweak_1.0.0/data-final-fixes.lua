
-- nuclear artillery shell
local nuclear_artillery_projectile = util.table.deepcopy(data.raw["artillery-projectile"]["artillery-projectile"])
nuclear_artillery_projectile.name = "artillery-projectile-nuclear"
table.insert(nuclear_artillery_projectile.action.action_delivery.target_effects,
	{
		type = "nested-result",
		action =
		{
			type = "area",
			target_entities = false,
			repeat_count = 2000,
			radius = 35,
			action_delivery =
			{
				type = "projectile",
				projectile = "atomic-bomb-wave",
				starting_speed = 0.5
			}
		}

	}
)

data:extend(
	{
		nuclear_artillery_projectile,
		{
			type = "ammo",
			name = "artillery-shell-nuclear",
			icon = "__Nuclear_Artillery_Shell__/graphics/artillery-shell-nuclear.png",
			icon_size = 32,
			flags = {"goes-to-main-inventory"},
			ammo_type =
			{
				category = "artillery-shell",
				target_type = "position",
				action =
				{
					type = "direct",
					action_delivery =
					{
						type = "artillery",
						projectile = "artillery-projectile-nuclear",
						starting_speed = 1,
						direction_deviation = 0,
						range_deviation = 0,
						source_effects =
						{
							type = "create-explosion",
							entity_name = "artillery-cannon-muzzle-flash"
						}
					}
				}
			},
			subgroup = "ammo",
			order = "d[explosive-cannon-shell]-d[artillery]2",
			stack_size = 1
		},
		{
			type = "recipe",
			name = "artillery-shell-nuclear",
			enabled = false,
			energy_required = 50,
			ingredients =
			{
				{"artillery-shell", 1},
				{"uranium-235", 30}
			},
			result = "artillery-shell-nuclear"
		},
		{
			type = "technology",
			name = "artillery-shell-nuclear",
			icon_size = 128,
			icon = "__base__/graphics/technology/atomic-bomb.png",
			effects =
			{
				{
					type = "unlock-recipe",
					recipe = "artillery-shell-nuclear"
				},
			},
			prerequisites = {"atomic-bomb", "artillery"},
			unit =
			{
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1},
					{"science-pack-3", 1},
					{"military-science-pack", 1},
					{"high-tech-science-pack", 1},
				},
				time = 15,
				count = 1000
			},
			order = "d-e-f"
		}
	}
)
