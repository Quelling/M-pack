data:extend({
  {
	type = "item",
	name = "artifact-loot-chest",
	icon = "__LootChestPlus__/graphics/icon-loot-chest.png",
	icon_size = 32,
	flags = {"goes-to-quickbar"},
	subgroup = "storage",
	place_result = "artifact-loot-chest",
	order = "a[items]-d[artifact-loot-chest]",
	stack_size = 1
  }
})