data:extend(
{
  {
    type = "recipe",
    name = "artifact-loot-chest",
    enabled = false,
	ingredients =
	{
	  {"steel-plate", 20},
	  {"electronic-circuit", 25},
	},	
    result = "artifact-loot-chest",
	requester_paste_multiplier = 1
  }
})

--Unlock the Loot Chest when you research Military-2
table.insert(data.raw["technology"]["military-2"].effects,{type="unlock-recipe",recipe="artifact-loot-chest"})