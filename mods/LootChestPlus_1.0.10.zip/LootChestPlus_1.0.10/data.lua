require("prototypes.item")
require("prototypes.entity")
require("prototypes.recipe")