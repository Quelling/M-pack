data:extend(
{
  {
    type = "int-setting",
    name = "texugo-wind-power",
    setting_type = "startup",
    default_value = 1,
    maximum_value = 10,
    minimum_value = 0,
  }
 }
)