--------------------------------------wind----------------
---   https://www.geogebra.org/m/GDgua6HK
---    y = sin(3x/2)/3+sin(2x/2+2)/3+sin(3x/2-3)/2-sin(4x/2+1)/3-sin(5x/2+3)/4-sin(6x/2+4)/2+sin(x/3)+2.5


require "util"

script.on_event(defines.events.on_tick, function(event)

	if global.wind == nil then
	global.wind = 0
	end
	
	if global.wind_turbine == nil then
	global.wind_turbine = {}
	end
	
	if (game.tick % 6000) == 0 then
	if global.wind >= 1800 then
	global.wind = 0
	--game.print("reset 100s")
	end
	end

  	if (game.tick % 60) == 0 then
	global.wind = global.wind + 0.02
	local x = global.wind
	local y = (math.sin(3*x/2)/3)+(math.sin(2*x/2+2)/3)+(math.sin(3*x/2-3)/2)-(math.sin(4*x/2+1)/3)-(math.sin(5*x/2+3)/4)-(math.sin(6*x/2+4)/2)+math.sin(x/3)+5
	
	
	for key,wind_turbine in pairs(global.wind_turbine) do
            if wind_turbine.valid then
                wind_turbine.fluidbox [1]= {name="steam", amount=200, temperature=14*y}
            else
                table.remove(global.wind_turbine, key)
            end
		end
	end
end)
-------------------------------------------------------------------------------------------------------------------
------------------------------------------hiden poles---------------------------------------------

   local function on_passive_wood( entity )
   local twt_eletric_pole = entity.surface.create_entity{name="twt-electric-pole", position=entity.position, force=entity.force}
   twt_eletric_pole.minable = false
   twt_eletric_pole.destructible = false
   end

   local function on_passive_steel( entity )
   local twt_eletric_pole2 = entity.surface.create_entity{name="twt-electric-pole2", position=entity.position, force=entity.force}
   twt_eletric_pole2.minable = false
   twt_eletric_pole2.destructible = false
   end

   local function on_passive_huge( entity )
   local twt_eletric_pole3 = entity.surface.create_entity{name="twt-electric-pole3", position=entity.position, force=entity.force}
   twt_eletric_pole3.minable = false
   twt_eletric_pole3.destructible = false
   end
-------------------------------------------------------------------------------------------------------------------
function on_creation(event)
    if event.created_entity.name == "texugo-wind-turbine" or
	event.created_entity.name == "texugo-wind-turbine2" or 
	event.created_entity.name == "texugo-wind-turbine3" then
        local wind_turbine = event.created_entity
        table.insert(global.wind_turbine, wind_turbine)
    end
	if event.created_entity.name == "texugo-wind-turbine" then on_passive_wood( event.created_entity ) end
	if event.created_entity.name == "texugo-wind-turbine2" then on_passive_steel( event.created_entity ) end
	if event.created_entity.name == "texugo-wind-turbine3" then on_passive_huge( event.created_entity ) end
end

function on_remove(event)
--------------------------------------------------------------------------wind1
	if event.entity.name == "texugo-wind-turbine" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "twt-electric-pole"}) do
    entity.destroy()    
    end
	--end 
	elseif event.entity.name == "twt-electric-pole" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "texugo-wind-turbine"}) do
    entity.damage(6666, "neutral")    
    end
	--end 
--------------------------------------------------------------------------wind2

	elseif event.entity.name == "texugo-wind-turbine2" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "twt-electric-pole2"}) do
    entity.destroy()    
    end
	--end
	elseif event.entity.name == "twt-electric-pole2" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "texugo-wind-turbine2"}) do
    entity.damage(6666, "neutral")    
    end
	--end
--------------------------------------------------------------------------wind3
	elseif event.entity.name == "texugo-wind-turbine3" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "twt-electric-pole3"}) do
    entity.destroy()    
    end
	--end
	elseif event.entity.name == "twt-electric-pole3" then
    center = event.entity.position
    for _, entity in pairs(event.entity.surface.find_entities_filtered{
    area = {{center.x-0.5, center.y-0.5}, {center.x+0.5, center.y+0.5}},
    name = "texugo-wind-turbine3"}) do
    entity.damage(6666, "neutral")    
    end
	end
	
	
	
end



script.on_event(defines.events.on_built_entity, on_creation)
script.on_event(defines.events.on_robot_built_entity, on_creation)
script.on_event(defines.events.on_entity_died, on_remove)
script.on_event(defines.events.on_robot_mined_entity, on_remove)
script.on_event(defines.events.on_player_mined_entity, on_remove)