data:extend({
  {
    type = "recipe",
    name = "nuclear-locomotive",
    enabled = false,
    ingredients =
    {
      {"electric-engine-unit", 20},
      {"steel-plate", 30},
      {"advanced-circuit", 10},
      {"copper-plate", 10}
    },
    result = "nuclear-locomotive"
  }
})