data:extend({
  {
    type = "technology",
    name = "nuclear-locomotives",
    icon = "__Nuclear Locomotives__/graphics/technology/nuclear-locomotive.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "nuclear-locomotive"
      }
    },
    prerequisites = {"railway", "nuclear-power"},
    unit =
    {
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30,
      count = 100
    },
    order = "e-p-b-c-a",
  }
})