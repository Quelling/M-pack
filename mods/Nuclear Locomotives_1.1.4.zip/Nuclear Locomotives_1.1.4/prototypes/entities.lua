nuke_loco = util.table.deepcopy(data.raw["locomotive"]["locomotive"])
nuke_loco.name = "nuclear-locomotive"
nuke_loco.icon = "__Nuclear Locomotives__/graphics/icons/nuclear-locomotive.png"
nuke_loco.minable.result = "nuclear-locomotive"
nuke_loco.burner.fuel_category = "nuclear"
nuke_loco.burner.effectivity = 1
nuke_loco.burner.fuel_inventory_size = 1
nuke_loco.burner.burnt_inventory_size = 1
nuke_loco.burner.smoke = nil
nuke_loco.weight = 4000 -- 2000
nuke_loco.max_speed = 1.38 -- 1.2 * 1.15
nuke_loco.max_power = "1.2MW" -- "600kW"
nuke_loco.reversing_power_modifier = 1
nuke_loco.braking_force = 20 -- 10
nuke_loco.color = { r = 0, g = 0.75, b = 0.5, a = 0.5 }
nuke_loco.working_sound.sound.filename = "__base__/sound/idle1.ogg"
nuke_loco.working_sound.sound.volume = 1.5
nuke_loco.working_sound.idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 1.5 }

data:extend({
  nuke_loco
})