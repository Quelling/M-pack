data:extend({
  {
    type = "item-with-entity-data",
    name = "nuclear-locomotive",
    icon = "__Nuclear Locomotives__/graphics/icons/nuclear-locomotive.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-fz[diesel-locomotive]",
    place_result = "nuclear-locomotive",
    stack_size = 5
  }
})