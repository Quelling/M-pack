-- Reload recipes and technologies
for i, player in ipairs(game.players) do
  player.force.reset_recipes()
  player.force.reset_technologies()
end

for index, force in pairs(game.forces) do
  -- Generate technology and recipe tables
  local tech = force.technologies
  local recipes = force.recipes

  -- Unlock researched recipes
  if tech["nuclear-locomotives"] and tech["nuclear-locomotives"].researched then
    if recipes["nuclear-locomotive"] then
      recipes["nuclear-locomotive"].enabled = true
    end
  end
end