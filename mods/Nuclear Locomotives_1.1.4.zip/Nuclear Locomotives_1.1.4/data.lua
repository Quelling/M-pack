require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technology")

if data.raw.item["uranium-fuel-cell"] then
  data.raw.item["uranium-fuel-cell"].fuel_acceleration_multiplier = 2.5
end
if data.raw.item["breeder-fuel-cell"] then
  data.raw.item["breeder-fuel-cell"].fuel_acceleration_multiplier = 2.5
end